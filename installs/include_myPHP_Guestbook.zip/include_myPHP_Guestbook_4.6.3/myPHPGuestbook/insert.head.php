<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

// fuer Neuinstallationen ab dem 02.01.2016 bzw. ab V.4.5.6 die Zeile 26 unverändert auskommentiert lassen oder ganz löschen,
// (nur) fuer aeltere Installationen die Auskommentierung am Anfang der Zeile 26 (die beiden ersten slashes "//") entfernen!

//	require_once("".$gbook_folder."/includes/url.inc.php"); // Zeile 26

	require_once("".$gbook_folder."/includes/functions.inc.php");

	//Ausschluss dauerhaft gesperrter IPs gem. Tabelle mit Umleitung zum Gästebuch
	$ip_sperre = $gbook->query("SELECT `ip` FROM `".$table."_forbidden_ip` WHERE `ip` = '".$_SERVER['REMOTE_ADDR']."'");

	if ($ip_sperre != ""){
		$sperre = $ip_sperre->num_rows;
	}

	$ip_freigabe 	= time()-(86400*7); 		// Zeit, nach der eine gesperrte IP in der DB gelöscht wird, hier 7 Tage
	$gbook->query("DELETE FROM `".$table."_forbidden_ip` WHERE `www_time` <= ".$ip_freigabe." AND `no_del` != '1'");

	$bad = $good = "";
	$mark_name = $mark_email = $mark_hp = $mark_icq = $mark_town = $mark_country = $mark_subject = $mark_text = "";
	$count_entries = $origin = $slash = $output = $user_info = $maxlenght = $js_limit = $tarea_count = $text_quote = $hidden_email = $quote_id = $new_marker = $email_quote = $free_email = "";
	$div_c = $div_t = $div_h = $div_i = "dsR3";
	$short_town = "30";
	$rows = 13;
	$allowed_characters = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿß';
	$startzeit = time();

	isset($_POST['betreff']) ? ($_POST['betreff'] = $_POST['betreff']) : ($_POST['betreff'] = "");
	isset($_POST['email']) ? ($_POST['email'] = $_POST['email']) : ($_POST['email'] = "");
	isset($_POST['homepage']) ? ($_POST['homepage'] = $_POST['homepage']) : ($_POST['homepage'] = "");
	isset($_POST['icq']) ?  ($_POST['icq'] = $_POST['icq']) : ($_POST['icq'] = "");
	isset($_POST['town']) ? ($_POST['town'] = $_POST['town']) : ($_POST['town'] = "");
	isset($_POST['country']) ? ($_POST['country'] = $_POST['country']) : ($_POST['country'] = "");
	isset($_POST['email_quote']) ? ($_POST['email_quote'] = $_POST['email_quote']) : ($_POST['email_quote'] = "");
	isset($_POST['quote_id']) ?  ($_POST['quote_id'] = $_POST['quote_id']) : ($_POST['quote_id'] = "");
	isset($_POST['quote_marker']) ? ($_POST['quote_marker'] = $_POST['quote_marker']) : ($_POST['quote_marker'] = "");
	isset($_POST['free_email']) ? ($_POST['free_email'] = $_POST['free_email']) : ($_POST['free_email'] = "");

	(isset($_POST['comment_info']) && ($_POST['comment_info']) == "1") ? ($_POST['comment_info'] = $_POST['comment_info']) : ($_POST['comment_info'] = "0");

	isset($_SERVER['HTTP_REFERER']) ? $woher = htmlspecialchars($_SERVER['HTTP_REFERER']) : $woher = "";
	isset($_SERVER['SERVER_NAME']) ? $hostname = $_SERVER['SERVER_NAME'] : $hostname = "";

	timezoneGBook();

	require_once("".$gbook_folder."/includes/lang.inc02.php");

	$placeholder = $fmsg[337];

	$sql_properties = $gbook->query("SELECT `admin_email`, `antiflood_ban`, `bbcode`, `check_email`, `check_homepage`, `check_icq`, `deactivate_html`, `default_style`, `default_template`, `entry_length_limit`, `entry_length_maximum`, `entry_length_minimum`, `guestbook_status`, `no_spam_entries`, `spam_marker`, 
											`no_spam_links`, `max_links`, `guestbook_title`, `images_in_entries`, `max_word_length`, `notification_entries`, `release_entries`, `show_ip`, `smilies`, `thanks_email`, `statistic`, `statistic_ban`, `quote_func`, `check_subject`, `check_town`, `check_country`, `check_free`, `button_link` 
									 FROM `".$table."_properties`");
	$properties    = $sql_properties->fetch_assoc();
    $default_style = $properties['default_style'];

	header("X-Robots-Tag: noindex");
	header("content-type: text/html; charset=\"".$encoding."\"" );
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Pragma: no-cache");

	if (isset($_GET['action']))	{
		$_GET['action'] = strip_tags(trim($_GET['action']));
		$_GET['action'] = $gbook->real_escape_string($_GET['action']);

		if (!preg_match("/^[_\a-z]*$/is", $_GET['action']))	{
			$_GET['action'] = "quote";
		}
	}
	else {
		$_GET['action'] = "quote";
	}
		
	if (isset($_GET['id']))	{
		$_GET['id'] = strip_tags(trim($_GET['id']));
		$_GET['id'] = $gbook->real_escape_string($_GET['id']);
	}

	if ($properties['quote_func'] && $_GET['action'] == "quote"){
		if (isset($_GET['id']) && is_numeric($_GET['id']) && !empty($_GET['id']) && (intval($_GET['id']) == $_GET['id'])) {
		    $quote_entries = $gbook->query("SELECT `email`, `date`, `name`, `text`, `time`, `marker`  FROM  `".$table."_entries`  WHERE  `id` = '".$_REQUEST['id']."'");
			$entrie_quote  = $quote_entries->fetch_assoc();
					
			$email_quote = $entrie_quote['email'];
			$email_quote = stripslashes(htmlentities(strip_tags($email_quote), ENT_QUOTES, "UTF-8"));
			$email_quote = noSpam02($email_quote);
						
			$date_quote = $entrie_quote['date'];
			$date_quote = stripslashes(htmlentities(strip_tags($date_quote), ENT_QUOTES, "UTF-8"));
								
			$name_quote = $entrie_quote['name'];
			$name_quote = stripslashes(htmlentities(strip_tags($name_quote), ENT_QUOTES, "UTF-8"));
								
			$text_quote = $entrie_quote['text'];
			$text_quote = preg_replace("/\[img\](.*?)\[\/img\]/si", "", $text_quote);
			$text_quote = stripslashes(htmlentities(strip_tags(trim($text_quote)), ENT_QUOTES, "UTF-8"));

			$time_quote = $entrie_quote['time'];
			$time_quote = stripslashes(htmlentities(strip_tags($time_quote), ENT_QUOTES, "UTF-8"));
					
			$rows = 20;

			if (($entrie_quote['marker'] == 1 || $entrie_quote['marker'] == 2) && $email_quote != "") {
				$free_email = 1;
				$quote_id	= $_REQUEST['id'];
				
				if ($entrie_quote['marker'] == 1) {
					$new_marker = 3;
				}
				elseif ($entrie_quote['marker'] == 2) {
					$new_marker = 0;
				}
				else {
					$new_marker = $entrie_quote['marker'];
				}
			}
			else {
				$email_quote = "";
			}
		}
		else {
			$_GET['id'] = "";
		}
	}

	if ($properties['release_entries'] == 1) {
		$user_info = "<p class=\"text-center\">(".$fmsg[351].")</p>";
	}

	if ($properties['check_town'] == 0 && $properties['check_country'] == 1) {
		$div_t = "town";
	}
	elseif ($properties['check_town'] == 1 && $properties['check_country'] == 0) {
		$div_c = "country";
	}
	elseif ($properties['check_town'] == 0 && $properties['check_country'] == 0) {
		$div_c = "country-plus";
		$div_t = "town-plus";
	}

	if ($properties['check_homepage'] == 0 && $properties['check_icq'] == 1) {
		$div_h = "homepage";
	}
	elseif ($properties['check_homepage'] == 1 && $properties['check_icq'] == 0) {
		$div_i = "icq";
	}
	elseif ($properties['check_homepage'] == 0 && $properties['check_icq'] == 0) {
		$div_h = "homepage-plus";
		$div_i = "icq-plus";
	}

    if ($properties['statistic']) {
        require_once("".$gbook_folder."/includes/stats.inc.php");
	}

	if ($properties['check_email'] == 2 || $properties['check_email'] == 3) {
		$hidden_email = "<span class=\"size-12\">".$fmsg[125]."</span>";
	}

	$sql_template = $gbook->query("SELECT `bgcolor`, `bgimage`, `fontcolor`, `html`, `image_email`, `image_homepage`, `divalign`, `tablewidth`, `tdcolor`, `td2color` FROM `".$table."_template` WHERE `id` = '".$properties['default_template']."'");
    $template = $sql_template->fetch_assoc();

?>