<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    03.07.2016
*/

// fuer Neuinstallationen ab dem 02.01.2016 bzw. ab V.4.5.6 die Zeile 26 unverändert auskommentiert lassen oder ganz löschen,
// (nur) fuer aeltere Installationen die Auskommentierung am Anfang der Zeile 26 (die beiden ersten slashes "//") entfernen!

//	require_once("".$gbook_folder."/includes/url.inc.php");  // Zeile 26

	require_once("".$gbook_folder."/includes/functions.inc.php");

	$sql_properties = $gbook->query("SELECT `admin_email`,`bbcode`,`check_email`,`check_homepage`,`check_icq`,`deactivate_html`,`default_style`,`default_template`,`entries_per_site`,`guestbook_status`,`guestbook_title`,`images_in_entries`,`links_in_sitefunction`,`max_word_length`,`release_entries`,`show_ip`,`smilies`,`statistic`,`statistic_ban`,`quote_func`,`link_entry`,`check_town`,`check_country`,`button_link` FROM `".$table."_properties`");
	$properties    = $sql_properties->fetch_assoc();
	$default_style = $properties['default_style'];

	$bad 	= "";
	$good 	= "";
	$short_town = "30";
	$js_limit = "";

	$query_count_entries = $gbook->query("SELECT `id` FROM `".$table."_entries` WHERE `status` != '0'");
	$count_entries       = $query_count_entries->num_rows;

	require_once("".$gbook_folder."/includes/lang.inc02.php");

	($properties['link_entry'] == "") ? ($link_entry = $fmsg[13]) : ($link_entry = $properties['link_entry']);

	if ($properties['button_link'] == "0") {
		$html_entry_01 = "<p><strong><a class=\"navi-page\" href=\"".$url02."gbook_insert.php#anchor-gbooktop02";
		$html_entry_02 = "\" title=\"".$link_entry."\">".$link_entry."</a></strong></p>";
	}
	elseif ($properties['button_link'] == "1") {
		$html_entry_01 = "<p class=\"button-marg\"><strong><a class=\"button-gb insert-button\" href=\"".$url02."gbook_insert.php#anchor-gbooktop02";
		$html_entry_02 = "\" title=\"".$link_entry."\">".$link_entry."</a></strong></p>";
	}
	else {
		$html_entry_01 = "<br />";
		$html_entry_02 = "";
	}

	header("content-type: text/html; charset=\"".$encoding."\"" );
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Pragma: no-cache");

	if (isset($_GET['action']))
		{
			$_GET['action'] = strip_tags(trim($_GET['action']));
			$_GET['action'] = $gbook->real_escape_string($_GET['action']);
		}
	else
		{
			$_GET['action'] = "";
		}

	$sql_template = $gbook->query("SELECT `bgcolor`, `bgimage`, `fontcolor`, `html`, `image_email`, `image_homepage`, `divalign`, `tablewidth`, `tdcolor`, `td2color` FROM `".$table."_template` WHERE `id` = '".$properties['default_template']."'");
	$template = $sql_template->fetch_assoc();

	if ($properties['statistic']){
		require_once("".$gbook_folder."/includes/stats.inc.php");
	}

	if (isset($_GET['page']))
		{
			if (!is_numeric($_GET['page']) OR empty($_GET['page']))
				{
					$page = 1;
				}
			else
				{
					$page = $_GET['page'];
				}
		}
	else
		{
			$page = 1;
		}

	$page               = $gbook->real_escape_string($page);
    $pages_total        = ceil($count_entries/$properties['entries_per_site']) ;
    $page_start         = floor($page - $properties['links_in_sitefunction']/2) ;
    $page_start         = $page_start <= 0 ?  1 : $page_start ;
    $page_end           = ($page_start + $properties['links_in_sitefunction']-1) ;
    $page_end           = $page_end >= $pages_total ?  $pages_total : $page_end ;
    $page_max           = $page*$properties['entries_per_site'];
    $max_minus_per_page = $page_max-$properties['entries_per_site'];
    $page_entry_start   = $count_entries-$max_minus_per_page+1;

?>