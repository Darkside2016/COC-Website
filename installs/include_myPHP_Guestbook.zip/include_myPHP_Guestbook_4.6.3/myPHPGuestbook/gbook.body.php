<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    03.07.2016
*/

	switch($_GET['action'])
		{
		    case "deactivate_entry";
	        require_once("".$gbook_folder."/admin/deactivate_entry.php");
	        break;

		    case "activate_entry";
	        require_once("".$gbook_folder."/admin/activate_entry.php");
	        break;
		}
	
	if ($properties['guestbook_status'])
	    {
	      	if ($count_entries > 1)
		      	{
					echo"<div class=\"myphpgb gb-align text-center lineheight\">";
						
					if ($properties['default_template'] < 4)
						{
							echo"
								<p><br />".$fmsg[12]."</p>";
						}
							
					echo"
						".$html_entry_01."";
		    	}
    		else
		    	{
		    		echo"<div class=\"myphpgb gb-align text-center lineheight\">";
		    		
		      		if ($count_entries > 0)
		      			{
		      				if ($properties['default_template'] < 4) {
								echo"
									<p><br />".$fmsg[227]."</p>";
							}
							
		    			}
	    			else
	    				{   
							echo"
								<p><br /><strong>".$fmsg[226]."</strong></p>";
	    				}
	    			
	    			echo"
	    				".$html_entry_01."";
	    		}

        if (isset($get_lang)) {
			echo "?lang=".$_GET['lang']."";
        }

		echo "".$html_entry_02."
			<span class=\"size-13\">";

        if ($page > 1) {
            $page_minus = $page-1;
			echo "<a href=\"".$url02."gbook.php?page=".$page_minus."#anchor-gbooktop";


            if (isset($get_lang)) {
				echo "&lang=".$_GET['lang']."";
            }

			echo "\"><img src=\"".$url."images/links.gif\" alt=\"".$fmsg[4]."\" /></a>&nbsp;&nbsp;&nbsp;";
        }

        if ($page_start > 1) {
			echo "<a class=\"navi-page\" href=\"".$url02."gbook.php?page=1#anchor-gbooktop";

            if (isset($get_lang)) {
				echo "&lang=".$_GET['lang']."";
            }
			echo "\">1</a> ...";
        }

        for ($i = $page_start; $i <= $page_end ;$i++) {
            if ($i == $page) {
				echo "&nbsp;<span class=\"this-page\">[".$i."]</span>&nbsp;&nbsp;";
            } else {
				echo "<a class=\"navi-page\" href=\"".$url02."gbook.php?page=".$i."#anchor-gbooktop";

                if (isset($get_lang)) {
					echo "&lang=".$_GET['lang']."";
                }
				echo "\">&nbsp;".$i."&nbsp;</a>&nbsp;&nbsp;";
            }
        }

        if ($page_end < $pages_total) {
			echo " ... <a class=\"navi-page\" href=\"".$url02."gbook.php?page=".$pages_total."#anchor-gbooktop";

            if (isset($get_lang)) {
				echo "&lang=".$_GET['lang']."";
            }

			echo "\">".$pages_total."</a>";
        }

        if ($page < $pages_total) {
            $page_plus = $page+1;
			echo "&nbsp;&nbsp;&nbsp;<a href=\"".$url02."gbook.php?page=".$page_plus."#anchor-gbooktop";

            if (isset($get_lang)) {
				echo "&lang=".$_GET['lang']."";
            }

			echo "\"><img src=\"".$url."images/rechts.gif\" alt=\"".$fmsg[14]."\" /></a>
				";
        }

		echo "</span></div>
			<div class=\"break\"><br /></div>";

        $sql_entries = $gbook->query("SELECT `comment`, `date`, `email`, `homepage`, `icq`, `id`, `ip`, `status`, `name`, `text`, `time`, `origin` FROM `".$table."_entries` WHERE `status` != '0' ORDER BY `id` DESC LIMIT ".(($page-1)*$properties['entries_per_site'] ).",".$properties['entries_per_site']."");
        
        while ($entries = $sql_entries->fetch_assoc()) {
            $page_entry_start  = $page_entry_start-1;
 	        $entries['number'] = $page_entry_start;
            
			$bad 	= array("(",")","{","}","@");
			$good 	= array("&#40;","&#41;","&#123;","&#125;","&#64;");

			$entries['name'] = nobadwords($entries['name']);
			$entries['name'] = htmlentities(strip_tags($entries['name']), ENT_QUOTES, "UTF-8");
			$entries['name'] = stripslashes($entries['name']);
			$entries['name'] = str_replace($bad, $good, $entries['name']);
            
			(($properties['check_town'] == 1) && ($properties['check_country'] == 1)) ? $origin = $entries['origin'] = "" : $origin = $entries['origin'];
			$origin = nobadwords($origin);
			$origin = htmlentities(strip_tags($origin), ENT_QUOTES, "UTF-8");
			$origin = stripslashes($origin);
			$origin = shortWords($origin, $short_town);

			($properties['check_email'] > 1) ? $email = $entries['email'] = "" : $email = $entries['email'];
			$email = strip_tags($email);
			$email = stripslashes($email);
			$email = noInjektion($email);
			$email = noSpam02($email);
		            
			($properties['check_homepage'] == 1) ? $homepage = $entries['homepage'] = "" : $homepage = $entries['homepage'];
			$homepage = stripslashes($homepage);
			$homepage = htmlentities(strip_tags($homepage), ENT_QUOTES, "UTF-8");
        
			($properties['check_icq'] == 1) ? $icq = $entries['icq'] = "" : $icq = $entries['icq'];
			$icq = stripslashes($icq);
			$icq = htmlentities(strip_tags($icq), ENT_QUOTES, "UTF-8");
        
			$entries['text'] = preg_replace('/(\r\n)(\\1{1,1})\\1*/sS', '$1$2', $entries['text']);
			$entries['text'] = nobadwords($entries['text']);
			$entries['text'] = shortWords($entries['text'], $properties['max_word_length']);

			if($properties['deactivate_html']){
				$entries['text']	= htmlentities($entries['text'], ENT_QUOTES, "UTF-8");
				$entries['comment'] = htmlentities($entries['comment'], ENT_QUOTES, "UTF-8");
			}

			$entries['text'] = nl2br($entries['text']);
			$entries['text'] = stripslashes($entries['text']);
		
	        if ($properties['quote_func']) {
				$entries['text'] = quote($entries['text']);
			}

			$entries['comment'] = nl2br($entries['comment']);
			$entries['comment'] = stripslashes($entries['comment']);
            
            if ($properties['bbcode']) {
                $entries['text']    = bbcode($entries['text']);
                $entries['comment'] = bbcode($entries['comment']);
				$entries['comment'] = pictures($entries['comment']);
                
                if ($properties['images_in_entries']) {
					if ($entries['status'] == 2){
						$entries['text'] = pictures($entries['text']);
					}
					else {
						$entries['text'] = preg_replace("/\[img\](.*?)\[\/img\]/si", "<p id=\"placeholder\"><br /><br />".$fmsg[318]."</p>", $entries['text']);
					}
                }
				else {
                	$entries['text'] = preg_replace("/\[img\](.*?)\[\/img\]/si", "", $entries['text']);
                }
            }
            else {
               	$entries['text'] = preg_replace("/\[img\](.*?)\[\/img\]/si", "", $entries['text']);
            	$entries['text'] = preg_replace("/\[b\](.*?)\[\/b\]/si", "<strong>\\1</strong>", $entries['text']);
            }

            if ($properties['smilies']) {
                $entries['text']    = smilies($entries['text']);
                $entries['comment'] = smilies($entries['comment']);
            }

		    $entries['text'] = preg_replace('/(.)(\\1{1,2})\\1*/sS', '$1$2', $entries['text']);
		    $entries['text'] = str_replace($bad, $good, $entries['text']);
		    
            $template_data = $template['html'];
            $template_data = str_replace("<\$date\$>", $entries['date'], $template_data);
            $template_data = str_replace("<\$id\$>", $entries['number'], $template_data);
            $template_data = str_replace("<\$name\$>", $entries['name'], $template_data);
            $template_data = str_replace("<\$text\$>", $entries['text'], $template_data);
            $template_data = str_replace("<\$time\$>", $entries['time'], $template_data);
            $template_data = str_replace("<\$nr\$>", "$amsg[84]", $template_data);
            $template_data = str_replace("<\$wh\$>", "$amsg[85]", $template_data);
            $template_data = str_replace("<\$done\$>", "$amsg[86]", $template_data);

            if ($entries['comment']) {
                $template_data = str_replace("<\$comment\$>", "
				<br /><br />
				<div class=\"comment\">
				<p class=\"heading\">".$fmsg[106].":</p>
				".$entries['comment']."
				</div>", $template_data);
            } else {
				$template_data = str_replace("<\$comment\$>", "", $template_data);
            }

			if ($origin != "") {
				$template_data = str_replace("<\$origin\$>", "".$origin."", $template_data);
				$template_data = str_replace("<\$from\$>", "$fmsg[349]", $template_data);
				$template_data = str_replace("<\$br\$>", "<br />", $template_data);
			}
			else {
				$template_data = str_replace("<\$origin\$>", "", $template_data);
				$template_data = str_replace("<\$from\$>", "", $template_data);
				$template_data = str_replace("<\$br\$>", "", $template_data);
			}

            if ($properties['show_ip']) {
				$template_data = str_replace("<\$ip\$>", "<div class=\"ip pad-bottom\">IP: ".$entries['ip']."</div>
				", $template_data);
            } else {
				$template_data = str_replace("<\$ip\$>", "", $template_data);
            }

			if ($email == "")
				{
	               	$template_data = str_replace("<\$email\$>", "", $template_data);
	               	$template_data = str_replace("<\$email_icon\$>", "", $template_data);
	            }
			else
				{
	               	$template_data = str_replace("<\$email\$>", "<a href=\"&#109;&#97;&#105;&#108;&#116;&#111;&#58;".$email."\" title=\"".$email."\">".$email."</a>", $template_data);
	               	$template_data = str_replace("<\$email_icon\$>", "<a href=\"&#109;&#97;&#105;&#108;&#116;&#111;&#58;".$email."\"><img class=\"ico\" title=\"".$email."\" src=\"".$url."images/icons/email/".$template['image_email']."\" width=\"16\" height=\"17\" alt=\"".$email."\" /></a>", $template_data);
	           	}
	
	        if ($homepage == "" OR $homepage == "http://")
				{
	               	$template_data = str_replace("<\$homepage\$>", "", $template_data);
	               	$template_data = str_replace("<\$homepage_icon\$>", "", $template_data);
	           	}
	        elseif (($homepage != "" && $homepage != "http://") && ($email != "" || ($icq != "" && $icq != 0)))
				{
	               	$template_data = str_replace("<\$homepage\$>", "<a href=\"".$homepage."\" title=\"".$homepage."\" rel=\"external\">".$homepage."</a>", $template_data);
	               	$template_data = str_replace("<\$homepage_icon\$>", "<a title=\"".$homepage."\" href=\"".$homepage."\" rel=\"external\"><img class=\"ico\" src=\"".$url."images/icons/homepage/".$template['image_homepage']."\" width=\"16\" height=\"16\" alt=\"".$homepage."\" /></a>", $template_data);
	           	}
			else
				{
	               	$template_data = str_replace("<\$homepage\$>", "<a href=\"".$homepage."\" title=\"".$homepage."\" rel=\"external\">".$homepage."</a>", $template_data);
	               	$template_data = str_replace("<\$homepage_icon\$>", "<a title=\"".$homepage."\" href=\"".$homepage."\" rel=\"external\"><img src=\"".$url."images/icons/homepage/".$template['image_homepage']."\" width=\"16\" height=\"16\" alt=\"".$homepage."\" /></a>", $template_data);
	           	}
	
            if ($icq == "" OR $icq == 0)
            	{
					$template_data = str_replace("<\$icq\$>", "", $template_data);
					$template_data = str_replace("<\$icq_icon\$>", "", $template_data);
	            }
	        elseif (($icq != "" && $icq != 0) && (($homepage != "" && $homepage != "http://") || $email != "" ))
				{
					$template_data = str_replace("<\$icq\$>", "<a href=\"http://www.icq.com/people/".$icq."&#38;lang=de\">".$icq."</a>", $template_data);
					$template_data = str_replace("<\$icq_icon\$>", "<a href=\"http://www.icq.com/people/".$icq."&#38;lang=de\" rel=\"external\"><img class=\"ico\" src=\"http://wwp.icq.com/scripts/online.dll?icq=".$icq."&amp;img=5\" alt=\"".$icq."\" /></a>", $template_data);
	           	}
	        else
	        	{
					$template_data = str_replace("<\$icq\$>", "<a href=\"http://www.icq.com/people/".$icq."&#38;lang=de\">".$icq."</a>", $template_data);
					$template_data = str_replace("<\$icq_icon\$>", "<a href=\"http://www.icq.com/people/".$icq."&#38;lang=de\" rel=\"external\"><img src=\"http://wwp.icq.com/scripts/online.dll?icq=".$icq."&amp;img=5\" alt=\"".$icq."\" /></a>", $template_data);
	            }

			if ($properties['quote_func'])
				{
					if ($properties['default_template'] < 9)
						{
							$template_data = str_replace("<\$quote_ico\$>", "<div class=\"quote\"><a href=\"".$url02."gbook_insert.php?action=quote&#38;id=".$entries['id']."#anchor-gbooktop02\" title=\"".$fmsg[321]."\"><img title=\"".$fmsg[321]."\" src=\"".$url."images/quote.png\" width=\"20\" height=\"20\" alt=\"".$fmsg[321]."\" /></a></div>", $template_data);
						}
					else
						{
							$template_data = str_replace("<\$quote_ico\$>", "<a href=\"".$url02."gbook_insert.php?action=quote&#38;id=".$entries['id']."#anchor-gbooktop02\" title=\"".$fmsg[322]."\">REPLY</a>", $template_data);
						}
				}
			else
				{
					$template_data = str_replace("<\$quote_ico\$>", "", $template_data);
				}

            echo "
				".$template_data."";
        }

		echo "
			<div class=\"myphpgb gb-align text-center lineheight\">
			<span class=\"size-13\">";

        if ($page > 1) {
            $page_minus = $page-1;
			echo "<a href=\"".$url02."gbook.php?page=".$page_minus."#anchor-gbooktop";


            if (isset($get_lang)) {
                echo "&lang=".$_GET['lang']."";
            }

            echo "\"><img src=\"".$url."images/links.gif\" alt=\"".$fmsg[4]."\" /></a>&nbsp;&nbsp;&nbsp;";
        }

        if ($page_start > 1) {
            echo "<a class=\"navi-page\" href=\"".$url02."gbook.php?page=1#anchor-gbooktop";

            if (isset($get_lang)) {
                echo "&lang=".$_GET['lang']."";
            }

            echo "\">1</a> ...";
        }

        for ($i = $page_start; $i <= $page_end ;$i++) {
            if ($i == $page) {
                echo "&nbsp;<span class=\"this-page\">[".$i."]</span>&nbsp;&nbsp;";
            } else {
                echo "<a class=\"navi-page\" href=\"".$url02."gbook.php?page=".$i."#anchor-gbooktop";

                if (isset($get_lang)) {
                    echo "&lang=".$_GET['lang']."";
                }

                echo "\">&nbsp;".$i."&nbsp;</a>&nbsp;&nbsp;";
            }
        }

        if ($page_end < $pages_total) {
            echo " ... <a class=\"navi-page\" href=\"".$url02."gbook.php?page=".$pages_total."#anchor-gbooktop";

            if (isset($get_lang)) {
                echo "&lang=".$_GET['lang']."";
            }

            echo "\">".$pages_total."</a>";
        }

        if ($page < $pages_total) {
            $page_plus = $page+1;
            echo "&nbsp;&nbsp;&nbsp;<a href=\"".$url02."gbook.php?page=".$page_plus."#anchor-gbooktop";

            if (isset($get_lang)) {
                echo "&lang=".$_GET['lang']."";
            }

            echo "\"><img src=\"".$url."images/rechts.gif\" alt=\"".$fmsg[14]."\" /></a>";
        }
    echo"</span>";
    
	echo"
		".$html_entry_01." ".$html_entry_02."";
	
	echo" 
		</div>
		<div class=\"break\"></div>
		";
    
    } else {
		echo "
			<div class=\"myphpgb gb-align\">
			<p class=\"text-center\"><br /><strong>".$emsg[17]."</strong></p>
			</div>
			<div class=\"break\"></div>
			";
    }

echo"<div class=\"myphpgb gb-align\">
		<p class=\"margtop-twenty\"><a href=\"https://www.php-guestbook.de\" title=\"Download myPHP Guestbook ".$version."\" rel=\"external\"><img class=\"aligncenter\" title=\"Download 'myPHP Guestbook ".$version."'\" src=\"".$url."images/myphpGuestbook.png\" width=\"110\" height=\"20\" alt=\"myPHP Guestbook ".$version."\" /></a></p>
	</div>";

?>