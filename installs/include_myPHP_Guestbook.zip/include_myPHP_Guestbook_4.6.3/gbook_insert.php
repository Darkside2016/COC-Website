<?php
	$gbook_folder = "myPHP_Guestbook";							// Ordner, in dem sich die Gaestebuchdateien befinden (hier: myPHP_Guestbook), anpassen!

	include_once ("".$gbook_folder."/insert.head.php");			//nicht ändern
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--[if IE 9]><html id=\"ie9\" dir=\"ltr\" lang=\"".$lang_short."\"><![endif]-->
<!--[if IE 8]><html id=\"ie8\" dir=\"ltr\" lang=\"".$lang_short."\"><![endif]-->
<!--[if IE 7]><html id=\"ie7\" dir=\"ltr\" lang=\"".$lang_short."\"><![endif]-->
<!--[if !(IE 7) | !(IE 8) | !(IE 9) ]><!-->
<html xml:lang="de" lang="de" xmlns="http://www.w3.org/1999/xhtml">
<!--<![endif]-->
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="viewport" content="width=device-width" />	<!-- Meta-Tag für mobile Endgeräte -->
	<title>myPHP Guestbook</title>
	<meta http-equiv="content-script-type" content="text/javascript" />
	<meta http-equiv="content-style-type" content="text/css" />
	<meta name="language" content="de" />
	<!-- ## Block 1 => in diese Zeile eigene externe oder interne CSS einfügen -->
	<?php
		include_once ("".$gbook_folder."/style.myphpgb.php");		//nicht ändern
	?>
	<!-- ## Block 2 => in diese Zeile oder am Ende der Seite eigenes Javascript einfügen -->
</head>
<body>
	<!-- ## Block 3 => hier eigener Inhalt möglich, danach bis zu Block 4 nichts mehr ändern -->	
	<div class="gbook-wrapper"><a id="anchor-gbooktop02" name="anchor-gbooktop02"></a>
	<p>&nbsp;</p>
	<?php
		echo "<div>";												//nicht ändern
		include_once ("".$gbook_folder."/insert.body.php");			//nicht ändern
	?>
	</div>
	<!-- ## Block 4 => ab hier wieder eigener Inhalt möglich -->
	<p>&nbsp;</p>
	<!-- hier ggf. eigenes Javascript einfügen, danach nichts mehr ändern -->
	<?php
		echo"".$js_limit."";										//nicht ändern
	?>
	
</body>
</html>