<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    07.03.2015
*/

    require_once("../includes/functions.inc.php");

    $count_entries = "";
	$error_msg = "";
    $sql_language = $gbook->query("SELECT language FROM ".$table."_properties");
    $language  = $sql_language->fetch_assoc();

    require_once("../lang/".$language['language'].".php");

    header("content-type: text/html; charset=\"".$encoding."\"" );
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Pragma: no-cache");
	header("Content-Type: text/html;charset=\"".$encoding."\"");
	header("X-Robots-Tag: noindex");

    echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
	<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"".$lang_short."\" lang=\"".$lang_short."\">
	<head>
	<meta http-equiv=\"content-type\" content=\"text/html;charset=".$encoding."\" />
	<link href=\"".$url."gbook.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
	<style type=\"text/css\">
	.text{font-size:13px;width:620px;margin-left:auto;margin-right:auto;}
	.td1{color:#000000;text-align:center;letter-spacing:1px;}
	.td2{color:#ffffff;text-align:center;letter-spacing:1px;}
	.entry{font-size:16px;line-height:1.5;text-shadow:3px 3px 4px #525252;text-align:center;}
	</style>
	<title>>Websichere Farben und Grautöne - myPHP Guestbook</title>
	<meta name=\"robots\" content=\"noindex, nofollow\" />
	</head>";
	
	echo'
		<body>
			<div class="text">
			<p>&nbsp;</p>
			<h1 class="entry">'.$amsg[114].'</h1>
			<h1 class="shadow text-center size-14">- '.$amsg[115].' -</h1>
			<p>&nbsp;</p>
				<table style="width:615px" class="center-table" border="0" cellpadding="0" cellspacing="3">
					<tr style="height:25px">
						<td style="width:100px;background-color:#ffffff" class="td1">#ffffff</td>
						<td style="width:100px;background-color:#ffffcc" class="td1">#ffffcc</td>
						<td style="width:100px;background-color:#ffff99" class="td1">#ffff99</td>
						<td style="width:100px;background-color:#ffff66" class="td1">#ffff66</td>
						<td style="width:100px;background-color:#ffff33" class="td1">#ffff33</td>
						<td style="width:100px;background-color:#ffff00" class="td1">#ffff00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#ffccFF" class="td1">#ffccff</td>
						<td style="background-color:#ffcccc" class="td1">#ffcccc</td>
						<td style="background-color:#ffcc99" class="td1">#ffcc99</td>
						<td style="background-color:#ffcc66" class="td1">#ffcc66</td>
						<td style="background-color:#ffcc33" class="td1">#ffcc33</td>
						<td style="background-color:#ffcc00" class="td1">#ffcc00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#ff99ff" class="td1">#ff99ff</td>
						<td style="background-color:#ff99cc" class="td1">#ff99cc</td>
						<td style="background-color:#ff9999" class="td1">#ff9999</td>
						<td style="background-color:#ff9966" class="td1">#ff9966</td>
						<td style="background-color:#ff9933" class="td1">#ff9933</td>
						<td style="background-color:#ff9900" class="td1">#ff9900</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#ff66ff" class="td2">#ff66ff</td>
						<td style="background-color:#ff66cc" class="td2">#ff66cc</td>
						<td style="background-color:#ff6699" class="td2">#ff6699</td>
						<td style="background-color:#ff6666" class="td2">#ff6666</td>
						<td style="background-color:#ff6633" class="td2">#ff6633</td>
						<td style="background-color:#ff6600" class="td2">#ff6600</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#ff33ff" class="td2">#ff33ff</td>
						<td style="background-color:#ff33cc" class="td2">#ff33cc</td>
						<td style="background-color:#ff3399" class="td2">#ff3399</td>
						<td style="background-color:#ff3366" class="td2">#ff3366</td>
						<td style="background-color:#ff3333" class="td2">#ff3333</td>
						<td style="background-color:#ff3300" class="td2">#ff3300</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#ff00ff" class="td2">#ff00ff</td>
						<td style="background-color:#ff00cc" class="td2">#ff00cc</td>
						<td style="background-color:#ff0099" class="td2">#ff0099</td>
						<td style="background-color:#ff0066" class="td2">#ff0066</td>
						<td style="background-color:#ff0033" class="td2">#ff0033</td>
						<td style="background-color:#ff0000" class="td2">#ff0000</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#ccffff" class="td1">#ccffff</td>
						<td style="background-color:#ccffcc" class="td1">#ccffcc</td>
						<td style="background-color:#ccff99" class="td1">#ccff99</td>
						<td style="background-color:#ccff66" class="td1">#ccff66</td>
						<td style="background-color:#ccff33" class="td1">#ccff33</td>
						<td style="background-color:#ccff00" class="td1">#ccff00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#ccccff" class="td1">#ccccff</td>
						<td style="background-color:#cccccc" class="td1">#cccccc</td>
						<td style="background-color:#cccc99" class="td1">#cccc99</td>
						<td style="background-color:#cccc66" class="td1">#cccc66</td>
						<td style="background-color:#cccc33" class="td1">#cccc33</td>
						<td style="background-color:#cccc00" class="td1">#cccc00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#cc99ff" class="td1">#cc99ff</td>
						<td style="background-color:#cc99cc" class="td1">#cc99cc</td>
						<td style="background-color:#cc9999" class="td1">#cc9999</td>
						<td style="background-color:#cc9966" class="td1">#cc9966</td>
						<td style="background-color:#cc9933" class="td1">#cc9933</td>
						<td style="background-color:#cc9900" class="td1">#cc9900</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#cc66ff" class="td2">#cc66ff</td>
						<td style="background-color:#cc66cc" class="td2">#cc66cc</td>
						<td style="background-color:#cc6699" class="td2">#cc6699</td>
						<td style="background-color:#cc6666" class="td2">#cc6666</td>
						<td style="background-color:#cc6633" class="td2">#cc6633</td>
						<td style="background-color:#cc6600" class="td2">#cc6600</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#cc33ff" class="td2">#cc33ff</td>
						<td style="background-color:#cc33cc" class="td2">#cc33cc</td>
						<td style="background-color:#cc3399" class="td2">#cc3399</td>
						<td style="background-color:#cc3366" class="td2">#cc3366</td>
						<td style="background-color:#cc3333" class="td2">#cc3333</td>
						<td style="background-color:#cc3300" class="td2">#cc3300</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#cc00ff" class="td2">#cc00ff</td>
						<td style="background-color:#cc00cc" class="td2">#cc00cc</td>
						<td style="background-color:#cc0099" class="td2">#cc0099</td>
						<td style="background-color:#cc0066" class="td2">#cc0066</td>
						<td style="background-color:#cc0033" class="td2">#cc0033</td>
						<td style="background-color:#cc0000" class="td2">#cc0000</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#99ffff" class="td1">#99ffff</td>
						<td style="background-color:#99ffcc" class="td1">#99ffcc</td>
						<td style="background-color:#99ff99" class="td1">#99ff99</td>
						<td style="background-color:#99ff66" class="td1">#99ff66</td>
						<td style="background-color:#99ff33" class="td1">#99ff33</td>
						<td style="background-color:#99ff00" class="td1">#99ff00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#99ccff" class="td1">#99ccff</td>
						<td style="background-color:#99cccc" class="td1">#99cccc</td>
						<td style="background-color:#99cc99" class="td1">#99cc99</td>
						<td style="background-color:#99cc66" class="td1">#99cc66</td>
						<td style="background-color:#99cc33" class="td1">#99cc33</td>
						<td style="background-color:#99cc00" class="td1">#99cc00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#9999ff" class="td1">#9999ff</td>
						<td style="background-color:#9999cc" class="td1">#9999cc</td>
						<td style="background-color:#999999" class="td1">#999999</td>
						<td style="background-color:#999966" class="td1">#999966</td>
						<td style="background-color:#999933" class="td1">#999933</td>
						<td style="background-color:#999900" class="td1">#999900</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#9966ff" class="td2">#9966ff</td>
						<td style="background-color:#9966cc" class="td2">#9966cc</td>
						<td style="background-color:#996699" class="td2">#996699</td>
						<td style="background-color:#996666" class="td2">#996666</td>
						<td style="background-color:#996633" class="td2">#996633</td>
						<td style="background-color:#996600" class="td2">#996600</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#9933ff" class="td2">#9933ff</td>
						<td style="background-color:#9933cc" class="td2">#9933cc</td>
						<td style="background-color:#993399" class="td2">#993399</td>
						<td style="background-color:#993366" class="td2">#993366</td>
						<td style="background-color:#993333" class="td2">#993333</td>
						<td style="background-color:#993300" class="td2">#993300</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#9900ff" class="td2">#9900ff</td>
						<td style="background-color:#9900cc" class="td2">#9900cc</td>
						<td style="background-color:#990099" class="td2">#990099</td>
						<td style="background-color:#990066" class="td2">#990066</td>
						<td style="background-color:#990033" class="td2">#990033</td>
						<td style="background-color:#990000" class="td2">#990000</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#66ffff" class="td1">#66ffff</td>
						<td style="background-color:#66ffcc" class="td1">#66ffcc</td>
						<td style="background-color:#66ff99" class="td1">#66ff99</td>
						<td style="background-color:#66ff66" class="td1">#66ff66</td>
						<td style="background-color:#66ff33" class="td1">#66ff33</td>
						<td style="background-color:#66ff00" class="td1">#66ff00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#66ccff" class="td1">#66ccff</td>
						<td style="background-color:#66cccc" class="td1">#66cccc</td>
						<td style="background-color:#66cc99" class="td1">#66cc99</td>
						<td style="background-color:#66cc66" class="td1">#66cc66</td>
						<td style="background-color:#66cc33" class="td1">#66cc33</td>
						<td style="background-color:#66cc00" class="td1">#66cc00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#6699ff" class="td1">#6699ff</td>
						<td style="background-color:#6699cc" class="td1">#6699cc</td>
						<td style="background-color:#669999" class="td1">#669999</td>
						<td style="background-color:#669966" class="td1">#669966</td>
						<td style="background-color:#669933" class="td1">#669933</td>
						<td style="background-color:#669900" class="td1">#669900</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#6666ff" class="td2">#6666ff</td>
						<td style="background-color:#6666cc" class="td2">#6666cc</td>
						<td style="background-color:#666699" class="td2">#666699</td>
						<td style="background-color:#666666" class="td2">#666666</td>
						<td style="background-color:#666633" class="td2">#666633</td>
						<td style="background-color:#666600" class="td2">#666600</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#6633ff" class="td2">#6633ff</td>
						<td style="background-color:#6633cc" class="td2">#6633cc</td>
						<td style="background-color:#663399" class="td2">#663399</td>
						<td style="background-color:#663366" class="td2">#663366</td>
						<td style="background-color:#663333" class="td2">#663333</td>
						<td style="background-color:#663300" class="td2">#663300</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#6600ff" class="td2">#6600ff</td>
						<td style="background-color:#6600cc" class="td2">#6600cc</td>
						<td style="background-color:#660099" class="td2">#660099</td>
						<td style="background-color:#660066" class="td2">#660066</td>
						<td style="background-color:#660033" class="td2">#660033</td>
						<td style="background-color:#660000" class="td2">#660000</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#33ffff" class="td1">#33ffff</td>
						<td style="background-color:#33ffCC" class="td1">#33ffCC</td>
						<td style="background-color:#33ff99" class="td1">#33ff99</td>
						<td style="background-color:#33ff66" class="td1">#33ff66</td>
						<td style="background-color:#33ff33" class="td1">#33ff33</td>
						<td style="background-color:#33ff00" class="td1">#33ff00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#33ccff" class="td1">#33ccff</td>
						<td style="background-color:#33cccc" class="td1">#33cccc</td>
						<td style="background-color:#33cc99" class="td1">#33cc99</td>
						<td style="background-color:#33cc66" class="td1">#33cc66</td>
						<td style="background-color:#33cc33" class="td1">#33cc33</td>
						<td style="background-color:#33cc00" class="td1">#33cc00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#3399ff" class="td1">#3399ff</td>
						<td style="background-color:#3399cc" class="td1">#3399cc</td>
						<td style="background-color:#339999" class="td1">#339999</td>
						<td style="background-color:#339966" class="td1">#339966</td>
						<td style="background-color:#339933" class="td1">#339933</td>
						<td style="background-color:#339900" class="td1">#339900</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#3366ff" class="td2">#3366ff</td>
						<td style="background-color:#3366cc" class="td2">#3366cc</td>
						<td style="background-color:#336699" class="td2">#336699</td>
						<td style="background-color:#336666" class="td2">#336666</td>
						<td style="background-color:#336633" class="td2">#336633</td>
						<td style="background-color:#336600" class="td2">#336600</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#3333ff" class="td2">#3333ff</td>
						<td style="background-color:#3333cc" class="td2">#3333cc</td>
						<td style="background-color:#333399" class="td2">#333399</td>
						<td style="background-color:#333366" class="td2">#333366</td>
						<td style="background-color:#333333" class="td2">#333333</td>
						<td style="background-color:#333300" class="td2">#333300</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#3300ff" class="td2">#3300ff</td>
						<td style="background-color:#3300cc" class="td2">#3300cc</td>
						<td style="background-color:#330099" class="td2">#330099</td>
						<td style="background-color:#330066" class="td2">#330066</td>
						<td style="background-color:#330033" class="td2">#330033</td>
						<td style="background-color:#330000" class="td2">#330000</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#00ffff" class="td1">#00ffff</td>
						<td style="background-color:#00ffcc" class="td1">#00ffcc</td>
						<td style="background-color:#00ff99" class="td1">#00ff99</td>
						<td style="background-color:#00ff66" class="td1">#00ff66</td>
						<td style="background-color:#00ff33" class="td1">#00ff33</td>
						<td style="background-color:#00ff00" class="td1">#00ff00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#00ccff" class="td1">#00ccff</td>
						<td style="background-color:#00cccc" class="td1">#00cccc</td>
						<td style="background-color:#00cc99" class="td1">#00cc99</td>
						<td style="background-color:#00cc66" class="td1">#00cc66</td>
						<td style="background-color:#00cc33" class="td1">#00cc33</td>
						<td style="background-color:#00cc00" class="td1">#00cc00</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#0099ff" class="td1">#0099ff</td>
						<td style="background-color:#0099cc" class="td1">#0099cc</td>
						<td style="background-color:#009999" class="td1">#009999</td>
						<td style="background-color:#009966" class="td1">#009966</td>
						<td style="background-color:#009933" class="td1">#009933</td>
						<td style="background-color:#009900" class="td1">#009900</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#0066ff" class="td2">#0066ff</td>
						<td style="background-color:#0066cc" class="td2">#0066cc</td>
						<td style="background-color:#006699" class="td2">#006699</td>
						<td style="background-color:#006666" class="td2">#006666</td>
						<td style="background-color:#006633" class="td2">#006633</td>
						<td style="background-color:#006600" class="td2">#006600</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#0033ff" class="td2">#0033ff</td>
						<td style="background-color:#0033cc" class="td2">#0033cc</td>
						<td style="background-color:#003399" class="td2">#003399</td>
						<td style="background-color:#003366" class="td2">#003366</td>
						<td style="background-color:#003333" class="td2">#003333</td>
						<td style="background-color:#003300" class="td2">#003300</td>
					</tr>
					<tr style="height:25px">
						<td style="background-color:#0000ff" class="td2">#0000ff</td>
						<td style="background-color:#0000cc" class="td2">#0000cc</td>
						<td style="background-color:#000099" class="td2">#000099</td>
						<td style="background-color:#000066" class="td2">#000066</td>
						<td style="background-color:#000033" class="td2">#000033</td>
						<td style="background-color:#000000" class="td2">#000000</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#ffffff;">#ffffff</td>
						<td class="td1" style="background-color:#fefefe;">#fefefe</td>
						<td class="td1" style="background-color:#fdfdfd;">#fdfdfd</td>
						<td class="td1" style="background-color:#fcfcfc;">#fcfcfc</td>
						<td class="td1" style="background-color:#fbfbfb;">#fbfbfb</td>
						<td class="td1" style="background-color:#fafafa;">#fafafa</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#f9f9f9;">#f9f9f9</td>
						<td class="td1" style="background-color:#f8f8f8;">#f8f8f8</td>
						<td class="td1" style="background-color:#f7f7f7;">#f7f7f7</td>
						<td class="td1" style="background-color:#f6f6f6;">#f6f6f6</td>
						<td class="td1" style="background-color:#f5f5f5;">#f5f5f5</td>
						<td class="td1" style="background-color:#f4f4f4;">#f4f4f4</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#f3f3f3;">#f3f3f3</td>
						<td class="td1" style="background-color:#f2f2f2;">#f2f2f2</td>
						<td class="td1" style="background-color:#f1f1f1;">#f1f1f1</td>
						<td class="td1" style="background-color:#f0f0f0;">#f0f0f0</td>
						<td class="td1" style="background-color:#efefef;">#efefef</td>
						<td class="td1" style="background-color:#eeeeee;">#eeeeee</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#ededed;">#ededed</td>
						<td class="td1" style="background-color:#ececec;">#ececec</td>
						<td class="td1" style="background-color:#ebebeb;">#ebebeb</td>
						<td class="td1" style="background-color:#eaeaea;">#eaeaea</td>
						<td class="td1" style="background-color:#e9e9e9;">#e9e9e9</td>
						<td class="td1" style="background-color:#e8e8e8;">#e8e8e8</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#e7e7e7;">#e7e7e7</td>
						<td class="td1" style="background-color:#e6e6e6;">#e6e6e6</td>
						<td class="td1" style="background-color:#e5e5e5;">#e5e5e5</td>
						<td class="td1" style="background-color:#e4e4e4;">#e4e4e4</td>
						<td class="td1" style="background-color:#e3e3e3;">#e3e3e3</td>
						<td class="td1" style="background-color:#e2e2e2;">#e2e2e2</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#e1e1e1;">#e1e1e1</td>
						<td class="td1" style="background-color:#e0e0e0;">#e0e0e0</td>
						<td class="td1" style="background-color:#dfdfdf;">#dfdfdf</td>
						<td class="td1" style="background-color:#dedede;">#dedede</td>
						<td class="td1" style="background-color:#dddddd;">#dddddd</td>
						<td class="td1" style="background-color:#dcdcdc;">#dcdcdc</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#dbdbdb;">#dbdbdb</td>
						<td class="td1" style="background-color:#dadada;">#dadada</td>
						<td class="td1" style="background-color:#d9d9d9;">#d9d9d9</td>
						<td class="td1" style="background-color:#d8d8d8;">#d8d8d8</td>
						<td class="td1" style="background-color:#d7d7d7;">#d7d7d7</td>
						<td class="td1" style="background-color:#d6d6d6;">#d6d6d6</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#d5d5d5;">#d5d5d5</td>
						<td class="td1" style="background-color:#d4d4d4;">#d4d4d4</td>
						<td class="td1" style="background-color:#d3d3d3;">#d3d3d3</td>
						<td class="td1" style="background-color:#d2d2d2;">#d2d2d2</td>
						<td class="td1" style="background-color:#d1d1d1;">#d1d1d1</td>
						<td class="td1" style="background-color:#d0d0d0;">#d0d0d0</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#cfcfcf;">#cfcfcf</td>
						<td class="td1" style="background-color:#cecece;">#cecece</td>
						<td class="td1" style="background-color:#cdcdcd;">#cdcdcd</td>
						<td class="td1" style="background-color:#cccccc;">#cccccc</td>
						<td class="td1" style="background-color:#cbcbcb;">#cbcbcb</td>
						<td class="td1" style="background-color:#cacaca;">#cacaca</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#c9c9c9;">#c9c9c9</td>
						<td class="td1" style="background-color:#c8c8c8;">#c8c8c8</td>
						<td class="td1" style="background-color:#c7c7c7;">#c7c7c7</td>
						<td class="td1" style="background-color:#c6c6c6;">#c6c6c6</td>
						<td class="td1" style="background-color:#c5c5c5;">#c5c5c5</td>
						<td class="td1" style="background-color:#c4c4c4;">#c4c4c4</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#c3c3c3;">#c3c3c3</td>
						<td class="td1" style="background-color:#c2c2c2;">#c2c2c2</td>
						<td class="td1" style="background-color:#c1c1c1;">#c1c1c1</td>
						<td class="td1" style="background-color:#c0c0c0;">#c0c0c0</td>
						<td class="td1" style="background-color:#bfbfbf;">#bfbfbf</td>
						<td class="td1" style="background-color:#bebebe;">#bebebe</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#bdbdbd;">#bdbdbd</td>
						<td class="td1" style="background-color:#bcbcbc;">#bcbcbc</td>
						<td class="td1" style="background-color:#bbbbbb;">#bbbbbb</td>
						<td class="td1" style="background-color:#bababa;">#bababa</td>
						<td class="td1" style="background-color:#b9b9b9;">#b9b9b9</td>
						<td class="td1" style="background-color:#b8b8b8;">#b8b8b8</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#b7b7b7;">#b7b7b7</td>
						<td class="td1" style="background-color:#b6b6b6;">#b6b6b6</td>
						<td class="td1" style="background-color:#b5b5b5;">#b5b5b5</td>
						<td class="td1" style="background-color:#b4b4b4;">#b4b4b4</td>
						<td class="td1" style="background-color:#b3b3b3;">#b3b3b3</td>
						<td class="td1" style="background-color:#b2b2b2;">#b2b2b2</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#b1b1b1;">#b1b1b1</td>
						<td class="td1" style="background-color:#b0b0b0;">#b0b0b0</td>
						<td class="td1" style="background-color:#afafaf;">#afafaf</td>
						<td class="td1" style="background-color:#aeaeae;">#aeaeae</td>
						<td class="td1" style="background-color:#adadad;">#adadad</td>
						<td class="td1" style="background-color:#acacac;">#acacac</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#ababab;">#ababab</td>
						<td class="td1" style="background-color:#aaaaaa;">#aaaaaa</td>
						<td class="td1" style="background-color:#a9a9a9;">#a9a9a9</td>
						<td class="td1" style="background-color:#a8a8a8;">#a8a8a8</td>
						<td class="td1" style="background-color:#a7a7a7;">#a7a7a7</td>
						<td class="td1" style="background-color:#a6a6a6;">#a6a6a6</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#a5a5a5;">#a5a5a5</td>
						<td class="td1" style="background-color:#a4a4a4;">#a4a4a4</td>
						<td class="td1" style="background-color:#a3a3a3;">#a3a3a3</td>
						<td class="td1" style="background-color:#a2a2a2;">#a2a2a2</td>
						<td class="td1" style="background-color:#a1a1a1;">#a1a1a1</td>
						<td class="td1" style="background-color:#a0a0a0;">#a0a0a0</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#9f9f9f;">#9f9f9f</td>
						<td class="td1" style="background-color:#9e9e9e;">#9e9e9e</td>
						<td class="td1" style="background-color:#9d9d9d;">#9d9d9d</td>
						<td class="td1" style="background-color:#9c9c9c;">#9c9c9c</td>
						<td class="td1" style="background-color:#9b9b9b;">#9b9b9b</td>
						<td class="td1" style="background-color:#9a9a9a;">#9a9a9a</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#999999;">#999999</td>
						<td class="td1" style="background-color:#989898;">#989898</td>
						<td class="td1" style="background-color:#979797;">#979797</td>
						<td class="td1" style="background-color:#969696;">#969696</td>
						<td class="td1" style="background-color:#959595;">#959595</td>
						<td class="td1" style="background-color:#949494;">#949494</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#939393;">#939393</td>
						<td class="td1" style="background-color:#929292;">#929292</td>
						<td class="td1" style="background-color:#919191;">#919191</td>
						<td class="td1" style="background-color:#909090;">#909090</td>
						<td class="td1" style="background-color:#8f8f8f;">#8f8f8f</td>
						<td class="td1" style="background-color:#8e8e8e;">#8e8e8e</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#8d8d8d;">#8d8d8d</td>
						<td class="td1" style="background-color:#8c8c8c;">#8c8c8c</td>
						<td class="td1" style="background-color:#8b8b8b;">#8b8b8b</td>
						<td class="td1" style="background-color:#8a8a8a;">#8a8a8a</td>
						<td class="td1" style="background-color:#898989;">#898989</td>
						<td class="td1" style="background-color:#888888;">#888888</td>
					</tr>
					<tr style="height:25px">
						<td class="td1" style="background-color:#878787;">#878787</td>
						<td class="td1" style="background-color:#868686;">#868686</td>
						<td class="td1" style="background-color:#858585;">#858585</td>
						<td class="td1" style="background-color:#848484;">#848484</td>
						<td class="td1" style="background-color:#838383;">#838383</td>
						<td class="td1" style="background-color:#828282;">#828282</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#818181;">#818181</td>
						<td class="td2" style="background-color:#808080;">#808080</td>
						<td class="td2" style="background-color:#7f7f7f;">#7f7f7f</td>
						<td class="td2" style="background-color:#7e7e7e;">#7e7e7e</td>
						<td class="td2" style="background-color:#7d7d7d;">#7d7d7d</td>
						<td class="td2" style="background-color:#7c7c7c;">#7c7c7c</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#7b7b7b;">#7b7b7b</td>
						<td class="td2" style="background-color:#7a7a7a;">#7a7a7a</td>
						<td class="td2" style="background-color:#797979;">#797979</td>
						<td class="td2" style="background-color:#787878;">#787878</td>
						<td class="td2" style="background-color:#777777;">#777777</td>
						<td class="td2" style="background-color:#767676;">#767676</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#757575;">#757575</td>
						<td class="td2" style="background-color:#747474;">#747474</td>
						<td class="td2" style="background-color:#737373;">#737373</td>
						<td class="td2" style="background-color:#727272;">#727272</td>
						<td class="td2" style="background-color:#717171;">#717171</td>
						<td class="td2" style="background-color:#707070;">#707070</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#6f6f6f;">#6f6f6f</td>
						<td class="td2" style="background-color:#6e6e6e;">#6e6e6e</td>
						<td class="td2" style="background-color:#6d6d6d;">#6d6d6d</td>
						<td class="td2" style="background-color:#6c6c6c;">#6c6c6c</td>
						<td class="td2" style="background-color:#6b6b6b;">#6b6b6b</td>
						<td class="td2" style="background-color:#6a6a6a;">#6a6a6a</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#696969;">#696969</td>
						<td class="td2" style="background-color:#686868;">#686868</td>
						<td class="td2" style="background-color:#676767;">#676767</td>
						<td class="td2" style="background-color:#666666;">#666666</td>
						<td class="td2" style="background-color:#656565;">#656565</td>
						<td class="td2" style="background-color:#646464;">#646464</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#636363;">#636363</td>
						<td class="td2" style="background-color:#626262;">#626262</td>
						<td class="td2" style="background-color:#616161;">#616161</td>
						<td class="td2" style="background-color:#606060;">#606060</td>
						<td class="td2" style="background-color:#5f5f5f;">#5f5f5f</td>
						<td class="td2" style="background-color:#5e5e5e;">#5e5e5e</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#5d5d5d;">#5d5d5d</td>
						<td class="td2" style="background-color:#5c5c5c;">#5c5c5c</td>
						<td class="td2" style="background-color:#5b5b5b;">#5b5b5b</td>
						<td class="td2" style="background-color:#5a5a5a;">#5a5a5a</td>
						<td class="td2" style="background-color:#595959;">#595959</td>
						<td class="td2" style="background-color:#585858;">#585858</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#575757;">#575757</td>
						<td class="td2" style="background-color:#565656;">#565656</td>
						<td class="td2" style="background-color:#555555;">#555555</td>
						<td class="td2" style="background-color:#545454;">#545454</td>
						<td class="td2" style="background-color:#535353;">#535353</td>
						<td class="td2" style="background-color:#525252;">#525252</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#515151;">#515151</td>
						<td class="td2" style="background-color:#505050;">#505050</td>
						<td class="td2" style="background-color:#4f4f4f;">#4f4f4f</td>
						<td class="td2" style="background-color:#4e4e4e;">#4e4e4e</td>
						<td class="td2" style="background-color:#4d4d4d;">#4d4d4d</td>
						<td class="td2" style="background-color:#4c4c4c;">#4c4c4c</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#4b4b4b;">#4b4b4b</td>
						<td class="td2" style="background-color:#4a4a4a;">#4a4a4a</td>
						<td class="td2" style="background-color:#494949;">#494949</td>
						<td class="td2" style="background-color:#484848;">#484848</td>
						<td class="td2" style="background-color:#474747;">#474747</td>
						<td class="td2" style="background-color:#464646;">#464646</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#454545;">#454545</td>
						<td class="td2" style="background-color:#444444;">#444444</td>
						<td class="td2" style="background-color:#434343;">#434343</td>
						<td class="td2" style="background-color:#424242;">#424242</td>
						<td class="td2" style="background-color:#414141;">#414141</td>
						<td class="td2" style="background-color:#404040;">#404040</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#3f3f3f;">#3f3f3f</td>
						<td class="td2" style="background-color:#3e3e3e;">#3e3e3e</td>
						<td class="td2" style="background-color:#3d3d3d;">#3d3d3d</td>
						<td class="td2" style="background-color:#3c3c3c;">#3c3c3c</td>
						<td class="td2" style="background-color:#3b3b3b;">#3b3b3b</td>
						<td class="td2" style="background-color:#3a3a3a;">#3a3a3a</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#393939;">#393939</td>
						<td class="td2" style="background-color:#383838;">#383838</td>
						<td class="td2" style="background-color:#373737;">#373737</td>
						<td class="td2" style="background-color:#363636;">#363636</td>
						<td class="td2" style="background-color:#353535;">#353535</td>
						<td class="td2" style="background-color:#343434;">#343434</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#333333;">#333333</td>
						<td class="td2" style="background-color:#323232;">#323232</td>
						<td class="td2" style="background-color:#313131;">#313131</td>
						<td class="td2" style="background-color:#303030;">#303030</td>
						<td class="td2" style="background-color:#2f2f2f;">#2f2f2f</td>
						<td class="td2" style="background-color:#2e2e2e;">#2e2e2e</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#2d2d2d;">#2d2d2d</td>
						<td class="td2" style="background-color:#2c2c2c;">#2c2c2c</td>
						<td class="td2" style="background-color:#2b2b2b;">#2b2b2b</td>
						<td class="td2" style="background-color:#2a2a2a;">#2a2a2a</td>
						<td class="td2" style="background-color:#292929;">#292929</td>
						<td class="td2" style="background-color:#282828;">#282828</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#272727;">#272727</td>
						<td class="td2" style="background-color:#262626;">#262626</td>
						<td class="td2" style="background-color:#252525;">#252525</td>
						<td class="td2" style="background-color:#242424;">#242424</td>
						<td class="td2" style="background-color:#232323;">#232323</td>
						<td class="td2" style="background-color:#222222;">#222222</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#212121;">#212121</td>
						<td class="td2" style="background-color:#202020;">#202020</td>
						<td class="td2" style="background-color:#1f1f1f;">#1f1f1f</td>
						<td class="td2" style="background-color:#1e1e1e;">#1e1e1e</td>
						<td class="td2" style="background-color:#1d1d1d;">#1d1d1d</td>
						<td class="td2" style="background-color:#1c1c1c;">#1c1c1c</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#1b1b1b;">#1b1b1b</td>
						<td class="td2" style="background-color:#1a1a1a;">#1a1a1a</td>
						<td class="td2" style="background-color:#191919;">#191919</td>
						<td class="td2" style="background-color:#181818;">#181818</td>
						<td class="td2" style="background-color:#171717;">#171717</td>
						<td class="td2" style="background-color:#161616;">#161616</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#151515;">#151515</td>
						<td class="td2" style="background-color:#141414;">#141414</td>
						<td class="td2" style="background-color:#131313;">#131313</td>
						<td class="td2" style="background-color:#121212;">#121212</td>
						<td class="td2" style="background-color:#111111;">#111111</td>
						<td class="td2" style="background-color:#101010;">#101010</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#0f0f0f;">#0f0f0f</td>
						<td class="td2" style="background-color:#0e0e0e;">#0e0e0e</td>
						<td class="td2" style="background-color:#0d0d0d;">#0d0d0d</td>
						<td class="td2" style="background-color:#0c0c0c;">#0c0c0c</td>
						<td class="td2" style="background-color:#0b0b0b;">#0b0b0b</td>
						<td class="td2" style="background-color:#0a0a0a;">#0a0a0a</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#090909;">#090909</td>
						<td class="td2" style="background-color:#080808;">#080808</td>
						<td class="td2" style="background-color:#070707;">#070707</td>
						<td class="td2" style="background-color:#060606;">#060606</td>
						<td class="td2" style="background-color:#050505;">#050505</td>
						<td class="td2" style="background-color:#040404;">#040404</td>
					</tr>
					<tr style="height:25px">
						<td class="td2" style="background-color:#030303;">#030303</td>
						<td class="td2" style="background-color:#020202;">#020202</td>
						<td class="td2" style="background-color:#010101;">#010101</td>
						<td class="td2" style="background-color:#000000;">#000000</td>
						<td></td>
						<td></td>
					</tr>
				</table>
			</div>';
		echo"
		<script type=\"text/javascript\" src=\"".$url."js/functions.js\"></script>
	</body>
	</html>";
?>
