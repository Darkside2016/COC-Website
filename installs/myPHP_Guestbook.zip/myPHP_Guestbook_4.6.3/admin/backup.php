<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    06.02.2015
*/

    if (!isset($_SESSION['sid']))
	    {
	        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
	    }
    else
		{
	        if ($_GET['show'] == "make_backup")
				{
		            $timestamp			= time();
		            $date				= date("d.m.Y", $timestamp);
							
					$backup_version = 'gbv4-backup';  // Falls Änderung, auch Zeile 282 entsprechend anpassen !!
					mt_srand(makeRandomName());
					$random = mt_rand();
					$random = substr($random, 0, 10);

					$select_backup_query = $gbook->query("SELECT `guestbook_title`, `clean_backup`, `admin_email` FROM `".$table."_properties`");
					$backup_options 	 = $select_backup_query->fetch_assoc();
					$title				 = $backup_options['guestbook_title'];
					$empfaenger 		 = $backup_options['admin_email'];
					$clean_backup 		 = $backup_options['clean_backup'];
		
					(!extension_loaded("zlib")) ? $compr = 0  :  $compr = 1 ;
					($compr == 1) ? $filetype = "sql.gz" : $filetype = "sql";

		            @set_time_limit(0);
		
		            $file_exist = "../backup/".$backup_version."_".$random.".".$filetype."";
		
		            if (file_exists($file_exist)) { unlink("../backup/".$backup_version."_".$random.".".$filetype.""); }
		
		            $i 					= 0;
		            $entriefields[$i]	= array();
		            $picturefields[$i]	= array();
		            $time				= date("H:i:s", $timestamp);
		            $uhr				= date("H:i", $timestamp);
		            $mysqlversion_sql 	= $gbook->query("SELECT VERSION()");
		            $mysqlversion		= $mysqlversion_sql->fetch_row();
		            $phpversion			= phpversion();
		            $insert[$i]			= "\n# -------------------------------------------\n# myPHP Guestbook ".$version." SQL Dump\n# ".$date." ".$time."\n# PHP Version: ".$phpversion."\n# MySQL Version: ".$mysqlversion[0]."\n# Table: ".$table."_entries\n# Table: ".$table."_pictures\n# -------------------------------------------\n#\n\n";
		            $entries_query		= $gbook->query("SHOW COLUMNS FROM ".$table."_entries");
		            $picture_query		= $gbook->query("SHOW COLUMNS FROM ".$table."_pictures");
		            $one[$i]			= "";
		            $two[$i]			= "";
		            $three[$i]			= "";
		            $four[$i]			= "";
		            $x					= 0;
		            $xx					= 0;

		            while ($entries_data = $entries_query->fetch_row())
			            {
			                if ($x < $entries_query->num_rows - 1)
				                {
				                    $one[$i] .= $entries_data[0].", ";
				                }
			                else
				                {
				                    $one[$i] .= $entries_data[0];
				                }
			
			                array_push($entriefields[$i], $entries_data[0]);
			                $x++;
			            }

		            $insert_entries_query = $gbook->query("SELECT `comment`, `date`, `email`, `homepage`, `icq`, `id`, `ip`, `status`, `name`, `activation_code`, `text`, `time`, `origin`, `marker` FROM `".$table."_entries`");
		
					while ($insert_entries_data = $insert_entries_query->fetch_assoc())
			            {
			                for ($t=0;$t<count($entriefields[$i]);$t++)
								{
				                    if ($t < count($entriefields[$i])-1)
					                    {
											if ($entriefields[$i][$t] == "activation_code")
												{
						                            $two[$i] .= "'', ";
						                        }
					                        else
						                        {
						                            $two[$i] .= "'".prepare($insert_entries_data[$entriefields[$i][$t]])."', ";
						                        }
					                    }
				                    else
					                    {
											if ($entriefields[$i][$t] == "activation_code")
												{
						                            $two[$i] .= "'', ";
						                        }
					                        else
						                        {
						                            $two[$i] .= "'".prepare($insert_entries_data[$entriefields[$i][$t]])."'";
						                        }
					                    }
								}
	
							$insert[$i] .= "INSERT INTO `".$table."_entries` (".$one[$i].") VALUES (".$two[$i].");\n";
	                		$two[$i] = "";
						}

		            while ($picture_data = $picture_query->fetch_row())
			            {
			                if ($xx < $picture_query->num_rows - 1)
				                {
				                    $three[$i] .= $picture_data[0].", ";
				                }
			                else
				                {
				                    $three[$i] .= $picture_data[0];
				                }
			
			                array_push($picturefields[$i], $picture_data[0]);
			                $xx++;
			            }

		            $insert_picture_query = $gbook->query("SELECT `id`, `ip`, `pic_name`, `width`, `height`, `title`, `date`, `time` FROM `".$table."_pictures`");
		
					while ($insert_picture_data = $insert_picture_query->fetch_assoc())
			            {
			                for ($tt=0;$tt<count($picturefields[$i]);$tt++)
								{
				                    if ($tt < count($picturefields[$i])-1)
					                    {
				                            $four[$i] .= "'".prepare($insert_picture_data[$picturefields[$i][$tt]])."', ";
					                    }
				                    else
					                    {
				                            $four[$i] .= "'".prepare($insert_picture_data[$picturefields[$i][$tt]])."'";
					                    }
								}
							$insert[$i] .= "INSERT INTO `".$table."_pictures` (".$three[$i].") VALUES (".$four[$i].");\n";
	            			$four[$i] = "";
						}
	
					$dump_buffer = $insert[$i];

					if ($compr == 1)
						{
				            $open_backup  = gzopen("../backup/".$backup_version."_".$random.".".$filetype."","w9");
				            $write_backup = gzwrite($open_backup,$dump_buffer);
				            gzclose ($open_backup);
						}
					else
						{
				            $open_backup  = fopen("../backup/".$backup_version."_".$random.".".$filetype."","w");
				            $write_backup = fputs($open_backup,$dump_buffer);
				            fclose ($open_backup);
						}

	
		            if ($write_backup)
						{
							$gbook->query("INSERT INTO `".$table."_backup` (`id`,`dateiname`,`datum`,`uhrzeit`) VALUES ('','".$backup_version."_".$random.".".$filetype."','".$date."','".$uhr."')");
			
							$pfad = "../backup/".$backup_version."_".$random.".".$filetype.""; 
							
							if (file_exists($pfad))
								{
									$anhang = array(); 
									$anhang["name"] = basename($pfad); 
									$anhang["size"] = filesize($pfad); 
									$anhang["data"] = implode("",file($pfad)); 
									$message		= $amsg[65];
									$betreff 		= "BackUp myPHP-Guestbook - ".$_SERVER['SERVER_NAME']."\n";
			 
									(function_exists("mime_content_type")) ? $anhang["type"] = mime_content_type($pfad) : $anhang["type"] = "application/octet-stream";

									function mail_anhang($empfaenger,$betreff,$message,$anhang) 
										{ 
											global $title;

											$data = chunk_split(base64_encode($anhang['data'])); 
											$boundary = md5(uniqid(time()));
								
											$header  = "From: \"".$title."\" <".$empfaenger.">\r\n";
											$header.= "MIME-Version: 1.0\r\n"; 
											$header.= "Content-Type: multipart/mixed;\r\n"; 
											$header.= " boundary=\"".$boundary."\"\r\n"; 
														
											$content = "This is a multi-part message in MIME format -- Dies ist eine mehrteilige Nachricht im MIME-Format.\r\n\r\n"; 
											$content.= "--".$boundary."\r\n"; 
											$content.= "Content-Type: text/html; charset=utf-8\r\n";
											$content.= "Content-Transfer-Encoding: 8bit\r\n\r\n"; 
											$content.= $message."\r\n"; 
											$content.= "--".$boundary."\r\n"; 
											$content.= "Content-Disposition: attachment;\r\n"; 
											$content.= "\tfilename=\"".$anhang['name']."\";\r\n"; 
											$content.= "Content-Length: ".$anhang['size'].";\r\n"; 
											$content.= "Content-Type: ".$anhang['type']."; name=\"".$anhang['name']."\"\r\n"; 
											$content.= "Content-Transfer-Encoding: base64\r\n\r\n"; 
											$content.= $data."\r\n"; 
												
										   if(@mail($empfaenger, $betreff, $content, $header)) return true; 
						
										   else return false; 
										} 

									mail_anhang($empfaenger, $betreff, $message, $anhang); 
								}

			                echo "<br /><fieldset>
								<legend><strong>".$amsg[66]."</strong></legend>
								<br /><br />   
								<p class=\"zentriert\">".$amsg[67]."</p>";
								
								if ($clean_backup == 1)
									{
										$ordner = "../backup";
										$all_backups = scandir($ordner);
							
										foreach ($all_backups as $single_backup)
											{
												if ($single_backup != "." && $single_backup != ".." && $single_backup != ".htaccess" && $single_backup != "index.php")
													{
														unlink("../backup/".$single_backup."");
														$gbook->query("TRUNCATE TABLE `".$table."_backup`");
													}
											}
											
										echo"<p class=\"zentriert\">".$amsg[80]."</p>";
									}
								else
									{
										echo"<p class=\"zentriert\">".$amsg[68]."</p>";
									}
								
							echo"
								<form method=\"post\" action=\"".$url."admin/admin.php?action=backup&#38;show=restore_backup&#38;".session_name()."=".session_id()."\">
								<table style=\"width:450px\" class=\"tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
									<tr>
										<td align=\"center\">
											<p>&nbsp;</p>
											<p><input type=\"button\" class=\"button\" title=\"".$fmsg[4]."\" name=\"zurueck\" value=\"".$fmsg[4]."\"  onclick=\"self.location.href='".$url."admin/admin.php?action=backup&#38;show=restore_backup&#38;".session_name()."=".session_id()."'\" /></p>
										</td>
									</tr>
								</table>
								</form>
								</fieldset>";
						}
						
					else
						{
			               echo "<div class=\"aligncenter\">
									<p class=\"red\"><strong>- ".$emsg[4]."</strong></p>
									<form method=\"post\" action=\"".$url."admin/admin.php?action=backup&#38;show=restore_backup&#38;".session_name()."=".session_id()."\">
										<table style=\"width:450px\" class=\"tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
											<tr>
												<td align=\"center\">
													<p>&nbsp;</p>
													<p><input type=\"button\" class=\"button\" title=\"".$fmsg[4]."\" name=\"zurueck\" value=\"".$fmsg[4]."\"  onclick=\"self.location.href='".$url."admin/admin.php?action=backup&#38;show=restore_backup&#38;".session_name()."=".session_id()."'\"/></p>
												</td>
											</tr>
										</table>
									</form>
								</div>";
			            }
				}
        
	        elseif ($_GET['show'] == "restore_backup")
				{
					$old_backup_version	 = 'gbv3-backup';
					$backup_version 	 = 'gbv4-backup';  // Falls Änderung, ggf. auch Zeile 34 entsprechend anpassen; beachte Zeile 322 !!
					$select_backup_query = $gbook->query("SELECT `clean_backup` FROM `".$table."_properties`");
					$backup_options 	 = $select_backup_query->fetch_assoc();
					$clean_backup 		 = $backup_options['clean_backup'];
					$info 				 = "";
					$info_02 			 = "";
					
					(!extension_loaded("zlib")) ? $compr = 0  :  $compr = 1 ;

					if (isset($_POST['send']) && isset($_POST['entry_id']))
						{
							$y = count($_POST['entry_id']);
											
							if ($y > 1)
								{
									$info_02 = "<p class=\"zentriert red\"><strong>- ".$emsg[46]."</strong></p>";
								}
								
							else
								{
									for ($x=0;$x<$y;$x++)
										{
											$entry_id = $_POST['entry_id'][$x];
			
											$select_dateiname_query = $gbook->query("SELECT  `dateiname`  FROM  `".$table."_backup`  WHERE  id = '$entry_id'");
											$select_dateiname 		= $select_dateiname_query->fetch_assoc();
											
											if (isset($_POST['send']))
												{
								                	@set_time_limit(0);
					
								               		$file_exist = "../backup/".$select_dateiname['dateiname']."";
									
								               		if (file_exists($file_exist))
														{
															$gbbuv  = explode('_', $select_dateiname['dateiname']);
															$backup_vers = $gbbuv[0];
														
								                			$gbook->query("TRUNCATE TABLE ".$table."_entries"); //Löscht den vorhandenen Inhalt der Tabelle "_entries"
								                			
								                			if (($backup_vers === $backup_version) || ($backup_vers === $old_backup_version)) {
								                				$gbook->query("TRUNCATE TABLE ".$table."_pictures"); //Löscht den vorhandenen Inhalt der Tabelle "_pictures", wenn BackUp mit einer Gästebuch-Version ab 4.5.4 erstellt
								                			}
								                			
															$file_ext = explode(".", $select_dateiname['dateiname']);
															$file_ext[2] = isset($file_ext[2]) ? $file_ext[2] : '';
															$file_ext[4] = isset($file_ext[4]) ? $file_ext[4] : '';
															
															if ($compr == 1 AND ($file_ext[2] == "gz" || $file_ext[4] == "gz"))
																{
										                   			$fd = gzopen ("../backup/".$select_dateiname['dateiname']."", "r");
										                   			$query = "";
										                   			$error = 0;
							
											                        while (!feof($fd))
											                        	{
																			$line = fgets($fd, 4096);
																			$line = chop($line);
											
																			if (!preg_match("/^#/", $line))
																				{
											                                		$query .= $line;
											
											                                		if ((preg_match("/;\n?$/",$line) OR feof($fd)) AND $query != "")
											                                			{
											                                    			if (!$gbook->query($query))
											                                    				{
											                                        				$error++;
											                                    				}
											
											                                    			$query = "";
											                                			}
											                            		}
											                        	}
					
											                        gzclose ($fd);
											                    }
											                else
											                	{
										                   			$fd = fopen ("../backup/".$select_dateiname['dateiname']."", "r");
										                   			$query = "";
										                   			$error = 0;
							
											                        while (!feof($fd))
											                        	{
																			$line = fgets($fd, 4096);
																			$line = chop($line);
											
																			if (!preg_match("/^#/", $line))
																				{
											                                		$query .= $line;
											
											                                		if ((preg_match("/;\n?$/",$line) OR feof($fd)) AND $query != "")
											                                			{
											                                    			if (!$gbook->query($query))
											                                    				{
											                                        				$error++;
											                                    				}
											
											                                    			$query = "";
											                                			}
											                            		}
											                        	}
					
											                        fclose ($fd);
											                	}
									
									                        if ($error > 0)
									                        	{
																	$info_02 = "<p class=\"zentriert red\"><strong>- ".$fmsg[148].".</strong></p>";
					                        					}
					                        				else
					                        					{
																	$info_02 = "<p class=\"zentriert green\"><strong>- ".$fmsg[149]."</strong></p>";
					                        					}

					                        				if ($clean_backup == 1)
																{
																	$ordner = "../backup";
																	$all_backups = scandir($ordner);
																	
																	foreach ($all_backups as $single_backup)
																		{
																			if ($single_backup != "." && $single_backup != ".." && $single_backup != ".htaccess" && $single_backup != "index.php")
																				{
																					unlink("../backup/".$single_backup."");
																					$gbook->query("TRUNCATE TABLE `".$table."_backup`");
																				}
																		}
																					
																	echo"<p class=\"zentriert\">".$amsg[83]."</p>";
																}
														}
													
													else
														{
					                        				$info_02 = "<p class=\"zentriert red\"><strong>- ".$emsg[6]."</strong></p><br />";
					                    				}
												}
										}
								}
						}
					
					elseif (isset($_POST['send']) && !isset($_POST['entry_id']))
						{
							$info = "<p class=\"zentriert red\"><strong>- ".$emsg[45]."</strong></p>";
						}
					
					$backup_delete = 3;
		
					$sql_count_backup = $gbook->query("SELECT `id` FROM `".$table."_backup`");
					$count_backup = $sql_count_backup->num_rows;
		
					while($count_backup > $backup_delete)
						{
							$del_backup_query	= $gbook->query("SELECT  `dateiname`  FROM  `".$table."_backup` WHERE `id` = (SELECT min(id) FROM `".$table."_backup`)");
							$del_backup			= $del_backup_query->fetch_assoc();
							$datei_del			= $del_backup['dateiname'];
		
							unlink("../backup/".$datei_del."");
							$gbook->query("DELETE FROM `".$table."_backup` WHERE `dateiname` = '$datei_del'");
		
							$count_backup--;
						}
					
		            echo "<fieldset>
						<legend><strong>".$amsg[69]."</strong></legend><br/>
						<script type=\"text/javascript\">function backup_upload() {return confirm('".$emsg[47]."');}</script>
						<form method=\"post\" action=\"".$url."admin/admin.php?action=backup&#38;show=restore_backup&#38;".session_name()."=".session_id()."\">
						<table style=\"width:500px\" class=\"tableCenter\" border=\"1\" rules=\"rows\" frame=\"below\" cellspacing=\"0\" cellpadding=\"5\">";
						
							if (!$count_backup)
								{
									echo"
										<tr><td colspan=\"4\" align=\"center\"><p class=\"red\"><strong>".$amsg[87]."</strong></p></td></tr>
										</table>";
								}
							else
								{
									echo"
										<tr><td colspan=\"4\" align=\"center\"><p>".$amsg[70]."</p></td></tr>
										<tr class=\"tdinstall1\">
											<td style=\"width:220px\" align=\"center\"><strong>".$amsg[71]."</strong></td>
											<td style=\"width:125px\" align=\"center\"><strong>".$amsg[55]."</strong></td>
											<td style=\"width:125px\" align=\"center\"><strong>".$amsg[56]."</strong></td>
											<td align=\"center\"><img title=\"".$amsg[73]."\" src=\"../images/ausruf.png\" width=\"14\" height=\"14\" alt=\"\" /></td>
										</tr>";
						
									$sql_backuplist = $gbook->query("SELECT * FROM `".$table."_backup` ORDER BY `id` DESC");
				
									while ($backuplist = $sql_backuplist->fetch_assoc())
										{
											echo"
												<tr>
													<td align=\"left\">".$backuplist['dateiname']."</td>
													<td align=\"center\">".$backuplist['datum']."</td>
													<td align=\"center\">".$backuplist['uhrzeit']."</td>
													<td align=\"center\"><input class=\"delete\" type=\"checkbox\" name=\"entry_id[]\" value=\"".$backuplist['id']."\" /></td>
												</tr>";
									    }

									echo"
									</table>
									<p>&nbsp;</p>
									$info	$info_02	".$amsg[74]."
									<p>&nbsp;</p>
									<table style=\"width:450px\" class=\"tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
										<tr>
											<td align=\"center\"><p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$amsg[73]."\" /></p></td>
										</tr>
									</table>
									<p>&nbsp;</p>
									<hr style=\"width:500px\" />";
								}
									
					echo"			
						<p>&nbsp;</p>
						<table style=\"width:450px\" class=\"tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
							<tr>
								<td align=\"center\"><p><strong>".$amsg[76]."</strong></p></td>
							</tr>
							<tr>
								<td align=\"center\"><br />".$amsg[77]."<br /></td>
							</tr>";
				
				       		if (isset($_POST['backup_plus']) AND isset($_POST['send_backup']))
								{
				           			$fehler 	= "";
				           			$_POST['backup_plus'] = $gbook->real_escape_string($_POST['backup_plus']);
				
									if ($_POST['backup_plus'] == "")
										{
											$fehler .= "".$emsg[48]."";
										}
									
									elseif (!preg_match("/^[a-z0-9_ -.]*$/is", $_POST['backup_plus']))
										{
											$fehler .= "".$emsg[49]."";
										}
										
									else
										{
											while (substr_count ($_POST['backup_plus'], " ") > 0)
												{
													$_POST['backup_plus'] = str_replace (" ", "", $_POST['backup_plus']);
												}
			
											$update = $gbook->query("INSERT INTO `".$table."_backup` (`id`,`dateiname`,`datum`,`uhrzeit`) VALUES ('','".$_POST['backup_plus']."','".date("d.m.Y")."','".date("H:i")."')");
					
											if ($update)
												{					                        
													echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=backup&#38;show=restore_backup&#38;".session_name()."=".session_id()."\" />";
												}
			
										}
			
									if (!$fehler == "")
										{ 
											echo "<tr><td><br /><br /><p class=\"zentriert red\"><strong>".$fehler."</strong></p></td></tr>";
										}
								}

						echo"
							<tr>
								<td align=\"center\"><p class=\"zentriert\"><input type=\"text\" class=\"insert\" name=\"backup_plus\" value=\"\" /></p></td>
							</tr>
							</table>
							<p>&nbsp;</p>
							<p class=\"aligncenter\"><input type=\"submit\" class=\"button\" name=\"send_backup\" value=\"".$amsg[78]."\" onclick=\"return backup_upload()\" /></p>		
							</form>
							</fieldset>";
				}
		}
?>