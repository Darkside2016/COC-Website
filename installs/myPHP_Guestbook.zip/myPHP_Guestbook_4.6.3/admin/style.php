<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    06.02.2015
*/
    
    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
        if ($_GET['show'] == "edit_style") {
            $sql_properties = $gbook->query("SELECT default_style FROM ".$table."_properties");
            $properties = $sql_properties->fetch_assoc();

            $sql_select_style = $gbook->query("SELECT name FROM ".$table."_style WHERE id='".$properties['default_style']."'");
            $select_style = $sql_select_style->fetch_assoc();

            echo "<fieldset>
				<legend><strong>".$fmsg[69]."</strong></legend>
				<br /><br />
				<form method=\"post\" name=\"style\" action=\"".$url."admin/admin.php?action=style&#38;show=edit_style_action&#38;".session_name()."=".session_id()."\">
				<table style=\"width:361px\" class=\"guestbook_table2 tableCenter\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
				<tr>
				<td align=\"left\">".$fmsg[59]." <strong>".$select_style['name']."</strong><br /><br /><select name=\"style\">";

            $sql_style = $gbook->query("SELECT id, name FROM ".$table."_style");

            while ($style = $sql_style->fetch_assoc()) {
                echo "<option value='".$style['id']."'";

                if ($style['id'] == $properties['default_style']) {
                    echo " selected=\"selected\"";
                }

                echo ">".$style['name']."</option>";
            }

            echo "</select></td>
				</tr>
				<tr>
				<td align=\"center\"><p><br /><input type=\"submit\" class=\"button\" name=\"Button\" value=\"".$fmsg[70]."\" /><br /></p></td>
				</tr>
				</table>
				</form>
				</fieldset>";
        } elseif ($_GET['show'] == "edit_style_action") {
            if (isset($_POST['send'])) {
                if ($_POST['style'] == "") {
                    echo "<br /><p class=\zentriert\"><strong>- ".$emsg[44]."</strong></p><br >";
                } else {
                    $sql_update_style = $gbook->query("UPDATE ".$table."_style SET style='".$_POST['style']."' WHERE id='".$_POST['id']."'");
                    if ($sql_update_style) {
                        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=style&#38;show=edit_style&#38;".session_name()."=".session_id()."\" />";
                    }
                }
            }

            $sql_select_style = $gbook->query("SELECT style FROM ".$table."_style WHERE id='".$_POST['style']."'");
            $select_style = $sql_select_style->fetch_assoc();

		        echo"<fieldset>
            	<legend><strong>".$fmsg[71]."</strong></legend>
            	<br /><br />
            	<form method=\"post\" action=\"".$url."admin/admin.php?action=style&#38;show=edit_style_action&#38;".session_name()."=".session_id()."\">
				<table style=\"width:361px\" class=\"guestbook_table tableCenter\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
				<tr>
				<td align=\"center\" class=\"tdinstall2\"><p><strong><a class=\"cursor underline gray\" onclick=\"javascript:NewWindow('colors.php','colors','650','740','custom','front');return true;\">".$amsg[113]."</a></strong><br /></p></td>
				</tr>
				<tr>
				<td align=\"left\" class=\"tdinstall2\"><p><strong>".$fmsg[72]."</strong></p><textarea class=\"insert\" rows=\"20\" name=\"style\" cols=\"68\">".$select_style['style']."</textarea></td>
				</tr>
				<tr>
				<td align=\"left\" class=\"tdinstall2\">
					<p class=\"red text-center\"><strong>".$fmsg[331]."</strong></p>
					<p>&nbsp;</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;divalign&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[332].".</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;bodycolor&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[330].".</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;fontcolor&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[333].".</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;maxwidth&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[86]."</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;topcolor&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[89]."</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;entriecolor&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[90]."</p>
					<input type=\"hidden\" name=\"id\" value=\"".$_POST['style']."\" />
				</td>
				</tr>
				<tr>
				<td align=\"center\" class=\"tdinstall2\">
					<p><br /><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[55]."\" onclick=\"return confirm_cssstyle()\" /></p>
					<p><br /><input type=\"button\" class=\"button\" title=\"".$fmsg[4]."\" name=\"abbruch\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='admin.php?action=style&show=edit_style&#38;".session_name()."=".session_id()."'\" /></p>
					<p>&nbsp;</p>
				</td>
				</tr>
				</table>
				</form>
				</fieldset>";
        } elseif ($_GET['show'] == "default_style") {
            if (isset($_POST['send'])) {
                $gbook->query("UPDATE ".$table."_properties SET default_style='".$_POST['style']."'");
				echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=style&#38;show=default_style&#38;".session_name()."=".session_id()."\">";
            }

            $sql_properties = $gbook->query("SELECT default_style FROM ".$table."_properties");
            $properties = $sql_properties->fetch_assoc();

            $sql_style = $gbook->query("SELECT id, name FROM ".$table."_style");

            $sql_select_style = $gbook->query("SELECT name FROM ".$table."_style WHERE id='".$properties['default_style']."'");
            $select_style = $sql_select_style->fetch_assoc();

		        echo"<script type=\"text/javascript\">
				function confirm_cssstyle() {return confirm('".$fmsg[277]."');}
				</script>
				<fieldset>
				<legend><strong>".$fmsg[58]."</strong></legend>
				<br /><br />".$fmsg[329]."<br />
				<form method=\"post\" action=\"".$url."admin/admin.php?action=style&#38;show=default_style&#38;".session_name()."=".session_id()."\">
				<table style=\"width:250px\" class=\"guestbook_table2 tableCenter\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
				<tr>
				<td align=\"left\">";
				
		        $sql_style = $gbook->query("SELECT id, name FROM ".$table."_style");
		
				while ($style_list = $sql_style->fetch_assoc())
					{
						echo"
							<input type=\"radio\" class=\"radio\" name=\"style\" id=\"style-".$style_list['id']."\" value=\"".$style_list['id']."\"";
																	
							if (isset($_POST['style']) AND $_POST['style'] == $style_list['name'])
								{
									echo" checked=\"checked\" /> <label for=\"style-".$style_list['id']."\"><strong style=\"color:green\">".$style_list['name']."</strong></label><br /><br />";
								}
							elseif (!isset($_POST['style']) AND $style_list['name'] == $select_style['name'])
								{
									echo" checked=\"checked\" /> <label for=\"style-".$style_list['id']."\"><strong style=\"color:green\">".$style_list['name']."</strong></label><br /><br />";
								}
							else
								{										
									echo" /> <label for=\"style-".$style_list['id']."\">".$style_list['name']."</label><br /><br />";
								}
					}
		
				echo "
				</td>
				</tr>
				<tr>
				<td align=\"center\"><p><br /><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[55]."\" onclick=\"return confirm_cssstyle()\" /><br /></p></td>
				</tr>
				</table>
				</form>
				</fieldset>";
        } elseif ($_GET['show'] == "delete_style") {
            if (isset($_POST['send']))
            	{
					$sql_style_id = $gbook->query("SELECT id FROM ".$table."_style");
					
					if ($sql_style_id->num_rows > 1)
						{
                			$gbook->query("DELETE FROM ".$table."_style WHERE id='".$_POST['style']."'");
                		}
                	else
                		{
                			$error_02 = "<p class=\"error\">".$emsg[51]."</p>";
                		}
            	}

            $sql_properties = $gbook->query("SELECT default_style FROM ".$table."_properties");
            $properties = $sql_properties->fetch_assoc();

            $sql_style = $gbook->query("SELECT id, name FROM ".$table."_style");

            $sql_select_style = $gbook->query("SELECT name FROM ".$table."_style WHERE id='".$properties['default_style']."'");
            $select_style = $sql_select_style->fetch_assoc();

            echo "<fieldset>
				<legend><strong>".$fmsg[61]."</strong></legend>
				<br /><br />";
				
				if ($error_02 != "")
					{
						echo"$error_02";
					}
				
				echo"
				<form method=\"post\" name=\"style\" action=\"".$url."admin/admin.php?action=style&#38;show=delete_style&#38;".session_name()."=".session_id()."\">
				<table style=\"width:361px\" class=\"guestbook_table2 tableCenter\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
				<tr>
				<td align=\"left\"><br />".$fmsg[59]." <strong>".$select_style['name']."</strong><br /><br /><select name=\"style\">";

            if ($sql_style->num_rows == 1) {
                $sql_style = $gbook->query("SELECT id, name FROM ".$table."_style");
            } else {
                $sql_style = $gbook->query("SELECT id, name FROM ".$table."_style WHERE id != '".$properties['default_style']."'");
            }

            while ($style_list = $sql_style->fetch_assoc()) {
                echo "<option value='".$style_list['id']."'";

                if ($style_list['id'] == $properties['default_style']) {
                    echo " selected=\"selected\"";
                }

                echo ">".$style_list['name']."</option>";
            }

            echo "</select></td>
				</tr>
				<tr>
				<td align=\"center\"><p><br /><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[62]."\" /><br /></p></td>
				</tr>
				</table>
				</form>
				</fieldset>";
        } elseif ($_GET['show'] == "make_style") {
            if (isset($_POST['send'])) {
                $sql_select_style = $gbook->query("SELECT name FROM ".$table."_style WHERE name='".$_POST['name']."'");

                if ($sql_select_style->num_rows == 0) {
                    if ($_POST['name'] == "" OR $_POST['style'] == "") {
                        echo "<br /><p class=\"zentriert red\"><strong>- ".$emsg[0]."</strong></p><br /><br />";
                    } else {
                        $sql_insert_style = $gbook->query("INSERT INTO ".$table."_style (id, name, style) VALUES ('', '".$_POST['name']."', '".$_POST['style']."')");
                        if ($sql_insert_style) {
                            echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=style&#38;show=default_style&#38;".session_name()."=".session_id()."\" />";
                        }
                    }
                } else {
                    echo "<br /><p class=\"zentriert red\"><strong>- ".$emsg[28]."</strong></p><br />";
                }
            }

            echo "<fieldset>
				<legend><strong>".$fmsg[141]."</strong></legend><br /><br />
				<form method=\"post\" action=\"".$url."admin/admin.php?action=style&#38;show=make_style&#38;".session_name()."=".session_id()."\">
				<table style=\"width:361px\" class=\"guestbook_table tableCenter\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
				<tr>
				<td align=\"center\" class=\"tdinstall2\"><p><strong><a class=\"cursor underline gray\" onclick=\"javascript:NewWindow('colors.php','colors','650','740','custom','front');return true;\">".$amsg[113]."</a></strong><br /></p></td>
				</tr>
				<tr>
				<td align=\"left\" class=\"tdinstall2\"><br /><strong>".$fmsg[142]."</strong><br /><br /><input type=\"text\" class=\"insert\" name=\"name\" value=\"";

            if (isset($_POST['name'])) {
                echo $_POST['name'];
            }

            echo "\"/><br /></td>
				</tr>
				<tr>
				<td align=\"left\" class=\"tdinstall2\"><br /><strong>".$fmsg[143]."</strong><br /><textarea class=\"insert\" rows=\"20\" name=\"style\" cols=\"68\">";

            if (isset($_POST['style'])) {
                echo $_POST['style'];
            }

            echo "</textarea></td>
				</tr>
				<tr>
				<td align=\"left\" class=\"tdinstall2\">
					<p class=\"red text-center\"><strong>".$fmsg[331]."</strong><br /></p>
					<p>&nbsp;</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;divalign&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[332].".</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;bodycolor&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[330].".</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;fontcolor&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[333].".</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;maxwidth&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[86]."</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;topcolor&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[89]."</p>
					<p>&nbsp;&nbsp;&nbsp;&#60;&#36;entriecolor&#36;&#62;&nbsp;&nbsp;&nbsp;&nbsp;".$fmsg[90]."</p>
				</td>
				</tr>
				<tr>
				<td align=\"center\" class=\"tdinstall2\"><p><br /><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[55]."\" /><br /></p></td>
				</tr>
				</table>
				</form>
				</fieldset>";
        }
    }
?>