<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    01.05.2016
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
        if (isset($_POST['send'])) {
			$gbook->query("UPDATE ".$table."_properties SET default_template='".$_POST['template']."'");
			echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=default_template&#38;".session_name()."=".session_id()."\">";
        }

        $sql_properties = $gbook->query("SELECT default_template FROM  ".$table."_properties");
        $properties = $sql_properties->fetch_assoc();

        $sql_template = $gbook->query("SELECT id, name  FROM  ".$table."_template");

        $sql_select_template = $gbook->query("SELECT name FROM ".$table."_template  WHERE id='".$properties['default_template']."'");
        $select_template = $sql_select_template->fetch_assoc();

		$width = 0;
		$height = 0;
		
        echo"<script type=\"text/javascript\">
		function confirm_template() {return confirm('".$fmsg[276]."');}
		</script>
		<fieldset>
		<legend><strong>".$fmsg[60]."</strong></legend>
		<br /><br />".$fmsg[328]."<br />
		<form style=\"float:left;width:300px;\" method=\"post\" action=\"".$url."admin/admin.php?action=default_template&#38;".session_name()."=".session_id()."\">
		<table style=\"width:200px\" class=\"guestbook_table2 right-table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">";
		
        $sql_template = $gbook->query("SELECT `id`, `name` FROM `".$table."_template`");

		while ($template_list = $sql_template->fetch_assoc())
			{
				echo"
					<tr style=\"height:45px\">
					<td align=\"left\" class=\"td-bottom\">
					<input type=\"radio\" class=\"radio\" name=\"template\" id=\"templ-".$template_list['id']."\" value=\"".$template_list['id']."\"";
															
					if (isset($_POST['template']) AND $_POST['template'] == $template_list['name'])
						{
							echo" checked=\"checked\" />  <label for=\"templ-".$template_list['id']."\"><strong style=\"color:green\">".$template_list['name']."</strong></label><br /><br />";
						}
					elseif (!isset($_POST['template']) AND $template_list['name'] == $select_template['name'])
						{
							echo" checked=\"checked\" />  <label for=\"templ-".$template_list['id']."\"><strong style=\"color:green\">".$template_list['name']."</strong></label><br /><br />";
						}
					else
						{										
							echo" /> <label for=\"templ-".$template_list['id']."\">".$template_list['name']."</label><br /><br />";
						}
					
					echo"
					</td>
					</tr>";
			}

		echo "
		<tr>
		<td align=\"right\"><br /><br /><p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[55]."\" onclick=\"return confirm_template()\" /></p></td>
		</tr>
		</table>
		</form>";
		echo"
		<table style=\"width:150px\" class=\"guestbook_table2 left-table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">";

        $sql_template_example = $gbook->query("SELECT `id` FROM `".$table."_template`");

		while ($template_example = $sql_template_example->fetch_assoc())
			{
				$x = $template_example['id'];
				
				echo"
					<tr style=\"height:45px\">
					<td align=\"left\" class=\"td-middle\">
					<button class=\"cursor\" onclick=\"document.getElementById('lightbox_$x').style.display='inline';\">Show example</button>
					</td>
					</tr>";
			}
			
		echo "
		</table>";
					
        $sql_template_example = $gbook->query("SELECT `id`, `name` FROM `".$table."_template`");

		while ($template_example = $sql_template_example->fetch_assoc())
			{
				$x = $template_example['id'];
				$img = '';
				
				echo"
				<div id=\"lightbox_$x\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('lightbox_$x').style.display='none';\">
					<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
					<tr><td align=\"center\">";

				if ($template_example['name'] == 'myPHP-GBook4_classic-R'){
					$width = "300";
					$height = "343";
					$img = '<img src="'.$url.'images/examples/templ_classic.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				if ($template_example['name'] == 'myPHP-GBook4_transp-R'){
					$width = "300";
					$height = "331";
					$img = '<img src="'.$url.'images/examples/templ_transp.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				if ($template_example['name'] == 'myPHP-GBook4_gray-R'){
					$width = "300";
					$height = "318";
					$img = '<img src="'.$url.'images/examples/templ_gray.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				if ($template_example['name'] == 'myPHP-GBook4_left-R'){
					$width = "300";
					$height = "287";
					$img = '<img src="'.$url.'images/examples/templ_left.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				if ($template_example['name'] == 'myPHP-GBook4_right-R'){
					$width = "300";
					$height = "292";
					$img = '<img src="'.$url.'images/examples/templ_right.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				if ($template_example['name'] == 'myPHP-GBook4_black-R'){
					$width = "330";
					$height = "272";
					$img = '<img src="'.$url.'images/examples/templ_black.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				if ($template_example['name'] == 'myPHP-GBook4_color-R'){
					$width = "300";
					$height = "303";
					$img = '<img src="'.$url.'images/examples/templ_color.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				if ($template_example['name'] == 'myPHP-GBook4_wide-R'){
					$width = "400";
					$height = "294";
					$img = '<img src="'.$url.'images/examples/templ_wide.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				if ($template_example['name'] == 'myPHP-GBook4_blog-R'){
					$width = "300";
					$height = "250";
					$img = '<img src="'.$url.'images/examples/templ_blog.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				if ($template_example['name'] == 'myPHP-GBook4_s-black-R'){
					$width = "400";
					$height = "396";
					$img = '<img src="'.$url.'images/examples/templ_small-black.jpg" width="'.$width.'" height="'.$height.'" alt="" />';
				}
				
				echo"<div style=\"width:".$width."px;height:".$height."px;background-color:white;\">".$img."</div></td></tr>
					</table>
				</div>";
			}
				
		echo"		
		</fieldset>";
    }
?>