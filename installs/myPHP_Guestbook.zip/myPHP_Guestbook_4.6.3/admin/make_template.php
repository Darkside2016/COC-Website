<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    19.06.2015
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
        echo "<fieldset>
		<legend><strong>".$fmsg[144]."</strong></legend>
		<br /><br />
		<form method=\"post\" action=\"".$url."admin/admin.php?action=make_template_action&#38;".session_name()."=".session_id()."\">
		<table style=\"width:380px\" class=\"guestbook_table2 tableCenter\">
		<tr>
		<td colspan=\"2\" align=\"center\"><p><strong><a class=\"cursor underline gray\" onclick=\"javascript:NewWindow('colors.php','colors','650','740','custom','front');return true;\">".$amsg[113]."</a></strong><br /><br /></p></td>
		</tr>
		<tr>
		<td align=\"left\">".$fmsg[145]."</td><td align=\"left\"><input type=\"text\" class=\"insert\" name=\"name\" /></td>
		</tr>
		<tr>
		<td align=\"left\"><br />".$fmsg[92]." <sup><strong class=\"red\">**</strong></sup></td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"bgcolor\" /></td>
		</tr>
		<tr>
		<td align=\"left\"><br />".$fmsg[96]." </td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"fontcolor\" /></td>
		</tr>
		<tr>
		<td align=\"left\"><br />".$fmsg[93]."</td>
		<td align=\"left\">
			<br />
			<select name=\"divalign\">
				<option value=\"margin-left:auto;margin-right:auto;\">".$fmsg[181]."</option>
				<option value=\"margin-left:0;margin-right:auto;\">".$fmsg[180]."</option>
				<option value=\"margin-left:auto;margin-right:0;\">".$fmsg[182]."</option>
			</select>
		</td>
		</tr>
		<tr>
		<td align=\"left\"><br />(max.) ".$fmsg[94]."</td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"tablewidth\" /></td>
		</tr>
		<tr>
		<td align=\"left\"><br />".$fmsg[98]." <sup><strong class=\"red\">**</strong></sup></td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"tdcolor\" /></td>
		</tr>
		<tr>
		<td align=\"left\"><br />".$fmsg[99]." <sup><strong class=\"red\">**</strong></sup></td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"td2color\" /></td>
		</tr>
		<tr>
		<td align=\"left\"><br />".$fmsg[100]."</td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"bgimage\" /></td>
		</tr>
		<tr>
		<td align=\"left\"><br />".$fmsg[101]."</td><td align=\"left\"><br /><select name=\"image_email\">";

		$email_dir = "../images/icons/email";

    	$emailfiles = scandir($email_dir);
    	$i = "";

		foreach ($emailfiles as $emailfile)
			{
				if ($emailfile != "." && $emailfile != ".." && $emailfile != ".htaccess" && $emailfile != "index.php")
					{
						$email_ico[$i] = $emailfile;
					}
				if (isset($email_ico[$i]) && $email_ico[$i] != "")
					{
						echo "<option value=\"".$email_ico[$i]."\">".$email_ico[$i]."</option>";
					}
			}

		echo "</select>
		</td>
		</tr>
		<tr>
		<td align=\"left\"><br />".$fmsg[102]."</td><td align=\"left\"><br /><select name=\"image_homepage\">";

		$hp_dir = "../images/icons/homepage";

    	$hpfiles = scandir($hp_dir);
    	$i = "";

		foreach ($hpfiles as $hpfile)
			{
				if ($hpfile != "." && $hpfile != ".." && $hpfile != ".htaccess" && $hpfile != "index.php")
					{
						$hp_ico[$i] = $hpfile;
					}
				if (isset($hp_ico[$i]) && $hp_ico[$i] != "")
					{
						echo "<option value=\"".$hp_ico[$i]."\">".$hp_ico[$i]."</option>";
					}
			}

		echo "</select>
		</td>
		</tr>
		<tr>
		<td align=\"left\" colspan=\"2\"><p><sup><strong class=\"red\">**</strong></sup> ".$amsg[116]."</p></td>
		</tr>
		<tr>
		<td align=\"center\" colspan=\"2\"><br /><p><input type=\"submit\" class=\"button\" name=\"send_1\" value=\"".$fmsg[14]."\" /></p></td>
		</tr>
		</table>
		</form>
		</fieldset>";
    }
?>