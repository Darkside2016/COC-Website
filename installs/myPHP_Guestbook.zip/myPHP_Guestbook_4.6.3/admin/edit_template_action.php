<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    06.02.2015
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
    	$show_select = 0;
    	$templ_error = "";
    	
		$_POST['bgcolor']	= (isset($_POST['bgcolor'])) ? $_POST['bgcolor'] : '';
		$_POST['fontcolor']	= (isset($_POST['fontcolor'])) ? $_POST['fontcolor'] : '';
		$_POST['bgimage']	= (isset($_POST['bgimage'])) ? $_POST['bgimage'] : '';
		$_POST['td2color']	= (isset($_POST['td2color'])) ? $_POST['td2color'] : '';
		$_POST['tdcolor']	= (isset($_POST['tdcolor'])) ? $_POST['tdcolor'] : '';
    	
        if (isset($_POST['send_template'])) {
            $error_msg = "";
            
            if ($_POST['bgcolor'] != "") {
                $count_col = strlen($_POST['bgcolor']);
            }
            
            if (!preg_match("/^[0-9a-z#]*$/is", $_POST['bgcolor'])) {
                $error_msg .= "<strong>- ".$emsg[69]."</strong><br />";
            }

            if ($_POST['bgcolor'] != "" && preg_match("/^[0-9a-z#]*$/is", $_POST['bgcolor']) && (($_POST['bgcolor'] != "transparent" && !preg_match("!^#([a-f0-9]{3,6})+$!i", $_POST['bgcolor'])) || ($_POST['bgcolor'] != "transparent" && $count_col > 7))) {
				$error_msg .= "<strong>- ".$emsg[71]."</strong><br />";
			}		
            
            if ($_POST['fontcolor'] == "" || $_POST['fontcolor'] == "transparent") {
            	$error_msg .= "<strong>- ".$emsg[74]."</strong><br />";
            }
            
            if ($_POST['fontcolor'] != "") {
                $count_fontcol = strlen($_POST['fontcolor']);
            }
            
            if (!preg_match("/^[0-9a-z#]*$/is", $_POST['fontcolor'])) {
                $error_msg .= "<strong>- ".$emsg[69]."</strong><br />";
            }

            if ($_POST['fontcolor'] != "" && preg_match("/^[0-9a-z#]*$/is", $_POST['fontcolor']) && (($_POST['fontcolor'] != "transparent" && !preg_match("!^#([a-f0-9]{3,6})+$!i", $_POST['fontcolor'])) || ($_POST['fontcolor'] != "transparent" && $count_fontcol > 7))) {
				$error_msg .= "<strong>- ".$emsg[71]."</strong><br />";
			}

            if ($_POST['tdcolor'] != "") {
                $count_tdcol = strlen($_POST['tdcolor']);
            }
            
            if (!preg_match("/^[0-9a-z#]*$/is", $_POST['tdcolor'])) {
                $error_msg .= "<strong>- ".$emsg[69]."</strong><br />";
            }

            if ($_POST['tdcolor'] != "" && preg_match("/^[0-9a-z#]*$/is", $_POST['tdcolor']) && (($_POST['tdcolor'] != "transparent" && !preg_match("!^#([a-f0-9]{3,6})+$!i", $_POST['tdcolor'])) || ($_POST['tdcolor'] != "transparent" && $count_tdcol > 7))) {
				$error_msg .= "<strong>- ".$emsg[71]."</strong><br />";
			}		

            if ($_POST['td2color'] != "") {
                $count_td2col = strlen($_POST['td2color']);
            }
            
            if (!preg_match("/^[0-9a-z#]*$/is", $_POST['td2color'])) {
                $error_msg .= "<strong>- ".$emsg[69]."</strong><br />";
            }

            if ($_POST['td2color'] != "" && preg_match("/^[0-9a-z#]*$/is", $_POST['td2color']) && (($_POST['td2color'] != "transparent" && !preg_match("!^#([a-f0-9]{3,6})+$!i", $_POST['td2color'])) || ($_POST['td2color'] != "transparent" && $count_td2col > 7))) {
				$error_msg .= "<strong>- ".$emsg[71]."</strong><br />";
			}

           if ($_POST['tablewidth'] == "") {
                $error_msg .= "<strong>- ".$emsg[72]."</strong><br />";
            }

            if (!preg_match("/^[0-9]*$/is", $_POST['tablewidth'])) {
                $error_msg .= "<strong>- ".$emsg[18]."</strong><br />";
            }

            if ($_POST['tablewidth'] != "" && preg_match("/^[0-9]*$/is", $_POST['tablewidth']) && $_POST['tablewidth'] < 280) {
                $error_msg .= "<strong>- ".$emsg[73]."</strong><br />";
            }

            if (!$error_msg == "") {
            	$templ_error = "<p class=\"zentriert red\">".$error_msg."</p>";
            } else {
                if ($_POST['bgcolor'] == "") {
                	$_POST['bgcolor'] = "transparent";
                }

                if ($_POST['fontcolor'] == "") {
                	$_POST['fontcolor'] = "#000000";
                }

                if ($_POST['tdcolor'] == "") {
                	$_POST['tdcolor'] = "transparent";
                }

                if ($_POST['td2color'] == "") {
                	$_POST['td2color'] = "transparent";
                }

				$sql_update_template = $gbook->query("UPDATE ".$table."_template SET bgcolor='".$_POST['bgcolor']."', bgimage='".$_POST['bgimage']."', fontcolor='".$_POST['fontcolor']."', image_email='".$_POST['image_email']."', image_homepage='".$_POST['image_homepage']."', divalign='".$_POST['divalign']."', tablewidth='".$_POST['tablewidth']."', td2color='".$_POST['td2color']."', tdcolor='".$_POST['tdcolor']."' WHERE id='".$_REQUEST['template']."'");
            }
        }

        if (!isset($_GET['html'])) {
            $sql_select_template = $gbook->query("SELECT bgcolor, bgimage, fontcolor, image_email, image_homepage, name, divalign, tablewidth, tdcolor, td2color FROM ".$table."_template WHERE id='".$_REQUEST['template']."'");
            $select_template = $sql_select_template->fetch_assoc();
        }

		$select_template['name'] = (isset($select_template['name'])) ? $select_template['name'] : "";

		if ($select_template['name'] != "myPHP-GBook4_transp-R" && $select_template['name'] != "myPHP-GBook4_black-R") {
			$show_select = 1;
		}

        if (isset($_GET['html'])) {
            if (isset($_POST['send_html'])) {
                if (isset($_POST['html']) AND $_POST['html'] == "") {
                    echo "<br /><br /><p style=\"text-align:center\"><strong>- ".$fmsg[50]."</strong></p><br /><br />";
                } else {
					$sql_update_template_html = $gbook->query("UPDATE ".$table."_template SET html = '".$_POST['html']."' WHERE id = '".$_REQUEST['template']."'");

                    if ($sql_update_template_html) {
                        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=edit_template_action&#38;template=".$_POST['template']."&#38;".session_name()."=".session_id()."\" />";
					}
				  }
            }

            $sql_select_template_html = $gbook->query("SELECT `html` FROM `".$table."_template` WHERE `id` = '".$_GET['template']."'");
            $select_template_html= $sql_select_template_html->fetch_assoc();

            echo "<fieldset>
			<legend><strong>".$fmsg[78]."</strong></legend>
			<br /><br />
			<form method=\"post\" action=\"".$url."admin/admin.php?action=edit_template_action&#38;html=1&#38;template=".$_GET['template']."&#38;".session_name()."=".session_id()."\">
			<table style=\"width:500px\" class=\"guestbook_table2 tableCenter\">
			<tr>
			<td align=\"left\" colspan=\"2\"><p><strong>HTML Code:</strong></p><textarea class=\"insert\" rows=\"20\" name=\"html\" cols=\"68\">".$select_template_html['html']."</textarea></td>
			</tr>
			<tr>
			<td align=\"left\" colspan=\"2\"><input type=\"hidden\" name=\"template\" value=\"".$_GET['template']."\" /></td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;name&#36;&#62;</td><td align=\"left\"><br />".$fmsg[79]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;origin&#36;&#62;</td><td align=\"left\"><br />".$amsg[139]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;email_icon&#36;&#62;</td><td align=\"left\"><br />".$fmsg[80]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;homepage_icon&#36;&#62;</td><td align=\"left\"><br />".$fmsg[81]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;icq_icon&#36;&#62;</td><td align=\"left\"><br />".$fmsg[200]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;quote_ico&#36;&#62;</td><td align=\"left\"><br />".$fmsg[85]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;date&#36;&#62;</td><td align=\"left\"><br />".$fmsg[171]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;time&#36;&#62;</td><td align=\"left\"><br />".$fmsg[82]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;text&#36;&#62;</td><td align=\"left\"><br />".$fmsg[83]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;comment&#36;&#62;</td><td align=\"left\"><br />".$fmsg[84]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;ip&#36;&#62;</td><td align=\"left\"><br />".$fmsg[199]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;nr&#36;&#62;</td><td align=\"left\"><br />".$fmsg[87]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;wh&#36;&#62;</td><td align=\"left\"><br />".$fmsg[88]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;done&#36;&#62;</td><td align=\"left\"><br />".$fmsg[95]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;from&#36;&#62;</td><td align=\"left\"><br />".$amsg[140]."</td>
			</tr>
			<tr>
			<td align=\"left\"><br />&#60;&#36;br&#36;&#62;</td><td align=\"left\"><br />".$amsg[143]."</td>
			</tr>
			<tr>
			<td align=\"center\" colspan=\"2\">
				<br /><p><input type=\"submit\" class=\"button\" name=\"send_html\" value=\"".$fmsg[55]."\" />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type=\"button\" class=\"button\" title=\"".$fmsg[269]."\" name=\"zurueck\" value=\"".$fmsg[269]."\" onclick=\"self.location.href='admin.php?action=edit_template&#38;".session_name()."=".session_id()."'\" /></p>
			</td>
			</tr>
			</table>
			</form>
			</fieldset>";
        } else {
			($select_template['bgcolor'] == "transparent") ? ($bgcolor_select = "background-image:url(".$url."images/transparent.jpg)") : ($bgcolor_select = "background-color:".$select_template['bgcolor']."");
			($select_template['tdcolor'] == "transparent") ? ($tdcolor_select = "background-image:url(".$url."images/transparent.jpg)") : ($tdcolor_select = "background-color:".$select_template['tdcolor']."");
			($select_template['td2color'] == "transparent") ? ($td2color_select = "background-image:url(".$url."images/transparent.jpg)") : ($td2color_select = "background-color:".$select_template['td2color']."");

            echo "<fieldset>
			<legend><strong>".$amsg[110]."</strong></legend>
			<br /><br />$templ_error
			<form method=\"post\" action=\"".$url."admin/admin.php?action=edit_template_action&#38;".session_name()."=".session_id()."\">
			<table style=\"width:440px\" class=\"guestbook_table2 tableCenter\">
			<tr>
			<td colspan=\"3\" align=\"center\"><p><strong><a class=\"cursor underline gray\" onclick=\"javascript:NewWindow('colors.php','colors','650','740','custom','front');return true;\">".$amsg[113]."</a></strong><br /><br /></p></td>
			</tr>
			<tr>
			<td align=\"left\">".$fmsg[92]." <sup><strong class=\"red\">**</strong></sup></td><td align=\"left\"><input type=\"text\" class=\"insert\" name=\"bgcolor\" value=\"".$select_template['bgcolor']."\" /></td><td><input type=\"text\" size=\"4\" style=\"".$bgcolor_select.";\" value=\"\" readonly=\"readonly\" /></td>
			</tr>
			<tr>
			<td align=\"left\"><br />".$fmsg[96]." </td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"fontcolor\" value=\"".$select_template['fontcolor']."\" /></td><td><br /><input type=\"text\" size=\"4\" style=\"background-color:".$select_template['fontcolor']."\" value=\"\" readonly=\"readonly\" /></td>
			</tr>
			<tr>
			<td align=\"left\"><br />".$fmsg[93]."</td><td align=\"left\"><br /><select name=\"divalign\">
			<option value=\"margin-left:auto;margin-right:auto;\"";

            if ($select_template['divalign'] == "margin-left:0;margin-right:auto;") {
                echo " selected=\"selected\"";
            }

            echo ">".$fmsg[181]."</option>
			<option value=\"margin-left:0;margin-right:auto;\"";

            if ($select_template['divalign'] == "margin-left:0;margin-right:auto;") {
                echo " selected=\"selected\"";
            }

            echo ">".$fmsg[180]."</option>
			<option value=\"margin-left:auto;margin-right:0;\"";

            if ($select_template['divalign'] == "margin-left:auto;margin-right:0;") {
                echo " selected=\"selected\"";
            }

            echo ">".$fmsg[182]."</option>
			</select></td><td></td>
			</tr>
			<tr>
			<td align=\"left\"><br />(max.) ".$fmsg[94]."</td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"tablewidth\" value=\"".$select_template['tablewidth']."\" /></td><td></td>
			</tr>
			";

			if ($show_select) {
				if ($select_template['name'] != "myPHP-GBook4_gray-R" AND $select_template['name'] != "myPHP-GBook4_blog-R"){
					echo"<tr>
					<td align=\"left\"><br />";
					
						($select_template['name'] == "myPHP-GBook4_color-R" || $select_template['name'] == "myPHP-GBook4_blog-R") ? ($tdcolor = $fmsg[327]) : ($tdcolor = $fmsg[98]);
					
					echo"".$tdcolor." <sup><strong class=\"red\">**</strong></sup></td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"tdcolor\" value=\"".$select_template['tdcolor']."\" /></td><td><br /><input type=\"text\" size=\"4\" style=\"".$tdcolor_select."\" value=\"\" readonly=\"readonly\" /></td>
					</tr>";
				}
				
				echo"
					<tr>
					<td align=\"left\"><br />".$fmsg[99]." <sup><strong class=\"red\">**</strong></sup></td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"td2color\" value=\"".$select_template['td2color']."\" /></td><td><br /><input type=\"text\" size=\"4\" style=\"".$td2color_select."\" value=\"\" readonly=\"readonly\" /></td>
					</tr>";
			}
			
			echo"
			<tr>
			<td align=\"left\"><br />".$fmsg[100]."</td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"bgimage\" value=\"".$select_template['bgimage']."\" /></td><td></td>
			</tr>
			<tr>
			<td align=\"left\"><br />".$fmsg[101]."</td><td align=\"left\"><br /><select name=\"image_email\">";

				$email_dir = "../images/icons/email";

        		$emailfiles = scandir($email_dir);
        		$i = "";

				foreach ($emailfiles as $emailfile)
					{
						if ($emailfile != "." && $emailfile != ".." && $emailfile != ".htaccess" && $emailfile != "index.php")
							{
								$email_ico[$i] = $emailfile;
							}
						if (isset($email_ico[$i]) && $email_ico[$i] != "")
							{
								echo "<option value=\"".$email_ico[$i]."\"";

										if ($email_ico[$i] == $select_template['image_email'])
											{
												echo " selected=\"selected\"";
											}
									
										echo ">".$email_ico[$i]."</option>";
							}
					}

            echo "</select></td><td align=\"center\" valign=\"bottom\"><img src=\"".$url."images/icons/email/".$select_template['image_email']."\" alt=\"".$select_template['image_email']."\" /></td>
			</tr>
			<tr>
			<td align=\"left\"><br />".$fmsg[102]."</td><td align=\"left\"><br /><select name=\"image_homepage\">";

				$hp_dir = "../images/icons/homepage";

        		$hpfiles = scandir($hp_dir);
        		$i = "";

				foreach ($hpfiles as $hpfile)
					{
						if ($hpfile != "." && $hpfile != ".." && $hpfile != ".htaccess" && $hpfile != "index.php")
							{
								$hp_ico[$i] = $hpfile;
							}
						if (isset($hp_ico[$i]) && $hp_ico[$i] != "")
							{
								echo "<option value=\"".$hp_ico[$i]."\"";

										if ($hp_ico[$i] == $select_template['image_homepage'])
											{
												echo " selected=\"selected\"";
											}
									
										echo ">".$hp_ico[$i]."</option>";
							}
					}

            echo "</select></td><td align=\"center\" valign=\"bottom\"><img src=\"".$url."images/icons/homepage/".$select_template['image_homepage']."\" alt=\"".$select_template['image_homepage']."\" /></td>
			</tr>
			<tr>
			<td align=\"left\" colspan=\"3\">
				<p><sup><strong class=\"red\">**</strong></sup> ".$amsg[116]."<input type=\"hidden\" name=\"template\" value=\"".$_REQUEST['template']."\" /></p>
			</td>
			</tr>
			<tr>
			<td align=\"center\" colspan=\"3\">
				<br /><p><input type=\"submit\" class=\"button\" name=\"send_template\" value=\"".$fmsg[55]."\" />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type=\"button\" class=\"button\" title=\"".$fmsg[269]."\" name=\"zurueck\" value=\"".$fmsg[269]."\" onclick=\"self.location.href='admin.php?action=edit_template&#38;".session_name()."=".session_id()."'\" /></p>
			</td>
			</tr>
			<tr>
			<td align=\"center\" colspan=\"3\"><p><strong><a class=\"underline gray\" href=\"".$url."admin/admin.php?action=edit_template_action&#38;html=1&#38;template=".$_REQUEST['template']."&#38;".session_name()."=".session_id()."\">".$fmsg[208]."</a></strong></p></td>
			</tr>
			</table>
			</form>
			</fieldset>";
        }
    }
?>