<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    06.02.2015
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
        if (isset($_POST['send_1'])) {
            $sql_select_template = $gbook->query("SELECT  name  FROM  ".$table."_template  WHERE  name='".$_POST['name']."'");

            if ($sql_select_template->num_rows == 0) {
                $error_msg = "";

                if (!preg_match("/^[0-9]*$/is", $_POST['tablewidth'])) {
                    $error_msg .= "<strong>- ".$emsg[18]."</strong><br />";
                }

	            if ($_POST['tablewidth'] != "" && preg_match("/^[0-9]*$/is", $_POST['tablewidth']) && $_POST['tablewidth'] < 280) {
	                $error_msg .= "<strong>- ".$emsg[73]."</strong><br />";
	            }

                if ($_POST['name'] == "" OR $_POST['tablewidth'] == "" OR $_POST['fontcolor'] == "") {
                    $error_msg .= "<strong>- ".$emsg[0]."</strong><br /><br />(".$fmsg[145]." -- ".$fmsg[96].": -- ".$fmsg[94].")<br />";
                }
                
                if ($_POST['bgcolor'] == "") {
                	$_POST['bgcolor'] = "transparent";
                }

                if ($_POST['tdcolor'] == "") {
                	$_POST['tdcolor'] = "transparent";
                }

                if ($_POST['td2color'] == "") {
                	$_POST['td2color'] = "transparent";
                }

                if (!$error_msg == "") {
                    echo "<br /><br /><p class=\"zentriert red\">".$error_msg."</p><br />
                    	<p class=\"aligncenter\"><input type=\"button\" class=\"button\" title=\"".$fmsg[4]."\" name=\"abbruch\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='admin.php?action=make_template&#38;".session_name()."=".session_id()."'\" /></p>";
                } else {
                    $_SESSION['bgcolor']        = $_POST['bgcolor'];
                    $_SESSION['bgimage']        = $_POST['bgimage'];
                    $_SESSION['fontcolor']      = $_POST['fontcolor'];
                    $_SESSION['image_email']    = $_POST['image_email'];
                    $_SESSION['image_homepage'] = $_POST['image_homepage'];
                    $_SESSION['name']           = $_POST['name'];
                    $_SESSION['divalign']       = $_POST['divalign'];
                    $_SESSION['tablewidth']     = $_POST['tablewidth'];
                    $_SESSION['tdcolor']        = $_POST['tdcolor'];
                    $_SESSION['td2color']       = $_POST['td2color'];

                    echo "<fieldset>
					<legend><strong>".$fmsg[78]."</strong></legend>
					<br /><br />
					<form method=\"post\" action=\"".$url."admin/admin.php?action=make_template_action&#38;".session_name()."=".session_id()."\">
					<table style=\"width:361px\" class=\"guestbook_table2 tableCenter\">
					<tr>
					<td align=\"left\" colspan=\"2\"><p><strong>HTML Code:</strong></p><textarea class=\"insert\" rows=\"20\" name=\"html\" cols=\"68\"></textarea></td>
					</tr>
					<tr>
					<td align=\"left\" colspan=\"2\"></td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;name&#36;&#62;</td><td align=\"left\"><br />".$fmsg[79]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;origin&#36;&#62;</td><td align=\"left\"><br />".$amsg[139]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;email_icon&#36;&#62;</td><td align=\"left\"><br />".$fmsg[80]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;homepage_icon&#36;&#62;</td><td align=\"left\"><br />".$fmsg[81]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;icq_icon&#36;&#62;</td><td align=\"left\"><br />".$fmsg[200]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;quote_ico&#36;&#62;</td><td align=\"left\"><br />".$fmsg[85]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;date&#36;&#62;</td><td align=\"left\"><br />".$fmsg[171]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;time&#36;&#62;</td><td align=\"left\"><br />".$fmsg[82]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;text&#36;&#62;</td><td align=\"left\"><br />".$fmsg[83]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;comment&#36;&#62;</td><td align=\"left\"><br />".$fmsg[84]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;ip&#36;&#62;</td><td align=\"left\"><br />".$fmsg[199]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;nr&#36;&#62;</td><td align=\"left\"><br />".$fmsg[87]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;wh&#36;&#62;</td><td align=\"left\"><br />".$fmsg[88]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;done&#36;&#62;</td><td align=\"left\"><br />".$fmsg[95]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;from&#36;&#62;</td><td align=\"left\"><br />".$amsg[140]."</td>
					</tr>
					<tr>
					<td align=\"left\"><br />&#60;&#36;br&#36;&#62;</td><td align=\"left\"><br />".$amsg[143]."</td>
					</tr>
					<tr>
					<td align=\"center\" colspan=\"2\"><br /><p><input type=\"submit\" class=\"button\" name=\"send_2\" value=\"".$fmsg[132]."\" /></p></td>
					</tr>
					</table>
					</form>
					</fieldset>";
                }
            } else {
                echo "<br /><br /><p class=\"zentriert\"><strong>- ".$emsg[29]."</strong></p><br />";
            }
        }
    }

    if (isset($_POST['send_2'])) {
        if ($_POST['html'] == "") {
            echo "<br /><br /><p class=\"zentriert\"><strong>- ".$amsg[79]."</strong></p><br /><br />";
        } else {
            $sql_template_insert = $gbook->query("INSERT INTO ".$table."_template (bgcolor, bgimage, fontcolor, id, image_email, image_homepage, name, divalign, tablewidth, tdcolor, td2color, html) VALUES

                                                    ('".$_SESSION['bgcolor']."',
                                                     '".$_SESSION['bgimage']."',
                                                     '".$_SESSION['fontcolor']."',
                                                     '',
                                                     '".$_SESSION['image_email']."',
                                                     '".$_SESSION['image_homepage']."',
                                                     '".$_SESSION['name']."',
                                                     '".$_SESSION['divalign']."',
                                                     '".$_SESSION['tablewidth']."',
                                                     '".$_SESSION['tdcolor']."',
                                                     '".$_SESSION['td2color']."',
                                                     '".$_POST['html']."')");

            unset($_SESSION['bgcolor']);
            unset($_SESSION['bgimage']);
            unset($_SESSION['fontcolor']);
            unset($_SESSION['image_email']);
            unset($_SESSION['image_homepage']);
            unset($_SESSION['name']);
            unset($_SESSION['divalign']);
            unset($_SESSION['tablewidth']);
            unset($_SESSION['tdcolor']);
            unset($_SESSION['td2color']);

            if ($sql_template_insert) {
                echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=default_template&#38;".session_name()."=".session_id()."\" />";
            }
        }
    }
?>