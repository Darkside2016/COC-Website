<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    01.10.2015
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
	} else {
		$sql_properties = $gbook->query("SELECT `bbcode`, `images_in_entries` FROM `".$table."_properties`");
		$properties = $sql_properties->fetch_assoc();

		if ($properties['bbcode'] && $properties['images_in_entries']) {
			$sql_zahl_eintraege = $gbook->query("SELECT `id` FROM `".$table."_pictures`");
			$zahl_eintraege = $sql_zahl_eintraege->num_rows;
			$eintraege_pro_seite = 3;
			$anzeige_zahl_seiten = 10;
	
	        if (isset($_GET['page'])) {
	            if (!is_numeric($_GET['page']) OR empty($_GET['page'])) {
	                $page = 1;
	            } else {
	                $page = $_GET['page'];
	            }
	        } else {
	            $page = 1;
	        }
	
	        $page               = $gbook->real_escape_string($page);
	        $pages_total        = ceil($zahl_eintraege/$eintraege_pro_seite) ;
	        $page_start         = floor($page - $anzeige_zahl_seiten/2) ;
	        $page_start         = $page_start <= 0 ?  1 : $page_start ;
	        $page_end           = ($page_start + $anzeige_zahl_seiten-1) ;
	        $page_end           = $page_end >= $pages_total ?  $pages_total : $page_end ;
	        $page_max           = $page*$eintraege_pro_seite;
	        $max_minus_per_page = $page_max-$eintraege_pro_seite;
	        $page_entry_start   = $zahl_eintraege-$max_minus_per_page+1;
	        
	        echo"
			<p class=\"aligncenter\">
				<strong>".$amsg[93]."</strong>
			</p>
			<p><a id=\"anchor-foto0610\" name=\"anchor-foto0610\"></a>&nbsp;</p>
			<p class=\"aligncenter\">
				<a href=\"".$url."admin/admin.php?action=edit_guest_pictures&#38;show=new_guestpic&#38;".session_name()."=".session_id()."\">".$amsg[94]."</a>
			</p>
			<p>&nbsp;</p>";
		
			if ($zahl_eintraege < 1) {
				echo"<p>&nbsp;</p>
					<p class=\"text-center\"><strong>".$amsg[112]."</strong></p>
					";
			}
			else {
					echo"
					<script type=\"text/javascript\">
						function confirm_delete() {return confirm('".$amsg[95]."');}
					</script>
					<div class=\"aligncenter\">
					";
	
			        if ($page > 1) {
			            $page_minus = $page-1;
						echo " <a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=".$page_minus."&#38;".session_name()."=".session_id()."\"><img src=\"".$url."images/links.gif\" alt=\"".$fmsg[4]."\" /></a>&nbsp;&nbsp;&nbsp;";
			        }
			
			        if ($page_start > 1) {
						echo " <a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=1&#38;".session_name()."=".session_id()."\">1</a> ...";
			        }
			
			        for ($i = $page_start; $i <= $page_end ;$i++) {
			            if ($i == $page) {
			                echo "&nbsp;<strong>".$i."</strong>&nbsp;&nbsp;";
			            } else {
			                echo " <a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=".$i."&#38;".session_name()."=".session_id()."\">&nbsp;".$i."&nbsp;</a>&nbsp;&nbsp;";
			            }
			        }
			
			        if ($page_end < $pages_total) {
			            echo " ... <a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=".$pages_total."&#38;".session_name()."=".session_id()."\">".$pages_total."</a>";
			        }
			
			        if ($page < $pages_total) {
			            $page_plus = $page+1;
			            echo "&nbsp;&nbsp;&nbsp;<a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=".$page_plus."&#38;".session_name()."=".session_id()."\"><img src=\"".$url."images/rechts.gif\" alt=\"".$fmsg[14]."\" /></a>";
			        }
			
					echo"
						</div>
						<p>&nbsp;</p>
						";
		
					echo"<form method=\"post\" action=\"".$url."admin/admin.php?action=guest_pictures#anchor-foto0610&#38;".session_name()."=".session_id()."\">
						<table style=\"width:100%\" class=\"guestbook_table tableCenter\" border=\"1\" rules=\"rows\" frame=\"below\" cellspacing=\"0\" cellpadding=\"0\">";
		
				            if (isset($_POST['send']) AND isset($_POST['entry']))
								{
					                $y = count($_POST['entry']);
		
					                for ($x=0;$x<$y;$x++)
										{
						                    $entry_id = $_POST['entry'][$x];
		
											$sql_select_dateiname = $gbook->query("SELECT  `pic_name`  FROM  `".$table."_pictures`  WHERE  id='$entry_id'");
											$select_dateiname = $sql_select_dateiname->fetch_assoc();
			
											unlink("../img_guest/".$select_dateiname['pic_name']."");
		
						                    $update_guestfoto = $gbook->query("DELETE FROM `".$table."_pictures` WHERE id='$entry_id'");
		
											if ($update_guestfoto)
												{		
				                       				echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=guest_pictures#anchor-foto0610&#38;".session_name()."=".session_id()."\" />";
												}
						                }
								}
		
					$sql_guestfoto = $gbook->query("SELECT * FROM `".$table."_pictures` ORDER BY `id` DESC LIMIT ".(($page-1)*$eintraege_pro_seite ).",".$eintraege_pro_seite."");
		
					while ($guestfoto = $sql_guestfoto->fetch_assoc()) {
						$page_entry_start = $page_entry_start-1;
		
						$guestfoto['pic_name'] 	= htmlentities(strip_tags($guestfoto['pic_name']), ENT_QUOTES, "UTF-8");
						$guestfoto['title'] 	= htmlentities(strip_tags($guestfoto['title']), ENT_QUOTES, "UTF-8");
						
						$maxpicwidth = '550';
						$newwidth = $guestfoto['width'];
						$newheight = $guestfoto['height'];
						
						if ($guestfoto['width'] > $maxpicwidth){
							$prozent = $maxpicwidth/$guestfoto['width'];
							$newwidth = floor($guestfoto['width']*$prozent);
							$newheight = floor($guestfoto['height']*$prozent);
						}
					
						echo"
						<tr style=\"height:40px\" class=\"tdinstall1 size-10\">
							<td style=\"width:110px\" align=\"center\"><p>".$amsg[54]."</p></td>
							<td style=\"width:100px\" align=\"center\"><p>".$amsg[71]."</p></td>
							<td style=\"width:40px\" align=\"center\"><p>".$fmsg[67]."</p></td>
							<td style=\"width:40px\" align=\"center\"><p>".$fmsg[68]."</p></td>
							<td align=\"center\"><p>".$amsg[97]."</p></td>
							<td style=\"width:80px\" align=\"center\"><p>".$amsg[55]."<br />".$amsg[56]."</p></td>
							<td style=\"width:30px\" align=\"center\">&nbsp;</td>
							<td style=\"width:30px\" align=\"center\"><p><img title=\"".$amsg[58]."\" src=\"../images/delete.png\" width=\"14\" height=\"14\" alt=\"".$amsg[58]."\" /></p></td>
						</tr>
						<tr style=\"height:40px\" class=\"tdinstall2 size-10\">
							<td>".$guestfoto['ip']."</td>
							<td>".$guestfoto['pic_name']."</td>
							<td>".$guestfoto['width']."</td>
							<td>".$guestfoto['height']."</td>
							<td>".$guestfoto['title']."</td>
							<td>".$guestfoto['date']."<br />".$guestfoto['time']."</td>
							<td><a href=\"".$url."admin/admin.php?action=edit_guest_pictures&#38;show=edit_guestpic&#38;id=".$guestfoto['id']."&#38;".session_name()."=".session_id()."\"><img title=\"".$amsg[96]."\" src=\"../images/edit.png\" width=\"14\" height=\"14\" alt=\"".$amsg[96]."\" /></a></td>
							<td><input type=\"checkbox\" name=\"entry[]\" value=\"".$guestfoto['id']."\" /></td>
						</tr>
						<tr>
							<td colspan=\"8\" align=\"center\" class=\"tdinstall2\">
								<br /><img class=\"centered\" title=\"".$guestfoto['title']."\" src=\"".$url."img_guest/".$guestfoto['pic_name']."\" alt=\"".$guestfoto['title']."\" width=\"".$newwidth."\" height=\"".$newheight."\" /><br />
							</td>
						</tr>
						<tr>
							<td colspan=\"8\" align=\"center\" class=\"tdinstall2\">
								<p><input type=\"submit\" class=\"button\" name=\"send\" title=\"".$fmsg[166]."\" value=\"".$fmsg[166]."\" onclick=\"return confirm_delete()\" /></p>
							</td>
						</tr>";
					}
		
					echo"
						<tr><td colspan=\"6\"></td></tr>
					</table>
					</form>
					<p>&nbsp;</p>
					<p class=\"aligncenter\">";
			
			        if ($page > 1) {
			            $page_minus = $page-1;
			            echo " <a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=".$page_minus."&#38;".session_name()."=".session_id()."\"><img src=\"".$url."images/links.gif\" alt=\"".$fmsg[4]."\" /></a>&nbsp;&nbsp;&nbsp;";
			        }
			
			        if ($page_start > 1) {
			            echo " <a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=1&#38;".session_name()."=".session_id()."\">1</a> ...";
			        }
			
			        for ($i = $page_start; $i <= $page_end ;$i++) {
			            if ($i == $page) {
			                echo "&nbsp;<strong>".$i."</strong>&nbsp;&nbsp;";
			            } else {
			                echo " <a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=".$i."&#38;".session_name()."=".session_id()."\">&nbsp;".$i."&nbsp;</a>&nbsp;&nbsp;";
			            }
			        }
			
			        if ($page_end < $pages_total) {
			            echo " ... <a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=".$pages_total."&#38;".session_name()."=".session_id()."\">".$pages_total."</a>";
			        }
			
			        if ($page < $pages_total) {
			            $page_plus = $page+1;
			            echo "&nbsp;&nbsp;&nbsp;<a href=\"".$url."admin/admin.php?action=guest_pictures&#38;page=".$page_plus."&#38;".session_name()."=".session_id()."\"><img src=\"".$url."/images/rechts.gif\" alt=\"".$fmsg[14]."\" /></a>";
			        }
		
					echo "</p>
					<p>&nbsp;</p>";
			}
		}
		else {
			echo"<fieldset><legend><strong>".$amsg[98]."</strong></legend>
				<p>&nbsp;</p>
				<p>".$amsg[99]."</p>
				<p>".$amsg[100]."</p>
				<p>&nbsp;</p>
				</fieldset>
				<p>&nbsp;</p>";
		}
	}
    
?>
