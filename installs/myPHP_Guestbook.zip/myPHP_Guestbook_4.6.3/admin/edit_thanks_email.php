<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/
    
	if (!isset($_SESSION['sid'])) {
		echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
	} else {
		if (isset($_GET['show']) && ($_GET['show'] == "guest_mail" || $_GET['show'] == "edit_guest_mail")) {
			$_GET['show'] = $_GET['show'];
		}
		else {
			$_GET['show'] = "guest_mail";
		}
	
		$sql_select_properties = $gbook->query("SELECT `admin_email`, `thanks_email` FROM `".$table."_properties`");
    	$select_properties = $sql_select_properties->fetch_assoc();
	    	
		if ($select_properties['thanks_email'] == 1) {
			$guest_thanks = '<img title="Yes" src="../images/ok.png" width="14" height="14" alt="Yes" />';
			$warning = '';
			$text_thanks = 'background-color:#f2f2f2;';
			$write_or_read = '';
		}
		else {
			$guest_thanks = '<img title="No" src="../images/delete.png" width="14" height="14" alt="No" />';
			$warning = '<p>'.$amsg[136].'<br /></p>';
			$text_thanks = 'background-color:#ffadad;opacity: .3;filter:Alpha(Opacity=30);';
			$write_or_read = ' readonly="readonly"';
		}
	
		$sql_select = $gbook->query("SELECT `thanks`, `noreply` FROM `".$table."_thankyou` WHERE `lang` = '".$lang_short."'");
		$select_input = $sql_select->fetch_assoc();

		$guest_text = $select_input['thanks'];
		$guest_text = htmlentities(strip_tags(trim($guest_text)), ENT_QUOTES, "UTF-8");
		$guest_text = nl2br($guest_text);
		$guest_text = stripslashes($guest_text);

		$mail_reply = $select_input['noreply'];
		$mail_reply = htmlentities(strip_tags(trim($mail_reply)), ENT_QUOTES, "UTF-8");
		$mail_reply = stripslashes($mail_reply);
		
		echo"<fieldset>
			<legend><strong>".$amsg[131]."</strong></legend>
			<br /><br />
			<table class=\"guestbook_table2 tableCenter\" style=\"width:480px;\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
				<tr>
					<td align=\"center\">
						<p><strong>".$amsg[132]."</strong></p>
					</td>
				</tr>
				<tr>
					<td align=\"center\">
						<p>".$amsg[184]."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"".$url."includes/flags/".$lang_short.".png\" title=\"".$amsg[183]."\" alt=\"".$language."\" /></p>
					</td>
				</tr>
				<tr>
					<td align=\"center\">
							<p>".$amsg[137]."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$guest_thanks."</p>
					</td>
				</tr>
				<tr>
					<td>
						$warning
					</td>
				</tr>
			</table>";

		if ($_GET['show'] == "guest_mail") {
			echo"		
				<table class=\"guestbook_table tableCenter\" style=\"width:480px;\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
					<tr>
						<td align=\"left\" class=\"tdinstall2\">
							<p>&nbsp;</p>
							<p>".$amsg[151]."</p><strong class=\"aligncenter\"><a title=\"".$amsg[150]."\" href=\"javascript:{}\" onclick=\"document.getElementById('reply_link').style.display='inline';return false;\">".$amsg[150]."!</a></strong>
							<p style=\"padding:8px;".$text_thanks."\">";
							
								if ($mail_reply != "") {
									echo"".$mail_reply."";
								}
								else {
									echo"<span style=\"opacity: .3;filter:Alpha(Opacity=30);\">".$select_properties['admin_email']."</span>";
								}
								
							echo"</p>
						</td>
					</tr>";
				echo"
					<tr>
						<td align=\"center\">
							<div id=\"reply_link\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('reply_link').style.display='none';\">
							<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
								<tr>
									<td align=\"center\">
										<div style=\"width:300px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$amsg[150].":</strong></span><br />".$amsg[152]."</div>
									</td>
								</tr>
							</table>
							</div>
						</td>
					</tr>";
				echo"
					<tr>
						<td align=\"left\" class=\"tdinstall2\">
							<p>&nbsp;</p>
							<p><strong>".$amsg[135].":</strong></p>
							<p style=\"padding:8px;".$text_thanks."\">".$guest_text."</p>
						</td>
					</tr>
				</table>
				<p class=\"aligncenter\">
					<strong><a class=\"underline gray\" href=\"".$url."admin/admin.php?action=thanks_email&#38;show=edit_guest_mail&#38;".session_name()."=".session_id()."\">".$amsg[138]."</a></strong>
				</p>
				<p>&nbsp;</p>";
		}
		
		elseif ($_GET['show'] == "edit_guest_mail") {
				$error_guestmail_options = "";
				
				$select_input['thanks'] = stripslashes(htmlentities(strip_tags(trim($select_input['thanks'])), ENT_QUOTES, "UTF-8"));
				$select_input['noreply'] = stripslashes(htmlentities(strip_tags(trim($select_input['noreply'])), ENT_QUOTES, "UTF-8"));

				$error_msg = "";
				$max_mail_lenght = "";
				$max_chars = "400";
				
				$_POST['text'] = (isset($_POST['text'])) ? $_POST['text'] : '';
				$_POST['reply'] = (isset($_POST['reply'])) ? trim($_POST['reply']) : '';
				
				$count_mailtext = $_POST['text'];
				$orig 		= array("ö","Ö","ä","Ä","ü","Ü","ß","€","@","\\r","\\n","\r\n");
				$fake 		= " ";
				$count_mailtext = str_replace($orig, $fake, $count_mailtext);
				$mail_length = strlen($count_mailtext);
				$still_poss_mail_lenght = ($max_chars - $mail_length);
				
				($still_poss_mail_lenght < $max_chars) ? ($max_mail_lenght = "<p class=\"aligncenter marg-five\">(".$fmsg[316]." <span id=\"charleft\">".$still_poss_mail_lenght."</span>)</p>") : ($max_mail_lenght = "<p class=\"aligncenter marg-five\">(".$fmsg[316]." <span id=\"charleft\" class=\"gray\">-".$amsg[144]."-</span>)</p>");
				($still_poss_mail_lenght < 0) ? ($imposs_mail_lenght = "<p class=\"error\"><strong>- ".$fmsg[317]." ".-$still_poss_mail_lenght." ".$fmsg[315].".</strong></p>") : "";

			if (isset($_POST['send_text'])) {
				$error_msg = "";
	
				if ($_POST['text'] == "") {
	                    $error_msg = "<p class=\"zentriert red\"><strong>- ".$emsg[44]."</strong></p>";
				}
				elseif ($mail_length > $max_chars) {
                    $error_msg = "<p class=\"zentriert red\"><strong>- ".$emsg[32]."".$imposs_mail_lenght."</strong></p>";
				}
				
				if($_POST['reply'] != "" AND !validate_mail($_POST['reply'])){
		   			$error_msg .= "<p class=\"zentriert red\"><strong>- ".$emsg[2]."</strong></p>";
				}
				
				if ($error_msg != "") {
					$error_guestmail_options = ''.$error_msg.'<br />';
				}
				else {
					$_POST['text'] = $gbook->real_escape_string($_POST['text']);
					$_POST['reply'] = $gbook->real_escape_string($_POST['reply']);

					$sql_update_thankyou = $gbook->query("UPDATE `".$table."_thankyou` SET `thanks` = '".$_POST['text']."', `noreply` = '".$_POST['reply']."'  WHERE `lang` = '".$lang_short."'");
	
					if ($sql_update_thankyou) {
						echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=thanks_email&#38;show=guest_mail&#38;".session_name()."=".session_id()."\" />";
					}
				}
			}
	
			echo"
				<form method=\"post\" action=\"".$url."admin/admin.php?action=thanks_email&#38;show=edit_guest_mail&#38;".session_name()."=".session_id()."\">
				<table style=\"width:480px\" class=\"guestbook_table tableCenter\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
					<tr>
						<td align=\"center\" class=\"tdinstall2\">$error_guestmail_options
							<p>&nbsp;</p>
							<p class=\"text-left\" style=\"margin-left:8px;\">".$amsg[151]."</p><strong class=\"aligncenter\"><a title=\"".$amsg[150]."\" href=\"javascript:{}\" onclick=\"document.getElementById('reply_link').style.display='inline';return false;\">".$amsg[150]."!</a></strong>
							<p><input type=\"text\" class=\"insert\" name=\"reply\" size=\"20\" style=\"width:95%;padding:4px;".$text_thanks."\" maxlength=\"50\"".$write_or_read." value=\"";
							
								if ($select_input['noreply'] != "") {
									echo"".$select_input['noreply']."";
									$placeholder = "";
								}
								else {
									$placeholder = " placeholder=\"".$select_properties['admin_email']."\"";
								}
								
								echo"\"$placeholder /></p>
						</td>
					</tr>";
				echo"
					<tr>
						<td align=\"center\">
							<div id=\"reply_link\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('reply_link').style.display='none';\">
							<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
								<tr>
									<td align=\"center\">
										<div style=\"width:300px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$amsg[150].":</strong></span><br />".$amsg[152]."</div>
									</td>
								</tr>
							</table>
							</div>
						</td>
					</tr>";
				echo"					
					<tr>
						<td align=\"center\" class=\"tdinstall2\">
							<p class=\"text-left\" style=\"margin-left:8px;\"><strong>".$amsg[135].":</strong></p>
							<textarea style=\"width:95%;padding:4px;".$text_thanks."\" onkeyup=\"textCounter()\" onblur=\"textCounter()\" id=\"text\" name=\"text\" class=\"insert\" rows=\"13\" cols=\"60\"".$write_or_read.">".$select_input['thanks']."</textarea>
							$max_mail_lenght
						</td>
					</tr>
					<tr>
						<td align=\"center\" class=\"tdinstall2\">
							<p><br /><input type=\"submit\" class=\"button\" name=\"send_text\" value=\"".$fmsg[55]."\" /></p>
							<p><br /><input type=\"button\" class=\"button\" title=\"".$fmsg[4]."\" name=\"abbruch\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='admin.php?action=thanks_email&#38;show=guest_mail&#38;".session_name()."=".session_id()."'\" /></p>
							<p>&nbsp;</p>
						</td>
					</tr>
				</table>
				</form>";
			
			echo"
			<script type=\"text/javascript\">function textCounter(){var counttext = document.getElementById('text').value.replace(/\\r?\\n/g, \"\\r\").length + 1;var freetext = 400 - counttext + 1; if(freetext < 0){document.getElementById('text').value = document.getElementById('text').value.substr(0, 400);freetext = 0;}var rest = document.getElementById('charleft');rest.innerHTML = freetext;return true;}</script>";
		}
		echo"
			</fieldset>";
	}
				
?>