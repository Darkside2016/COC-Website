<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

	if (!isset($_SESSION['sid'])) {
		echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
	} else {
		echo '<a id="anchor-pagetop" name="anchor-pagetop"></a>
			<fieldset>
				<legend><strong class="size-16">Dokumentation <span class="italic">myPHP Guestbook '.$version.'</span></strong><br />(Nur in Deutsch od. Portugiesisch / Only in German or Portuguese)</legend>
				<div class="help">';
					
					$sql_language = $gbook->query("SELECT `language` FROM `".$table."_properties`");
					$language  = $sql_language->fetch_assoc();
					
					if ($language['language'] == "pt") {
						include ("faq/pt_faq.php");
					}
					else {
						include ("faq/de_faq.php");
					}
		
			echo'
				</div>
			</fieldset>';
	}
?>