<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    	}
    else {
    		$error_gbook_options = "";
    		$thyo_lang = "";
			$allowed_characters = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿß';
    		
			if (isset($_POST['send'])) {
	            $error_msg = "";
	
				if ((SPAM_PROTECT && $_POST['spam_marker'] != "") && ((!preg_match("/^[0-9]*$/is", $_POST['spam_marker']) OR $_POST['spam_marker'] < 1 OR $_POST['spam_marker'] > 20))) {
					$error_msg .="- ".$emsg[40]."<br />";
				}
					
				if ((isset($_POST['no_spam_links']) && $_POST['no_spam_links'] == 1) && (isset($_POST['max_links']) && (!preg_match("/^[0-9]*$/is", $_POST['max_links']) OR $_POST['max_links'] < 0 OR $_POST['max_links'] > 20))) {
					$error_msg .="- ".$emsg[41]."<br />";
				}
					
	            if (($_POST['antiflood_ban'] != "") && ((!preg_match("/^[0-9]*$/is", $_POST['antiflood_ban'])) OR ($_POST['antiflood_ban'] < 0))) {
					$error_msg .="- ".$emsg[24]."<br />";
	            }
	
	            if ($_POST['entries_per_site'] != "" && !preg_match("/^[0-9]*$/is", $_POST['entries_per_site'])) {
					$error_msg .="- ".$emsg[22]."<br />";
	            }
	
	            if ($_POST['links_in_sitefunction'] != "" && !preg_match("/^[0-9]*$/is", $_POST['links_in_sitefunction'])) {
					$error_msg .= "- ".$emsg[23]."<br />";
	            }
	
	            if ($_POST['max_word_length'] != "" && (!preg_match("/^[0-9]*$/is", $_POST['max_word_length']) OR $_POST['max_word_length'] < 30 OR $_POST['max_word_length'] > 125)) {
					$error_msg .= "- ".$emsg[37]."<br />";
	            }
	
	            if ((isset($_POST['link_entry']) && ($_POST['link_entry'] != "") && !preg_match("/^[0-9a-zA-Z".$allowed_characters."\/ '():.,!?-]*$/is", $_POST['link_entry'])) OR ($_POST['guestbook_title'] != "" && !preg_match("/^[0-9a-zA-Z".$allowed_characters."\/ '():.,!?-]*$/is", $_POST['guestbook_title']))) {
					$error_msg .= "- ".$emsg[79]."<br />";
	            }

	            if ($_POST['statistic_ban'] != "" && !preg_match("/^[0-9]*$/is", $_POST['statistic_ban'])) {
					$error_msg .= "- ".$emsg[25]."<br />";
	            }
	
	            if (!extension_loaded('gd') && (isset($_POST['images_in_entries']) && $_POST['images_in_entries'] != 0)) {
					$error_msg .= "- ".$emsg[68]."<br />";
	            }
	
				$count_link_name = (isset($_POST['link_entry'])) ? $_POST['link_entry'] : '';
				$orig = array("ö","Ö","ä","Ä","ü","Ü","ß");
				$fake = " ";
				$count_link_name = str_replace($orig, $fake, $count_link_name);
				$link_lenght = strlen($count_link_name);
					
				if ($link_lenght > 35) {
					$error_msg .="- ".$emsg[83]."<br />";
				}

	            if ($_POST['guestbook_title'] == "" OR $_POST['entries_per_site'] == "" OR $_POST['links_in_sitefunction'] == "" OR $_POST['antiflood_ban'] == "" OR $_POST['statistic_ban'] == "" OR $_POST['max_word_length'] == "" OR ((SPAM_PROTECT) && $_POST['spam_marker'] == "") OR ((isset($_POST['no_spam_links']) && $_POST['no_spam_links'] != 1) && (isset($_POST['max_links']) && $_POST['max_links'] == ""))) {
					$error_msg .= "- ".$emsg[0]."<br />";
	            }
	
	            if (!$error_msg == "") {
	            	$error_gbook_options = '<p class="zentriert red"><strong>'.$error_msg.'</strong></p><br />';
	            }
				else {
					$_POST['antiflood_ban']			= (isset($_POST['antiflood_ban'])) ? $_POST['antiflood_ban'] : '';
					$_POST['bbcode']				= (isset($_POST['bbcode'])) ? $_POST['bbcode'] : '';
					$_POST['check_email']			= (isset($_POST['check_email'])) ? $_POST['check_email'] : '';
					$_POST['check_homepage']		= (isset($_POST['check_homepage'])) ? $_POST['check_homepage'] : '';
					$_POST['check_icq']				= (isset($_POST['check_icq'])) ? $_POST['check_icq'] : '';
					$_POST['deactivate_html']		= (isset($_POST['deactivate_html'])) ? $_POST['deactivate_html'] : '';
					$_POST['clean_backup']			= (isset($_POST['clean_backup'])) ? $_POST['clean_backup'] : '';
					$_POST['entries_per_site']		= (isset($_POST['entries_per_site'])) ? $_POST['entries_per_site'] : '';
					$_POST['entry_length_limit']	= (isset($_POST['entry_length_limit'])) ? $_POST['entry_length_limit'] : '';
					$_POST['entry_length_maximum']	= (isset($_POST['entry_length_maximum'])) ? $_POST['entry_length_maximum'] : '';
					$_POST['entry_length_minimum']	= (isset($_POST['entry_length_minimum'])) ? $_POST['entry_length_minimum'] : '';
					$_POST['guestbook_status']		= (isset($_POST['guestbook_status'])) ? $_POST['guestbook_status'] : '';
							
					if (SPAM_PROTECT) {
						$_POST['no_spam_entries']		= (isset($_POST['no_spam_entries'])) ? $_POST['no_spam_entries'] : '';
						$_POST['spam_marker']			= (isset($_POST['spam_marker'])) ? $_POST['spam_marker'] : '';
						$_POST['no_spam_links']			= (isset($_POST['no_spam_links'])) ? $_POST['no_spam_links'] : '';
						$_POST['max_links']				= (isset($_POST['max_links'])) ? $_POST['max_links'] : '';
						(isset($_POST['no_spam_links']) AND $_POST['no_spam_links'] != 1) ? ($_POST['max_links'] = 0) : ($_POST['max_links'] = $_POST['max_links']);
					}
					else {
						$select_spam_properties = $gbook->query("SELECT `no_spam_entries`, `spam_marker`, `no_spam_links`, `max_links` FROM `".$table."_properties`");
					    $spam_properties = $select_spam_properties->fetch_assoc();

						$_POST['no_spam_entries']		= $spam_properties['no_spam_entries'];
						$_POST['spam_marker']			= ($spam_properties['spam_marker'] > 0) ? $spam_properties['spam_marker'] : 1;
						$_POST['no_spam_links']			= $spam_properties['no_spam_links'];
						$_POST['max_links']				= $spam_properties['max_links'];
					}
							
					$_POST['guestbook_title']		= (isset($_POST['guestbook_title'])) ? $_POST['guestbook_title'] : '';
					$_POST['images_in_entries']		= (isset($_POST['images_in_entries'])) ? $_POST['images_in_entries'] : '';
					((isset($_POST['bbcode']) && $_POST['bbcode'] != 1) || (!extension_loaded('gd') && (isset($_POST['images_in_entries']) && $_POST['images_in_entries'] != 0))) ? ($_POST['images_in_entries'] = 0) : ($_POST['images_in_entries'] = $_POST['images_in_entries']);
					$_POST['quote_func']			= (isset($_POST['quote_func'])) ? $_POST['quote_func'] : '';
					$_POST['language']				= (isset($_POST['language'])) ? $_POST['language'] : '';
					$_POST['links_in_sitefunction']	= (isset($_POST['links_in_sitefunction'])) ? $_POST['links_in_sitefunction'] : '';
					$_POST['max_word_length']		= (isset($_POST['max_word_length'])) ? $_POST['max_word_length'] : '';
					$_POST['notification_entries']	= (isset($_POST['notification_entries'])) ? $_POST['notification_entries'] : '';
					$_POST['release_entries']		= (isset($_POST['release_entries'])) ? $_POST['release_entries'] : '';
					$_POST['show_ip']				= (isset($_POST['show_ip'])) ? $_POST['show_ip'] : '';
					$_POST['smilies']				= (isset($_POST['smilies'])) ? $_POST['smilies'] : '';
					$_POST['statistic']				= (isset($_POST['statistic'])) ? $_POST['statistic'] : '';
					$_POST['statistic_ban']			= (isset($_POST['statistic_ban'])) ? $_POST['statistic_ban'] : '';
					$_POST['thanks_email']			= (isset($_POST['thanks_email'])) ? $_POST['thanks_email'] : '';
					$_POST['link_entry']			= (isset($_POST['link_entry'])) ? $_POST['link_entry'] : '';
					$_POST['check_subject']			= (isset($_POST['check_subject'])) ? $_POST['check_subject'] : '';
					$_POST['check_town']			= (isset($_POST['check_town'])) ? $_POST['check_town'] : '';
					$_POST['check_country']			= (isset($_POST['check_country'])) ? $_POST['check_country'] : '';
					$_POST['check_free']			= (isset($_POST['check_free'])) ? $_POST['check_free'] : '';
					(isset($_POST['check_email']) && $_POST['check_email'] != 4) ? ($_POST['check_free'] = $_POST['check_free']) : ($_POST['check_free'] = 1);
					$_POST['button_link']			= (isset($_POST['button_link'])) ? $_POST['button_link'] : '';
					(isset($_POST['button_link']) && $_POST['button_link'] == 2 && isset($_POST['quote_func'])) ? ($_POST['quote_func'] = 0) : ($_POST['quote_func'] = $_POST['quote_func']);

					$_POST['guestbook_title']	= trim($_POST['guestbook_title']);
					$_POST['link_entry']		= trim($_POST['link_entry']);

					$_POST['guestbook_title']	= $gbook->real_escape_string($_POST['guestbook_title']);
					$_POST['link_entry']     	= $gbook->real_escape_string($_POST['link_entry']);

					$gbook->query("UPDATE ".$table."_properties SET
			      												 antiflood_ban			= '".$_POST['antiflood_ban']."', 
			      												 bbcode					= '".$_POST['bbcode']."', 
			      												 check_email			= '".$_POST['check_email']."', 
			      												 check_homepage			= '".$_POST['check_homepage']."', 
			      												 check_icq				= '".$_POST['check_icq']."', 
			      												 deactivate_html		= '".$_POST['deactivate_html']."', 
			      												 clean_backup			= '".$_POST['clean_backup']."', 
			      												 entries_per_site		= '".$_POST['entries_per_site']."', 
			      												 entry_length_limit		= '".$_POST['entry_length_limit']."', 
			      												 entry_length_maximum	= '".$_POST['entry_length_maximum']."', 
			      												 entry_length_minimum	= '".$_POST['entry_length_minimum']."', 
			      												 guestbook_status		= '".$_POST['guestbook_status']."', 
			      												 no_spam_entries		= '".$_POST['no_spam_entries']."', 
			      												 spam_marker			= '".$_POST['spam_marker']."', 
			      												 no_spam_links			= '".$_POST['no_spam_links']."', 
			      												 max_links				= '".$_POST['max_links']."', 
			      												 guestbook_title		= '".$_POST['guestbook_title']."', 
			      												 images_in_entries		= '".$_POST['images_in_entries']."', 
			      												 language				= '".$_POST['language']."', 
			      												 links_in_sitefunction	= '".$_POST['links_in_sitefunction']."', 
			      												 max_word_length		= '".$_POST['max_word_length']."', 
			      												 notification_entries	= '".$_POST['notification_entries']."', 
			      												 release_entries		= '".$_POST['release_entries']."', 
			      												 show_ip				= '".$_POST['show_ip']."', 
			      												 smilies				= '".$_POST['smilies']."', 
			      												 thanks_email			= '".$_POST['thanks_email']."',
			      												 statistic				= '".$_POST['statistic']."', 
			      												 statistic_ban			= '".$_POST['statistic_ban']."', 
			      												 quote_func				= '".$_POST['quote_func']."',
			      												 link_entry				= '".$_POST['link_entry']."', 
			      												 check_subject			= '".$_POST['check_subject']."', 
			      												 check_town				= '".$_POST['check_town']."', 
			      												 check_country			= '".$_POST['check_country']."',
			      												 check_free				= '".$_POST['check_free']."',
			      												 button_link			= '".$_POST['button_link']."'");

					if (isset($_POST['language'])){
						if ($_POST['language'] == "de" || $_POST['language'] == "at" || $_POST['language'] == "ch"){
							$thyo_lang = "de";
			      		}
			      		else {
			      			$thyo_lang = $_POST['language'];
			      		}
			      		
						$select_lang = $gbook->query("SELECT `lang` FROM `".$table."_thankyou` WHERE `lang` = '".$thyo_lang."'");
						$lang_ok = $select_lang->num_rows;
		
						if ($lang_ok < 1) {
							$gbook->query("INSERT INTO `".$table."_thankyou` (id, status, thanks, lang, noreply) VALUES ('','0','Please enter text','".$thyo_lang."','')");
						}

						echo'<meta http-equiv="Refresh" content="0; url='.$url.'admin/admin.php?action=guestbook_options&#38;'.session_name().'='.session_id().'" />';
					}
				}
			}

	$sql_select_properties = $gbook->query("SELECT `antiflood_ban`, `bbcode`, `check_email`, `check_homepage`, `check_icq`, `deactivate_html`, `clean_backup`, `entries_per_site`, `entry_length_limit`, `entry_length_maximum`, `entry_length_minimum`, `guestbook_status`, `no_spam_entries`, `spam_marker`, `no_spam_links`, `max_links`, `guestbook_title`, 
													`images_in_entries`, `language`, `links_in_sitefunction`, `max_word_length`, `notification_entries`, `release_entries`, `show_ip`, `smilies`, `thanks_email`, `statistic`, `statistic_ban`, `quote_func`, `link_entry`, `check_subject`, `check_town`, `check_country`, `check_free`, `button_link`  
									 		FROM `".$table."_properties`");
    $select_properties = $sql_select_properties->fetch_assoc();

	$spam_word_sperre = $gbook->query("SELECT `id` FROM `".$table."_spam`");

	if ($spam_word_sperre != "") {
		$spam_sperre = $spam_word_sperre->num_rows;
	}
	
	echo "<fieldset>
		<legend><strong>".$fmsg[113]."</strong></legend>
		<br /><br />".$error_gbook_options."
		<form method=\"post\" name=\"options\" action=\"".$url."admin/admin.php?action=guestbook_options&#38;".session_name()."=".session_id()."\">
		<table style=\"width:500px\" class=\"guestbook_table2 tableCenter\" cellspacing=\"0\" cellpadding=\"2\">
			<tr>
				<td align=\"left\">".$fmsg[57]."</td>
				<td align=\"left\"><img src=\"".$url."includes/flags/".$flag.".png\" alt=\"".$flag."\" />
					&nbsp;<select name=\"language\">";

					$lang_dir = "../lang";
	
	        		$files = scandir($lang_dir);
	
					foreach ($files as $file)
						{
							if ($file != "." && $file != ".." && $file != ".htaccess" && $file != "index.php" && $file != "ReadMe_Update_Sprachfiles.txt") {
								$lang = explode(".", $file);
							}
							if (isset($lang[0]) && $lang[0] != "") {
								echo "<option value=\"".$lang[0]."\"";
	
								if ($select_properties['language'] == $lang[0]) {
									echo " selected=\"selected\"";
								}
										
								echo ">".$lang[0]."</option>";
							}
						}

			echo "</select>
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[114]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"guestbook_title\" size=\"20\" style=\"width:99%;\" maxlength=\"50\" value=\"".$select_properties['guestbook_title']."\" /></td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[173]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"guestbook_status\"";

			        if (isset($select_properties['guestbook_status']) AND $select_properties['guestbook_status']== '1') {
			            echo " checked=\"checked\"";
						}
		
		        	echo " value=\"1\" />
		        </td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[123]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"release_entries\"";

			        if (isset($select_properties['release_entries']) AND $select_properties['release_entries']== '1') {
			            echo " checked=\"checked\"";
					}

					echo " value=\"1\" />
				</td>
			</tr>";
		echo"	
			<tr>
				<td align=\"left\"><br />".$fmsg[119]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"notification_entries\"";

			        if (isset($select_properties['notification_entries']) AND $select_properties['notification_entries']== '1') {
			            echo " checked=\"checked\"";
			        	}
		
					echo" value=\"1\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$amsg[148]."*</td>
				<td align=\"left\"><br /><strong>*<a title=\"".$amsg[148]."\" href=\"javascript:{}\" onclick=\"document.getElementById('entry_link').style.display='inline';return false;\">".$amsg[119]."</a></strong></td>
			</tr>";
		echo"
			<tr>
				<td colspan=\"2\" align=\"center\">
					<div id=\"entry_link\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('entry_link').style.display='none';\">
					<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
						<tr>
							<td align=\"center\">
								<div style=\"width:420px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$amsg[148]."</strong></span><br />".$amsg[149]."</div>
							</td>
						</tr>
					</table>
					</div>
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"right\" class=\"pad-right\"><br />".$amsg[169]."</td>
				<td align=\"left\"><br /><input type=\"radio\" name=\"button_link\"";
															
					if (isset($select_properties['button_link']) AND $select_properties['button_link'] == '0') {
						echo" checked=\"checked\"";
					}
														
					echo" value=\"0\" />
				</td>
			</tr>
			<tr>
				<td align=\"right\" class=\"pad-right\">".$amsg[170]."</td>
				<td align=\"left\"><input type=\"radio\" name=\"button_link\"";
															
					if (isset($select_properties['button_link']) AND $select_properties['button_link'] == '1') {
						echo" checked=\"checked\"";
					}
														
					echo" value=\"1\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"right\" class=\"pad-right\">".$amsg[172]."</td>
				<td align=\"left\"><input type=\"radio\" name=\"button_link\" onclick=\"input_activate_05();\"";
															
					if (isset($select_properties['button_link']) AND $select_properties['button_link'] == '2') {
						echo" checked=\"checked\"";
					}
														
					echo" value=\"2\" />
				</td>
			</tr>";

		if ($select_properties['button_link'] != 2) {
			echo"
				<tr>
					<td align=\"left\"><br />".$amsg[171]."</td>
					<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"link_entry\" size=\"20\" style=\"width:99%;\" maxlength=\"35\" value=\"";
					
					if ($select_properties['link_entry'] != "") {
						echo"".$select_properties['link_entry']."";
						$placeholder = "";
					}
					else {
						$placeholder = " placeholder=\"".$fmsg[13]."\"";
					}
					
					echo"\"$placeholder />
					</td>
				</tr>";
		}

		if (SPAM_PROTECT) {
			echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[255]."</td>
				<td align=\"left\"><br /><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"spam_marker\" value=\"".$select_properties['spam_marker']."\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>*<a title=\"".$fmsg[259]."\" href=\"javascript:{}\" onclick=\"document.getElementById('lightbox_spam').style.display='inline';return false;\">".$amsg[119]."</a></strong></td>
			</tr>";
		echo"
			<tr>
				<td colspan=\"2\" align=\"center\">
					<div id=\"lightbox_spam\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('lightbox_spam').style.display='none';\">
					<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
						<tr>
							<td align=\"center\">
								<div style=\"width:300px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$fmsg[259]."</strong></span><br />".$fmsg[260]."</div>
							</td>
						</tr>
					</table>
					</div>
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[256]."</td>
				<td align=\"left\">";
							
					if (!$spam_sperre) {
						echo" <span class=\"red\"><br />".$fmsg[261]." <strong><a class=\"layout\" href=\"admin.php?action=spamwords&#38;show=view_spam&#38;".session_name()."=".session_id()."\">=> LINK</a></strong>";
					}
					else {
						echo"<br /><br /><input type=\"checkbox\" name=\"no_spam_entries\"";
					
						if (isset($select_properties['no_spam_entries']) AND $select_properties['no_spam_entries'] == 1 AND $spam_sperre) {
							echo" checked=\"checked\"";
						}
						echo" value=\"1\" />";
					}
						
		echo"
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[257]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"no_spam_links\" onclick=\"input_activate_02();\"";

			        if (isset($select_properties['no_spam_links']) AND $select_properties['no_spam_links']== '1') {
			            echo " checked=\"checked\"";
			        	}
		
					echo" value=\"1\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[258]."</td>
				<td align=\"left\"><br /><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"max_links\"";
				
					if (isset($select_properties['no_spam_links']) AND $select_properties['no_spam_links'] != 1) {
						echo " disabled=\"disabled\"";
					}
					
					echo" value=\"".$select_properties['max_links']."\" />
				</td>
			</tr>";
		}
		else {
			echo"
			<tr>
				<td align=\"left\"><br /><span class=\"red\">".$fmsg[340]."</span></td>
				<td align=\"left\"><br /><strong>*<a title=\"".$fmsg[338]."\" href=\"javascript:{}\" onclick=\"document.getElementById('lightbox_nospam').style.display='inline';return false;\">".$amsg[119]."</a></strong></td>
			</tr>
			<tr>
				<td colspan=\"2\" align=\"center\">
					<div id=\"lightbox_nospam\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('lightbox_nospam').style.display='none';\">
					<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
						<tr>
							<td align=\"center\">
								<div style=\"width:320px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$fmsg[338]."</strong></span><br />".$fmsg[339]."</div>
							</td>
						</tr>
					</table>
					</div>
				</td>
			</tr>";
		}
		
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[117]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"antiflood_ban\" value=\"".$select_properties['antiflood_ban']."\" /></td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[124]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"deactivate_html\"";

			        if (isset($select_properties['deactivate_html']) AND $select_properties['deactivate_html']== '1') {
			            echo " checked=\"checked\"";
			        	}
		
					echo" value=\"1\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[115]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"entries_per_site\" value=\"".$select_properties['entries_per_site']."\" /></td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[116]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"links_in_sitefunction\" value=\"".$select_properties['links_in_sitefunction']."\" /></td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[203]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"max_word_length\" value=\"".$select_properties['max_word_length']."\" /></td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[174]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"entry_length_limit\" onclick=\"input_activate();\"";

			        if ($select_properties['entry_length_limit']) {
			            echo " checked=\"checked\"";
			        	}
		
					echo" value=\"1\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[175]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"entry_length_maximum\"";

			        if (isset($select_properties['entry_length_limit']) AND $select_properties['entry_length_limit'] != 1) {
			            echo " disabled=\"disabled\"";
			        	}
		
					echo" value=\"".$select_properties['entry_length_maximum']."\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[176]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"entry_length_minimum\"";

			        if (isset($select_properties['entry_length_limit']) AND $select_properties['entry_length_limit'] != 1) {
			            echo " disabled=\"disabled\"";
			        	}
		
					echo" value=\"".$select_properties['entry_length_minimum']."\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[206]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"thanks_email\"";

			        if (isset($select_properties['thanks_email']) AND $select_properties['thanks_email']== '1') {
			            echo " checked=\"checked\"";
			            define('EMAIL_LANG', true);
			        }
			        else {define('EMAIL_LANG', false);}
		
					echo" value=\"1\" />
				</td>
			</tr>";

			if (EMAIL_LANG) {
				echo"
					<tr>
						<td align=\"left\"><br />".$amsg[132]."</td>
						<td align=\"left\"><br />
							<img src=\"".$url."includes/flags/".$lang_short.".png\" alt=\"".$lang_short."\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>*<a title=\"".$amsg[146]."\" href=\"javascript:{}\" onclick=\"document.getElementById('email_lang').style.display='inline';return false;\">".$amsg[119]."</a></strong>
						</td>
					</tr>";
		
				echo"<tr>
						<td colspan=\"2\" align=\"center\">
							<div id=\"email_lang\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('email_lang').style.display='none';\">
							<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
								<tr>
									<td align=\"center\">
										<div style=\"width:350px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$amsg[146]."</strong></span><br />".$amsg[147]."</div>
									</td>
								</tr>
							</table>
							</div>
						</td>
					</tr>";
			}
				
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[122]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"statistic\"";

			        if (isset($select_properties['statistic']) AND $select_properties['statistic']== '1') {
			            echo " checked=\"checked\"";
			        	}
		
					echo" value=\"1\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[118]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"statistic_ban\" value=\"".$select_properties['statistic_ban']."\" /></td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[275]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"clean_backup\"";

			        if (isset($select_properties['clean_backup']) AND $select_properties['clean_backup']== '1') {
			            echo " checked=\"checked\"";
			        	}
		
					echo" value=\"1\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[120]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"smilies\"";

			        if (isset($select_properties['smilies']) AND $select_properties['smilies']== '1') {
			            echo " checked=\"checked\"";
			        	}
		
					echo " value=\"1\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[121]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"bbcode\" onclick=\"input_activate_03();\"";

			        if (isset($select_properties['bbcode']) AND $select_properties['bbcode'] == '1') {
			            echo " checked=\"checked\"";
			        	}
		
					echo" value=\"1\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[220]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"images_in_entries\"";

			        if (isset($select_properties['bbcode']) AND $select_properties['bbcode'] != '1') {
			            echo " disabled=\"disabled\"";
			       	}
			        elseif (isset($select_properties['bbcode']) AND $select_properties['bbcode'] == '1' AND isset($select_properties['images_in_entries']) AND $select_properties['images_in_entries']== '1') {
			            echo " checked=\"checked\"";
			       	}
			       		
					echo" value=\"1\" />
				</td>
			</tr>";

			if ((!PIC_CHECK) AND isset($select_properties['images_in_entries']) AND $select_properties['images_in_entries']== '1') {
				echo"
				<tr>
					<td align=\"left\"><br /><span class=\"red\">".$fmsg[343]."</span></td>
					<td align=\"left\"><br /><strong>*<a title=\"".$fmsg[341]."\" href=\"javascript:{}\" onclick=\"document.getElementById('lightbox_no_piccheck').style.display='inline';return false;\">".$amsg[119]."</a></strong></td>
				</tr>
				<tr>
					<td colspan=\"2\" align=\"center\">
						<div id=\"lightbox_no_piccheck\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('lightbox_no_piccheck').style.display='none';\">
						<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
							<tr>
								<td align=\"center\">
									<div style=\"width:385px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$fmsg[341]."</strong></span><br />".$fmsg[342]."</div>
								</td>
							</tr>
						</table>
						</div>
					</td>
				</tr>";
			}
			
		echo"
			<tr>
				<td align=\"left\"><br />".$amsg[111]."*</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"quote_func\"";

			        if (isset($select_properties['button_link']) AND $select_properties['button_link'] == '2') {
			            echo " disabled=\"disabled\"";
			       	}
			        elseif (isset($select_properties['button_link']) AND $select_properties['button_link'] != '2' AND isset($select_properties['quote_func']) AND $select_properties['quote_func']== '1') {
			            echo " checked=\"checked\"";
			       	}
		
					echo" value=\"1\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>*<a title=\"".$amsg[175]."\" href=\"javascript:{}\" onclick=\"document.getElementById('lightbox_quote').style.display='inline';return false;\">".$amsg[119]."</a></strong>
				</td>
			</tr>";
		echo"
			<tr>
				<td colspan=\"2\" align=\"center\">
					<div id=\"lightbox_quote\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('lightbox_quote').style.display='none';\">
					<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
						<tr>
							<td align=\"center\">
								<div style=\"width:300px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$amsg[175]."</strong></span><br />".$amsg[176]."</div>
							</td>
						</tr>
					</table>
					</div>
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[205]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"show_ip\"";

			        if (isset($select_properties['show_ip']) AND $select_properties['show_ip']== '1') {
			            echo " checked=\"checked\"";
			        }

					echo" value=\"1\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\" colspan=\"2\"><br />".$amsg[120]." <strong class=\"red\">".$amsg[122]."</strong> ".$amsg[121]."</td>
			</tr>
			<tr>
				<td align=\"right\" class=\"pad-right\"><br />".$amsg[124]."</td>
				<td align=\"left\"><br /><input type=\"radio\" name=\"check_email\"";
															
					if (isset($select_properties['check_email']) AND $select_properties['check_email'] == '0') {
						echo" checked=\"checked\"";
					}
														
					echo" value=\"0\" />
				</td>
			</tr>
			<tr>
				<td align=\"right\" class=\"pad-right\">".$amsg[125]."</td>
				<td align=\"left\"><input type=\"radio\" name=\"check_email\"";
															
					if (isset($select_properties['check_email']) AND $select_properties['check_email'] == '3') {
						echo" checked=\"checked\"";
					}
														
					echo" value=\"3\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\" colspan=\"2\"><br />".$amsg[120]." <strong class=\"red\">".$amsg[123]."</strong> ".$amsg[121]."</td>
			</tr>
			<tr>
				<td align=\"right\" class=\"pad-right\"><br />".$amsg[124]."</td>
				<td align=\"left\"><br /><input type=\"radio\" name=\"check_email\"";
															
					if (isset($select_properties['check_email']) AND $select_properties['check_email'] == '1') {
						echo" checked=\"checked\"";
					}
														
					echo" value=\"1\" />
				</td>
			</tr>
			<tr>
				<td align=\"right\" class=\"pad-right\">".$amsg[125]."</td>
				<td align=\"left\"><input type=\"radio\" name=\"check_email\"";
															
					if (isset($select_properties['check_email']) AND $select_properties['check_email'] == '2') {
						echo" checked=\"checked\"";
					}
														
					echo" value=\"2\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[196]."</td>
				<td align=\"left\"><br /><input type=\"radio\" name=\"check_email\" onclick=\"input_activate_04();\"";
															
					if (isset($select_properties['check_email']) AND $select_properties['check_email'] == '4') {
						echo" checked=\"checked\"";
					}
														
					echo" value=\"4\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$amsg[126]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"check_town\"";

			        if (isset($select_properties['check_town']) AND $select_properties['check_town']== '1') {
			            echo " checked=\"checked\"";
			        }
		
					echo" value=\"1\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$amsg[127]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"check_country\"";

			        if (isset($select_properties['check_country']) AND $select_properties['check_country']== '1') {
			            echo " checked=\"checked\"";
			        }
		
					echo" value=\"1\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$fmsg[201]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"check_homepage\"";

			        if (isset($select_properties['check_homepage']) AND $select_properties['check_homepage'] == '1') {
			            echo " checked=\"checked\"";
			        }
		
					echo" value=\"1\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$fmsg[202]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"check_icq\"";

			        if (isset($select_properties['check_icq']) AND $select_properties['check_icq']== '1') {
			            echo " checked=\"checked\"";
			        }
		
					echo" value=\"1\" />
				</td>
			</tr>
			<tr>
				<td align=\"left\"><br />".$amsg[128]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"check_subject\"";

			        if (isset($select_properties['check_subject']) AND $select_properties['check_subject']== '1') {
			            echo " checked=\"checked\"";
			        }
		
					echo" value=\"1\" />
				</td>
			</tr>";
		echo"
			<tr>
				<td align=\"left\"><br />".$amsg[159]."</td>
				<td align=\"left\"><br /><input type=\"checkbox\" name=\"check_free\"";

			        if (isset($select_properties['check_email']) AND $select_properties['check_email'] == '4') {
			            echo " disabled=\"disabled\"";
			       	}
			        elseif (isset($select_properties['check_email']) AND $select_properties['check_email'] != '4' AND isset($select_properties['check_free']) AND $select_properties['check_free']== '1') {
			            echo " checked=\"checked\"";
			       	}
			       		
					echo" value=\"1\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>*<a title=\"".$amsg[160]."\" href=\"javascript:{}\" onclick=\"document.getElementById('lightbox_info').style.display='inline';return false;\">".$amsg[119]."</a></strong>
				</td>
			</tr>";
		echo"
			<tr>
				<td colspan=\"2\" align=\"center\">
					<div id=\"lightbox_info\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('lightbox_info').style.display='none';\">
					<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
						<tr>
							<td align=\"center\">
								<div style=\"width:320px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$amsg[160]."</strong></span><br />".$amsg[161]."</div>
							</td>
						</tr>
					</table>
					</div>
				</td>
			</tr>";

		echo"
			<tr>
				<td align=\"center\" colspan=\"2\"><br /><br /><input class=\"button\" type=\"submit\" name=\"send\" value=\"".$fmsg[55]."\" /></td>
			</tr>
		</table>
		</form>
		</fieldset>";

	echo"
		<script type=\"text/javascript\">
			function input_activate(){if(document.options.entry_length_limit.checked == true){document.options.entry_length_maximum.disabled=false;document.options.entry_length_minimum.disabled=false;}else{document.options.entry_length_maximum.disabled=true;document.options.entry_length_minimum.disabled=true;}}
			function input_activate_02(){if(document.options.no_spam_links.checked == true){document.options.max_links.disabled = false;}else{document.options.max_links.disabled = true;}}
			function input_activate_03(){if(document.options.bbcode.checked == true){document.options.images_in_entries.disabled = false;}else{document.options.images_in_entries.disabled = true;}}
			function input_activate_04(){if(document.options.check_email.checked == true){document.options.check_free.disabled = false;}else{document.options.check_free.disabled = true;}}
			function input_activate_05(){if(document.options.button_link.checked == true){document.options.quote_func.disabled = false;}else{document.options.quote_func.disabled = true;}}
		</script>";
    }

?>