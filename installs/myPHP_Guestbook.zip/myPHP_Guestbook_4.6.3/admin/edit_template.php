<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    02.01.2015
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
        $sql_properties = $gbook->query("SELECT default_template FROM ".$table."_properties");
        $properties = $sql_properties->fetch_assoc();

        $sql_select_template = $gbook->query("SELECT name FROM ".$table."_template WHERE id='".$properties['default_template']."'");
        $select_template = $sql_select_template->fetch_assoc();

        echo "<fieldset>
		<legend><strong>".$fmsg[73]."</strong></legend>
		<br /><br />
		<form method=\"post\" name=\"style\" action=\"".$url."admin/admin.php?action=edit_template_action&#38;".session_name()."=".session_id()."\">
		<table style=\"width:361px\" class=\"guestbook_table2 tableCenter\">
		<tr>
		<td align=\"left\">
		".$fmsg[63]." <strong>".$select_template['name']."</strong><br /><br />
		<select name=\"template\">";

        $sql_template = $gbook->query("SELECT id, name FROM ".$table."_template");

        while ($template = $sql_template->fetch_assoc()) {
            echo "<option value='".$template['id']."'";

            if ($template['id'] == $properties['default_template']) {
                echo " selected=\"selected\"";
            }

            echo ">".$template['name']."</option>";
        }

		echo "</select>
		</td>
		</tr>
		<tr>
		<td align=\"center\"><br /><p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[70]."\" /></p><br /></td>
		</tr>
		</table>
		</form>
		</fieldset>";
    }
?>
