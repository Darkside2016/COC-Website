<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
		$sql_ip_sperre 	= $gbook->query("SELECT `ip` FROM `".$table."_forbidden_ip`");
		$count_ip_sperre = $sql_ip_sperre->num_rows;

		($count_ip_sperre < 1) ? ($ok = '<img class="img-ok" src="../images/ok.png" width="14" height="14" alt="" />') : ($ok = '<img class="img-ok" src="../images/delete.png" width="14" height="14" alt="" />');

        if (isset($_POST['send']) AND isset($_POST['action']) AND isset($_POST['entry'])) {
            $y = count($_POST['entry']);

            if ($_POST['action'] == "delete") {
                for ($x=0;$x<$y;$x++) {
                    $entry_id = $_POST['entry'][$x];
                    $gbook->query("DELETE FROM `".$table."_entries` WHERE `id`='".$entry_id."'");
                }
            }

            if ($_POST['action'] == "activate_entry") {
                for ($x=0;$x<$y;$x++) {
                    $entry_id = $_POST['entry'][$x];
                    $gbook->query("UPDATE `".$table."_entries` SET `status`='2' WHERE `id`='".$entry_id."'");
                }
            }

            if ($_POST['action'] == "activate_text") {
                for ($x=0;$x<$y;$x++) {
                    $entry_id = $_POST['entry'][$x];
                    $gbook->query("UPDATE `".$table."_entries` SET `status`='1' WHERE `id`='".$entry_id."'");
                }
            }

            if ($_POST['action'] == "deactivate") {
                for ($x=0;$x<$y;$x++) {
                    $entry_id = $_POST['entry'][$x];
                    $gbook->query("UPDATE `".$table."_entries` SET `status`='0' WHERE `id`='".$entry_id."'");
                }
            }
        }
        
		if(isset($_GET['change']) == "status") {
			$status_query = $gbook->query("SELECT `status` FROM `".$table."_entries` WHERE `id` = '".$_REQUEST['id']."'");
			list($entry_status) = $status_query->fetch_row();
						
			if ($entry_status == 0)	{
	        	$update_status = $gbook->query("UPDATE `".$table."_entries` SET `status` = '1' WHERE `id` = '".$_REQUEST['id']."'");
			}
			elseif ($entry_status == 1)	{
	        	$update_status = $gbook->query("UPDATE `".$table."_entries` SET `status` = '2' WHERE `id` = '".$_REQUEST['id']."'");				
			}
			elseif ($entry_status == 2)	{
	        	$update_status = $gbook->query("UPDATE `".$table."_entries` SET `status` = '0' WHERE `id` = '".$_REQUEST['id']."'");				
			}
			if ($update_status) {
				echo "<meta http-equiv=\"Refresh\" content=\"0; url=admin.php?action=guestbook&#38;".session_name()."=".session_id()."#anchor-entryID-".$_REQUEST['id']."\" />";
			}
		}

		$sql_entries_gesperrt 	= $gbook->query("SELECT `id` FROM `".$table."_entries` WHERE `status` = '0'");
		$entries_gesperrt 		= $sql_entries_gesperrt->num_rows;

		($entries_gesperrt < 1) ? ($gesperrt = '<img class="img-ok" src="../images/ok.png" width="14" height="14" alt="" />') : ($gesperrt = '<img class="img-ok" src="../images/delete.png" width="14" height="14" alt="" />');

        $sql_count_entries = $gbook->query("SELECT `id` FROM `".$table."_entries`");
        $count_entries = $sql_count_entries->num_rows;
				
        $sql_properties = $gbook->query("SELECT `bbcode`, `deactivate_html`, `check_homepage`, `check_icq`, `clean_backup`, `entries_per_site`, `links_in_sitefunction`, `images_in_entries`, `max_word_length`, `release_entries`, `smilies`, `quote_func`, `check_town`, `check_country` FROM `".$table."_properties`");
        $properties = $sql_properties->fetch_assoc();

        if (isset($_GET['page'])) {
            if (!is_numeric($_GET['page']) OR empty($_GET['page'])) {
                $page = 1;
            } else {
                $page = $_GET['page'];
            }
        } else {
            $page = 1;
        }

        $page               = $gbook->real_escape_string($page);
        $pages_total        = ceil($count_entries/$properties['entries_per_site']) ;
        $page_start         = floor($page - $properties['links_in_sitefunction']/2) ;
        $page_start         = $page_start <= 0 ?  1 : $page_start ;
        $page_end           = ($page_start + $properties['links_in_sitefunction']-1) ;
        $page_end           = $page_end >= $pages_total ?  $pages_total : $page_end ;
        $page_max           = $page*$properties['entries_per_site'];
        $max_minus_per_page = $page_max-$properties['entries_per_site'];
        $page_entry_start   = $count_entries-$max_minus_per_page+1;

		echo"
		<p class=\"aligncenter\">
			<strong>".$amsg[39]."<a title=\"".$amsg[40]."\" href=\"".$url."admin/admin.php?action=spamwords&#38;show=ip_forbidden&#38;".session_name()."=".session_id()."\">$ok</a>"; if ($count_ip_sperre > 1){echo"&nbsp;&nbsp;&nbsp;<a title=\"".$amsg[40]."\" href=\"".$url."admin/admin.php?action=spamwords&#38;show=ip_forbidden&#38;".session_name()."=".session_id()."\">[&nbsp;".$count_ip_sperre." ".$amsg[41]."]</a>";}
		echo "</strong>
		</p>
		<p class=\"aligncenter\">
			<strong>".$amsg[42]."$gesperrt"; if ($entries_gesperrt > 1){echo"&nbsp;&nbsp;&nbsp;[&nbsp;".$amsg[43]." ".$entries_gesperrt."&nbsp;]";}
	    echo "</strong>
		</p>";
		
		if (!$properties['clean_backup']) {
			include("check_backup.php");
		}
		
		echo"
		<hr style=\"width:80%\" />
		<br />";

       echo "
		<form action=\"".$url."admin/admin.php?action=guestbook&#38;".session_name()."=".session_id()."\" method=\"post\">
		<div class=\"aligncenter\">
		<br />".$fmsg[104]." <input type=\"checkbox\" name=\"all\" value=\"1\" onclick=\"select_all(this.checked,this.form)\" />&nbsp;&nbsp;
		<select name=\"action\"><option value=\"deactivate\">".$fmsg[326]."</option><option value=\"activate_entry\">".$fmsg[323]."</option><option value=\"activate_text\">".$fmsg[324]."</option><option value=\"delete\">".$fmsg[325]."</option></select>&nbsp;&nbsp;
		<input type=\"submit\" class=\"button\" name=\"send\" value=\"OK\" /><br /><br />
		";

        if ($page > 1) {
            $page_minus = $page-1;
			echo " <a href=\"".$url."admin/admin.php?action=guestbook&#38;page=".$page_minus."&#38;".session_name()."=".session_id()."\"><img src=\"".$url."images/links.gif\" alt=\"".$fmsg[4]."\" /></a>&nbsp;&nbsp;&nbsp;";
        }

        if ($page_start > 1) {
			echo " <a href=\"".$url."admin/admin.php?action=guestbook&#38;page=1&#38;".session_name()."=".session_id()."\">1</a> ...";
        }

        for ($i = $page_start; $i <= $page_end ;$i++) {
            if ($i == $page) {
                echo "&nbsp;<strong>".$i."</strong>&nbsp;&nbsp;";
            } else {
                echo " <a href=\"".$url."admin/admin.php?action=guestbook&#38;page=".$i."&#38;".session_name()."=".session_id()."\">&nbsp;".$i."&nbsp;</a>&nbsp;&nbsp;";
            }
        }

        if ($page_end < $pages_total) {
            echo " ... <a href=\"".$url."admin/admin.php?action=guestbook&#38;page=".$pages_total."&#38;".session_name()."=".session_id()."\">".$pages_total."</a>";
        }

        if ($page < $pages_total) {
            $page_plus = $page+1;
            echo "&nbsp;&nbsp;&nbsp;<a href=\"".$url."admin/admin.php?action=guestbook&#38;page=".$page_plus."&#38;".session_name()."=".session_id()."\"><img src=\"".$url."images/rechts.gif\" alt=\"".$fmsg[14]."\" /></a>";
        }

		echo"
			</div>
			<p>&nbsp;</p>
			";

        $sql_entries = $gbook->query("SELECT `comment`, `date`, `email`, `homepage`, `icq`, `id`, `ip`, `status`, `name`, `text`, `time`, `origin`, `marker`  FROM `".$table."_entries` ORDER BY `id` DESC LIMIT ".(($page-1)*$properties['entries_per_site'] ).",".$properties['entries_per_site']."");

        while ($entries = $sql_entries->fetch_assoc()) {
            $page_entry_start = $page_entry_start-1;
            $entries['number']   = $page_entry_start;

	        $entries['name']     = htmlentities(strip_tags($entries['name']), ENT_QUOTES, "UTF-8");
	        $entries['name']     = stripslashes($entries['name']);

			(($properties['check_town'] == 1) && ($properties['check_country'] == 1)) ? $origin = $entries['origin'] = "" : $origin = $entries['origin'];
            $origin   = htmlentities(strip_tags($origin), ENT_QUOTES, "UTF-8");
 			$origin   = stripslashes($origin);
 			$origin 	 = shortWords($origin, $short_town);

            $entries['email']    = htmlentities(strip_tags($entries['email']), ENT_QUOTES, "UTF-8");
            $entries['email']    = stripslashes($entries['email']);

    	    $entries['homepage'] = htmlentities(strip_tags($entries['homepage']), ENT_QUOTES, "UTF-8");
			$entries['homepage'] = stripslashes($entries['homepage']);

			$entries['icq'] = htmlentities(strip_tags($entries['icq']), ENT_QUOTES, "UTF-8");
			$entries['icq'] = stripslashes($entries['icq']);
			
		    $entries['text']     = shortWords($entries['text'], $properties['max_word_length']);

            if ($properties['deactivate_html']) {
                $entries['text'] = htmlentities($entries['text'], ENT_QUOTES, "UTF-8");
            }
 
		    $entries['text']     = nl2br($entries['text']);
		    $entries['text']     = stripslashes($entries['text']);
			$entries['text'] 	 = quote($entries['text']);

	   		$entries['comment']  = htmlentities(strip_tags($entries['comment']), ENT_QUOTES, "UTF-8");
	        $entries['comment']  = nl2br($entries['comment']);
	        $entries['comment']  = stripslashes($entries['comment']);

            if ($properties['smilies']) {
	            $entries['comment'] = smilies($entries['comment']);
				$entries['text']    = smilies($entries['text']);
            }

            if ($properties['bbcode']) {
	            $entries['comment'] = bbcode($entries['comment']);
				$entries['text']    = bbcode($entries['text']);

			$sql_picture = $gbook->query("SELECT `pic_name`, `width`, `height`, `title` FROM `".$table."_pictures`");
		
		    	while ($picture = $sql_picture->fetch_assoc()){
		    		$maxpicwidth = '490';
					$newwidth = $picture['width'];
					$newheight = $picture['height'];
					
					if ($picture['width'] > $maxpicwidth){
						$prozent = $maxpicwidth/$picture['width'];
						$newwidth = floor($picture['width']*$prozent);
						$newheight = floor($picture['height']*$prozent);
					}
	
					$entries['text'] = preg_replace("/\[img\](".$picture['pic_name'].")\[\/img\]/si", "<img class=\"centered\" title=\"".$picture['title']."\" src=\"".$url."img_guest/\\1\" alt=\"".$picture['title']."\" width=\"".$newwidth."\" height=\"".$newheight."\" />", $entries['text']);
					$entries['comment'] = preg_replace("/\[img\](".$picture['pic_name'].")\[\/img\]/si", "<img class=\"centered\" title=\"".$picture['title']."\" src=\"".$url."img_guest/\\1\" alt=\"".$picture['title']."\" width=\"".$newwidth."\" height=\"".$newheight."\" />", $entries['comment']);
				}
            }
            else {
            	$entries['text'] = preg_replace("/\[b\](.*?)\[\/b\]/si", "<strong>\\1</strong>", $entries['text']);
            }

			if ($entries['marker'] != 0 && $entries['email'] != "") {
				$mark = " <sup class=\"size-10 blue\">[e]</sup>";
				$mark_info = "";
				
				if ($properties['quote_func']) {
					($entries['marker'] == 1) ? $mark_info = "".$amsg[165]." - ".$amsg[167]."\n".$amsg[166]." - ".$amsg[167]."" : "";
					($entries['marker'] == 2) ? $mark_info = "".$amsg[165]." - ".$amsg[168]."\n".$amsg[166]." - ".$amsg[167]."" : "";

					($entries['marker'] == 3) ? $mark_info = "".$amsg[165]." - ".$amsg[167]."\n".$amsg[166]." - ".$amsg[168]."" : "";
				}
				else {
					($entries['marker'] == 1 || $entries['marker'] == 3) ? $mark_info = "".$amsg[165]." - ".$amsg[167]."" : "";
					($entries['marker'] == 2) ? $mark = "" : "";
				}
			}
			else {
				$mark = "";
				$mark_info = "";
			}

			echo"<a id=\"anchor-entryID-".$entries['id']."\" name=\"anchor-entryID-".$entries['id']."\"></a>
			<table style=\"width:530px\" class=\"guestbook-table03 edit-table tableCenter\" cellpadding=\"3\" cellspacing=\"1\" border=\"0\">
			<tr class=\"headpost tdinstall1\">
			<td align=\"left\" style=\"width:43%\" class=\"headpad\"><strong> &nbsp;".$entries['name']."</strong>";
			
			if ($origin != "") {
				echo "<br />&nbsp;<span class=\"size-10\">".$origin."</span>";
			}
			
			echo "</td>
			<td align=\"center\" style=\"width:20%\" class=\"headpad zentriert\">";

            if ($entries['email'] == "") {
                echo "";
            } else {
                echo "<a href=\"mailto:".$entries['email']."\"><img class=\"ico\" src=\"".$url."images/icons/email/emailnew.gif\" alt=\"".$entries['email']."\" /></a>";
            }

            if ($entries['homepage'] == "" OR $entries['homepage'] == "http://") {
                echo "";
            } else {
                echo "&nbsp;<a href=\"".$entries['homepage']."\" rel=\"external\"><img class=\"ico\" src=\"".$url."/images/icons/homepage/homepage.gif\" alt=\"".$entries['homepage']."\" /></a>";
            }

            if ($entries['icq'] == "" OR $entries['icq'] == 0) {
                echo "";
            } else {
                echo "&nbsp;<a href=\"http://www.icq.com/people/".$entries['icq']."&#38;lang=de\" rel=\"external\"><img class=\"ico\" src=\"http://wwp.icq.com/scripts/online.dll?icq=".$entries['icq']."&#38;img=5\" alt=\"".$entries['icq']."\" /></a>";
            }

			echo "</td>
			<td style=\"width:32%\" align=\"right\" class=\"headpad beitragnr\"><b>".$amsg[84]." # ".$entries['number']."</b><br />".$amsg[85]." ".$entries['date']." | ".$entries['time']."</td>
			<td style=\"width:5%\" align=\"center\"><input class=\"checkboxloeschen\" type=\"checkbox\" name=\"entry[]\" value=\"".$entries['id']."\" /></td>
			</tr>";
			
			echo "
			<tr class=\"tdinstall2\">
			<td align=\"left\" colspan=\"4\"><span style=\"font-size:10px;\">IP: ".$entries['ip']."</span>";

			echo "
				<br /><br />
				".$entries['text']."";

            if ($entries['comment']) {
				echo "<br />
					<table class=\"comment-table tableCenter\" cellpadding=\"4\" cellspacing=\"0\">
					<tr>
					<td class=\"tdinstall1\" align=\"left\">
					<p class=\"heading\">".$fmsg[106].":</p>
					".$entries['comment']."
					</td>
					</tr>
					</table>";
            }

			echo "</td>
			</tr>
			<tr><td colspan=\"5\">&nbsp;</td></tr>";
			
			echo "<tr>
			<td align=\"left\" colspan=\"4\" class=\"pad-top-bottom tdinstall5\">
				<strong><a class=\"adminlink\" style=\"text-decoration:none;\" href=\"".$url."admin/admin.php?action=edit&#38;id=".$entries['id']."&#38;".session_name()."=".session_id()."\">".$fmsg[70]."</a></strong>|<strong><a class=\"adminlink\" style=\"text-decoration:none;\" title=\"".$mark_info."\" href=\"".$url."admin/admin.php?action=comment&#38;id=".$entries['id']."&#38;".session_name()."=".session_id()."\">".$fmsg[106]."".$mark."</a></strong>";

				if ($entries['status'] == 1) {
					$status = '<a href="'.$url.'admin/admin.php?action=guestbook&#38;change=status&#38;id='.$entries['id'].'#anchor-entryID-'.$entries['id'].'" title="'.$fmsg[323].'"><img class="img-ok" src="../images/ok.png" width="14" height="14" alt="" /></a>';
					$photo_status = '<a href="'.$url.'admin/admin.php?action=guestbook&#38;change=status&#38;id='.$entries['id'].'#anchor-entryID-'.$entries['id'].'" title="'.$fmsg[323].'"><img class="img-ok" src="../images/delete.png" width="14" height="14" alt="" /></a>';
				}
				elseif ($entries['status'] == 2) {
					$status = '<a href="'.$url.'admin/admin.php?action=guestbook&#38;change=status&#38;id='.$entries['id'].'#anchor-entryID-'.$entries['id'].'" title="'.$fmsg[326].'"><img class="img-ok" src="../images/ok.png" width="14" height="14" alt="" /></a>';
					$photo_status = '<a href="'.$url.'admin/admin.php?action=guestbook&#38;change=status&#38;id='.$entries['id'].'#anchor-entryID-'.$entries['id'].'" title="'.$fmsg[326].'"><img class="img-ok" src="../images/ok.png" width="14" height="14" alt="" /></a>';
				}
				else {
					$status = '<a href="'.$url.'admin/admin.php?action=guestbook&#38;change=status&#38;id='.$entries['id'].'#anchor-entryID-'.$entries['id'].'" title="'.$fmsg[324].'"><img class="img-ok" src="../images/delete.png" width="14" height="14" alt="" /></a>';
					$photo_status = '<a href="'.$url.'admin/admin.php?action=guestbook&#38;change=status&#38;id='.$entries['id'].'#anchor-entryID-'.$entries['id'].'" title="'.$fmsg[324].'"><img class="img-ok" src="../images/delete.png" width="14" height="14" alt="" /></a>';
				}

			echo "|&nbsp;&nbsp;<strong>".$amsg[89]."</strong>&nbsp;&nbsp;".$status."";
				
				if ($properties['bbcode'] && $properties['images_in_entries']) {
					echo"&nbsp;&nbsp;|&nbsp;&nbsp;<strong>".$amsg[90]."</strong>&nbsp;&nbsp;".$photo_status."";
				}

			echo "
			</td>
			</tr>
			</table>
			<p>&nbsp;</p>";
        }
        
		echo"
		</form>
		<p class=\"aligncenter\">";

        if ($page > 1) {
            $page_minus = $page-1;
            echo " <a href=\"".$url."admin/admin.php?action=guestbook&#38;page=".$page_minus."&#38;".session_name()."=".session_id()."\"><img src=\"".$url."images/links.gif\" alt=\"".$fmsg[4]."\" /></a>&nbsp;&nbsp;&nbsp;";
        }

        if ($page_start > 1) {
            echo " <a href=\"".$url."admin/admin.php?action=guestbook&#38;page=1&#38;".session_name()."=".session_id()."\">1</a> ...";
        }

        for ($i = $page_start; $i <= $page_end ;$i++) {
            if ($i == $page) {
                echo "&nbsp;<strong>".$i."</strong>&nbsp;&nbsp;";
            } else {
                echo " <a href=\"".$url."admin/admin.php?action=guestbook&#38;page=".$i."&#38;".session_name()."=".session_id()."\">&nbsp;".$i."&nbsp;</a>&nbsp;&nbsp;";
            }
        }

        if ($page_end < $pages_total) {
            echo " ... <a href=\"".$url."admin/admin.php?action=guestbook&#38;page=".$pages_total."&#38;".session_name()."=".session_id()."\">".$pages_total."</a>";
        }

        if ($page < $pages_total) {
            $page_plus = $page+1;
            echo "&nbsp;&nbsp;&nbsp;<a href=\"".$url."admin/admin.php?action=guestbook&#38;page=".$page_plus."&#38;".session_name()."=".session_id()."\"><img src=\"".$url."/images/rechts.gif\" alt=\"".$fmsg[14]."\" /></a>";
        }

		echo "</p>
		";
    }
?>