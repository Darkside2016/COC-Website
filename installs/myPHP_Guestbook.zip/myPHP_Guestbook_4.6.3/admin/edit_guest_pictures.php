<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    01.05.2016
*/
    
    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
    
	if ($_GET['show'] == "edit_guestpic") {
		echo "<fieldset><legend><strong>".$amsg[101]."</strong></legend>
			<p>&nbsp;</p>";
		
			$sql_guestfoto = $gbook->query("SELECT * FROM `".$table."_pictures`  WHERE `id` = '".$_REQUEST['id']."'");
			$guestfoto = $sql_guestfoto->fetch_assoc();
		
			$size = getimagesize("".$url."img_guest/{$guestfoto['pic_name']}");
			$width = $size[0];
			$height = $size[1];
		
			$maxpicwidth = '550';
			$newwidth = $guestfoto['width'];
			$newheight = $guestfoto['height'];
						
			if ($guestfoto['width'] > $maxpicwidth){
				$prozent = $maxpicwidth/$guestfoto['width'];
				$newwidth = floor($guestfoto['width']*$prozent);
				$newheight = floor($guestfoto['height']*$prozent);
			}
					
			if (isset($_POST['speichern']))
				{
					$fehler = "";
									
					$_POST['pic_name']	= $gbook->real_escape_string($_POST['pic_name']);
					$_POST['breite']	= $gbook->real_escape_string($_POST['breite']);
					$_POST['hoehe']		= $gbook->real_escape_string($_POST['hoehe']);
					$_POST['title']		= $gbook->real_escape_string($_POST['title']);
					$_POST['datum']		= $gbook->real_escape_string($_POST['datum']);
					$_POST['uhr']		= $gbook->real_escape_string($_POST['uhr']);

					if ($_POST['pic_name'] == "" OR $_POST['title'] == "" OR $_POST['datum'] == "" OR $_POST['uhr'] == "")
						{
							$fehler .= "<p class=\"text-center error\">- ".$emsg[44]."</p>";
						}
					if ($_POST['pic_name'] != "" && !preg_match("/^[a-zA-Z0-9.]*$/is", $_POST['pic_name']))
						{
							$fehler .= "<p class=\"text-center error\">- ".$emsg[64]."</p>";
						}
					if (($_POST['breite'] != "" && $_POST['hoehe'] != "") && (!preg_match("/^[0-9 ]*$/is", $_POST['breite']) OR !preg_match("/^[0-9 ]*$/is", $_POST['hoehe'])))
						{
							$fehler .= "<p class=\"text-center error\">- ".$emsg[60]."</p>";
						}
					if ($_POST['title'] != "" && !preg_match("/^[a-zA-ZÄäÜüÖöß0-9' :?!,.-]*$/is", $_POST['title']))
						{
							$fehler .= "<p class=\"text-center error\">- ".$emsg[61]."</p>";
						}
					if ($_POST['datum'] != "" && !preg_match("/^[0-9 .]*$/is", $_POST['datum']))
						{
							$fehler .= "<p class=\"text-center error\">- ".$emsg[62]."</p>";
						}
					if ($_POST['uhr'] != "" && !preg_match("/^[0-9 :]*$/is", $_POST['uhr']))
						{
							$fehler .= "<p class=\"text-center error\">- ".$emsg[63]."</p>";
						}
										
					if (!$fehler == "")
						{ 
							echo "".$fehler."";
						}
					else
						{
							$update = $gbook->query("UPDATE `".$table."_pictures` SET `pic_name` = '".$_POST['pic_name']."', `width` = '".$_POST['breite']."', `height` = '".$_POST['hoehe']."', `title` = '".$_POST['title']."',  `date` = '".$_POST['datum']."',  `time` = '".$_POST['uhr']."' WHERE `id` = '".$_REQUEST['id']."'");
											
							if ($update)
								{
									echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=guest_pictures&#38;".session_name()."=".session_id()."\" />";
								}
						}
				}
								
				echo"
					<form method=\"post\" action=\"".$url."admin/admin.php?action=edit_guest_pictures&#38;show=edit_guestpic&#38;".session_name()."=".session_id()."\">
						<table style=\"width:100%\" class=\"guestbook_table tableCenter\" border=\"1\" rules=\"rows\" frame=\"below\" cellspacing=\"0\" cellpadding=\"0\">
							<tr style=\"height:1px\">
								<td align=\"center\"></td>
								<td style=\"width:40px\" align=\"center\"></td>
								<td style=\"width:40px\" align=\"center\"></td>
								<td style=\"width:210px\" align=\"center\"></td>
								<td align=\"center\"></td>
								<td align=\"center\"></td>
							</tr>
							<tr style=\"height:40px\" class=\"tdinstall1 size-10\">
								<td><p>".$amsg[71]."</p></td>
								<td><p>".$fmsg[67]."</p></td>
								<td><p>".$fmsg[68]."</p></td>
								<td><p>".$amsg[97]."</p></td>
								<td><p>".$amsg[55]."</p></td>
								<td><p>".$amsg[56]."</p></td>
							</tr>
							<tr style=\"height:40px\" class=\"tdinstall2\">
								<td>
									<input type=\"text\" class=\"insert\" name=\"pic_name\" maxlength=\"20\" size=\"12\" style=\"width:92%\" value=\"";
									
								        if (isset($_POST['pic_name']) AND $_POST['pic_name'] != "") {
								            echo stripslashes(htmlspecialchars(strip_tags($_POST['pic_name']), ENT_QUOTES));
								        }
										else {
											echo htmlentities(strip_tags($guestfoto['pic_name']), ENT_QUOTES, "UTF-8");
										}
									
									echo"\" />
								</td>
								<td>
									<input type=\"text\" class=\"insert\" name=\"breite\" maxlength=\"3\" size=\"2\" style=\"width:85%\" value=\"".$width."\" />
								</td>
								<td>
									<input type=\"text\" class=\"insert\" name=\"hoehe\" maxlength=\"3\" size=\"2\" style=\"width:85%\" value=\"".$height."\" />
								</td>
								<td>
									<input type=\"text\" class=\"insert\" name=\"title\" maxlength=\"60\" size=\"25\" style=\"width:92%\" value=\"";
									
								        if (isset($_POST['title']) AND $_POST['title'] != "") {
								            echo stripslashes(htmlspecialchars(strip_tags($_POST['title']), ENT_QUOTES));
								        }
										else {
											echo htmlentities(strip_tags($guestfoto['title']), ENT_QUOTES, "UTF-8");
										}
									
									echo"\" />
								</td>
								<td>
									<input type=\"text\" class=\"insert\" name=\"datum\" size=\"7\" style=\"width:90%\" maxlength=\"10\" value=\"";
									
								        if (isset($_POST['datum']) AND $_POST['datum'] != "") {
								            echo stripslashes(htmlspecialchars(strip_tags($_POST['datum']), ENT_QUOTES));
								        }
										else {
											echo htmlentities(strip_tags($guestfoto['date']), ENT_QUOTES, "UTF-8");
										}
									
									echo"\" />
								</td>
								<td>
									<input type=\"text\" class=\"insert\" name=\"uhr\" size=\"2\" style=\"width:90%\" maxlength=\"5\" value=\"";
									
								        if (isset($_POST['uhr']) AND $_POST['uhr'] != "") {
								            echo stripslashes(htmlspecialchars(strip_tags($_POST['uhr']), ENT_QUOTES));
								        }
										else {
											echo htmlentities(strip_tags($guestfoto['time']), ENT_QUOTES, "UTF-8");
										}
									
									echo"\" />
								</td>
							</tr>
							<tr>
								<td colspan=\"6\" align=\"center\" class=\"tdinstall2\">
									<br /><img class=\"centered\" title=\"Foto: ".$guestfoto['title']."\" src=\"".$url."img_guest/".$guestfoto['pic_name']."\" width=\"".$newwidth."\" height=\"".$newheight."\" alt=\"".$guestfoto['title']."\" /><br />
								</td>
							</tr>
						</table>
						<table style=\"width:100%\" class=\"guestbook_table tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
							<tr class=\"tdinstall2\">
								<td align=\"center\">
									<p>&nbsp;</p>
									<p><input type=\"submit\" class=\"button\" title=\"".$fmsg[55]."\" name=\"speichern\" value=\"".$fmsg[55]."\" /><input type=\"hidden\" name=\"id\" value=\"".$_REQUEST['id']."\" /></p>
									<p>&nbsp;</p>
									<p><input type=\"button\" class=\"button\" title=\"".$fmsg[4]."\" name=\"zurueck\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='admin.php?action=guest_pictures&#38;".session_name()."=".session_id()."'\" /></p>
								</td>
							</tr>
						</table>
					</form>
				</fieldset>
				<p>&nbsp;</p>";
			}
		

	elseif ($_GET['show'] == "new_guestpic")
		{
			echo "<fieldset><legend><strong>".$amsg[102]."</strong></legend>
			<p>&nbsp;</p>";
			
					if (isset($_POST['send_eintrag']))
						{
							$_POST['pic_name'] 	= $gbook->real_escape_string($_POST['pic_name']);
							$_POST['width'] 	= $gbook->real_escape_string($_POST['width']);
							$_POST['height'] 	= $gbook->real_escape_string($_POST['height']);
							$_POST['title'] 	= $gbook->real_escape_string($_POST['title']);
							$_POST['datum'] 	= $gbook->real_escape_string($_POST['datum']);
							$_POST['uhr'] 		= $gbook->real_escape_string($_POST['uhr']);

							$fehler	= "";

							if ($_POST['pic_name'] == "" OR $_POST['title'] == "" OR $_POST['datum'] == "" OR $_POST['uhr'] == "")
								{
									$fehler .= "<p class=\"text-center error\">- ".$emsg[44]."</p>";
								}
							if ($_POST['pic_name'] != "" && !preg_match("/^[a-zA-Z0-9.]*$/is", $_POST['pic_name']))
								{
									$fehler .= "<p class=\"text-center error\">- ".$emsg[64]."</p>";
								}
							if (($_POST['width'] != "" && $_POST['height'] != "") && (!preg_match("/^[0-9 ]*$/is", $_POST['width']) OR !preg_match("/^[0-9 ]*$/is", $_POST['height'])))
								{
									$fehler .= "<p class=\"text-center error\">- ".$emsg[60]."</p>";
								}
							if ($_POST['title'] != "" && !preg_match("/^[a-zA-ZÄäÜüÖöß0-9' :?!,.-]*$/is", $_POST['title']))
								{
									$fehler .= "<p class=\"text-center error\">- ".$emsg[61]."</p>";
								}
							if ($_POST['datum'] != "" && !preg_match("/^[0-9 .]*$/is", $_POST['datum']))
								{
									$fehler .= "<p class=\"text-center error\">- ".$emsg[62]."</p>";
								}
							if ($_POST['uhr'] != "" && !preg_match("/^[0-9 :]*$/is", $_POST['uhr']))
								{
									$fehler .= "<p class=\"text-center error\">- ".$emsg[63]."</p>";
								}
										
							if (!$fehler == "")
								{ 
									echo "".$fehler."";
								}

							else
								{
									$new_guestfoto = $gbook->query("INSERT INTO `".$table."_pictures` (`id`, `ip`, `pic_name`, `width`, `height`, `title`, `date`, `time`) VALUES ('', '".$_SERVER['REMOTE_ADDR']."', '".$_POST['pic_name']."', '".$_POST['width']."', '".$_POST['height']."', '".$_POST['title']."', '".$_POST['datum']."', '".$_POST['uhr']."')");
											
									if ($new_guestfoto)
										{
											echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=guest_pictures&#38;".session_name()."=".session_id()."\" />";
										}
								}
						}
			
			echo"
			<form method=\"post\" action=\"".$url."admin/admin.php?action=edit_guest_pictures&#38;show=new_guestpic&#38;".session_name()."=".session_id()."\">
				<table style=\"width:400px\" class=\"guestbook_table tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
					<tr style=\"height:1px\" class=\"tdinstall2\">
						<td style=\"width:120px\"></td><td></td>
					</tr>
					<tr style=\"height:40px\" class=\"tdinstall2\">
						<td align=\"left\"><p>".$amsg[54]."</p></td><td align=\"left\">".$_SERVER['REMOTE_ADDR']."</td>
					</tr>
					<tr style=\"height:40px\" class=\"tdinstall2\">
						<td align=\"left\"><p>".$amsg[71]."</p></td><td align=\"left\"><input type=\"text\" class=\"insert\" size=\"20\" maxlength=\"20\" name=\"pic_name\" value=\"\"/></td>
					</tr>
					<tr style=\"height:40px\" class=\"tdinstall2\">
						<td align=\"left\">".$fmsg[67]."</td><td align=\"left\"><input type=\"text\" class=\"insert\" size=\"10\" maxlength=\"3\" name=\"width\" value=\"\"/></td>
					</tr>
					<tr style=\"height:40px\" class=\"tdinstall2\">
						<td align=\"left\">".$fmsg[68]."</td><td align=\"left\"><input type=\"text\" class=\"insert\" size=\"10\" maxlength=\"4\" name=\"height\" value=\"\"/></td>
					</tr>
					<tr style=\"height:40px\" class=\"tdinstall2\">
						<td align=\"left\"><p>".$amsg[97]."</p></td><td align=\"left\"><input style=\"width:98%\" type=\"text\" class=\"insert\" size=\"25\" maxlength=\"60\" name=\"title\" value=\"\"/></td>
					</tr>
					<tr style=\"height:40px\" class=\"tdinstall2\">
						<td align=\"left\"><p>".$amsg[55]."</p></td><td align=\"left\"><input type=\"text\" class=\"insert\" size=\"10\" maxlength=\"10\" name=\"datum\" value=\"".date("d.m.Y")."\"/></td>
					</tr>
					<tr style=\"height:40px\" class=\"tdinstall2\">
						<td align=\"left\"><p>".$amsg[56]."</p></td><td align=\"left\"><input type=\"text\" class=\"insert\" size=\"10\" maxlength=\"5\" name=\"uhr\" value=\"".date("H:i")."\"/></td>
					</tr>
					<tr class=\"tdinstall2\">
						<td align=\"center\" colspan=\"2\">
							<p>&nbsp;</p>
							<p><input type=\"submit\" class=\"button\" title=\"".$fmsg[55]."\" name=\"send_eintrag\" value=\"".$fmsg[55]."\" /></p>
							<p>&nbsp;</p>
							<p><input type=\"button\" class=\"button\" title=\"".$fmsg[4]."\" name=\"zurueck\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='admin.php?action=guest_pictures'\" /></p>
						</td>
					</tr>
				</table>
			</form>
			</fieldset>
			<p>&nbsp;</p>";
    	}
	}

?>