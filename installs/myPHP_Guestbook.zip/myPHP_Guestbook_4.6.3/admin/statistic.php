<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    02.01.2015
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
        if (isset($_GET['delete'])) {
            $gbook->query("DELETE FROM `".$table."_statistic`  WHERE  `id` != '1'");
            $gbook->query("UPDATE `".$table."_statistic` SET `hits` = '0', `visits` = '0', `date` = '".date("d.m.Y")."' WHERE  `id` = '1'");
        }

        $sql_properties = $gbook->query("SELECT `statistic` FROM `".$table."_properties`");
        $properties = $sql_properties->fetch_assoc();

        if ($properties['statistic']) {
            $sql_all_hits_visits = $gbook->query("SELECT `hits`, `visits`, `date` FROM `".$table."_statistic` WHERE `id` = '1'");
            list ($all_hits, $all_visits, $date_beginn) = $sql_all_hits_visits->fetch_row();

            echo "
				<script type=\"text/javascript\">function stats_del(){return confirm('".$emsg[50]."');}</script>
				<div class=\"aligncenter\">
				<fieldset><legend><strong>".$fmsg[154]."</strong></legend>
				<p><strong>".$fmsg[279]." ".$date_beginn."</strong></p>
				<p>".$fmsg[155]." <strong>".number_format($all_visits, 0, ",", ".")."</strong></p>
				<p>".$fmsg[156]." <strong>".number_format($all_hits, 0, ",", ".")."</strong></p>
				<div><br /></div>
				<p><strong>".$fmsg[157]."</strong></p>
				<table style=\"width:230px\" class=\"guestbook_table tableCenter\" cellpadding=\"2\" cellspacing=\"1\" border=\"0\">
				<tr>
				<td align=\"center\" class=\"tdinstall1\"><strong>".$fmsg[158]."</strong></td>
				<td align=\"center\" class=\"tdinstall1\"><strong>".$fmsg[159]."</strong></td>
				<td align=\"center\" class=\"tdinstall1\"><strong>".$fmsg[160]."</strong></td>
				</tr>";

            $sql_statistic = $gbook->query("SELECT `date`, `hits`, `visits` FROM `".$table."_statistic` WHERE `id` != '1' ORDER BY `id` DESC");

            while ($statistic = $sql_statistic->fetch_assoc()) {
                echo "<tr>
					<td align=\"center\" class=\"tdinstall2\">".$statistic['date']."</td>
					<td align=\"center\" class=\"tdinstall2\">".$statistic['visits']."</td>
					<td align=\"center\" class=\"tdinstall2\">".$statistic['hits']."</td>
					</tr>";
            }

            echo "</table>
				<br />
				<p>&nbsp;</p>
				<form method=\"post\" action=\"".$url."admin/admin.php?action=statistic&#38;delete=1&#38;".session_name()."=".session_id()."\">
					<p class=\"aligncenter\"><input type=\"submit\" class=\"button\" name=\"delete\" value=\"".$fmsg[161]."\" onclick=\"return stats_del()\" /></p>
				</form>		
				</fieldset>
				</div>";

        } else {
            echo "<br /><p class=\"zentriert\"><strong>".$fmsg[162]."</strong></p>";
        }
    }
?>
