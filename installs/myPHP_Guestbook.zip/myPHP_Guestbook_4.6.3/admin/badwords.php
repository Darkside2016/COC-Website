<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    02.01.2016
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";

    } else {
    	$error_badword = "";

		if ($_GET['show'] == "view_badwords") {
            if (isset($_POST['send']) AND isset($_POST['entry'])) {
                $y = count($_POST['entry']);

                for ($x=0;$x<$y;$x++) {
                    $entry_id = $_POST['entry'][$x];
                    $gbook->query("DELETE FROM ".$table."_badwords WHERE id='$entry_id'");
                }
		}

			$sql_count_badwords = $gbook->query("SELECT id FROM ".$table."_badwords");
			$count_badwords 	= $sql_count_badwords->num_rows;

            $sql_badwords = $gbook->query("SELECT badword, id FROM ".$table."_badwords");

            if ($count_badwords < 1 ) {
                echo "<br /><p class=\"zentriert\"><strong>".$emsg[30]."</strong></p>";
            } else {

                echo "<fieldset>
					<legend><strong>".$fmsg[164]."</strong></legend><br />
					<p>&nbsp;</p>
					<form method=\"post\" action=\"".$url."admin/admin.php?action=badwords&#38;show=view_badwords&#38;".session_name()."=".session_id()."\">
						<table style=\"width:320px;\" cellpadding=\"4\" cellspacing=\"1\" border=\"1\" rules=\"rows\" frame=\"below\" class=\"guestbook_table2 tableCenter\">
							<tr>
								<td align=\"left\" style=\"width:87%\" class=\"tdinstall1\"><strong>".$fmsg[165]."</strong></td>
								<td align=\"center\" style=\"width:13%\"  class=\"tdinstall1\"><input type=\"checkbox\" class=\"checkboxloeschen\" name=\"all\" value=\"1\" onclick=\"select_all(this.checked,this.form)\" /></td>
							</tr>";

                $i = 1;

                while ($badwords = $sql_badwords->fetch_assoc()) {
                    $color = ($i % 2) ? "tdinstall2" : "tdinstall3";
                    echo "
                    	<tr>
							<td align=\"left\" style=\"width:87%;font-weight:normal;\" class=\"".$color."\">".$badwords['badword']."</td>
							<td align=\"center\" class=\"".$color."\"><input type=\"checkbox\" name=\"entry[]\" value=\"".$badwords['id']."\" /></td>
						</tr>";
						
                    $i++;
                }

                echo "
                	</table>
					<p>&nbsp;</p>
					<p class=\"aligncenter\"><br /><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[166]."\" /><br /></p>
					</form>
					</fieldset>";
            }
        }

		elseif ($_GET['show'] == "insert_badwords")
	        {
				if (isset($_POST['send']))
					{
						if ($_POST['badword'] == "")
							{
								$error_badword = '<p class="zentriert red"><strong>- '.$emsg[0].'</strong></p>';
							}
						else
							{
				                $sql_check_badword = $gbook->query("SELECT badword FROM ".$table."_badwords WHERE badword='".$_POST['badword']."'");
		
								if ($sql_check_badword->num_rows == 0)
									{
										$sql_insert_badword = $gbook->query("INSERT INTO ".$table."_badwords (badword, id) VALUES ('".$_POST['badword']."', '')");
										
					                    if ($sql_insert_badword)
											{
		                        				echo "<meta http-equiv=\"Refresh\" content=\"0; url=admin.php?action=badwords&#38;show=view_badwords&#38;".session_name()."=".session_id()."\" />";
		                    				}
									}
								else
									{
										$error_badword = '<p class="zentriert red"><strong>- '.$fmsg[126].'</strong></p>';
									}
							}
					}

            echo "<fieldset>
					<legend><strong>".$fmsg[127]."</strong></legend>
					<p>&nbsp;</p>".$error_badword."
					<p>&nbsp;</p>
					<form method=\"post\" action=\"".$url."admin/admin.php?action=badwords&#38;show=insert_badwords&#38;".session_name()."=".session_id()."\">
						<table style=\"width:200px\" class=\"guestbook_table2 tableCenter\" cellpadding=\"4\" cellspacing=\"0\" border=\"0\">
							<tr>
								<td align=\"left\"><strong>".$fmsg[128]."</strong></td>
								<td align=\"left\"><input type=\"text\" class=\"insert\" name=\"badword\" /></td>
							</tr>
							<tr>
								<td align=\"center\" colspan=\"2\">
									<p>&nbsp;</p>
									<p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[55]."\" /></p>
								</td>
							</tr>
						</table>
					</form>
				</fieldset>";
        }
    }
?>