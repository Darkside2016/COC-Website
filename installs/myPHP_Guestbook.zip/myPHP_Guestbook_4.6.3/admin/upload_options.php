<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    01.10.2015
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    	}
    else {
    	$error_upload 	= "";
		$sql_properties = $gbook->query("SELECT `bbcode`, `images_in_entries`, `default_template` FROM `".$table."_properties`");
		$properties		= $sql_properties->fetch_assoc();
			
		if ($properties['bbcode'] && $properties['images_in_entries']) {
			$sql_template = $gbook->query("SELECT `name`, `tablewidth` FROM `".$table."_template` WHERE `id` = '".$properties['default_template']."'");
			$template = $sql_template->fetch_assoc();
			
			if ($template['name'] == "myPHP-GBook4_wide-R") {
				$newPicDim = floor(($template['tablewidth'])*0.75 - '20');
			}
			else {
				$newPicDim = ($template['tablewidth']-'20');
			}

			if (isset($_POST['send'])) {
	            $error_msg = "";
	
	            if ((!preg_match("/^[0-9]*$/is", $_POST['max_filesize']) OR $_POST['max_filesize'] < 1 OR $_POST['max_filesize'] > 5)) {
					$error_msg .= "<strong>- ".$emsg[59]."</strong><br />";
	            }

				if (!preg_match("/^[0-9]*$/is", $_POST['max_width']) OR $_POST['max_width'] < 10 OR $_POST['max_width'] > $newPicDim) {
					$error_msg .="<strong>- ".$emsg[65]." ".$newPicDim."</strong><br />";
				}
					
	            if (!preg_match("/^[0-9]*$/is", $_POST['max_height']) OR $_POST['max_height'] < 10 OR $_POST['max_height'] > 1000) {
					$error_msg .="<strong>- ".$emsg[66]."</strong><br />";
	            }
	
	            if (!preg_match("/^[0-9]*$/is", $_POST['jpg_quality']) OR $_POST['jpg_quality'] < 10 OR $_POST['jpg_quality'] > 100) {
					$error_msg .="<strong>- ".$emsg[67]."</strong><br />";
	            }
	
	            if (!preg_match("/^[0-9]*$/is", $_POST['upload_max']) OR $_POST['upload_max'] < 1 OR $_POST['upload_max'] > 10) {
					$error_msg .="<strong>- ".$emsg[75]."</strong><br />";
	            }
	
	            if ($_POST['max_filesize'] == "" OR $_POST['max_width'] == "" OR $_POST['max_height'] == "" OR $_POST['jpg_quality'] == "" OR $_POST['upload_max'] == "") {
					$error_msg .= "<strong>- ".$emsg[0]."</strong><br />";
	            }
	
	            if (!$error_msg == "") {
	            	$error_upload = '<p class="red">'.$error_msg.'</p><p>&nbsp;</p>';
	            } else {
							$_POST['max_filesize']	= (isset($_POST['max_filesize'])) ? $_POST['max_filesize'] : '';
							$_POST['max_width']		= (isset($_POST['max_width'])) ? $_POST['max_width'] : '';
							$_POST['max_height']	= (isset($_POST['max_height'])) ? $_POST['max_height'] : '';
							$_POST['jpg_quality']	= (isset($_POST['jpg_quality'])) ? $_POST['jpg_quality'] : '';
							$_POST['upload_max']	= (isset($_POST['upload_max'])) ? $_POST['upload_max'] : '';

							$gbook->query("UPDATE ".$table."_upload SET
					      												 max_filesize = '".$_POST['max_filesize']."', 
					      												 max_width	  = '".$_POST['max_width']."', 
					      												 max_height	  = '".$_POST['max_height']."', 
					      												 jpg_quality  = '".$_POST['jpg_quality']."', 
					      												 upload_max   = '".$_POST['upload_max']."'"); 
            		}
			}

		    $sql_select_upload  = $gbook->query("SELECT * FROM ".$table."_upload");
		    $select_upload 		= $sql_select_upload->fetch_assoc();

        	echo "<fieldset>
			<legend><strong>".$amsg[104]."</strong></legend>
			<p>&nbsp;</p>".$error_upload."
			<form method=\"post\" name=\"upload_options\" action=\"".$url."admin/admin.php?action=upload_options&#38;".session_name()."=".session_id()."\">
			<table style=\"width:500px\" class=\"guestbook_table2 tableCenter\">
				<tr>
				<td align=\"left\" style=\"width:350px\">".$amsg[105]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"max_filesize\" size=\"4\" value=\"".$select_upload['max_filesize']."\" /></td>
				</tr>
				<tr>
				<td align=\"left\">".$amsg[117]."</td>
				<td align=\"left\"><br /><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"upload_max\" value=\"".$select_upload['upload_max']."\" /></td>
				</tr>
				<tr>
				<td align=\"left\">".$amsg[106]." ".$newPicDim."px ".$amsg[107]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"max_width\" size=\"4\" value=\"".$select_upload['max_width']."\" /></td>
				</tr>
				<tr>
				<td align=\"left\">".$amsg[108]."</td>
				<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"max_height\" size=\"4\" value=\"".$select_upload['max_height']."\" /></td>
				</tr>
				<tr>
				<td align=\"left\">".$amsg[109]."</td>
				<td align=\"left\"><br /><br /><input type=\"text\" class=\"insert\" size=\"4\" name=\"jpg_quality\" value=\"".$select_upload['jpg_quality']."\" /></td>
				</tr>
				<tr>
				<td align=\"center\" colspan=\"2\"><br /><br /><input class=\"button\" type=\"submit\" name=\"send\" value=\"".$fmsg[55]."\" /></td>
				</tr>
			</table>
			</form>
			</fieldset>";
		}
		else {
			echo"<fieldset><legend><strong>".$amsg[104]."</strong></legend>
				<p>&nbsp;</p>
				<p>".$amsg[99]."</p>
				<p>".$amsg[100]."</p>
				<p>&nbsp;</p>
				</fieldset>
				<p>&nbsp;</p>";
		}
    }

?>