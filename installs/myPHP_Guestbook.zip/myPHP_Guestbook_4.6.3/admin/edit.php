<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    06.02.2015
*/
    
    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
        $sql_properties = $gbook->query("SELECT `bbcode`, `check_email`, `check_homepage`, `check_icq`, `images_in_entries`, `smilies`, `check_town`, `check_country` FROM `".$table."_properties`");
        $properties = $sql_properties->fetch_assoc();

		($properties['check_email'] > 1) ? ($hidden_email = $fmsg[125]) : ($hidden_email = "");
		($properties['check_homepage'] == 1) ? ($hidden_hp = $fmsg[125]) : ($hidden_hp = "");
		($properties['check_icq'] == 1) ? ($hidden_icq = $fmsg[125]) : ($hidden_icq = "");
		(($properties['check_town'] == 1) && ($properties['check_country'] == 1)) ? ($hidden_origin = $fmsg[125]) : ($hidden_origin = "");
		
		$allowed_characters = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿß';

        if (isset($_POST['send'])) {
            $error_msg         = "";
            $output			   = "";

            if ($_POST['name'] == "") {
                $error_msg .= "<p class=\"error red\"><strong>- ".$emsg[9]."</strong></p>";
            }

            if ($_POST['origin'] != "") {
				if (!preg_match("/^[0-9a-zA-Z".$allowed_characters."\/ '():.,|-]*$/is", $_POST['origin'])) {
					$error_msg .= "<p class=\"error red\"><strong>- ".$emsg[78]."</strong></p>";
				}
            }

            if ($_POST['text'] == "") {
                $error_msg .= "<p class=\"error red\"><strong>- ".$emsg[10]."</strong></p>";
            }

			if($_POST['email'] != "" AND !validate_mail($_POST['email'])){
	   			$error_msg .= "<p class=\"error red\"><strong>- ".$emsg[2]."</strong></p>";
			}

			if ($_POST['homepage'] != "" && $_POST['homepage'] != "http://") {
				include("../includes/idna_convert.class.php");      
				$IDN = new idna_convert();     
				$output = $IDN->encode($_POST['homepage']);
			}
      
			if ($output != "" && $output != "http://" && !validate_url($output)){
				$error_msg .= "<p class=\"error red\"><strong>- ".$fmsg[207]."</strong></p>";
			}

           	if (isset($_POST['icq']) AND $_POST['icq'] != "") {
               	if (!preg_match("/^[0-9]*$/is", $_POST['icq'])) {
               	 	$error_msg .= "<p class=\"error red\"><strong>- ".$emsg[36]."</strong></p>";
               	}
           	}

            if ($_POST['date'] == "" OR $_POST['time'] == "") {
                $error_msg .= "<p class=\"error red\"><strong>- ".$fmsg[50]."</strong></p>";
            }

            if (!$error_msg == "") {
				echo "".$error_msg."<br />";
            }
            
            else {
	            $_POST['date']     = $gbook->real_escape_string($_POST['date']);
	            $_POST['time']	   = $gbook->real_escape_string($_POST['time']);
	            $_POST['name']     = $gbook->real_escape_string($_POST['name']);
				$_POST['origin']   = $gbook->real_escape_string($_POST['origin']);
	            $_POST['email']    = $gbook->real_escape_string($_POST['email']);
	            $_POST['homepage'] = $gbook->real_escape_string($_POST['homepage']);
	            $_POST['icq']      = $gbook->real_escape_string($_POST['icq']);
                $_POST['text']	   = $gbook->real_escape_string($_POST['text']);

                $sql_update_entries = $gbook->query("UPDATE `".$table."_entries` SET `date`='".$_POST['date']."', `email`='".$_POST['email']."', `homepage`='".$_POST['homepage']."', `icq`='".$_POST['icq']."', `name`='".$_POST['name']."', `text`='".$_POST['text']."', `time`='".$_POST['time']."', `origin`='".$_POST['origin']."' WHERE `id`='".$_REQUEST['id']."'");

                if ($sql_update_entries) {
                    echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=guestbook&#38;".session_name()."=".session_id()."\" />";
                }
            }
        }

        $sql_entries = $gbook->query("SELECT `date`, `email`, `homepage`, `icq`, `name`, `text`, `time`, `origin` FROM `".$table."_entries` WHERE `id` = '".$_REQUEST['id']."'");
        $entries = $sql_entries->fetch_assoc();

        $entries['name']     = stripslashes($entries['name']);
        $entries['name']     = strip_tags($entries['name']);

		$entries['origin']	 = stripslashes($entries['origin']);
		$entries['origin']	 = strip_tags($entries['origin']);

        $entries['email']    = stripslashes($entries['email']);
        $entries['email']    = strip_tags($entries['email']);

       	$entries['homepage'] = stripslashes($entries['homepage']);
       	$entries['homepage'] = strip_tags($entries['homepage']);

       	$entries['icq'] 	 = stripslashes($entries['icq']);
       	$entries['icq']		 = strip_tags($entries['icq']);

        $entries['text']     = stripslashes($entries['text']);

		echo "<fieldset><legend><strong>".$amsg[33]."</strong></legend>
		<form action=\"".$url."admin/admin.php?action=edit&#38;".session_name()."=".session_id()."\" method=\"post\" name=\"insert\">
		<table style=\"width:500px\" class=\"guestbook_table2 tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\">
		<tr>
		<td align=\"left\" style=\"width:80px\"><br />".$fmsg[170]."</td>
		<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"date\" size=\"11\" maxlength=\"10\" value=\"";

        if (isset($_POST['date']) AND $_POST['date'] != "") {
            echo "".$_POST['date']."";
        } elseif (isset($entries['date']) AND $entries['date'] != "") {
            echo "".$entries['date']."";
        }

		echo "\" tabindex=\"1\" />&nbsp;|&nbsp;<input type=\"text\" class=\"insert\" name=\"time\" size=\"6\" maxlength=\"5\" value=\"";

        if (isset($_POST['time']) AND $_POST['time'] != "") {
            echo "".$_POST['time']."";
        } elseif (isset($entries['time']) AND $entries['time'] != "") {
            echo "".$entries['time']."";
        }

		echo "\" tabindex=\"2\" /></td>
		</tr>
		<tr>
		<td align=\"left\"><br />".$fmsg[7]."<span class=\"red\">*</span></td>
		<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"name\" size=\"28\" maxlength=\"27\" value=\"";

        if (isset($_POST['name']) AND $_POST['name'] != "") {
            echo "".$_POST['name']."";
        } elseif (isset($entries['name']) AND $entries['name'] != "") {
            echo "".$entries['name']."";
        }

		echo "\" tabindex=\"3\" /></td>
		</tr>";

		echo"
		<tr>
		<td align=\"left\"><br />".$amsg[129]."</td>
		<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"origin\" size=\"28\" maxlength=\"100\" value=\"";
	
        if (isset($_POST['origin']) AND $_POST['origin'] != "") {
            echo "".$_POST['origin']."";
        } elseif (isset($entries['origin']) AND $entries['origin'] != "") {
            echo "".$entries['origin']."";
        }
	
        echo"\" tabindex=\"4\" /> ".$hidden_origin."</td>
		</tr>";

		echo"
		<tr>
		<td align=\"left\"><br />".$fmsg[8]."";

		if (isset($properties['check_email']) AND (($properties['check_email'] == 1) || ($properties['check_email'] == 2))) {
			echo "<span class=\"red\">*</span>";
		}
	
		echo "</td>
		<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"email\" size=\"28\" maxlength=\"40\" value=\"";
	
        if (isset($_POST['email']) AND $_POST['email'] != "") {
            echo "".$_POST['email']."";
        } elseif (isset($entries['email']) AND $entries['email'] != "") {
            echo "".$entries['email']."";
        }
	
        echo"\" tabindex=\"5\" /> ".$hidden_email."</td>
		</tr>";

		echo"
		<tr>
		<td align=\"left\"><br />".$fmsg[9]."</td>
		<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"homepage\" size=\"28\" maxlength=\"80\" value=\"";

        if (isset($_POST['homepage']) AND $_POST['homepage'] != "") {
            echo "".$_POST['homepage']."";
        } elseif (isset($entries['homepage']) AND $entries['homepage'] != "") {
            echo "".$entries['homepage']."";
        } else {
            echo "http://";
        }
	
        echo "\" tabindex=\"6\" /> ".$hidden_hp."</td>
		</tr>";

		echo"
		<tr>
		<td align=\"left\"><br />ICQ:</td>
		<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"icq\" size=\"28\" maxlength=\"9\" value=\"";
		
        if (isset($_POST['icq']) AND $_POST['icq'] != "") {
            echo "".$_POST['icq']."";
        } elseif (isset($entries['icq']) AND $entries['icq'] != 0) {
            echo "".$entries['icq']."";
        }
		
        echo "\" tabindex=\"7\" /> ".$hidden_icq."</td>
		</tr>";
		 
		if ($properties['bbcode'] OR $properties['smilies'])
			{
				echo "
					<tr>
						<td colspan=\"2\" align=\"center\"><br />
						<table style=\"width:100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
							<tr>
								<td align=\"left\" class=\"td-nowrap\">";
						
									if ($properties['bbcode'])
										{
											echo"
											<a class=\"sprite-bold\" style=\"margin-left:0\" title=\"".$fmsg[185]."\" href=\"javascript:insert('[b]','[/b]');\">&nbsp;</a>
											<a class=\"sprite-italic\" title=\"".$fmsg[186]."\" href=\"javascript:insert('[i]','[/i]');\">&nbsp;</a>
											<a class=\"sprite-underline\" title=\"".$fmsg[187]."\" href=\"javascript:insert('[u]','[/u]');\">&nbsp;</a>
											<a class=\"sprite-shadow\" title=\"".$fmsg[188]."\" href=\"javascript:insert(' [shadow]','[/shadow] ');\">&nbsp;</a>
											<a class=\"sprite-crossed\" title=\"".$fmsg[280]."\" href=\"javascript:insert(' [cross]','[/cross] ');\">&nbsp;</a>
											<a class=\"sprite-justify\" title=\"".$fmsg[281]."\" href=\"javascript:insert(' [justify]',' [/justify] ');\">&nbsp;</a>
											<a class=\"sprite-center\" title=\"".$fmsg[309]."\" href=\"javascript:insert(' [center]',' [/center] ');\">&nbsp;</a>
											<a class=\"sprite-right\" title=\"".$fmsg[282]."\" href=\"javascript:insert(' [right]',' [/right] ');\">&nbsp;</a>
											<a class=\"sprite-sup\" title=\"".$fmsg[283]."\" href=\"javascript:insert('[sup]','[/sup]');\">&nbsp;</a>
											<a class=\"sprite-quote\" title=\"".$fmsg[191]."\" href=\"javascript:insert(' [quote]',' [/quote] ');\">&nbsp;</a>
											<a class=\"sprite-code\" title=\"Code\" href=\"javascript:insert(' [code]','[/code] ');\">&nbsp;</a>
											<a class=\"sprite-list\" title=\"".$fmsg[284]."\" href=\"javascript:insert(' [list] [-]', ' [/-] [-] [/-] [/list] ');\">&nbsp;</a>
											<a class=\"sprite-numlist\" title=\"".$fmsg[285]."\" href=\"javascript:insert(' [numlist] [-]', ' [/-] [-] [/-] [/numlist] ');\">&nbsp;</a>
											<a class=\"sprite-hr\" title=\"".$fmsg[286]."\" href=\"javascript:insert('[hr]','');\">&nbsp;</a>
											<a class=\"sprite-link\" title=\"".$fmsg[287]."\" href=\"".$url."bbcodes.php\" onclick=\"return PopUp(335,330,this.href);\">&nbsp;</a>
											<a class=\"sprite-email\" title=\"".$fmsg[288]."\" href=\"".$url."bbcodes.php?action=step4\" onclick=\"return PopUp(325,300,this.href)\">&nbsp;</a>";
											
											 if ($properties['images_in_entries']){
											 		echo"
														<a class=\"sprite-img\" title=\"".$fmsg[310]."\" onclick=\"javascript:NewWindow('".$url."pic.upload.php','upload','510','740','custom','front');return true;\">&nbsp;</a>";
											}
												
									echo"
										</td>
									</tr>
									<tr>
										<td align=\"left\" class=\"td-nowrap\">
											<br />
											<select class=\"select\" name=\"Color\" size=\"1\" onchange=\"InsertColorSize(this.form.Color.options[this.form.Color.selectedIndex].value,'[/color] ');\">
												<option value=\"\">".$fmsg[289]."</option>
												<option value=\" [color=gray] \">".$fmsg[274]."</option>
												<option value=\" [color=red] \">".$fmsg[306]."</option>
												<option value=\" [color=green] \">".$fmsg[307]."</option>
												<option value=\" [color=blue] \">".$fmsg[308]."</option>
												<option value=\" [color=yellow] \">".$fmsg[290]."</option>
												<option value=\" [color=orange] \">".$fmsg[291]."</option>
												<option value=\" [color=lime] \">".$fmsg[292]."</option>
												<option value=\" [color=pink] \">".$fmsg[293]."</option>
												<option value=\" [color=brown] \">".$fmsg[294]."</option>
											</select>
											<select class=\"select\" name=\"Size\" size=\"1\" onchange=\"InsertColorSize(this.form.Size.options[this.form.Size.selectedIndex].value,'[/size] ');\">
												<option value=\"\">".$fmsg[295]."</option>
												<option value=\" [size=8] \">8px</option>
												<option value=\" [size=10] \">10px</option>
												<option value=\" [size=14] \">14px</option>
												<option value=\" [size=16] \">16px</option>
												<option value=\" [size=18] \">18px</option>
												<option value=\" [size=20] \">20px</option>
											</select>";
										}
					    
									if ($properties['smilies'])
		        						{
							            	$sql_smilies_count = $gbook->query("SELECT id FROM ".$table."_smilies");
							            	$count_smilies = $sql_smilies_count->num_rows;
							            	
							            	if ($count_smilies > 0 AND $properties['bbcode'])
							            		{
													echo"<span class=\"vertikal-linie\">||</span>
														";
							            		}
		
							            	($properties['bbcode']) ? ($show_smilies = '12') : ($show_smilies = '19');
		            						$sql_smilies = $gbook->query("SELECT `bbcode`, `filename`, `height`, `name`, `width` FROM `".$table."_smilies` ORDER BY `id` ASC LIMIT 0,".$show_smilies."");
		
							            	while ($smilies = $sql_smilies->fetch_assoc())
							            		{
													echo"<a href=\"javascript:insert(' ".$smilies['bbcode']." ','');\"><img class=\"smilies\" src=\"".$url."images/smilies/".$smilies['filename']."\" width=\"".$smilies['width']."\" height=\"".$smilies['height']."\" alt=\"".$smilies['name']."\" /></a>
														";
							            		}
		
		
								            if ($count_smilies > 12)
								            	{
													echo "<a class=\"sprite-more\" title=\"".$fmsg[15]."\" href=\"javascript:NewWindow('".$url."smilies.php";
							
							                				if (isset($get_lang)) {
																echo "?lang=".$_GET['lang']."";
							                				}
							
															echo "','Smilies','380','620','custom','front');\">&nbsp;</a>";
							            		}
							            
						            		echo"<br />
												";
										}
		
									echo"</td>
									</tr>
								</table>
							</td>
						</tr>
						";
				}
		 
		 echo"
		<tr>
		<td colspan=\"2\" align=\"center\">
		<br /><textarea id=\"text\" class=\"insert\" name=\"text\" cols=\"44\" rows=\"13\" style=\"width:98%\" tabindex=\"8\" >";

        if (isset($_POST['text']) AND $_POST['text'] != "") {
            echo "".$_POST['text']."";
        } elseif (isset($entries['text']) AND $entries['text'] != "") {
            echo "".$entries['text']."";
        }

        echo "</textarea>
		</td>
		</tr>
		<tr>
		<td colspan=\"2\" align=\"center\">
			<br />
			<table style=\"width:100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
				<tr>
					<td align=\"center\" style=\"width:50%\"><p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[55]."\" tabindex=\"9\" /><input type=\"hidden\" name=\"id\" value=\"".$_REQUEST['id']."\" /></p></td>
					<td align=\"center\"><p><input type=\"button\" class=\"button\" title=\"".$fmsg[269]."\" name=\"abbruch\" value=\"".$fmsg[269]."\" onclick=\"self.location.href='admin.php?action=guestbook&#38;".session_name()."=".session_id()."'\" /></p></td>
				</tr>
			</table>
		</td>
		</tr>
		</table>
		</form>
		</fieldset>";
    }
?>