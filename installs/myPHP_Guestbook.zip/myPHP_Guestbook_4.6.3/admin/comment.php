<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

   if (!isset($_SESSION['sid'])) {
       echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
		if (isset($_GET['delete'])) {
           $sql_delete_comment = $gbook->query("UPDATE `".$table."_entries` SET `comment` = '' WHERE `id` = '".$_REQUEST['id']."'");
               if ($sql_delete_comment) {
                echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=guestbook&".session_name()."=".session_id()."\" />";
                }
        } else {
        
			$sql_email = $gbook->query("SELECT `email`, `marker` FROM `".$table."_entries` WHERE `id` = '".$_REQUEST['id']."'");
			$guest_mail = $sql_email->fetch_assoc();

			(($guest_mail['marker'] == 1 || $guest_mail['marker'] == 3) && $guest_mail['email'] != "") ? $comment_info = "<tr><td align=\"center\"><p class=\"red\"><strong>".$amsg[164]."</strong><br /></p></td></tr>" : $comment_info = "";
	
	        $guest_mail['email'] = htmlentities(strip_tags($guest_mail['email']), ENT_QUOTES, "UTF-8");
	        $guest_mail['email'] = stripslashes($guest_mail['email']);
	
			$empfaenger = $guest_mail['email'];
			$betreff = "".$amsg[162]." - ".$_SERVER['SERVER_NAME']."\n";
	
			$sql_select_noreply = $gbook->query("SELECT `noreply` FROM `".$table."_thankyou` WHERE `lang` = '".$lang_short."'");
			$select_noreply = $sql_select_noreply->fetch_assoc();
    		$sql_select_properties = $gbook->query("SELECT `admin_email`, `guestbook_title` FROM `".$table."_properties`");
			$select_properties = $sql_select_properties->fetch_assoc();

			($select_noreply['noreply'] != "") ? ($abs_info = $select_noreply['noreply']) : ($abs_info = $select_properties['admin_email']);

			$header  = "MIME-Version: 1.0\n";
			$header .= "Content-type: text/html; charset=utf-8\n";
			$header .= "Content-Transfer-Encoding: 8bit\n";
			$header .= "X-Mailer: PHP\n";
			$header .= "From: \"".$select_properties['guestbook_title']."\" <".$abs_info.">\n";
															
			$nachricht = "".$amsg[163]."";

			if (isset($_POST['send'])) {

				$_POST['comment'] = $gbook->real_escape_string($_POST['comment']);

				if ($guest_mail['email'] != "" && ($guest_mail['marker'] == 1 || $guest_mail['marker'] == 3)) {
					mail($empfaenger, $betreff, $nachricht, $header);
					
					if ($guest_mail['marker'] == 1) {
						$sql_insert_comment = $gbook->query("UPDATE `".$table."_entries` SET `comment` = '".$_POST['comment']."', `marker` = '2' WHERE `id` = '".$_REQUEST['id']."'");
					}
					
					elseif ($guest_mail['marker'] == 3) {
						$sql_insert_comment = $gbook->query("UPDATE `".$table."_entries` SET `comment` = '".$_POST['comment']."', `marker` = '0' WHERE `id` = '".$_REQUEST['id']."'");
					}
            	}
				else {
					$sql_insert_comment = $gbook->query("UPDATE `".$table."_entries` SET `comment` = '".$_POST['comment']."' WHERE `id` = '".$_REQUEST['id']."'");
				}

				if ($sql_insert_comment) {
					echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=guestbook&".session_name()."=".session_id()."\" />";
		       	}
			}

            $sql_select_comment = $gbook->query("SELECT `comment` FROM `".$table."_entries` WHERE `id` = '".$_REQUEST['id']."'");
            $select_comment = $sql_select_comment->fetch_assoc();

            if (strlen($select_comment['comment']) > 0) {
                $delete_comment_text = $fmsg['134'];
            } else {
                $delete_comment_text = "";
            }
            
      $sql_properties = $gbook->query("SELECT `bbcode`, `deactivate_html`, `images_in_entries`, `max_word_length`, `smilies`, `check_town`, `check_country` FROM `".$table."_properties`");
      $properties = $sql_properties->fetch_assoc();
       
		echo"<fieldset><legend><strong>".$fmsg[133]."</strong></legend>";
            
		echo"
			<p><br />".$amsg[34]."</p>";

        $sql_entries = $gbook->query("SELECT `comment`, `date`, `email`, `homepage`, `icq`, `id`, `ip`, `status`, `name`, `text`, `time`, `origin`  FROM `".$table."_entries` WHERE `id` = '".$_REQUEST['id']."'");
        
        while ($entries = $sql_entries->fetch_assoc()) {
			$entries['number'] 	 = "";
			
            $entries['name ']    = htmlentities(strip_tags($entries['name']), ENT_QUOTES, "UTF-8");
            $entries['name']     = stripslashes($entries['name']);

			(($properties['check_town'] == 1) && ($properties['check_country'] == 1)) ? $origin = $entries['origin'] = "" : $origin = $entries['origin'];
            $origin   = htmlentities(strip_tags($origin), ENT_QUOTES, "UTF-8");
            $origin   = stripslashes($origin);
            $origin   = shortWords($origin, $short_town);

            $entries['email']    = htmlentities(strip_tags($entries['email']), ENT_QUOTES, "UTF-8");
            $entries['email']    = stripslashes($entries['email']);

            $entries['homepage'] = htmlentities(strip_tags($entries['homepage']), ENT_QUOTES, "UTF-8");
            $entries['homepage'] = stripslashes($entries['homepage']);

			$entries['icq']      = htmlentities(strip_tags($entries['icq']), ENT_QUOTES, "UTF-8");
           	$entries['icq']      = stripslashes($entries['icq']);

            $entries['text']     = preg_replace('/(\r\n)(\\1{1,1})\\1*/sS', '$1$2', $entries['text']);
            $entries['text']     = nobadwords($entries['text']);
            $entries['text']     = shortWords($entries['text'], $properties['max_word_length']);

			if ($properties['deactivate_html']){
				$entries['text'] = htmlentities(strip_tags($entries['text']), ENT_QUOTES, "UTF-8");
			}

            $entries['text']     = nl2br($entries['text']);
            $entries['text']     = stripslashes($entries['text']);
			$entries['text'] 	 = quote($entries['text']);

            if ($properties['bbcode']) {
                $entries['text'] = bbcode($entries['text']);
                
				$sql_picture = $gbook->query("SELECT `pic_name`, `width`, `height`, `title` FROM `".$table."_pictures`");
		
			    	while ($picture = $sql_picture->fetch_assoc()){
			    		$maxpicwidth = '510';
						$newwidth = $picture['width'];
						$newheight = $picture['height'];
						
						if ($picture['width'] > $maxpicwidth){
							$prozent = $maxpicwidth/$picture['width'];
							$newwidth = floor($picture['width']*$prozent);
							$newheight = floor($picture['height']*$prozent);
						}
	
					$entries['text'] = preg_replace("/\[img\](".$picture['pic_name'].")\[\/img\]/si", "<img class=\"centered\" title=\"".$picture['title']."\" src=\"".$url."img_guest/\\1\" alt=\"".$picture['title']."\" width=\"".$newwidth."\" height=\"".$newheight."\" />", $entries['text']);
				}
            }
            else {
            	$entries['text'] = preg_replace("/\[b\](.*?)\[\/b\]/si", "<strong>\\1</strong>", $entries['text']);
            }

			if ($properties['smilies']) {
				$entries['text'] = smilies($entries['text']);
			}

			$entries['text'] = preg_replace('/(.)(\\1{1,2})\\1*/sS', '$1$2', $entries['text']);

            $entries['comment']  = nl2br($entries['comment']);

            echo "
			<table style=\"width:520px\" class=\"guestbook-table03 edit_table tableCenter\" cellpadding=\"3\" cellspacing=\"1\" border=\"0\">
			<tr class=\"headpost tdinstall1\">
			<td align=\"left\" style=\"width:43%\" class=\"headpad\">
				<strong>&nbsp;".$entries['name']."</strong>";
			
			if ($origin != "") {
				echo "<br />&nbsp;<span class=\"size-10\">".$origin."</span>";
			}
			
			echo"			
			</td>
			<td align=\"center\" style=\"width:22%\" class=\"headpad\">
			";

            if ($entries['email'] == "") {
                echo "&nbsp;";
            } else {
                echo "<a href=\"mailto:".$entries['email']."\"><img class=\"ico\" src=\"".$url."images/icons/email/emailnew.gif\" alt=\"".$entries['email']."\" /></a>";
            }

            if ($entries['homepage'] == "" OR $entries['homepage'] == "http://") {
                echo "&nbsp;";
            } else {
                echo "<a href=\"".$entries['homepage']."\" rel=\"external\"><img class=\"ico\" src=\"".$url."/images/icons/homepage/homepage.gif\" alt=\"".$entries['homepage']."\" /></a>";
            }

            if ($entries['icq'] == "" OR $entries['icq'] == 0) {
                echo "&nbsp;";
            } else {
                echo " <a href=\"http://www.icq.com/people/".$entries['icq']."&#38;lang=de\" rel=\"external\"><img class=\"ico\" src=\"http://wwp.icq.com/scripts/online.dll?icq=".$entries['icq']."&#38;img=5\" alt=\"".$entries['icq']."\" /></a>";
            }    

            echo "</td>
				<td align=\"right\" style=\"width:37%\" class=\"headpad beitragnr\"><strong>".$amsg[84]." # ".$entries['number']."</strong><br />".$amsg[85]." ".$entries['date']." ".$entries['time']."</td>
				</tr>
				<tr class=\"tdinstall2\">
				<td align=\"left\" colspan=\"3\">
				<span class=\"size-10\">IP: ".$entries['ip']."</span>
				";

			echo "<br /><br />
				".$entries['text']."
				";

            echo "</td></tr>
				</table>
				";
        }

         echo"<form action=\"".$url."admin/admin.php?action=comment&#38;".session_name()."=".session_id()."\" method=\"post\" name=\"insert\">
			<table style=\"width:500px\" class=\"guestbook_table2 tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\">";
			
			if ($select_comment['comment'] != "")
				{
					echo"
						<tr>
							<td align=\"center\" style=\"width:100%\">
								<p><br /><strong><a href=\"".$url."admin/admin.php?action=comment&#38;delete=1&#38;id=".$_REQUEST['id']."&#38;".session_name()."=".session_id()."\">".$delete_comment_text."</a></strong><br /></p>
							</td>
						</tr>";
				}

			if ($properties['bbcode'] OR $properties['smilies'])
				{
					echo "
						<tr>
							<td align=\"center\"><br />
							<table style=\"width:100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
								<tr>
									<td align=\"left\" class=\"td-nowrap\">";
						
									if ($properties['bbcode'])
										{
											echo"
											<a class=\"sprite-bold\" style=\"margin-left:0\" title=\"".$fmsg[185]."\" href=\"javascript:insert('[b]','[/b]');\">&nbsp;</a>
											<a class=\"sprite-italic\" title=\"".$fmsg[186]."\" href=\"javascript:insert('[i]','[/i]');\">&nbsp;</a>
											<a class=\"sprite-underline\" title=\"".$fmsg[187]."\" href=\"javascript:insert('[u]','[/u]');\">&nbsp;</a>
											<a class=\"sprite-shadow\" title=\"".$fmsg[188]."\" href=\"javascript:insert(' [shadow]','[/shadow] ');\">&nbsp;</a>
											<a class=\"sprite-crossed\" title=\"".$fmsg[280]."\" href=\"javascript:insert(' [cross]','[/cross] ');\">&nbsp;</a>
											<a class=\"sprite-justify\" title=\"".$fmsg[281]."\" href=\"javascript:insert(' [justify]','[/justify] ');\">&nbsp;</a>
											<a class=\"sprite-center\" title=\"".$fmsg[309]."\" href=\"javascript:insert(' [center]','[/center] ');\">&nbsp;</a>
											<a class=\"sprite-right\" title=\"".$fmsg[282]."\" href=\"javascript:insert(' [right]','[/right] ');\">&nbsp;</a>
											<a class=\"sprite-sup\" title=\"".$fmsg[283]."\" href=\"javascript:insert('[sup]','[/sup]');\">&nbsp;</a>
											<a class=\"sprite-quote\" title=\"".$fmsg[191]."\" href=\"javascript:insert(' [quote]',' [/quote] ');\">&nbsp;</a>
											<a class=\"sprite-code\" title=\"Code\" href=\"javascript:insert(' [code]',' [/code] ');\">&nbsp;</a>
											<a class=\"sprite-list\" title=\"".$fmsg[284]."\" href=\"javascript:insert(' [list] [-]', ' [/-] [-] [/-] [/list] ');\">&nbsp;</a>
											<a class=\"sprite-numlist\" title=\"".$fmsg[285]."\" href=\"javascript:insert(' [numlist] [-]', ' [/-] [-] [/-] [/numlist] ');\">&nbsp;</a>
											<a class=\"sprite-hr\" title=\"".$fmsg[286]."\" href=\"javascript:insert('[hr]','');\">&nbsp;</a>
											<a class=\"sprite-link\" title=\"".$fmsg[287]."\" href=\"".$url."bbcodes.php\" onclick=\"return PopUp(335,330,this.href);\">&nbsp;</a>
											<a class=\"sprite-email\" title=\"".$fmsg[288]."\" href=\"".$url."bbcodes.php?action=step4\" onclick=\"return PopUp(325,300,this.href)\">&nbsp;</a>";
											
											 if ($properties['images_in_entries']){
											 		echo"
														<a class=\"sprite-img\" title=\"".$fmsg[310]."\" onclick=\"javascript:NewWindow('".$url."pic.upload.php','upload','510','740','custom','front');return true;\">&nbsp;</a>";
											}
												
									echo"
										</td>
									</tr>
									<tr>
										<td align=\"left\" class=\"td-nowrap\"><br />
											<select class=\"select\" name=\"Color\" size=\"1\" onchange=\"InsertColorSize(this.form.Color.options[this.form.Color.selectedIndex].value,'[/color] ');\">
												<option value=\"\">".$fmsg[289]."</option>
												<option value=\" [color=gray] \">".$fmsg[274]."</option>
												<option value=\" [color=red] \">".$fmsg[306]."</option>
												<option value=\" [color=green] \">".$fmsg[307]."</option>
												<option value=\" [color=blue] \">".$fmsg[308]."</option>
												<option value=\" [color=yellow] \">".$fmsg[290]."</option>
												<option value=\" [color=orange] \">".$fmsg[291]."</option>
												<option value=\" [color=lime] \">".$fmsg[292]."</option>
												<option value=\" [color=pink] \">".$fmsg[293]."</option>
												<option value=\" [color=brown] \">".$fmsg[294]."</option>
											</select>
											<select class=\"select\" name=\"Size\" size=\"1\" onchange=\"InsertColorSize(this.form.Size.options[this.form.Size.selectedIndex].value,'[/size] ');\">
												<option value=\"\">".$fmsg[295]."</option>
												<option value=\" [size=8] \">8px</option>
												<option value=\" [size=10] \">10px</option>
												<option value=\" [size=14] \">14px</option>
												<option value=\" [size=16] \">16px</option>
												<option value=\" [size=18] \">18px</option>
												<option value=\" [size=20] \">20px</option>
											</select>";
										}
					    
									if ($properties['smilies'])
		        						{
							            	$sql_smilies_count = $gbook->query("SELECT id FROM ".$table."_smilies");
							            	$count_smilies = $sql_smilies_count->num_rows;
							            	
							            	if ($count_smilies > 0 AND $properties['bbcode'])
							            		{
													echo"<span class=\"vertikal-linie\">||</span>
														";
							            		}
		
							            	($properties['bbcode']) ? ($show_smilies = '12') : ($show_smilies = '19');
		            						$sql_smilies = $gbook->query("SELECT bbcode, filename, height, name, width FROM ".$table."_smilies ORDER BY `id` ASC LIMIT 0,".$show_smilies."");
		
							            	while ($smilies = $sql_smilies->fetch_assoc())
							            		{
													echo"<a href=\"javascript:insert(' ".$smilies['bbcode']." ','');\"><img class=\"smilies\" src=\"".$url."images/smilies/".$smilies['filename']."\" width=\"".$smilies['width']."\" height=\"".$smilies['height']."\" alt=\"".$smilies['name']."\" /></a>
														";
							            		}
		
		
								            if ($count_smilies > 12)
								            	{
													echo "<a class=\"sprite-more\" title=\"".$fmsg[15]."\" href=\"javascript:NewWindow('".$url."smilies.php";
							
							                				if (isset($get_lang)) {
																echo "?lang=".$_GET['lang']."";
							                				}
							
															echo "','Smilies','380','620','custom','front');\">&nbsp;</a>";
							            		}
							            
						            		echo"<br /><br />
												";
										}
		
									echo"</td>
									</tr>
								</table>
							</td>
						</tr>
						";
				}

			echo "".$comment_info."";
			
            echo "<tr>
			<td align=\"center\"><textarea id=\"text\" class=\"insert\" name=\"comment\" cols=\"45\" rows=\"15\" style=\"width:98%\">".$select_comment['comment']."</textarea></td>
			</tr>
			<tr>
			<td>
				<table style=\"width:100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
					<tr>
						<td align=\"center\" style=\"width:50%\"><p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[55]."\" tabindex=\"7\" /><input type=\"hidden\" name=\"id\" value=\"".$_REQUEST['id']."\" /></p></td>
						<td align=\"center\"><p><input type=\"button\" class=\"button\" title=\"".$fmsg[269]."\" name=\"abbruch\" value=\"".$fmsg[269]."\" onclick=\"self.location.href='admin.php?action=guestbook&#38;".session_name()."=".session_id()."'\" /></p></td>
					</tr>
				</table>
			</td>
			</tr>
			</table>
			</form>
			</fieldset>";
        }
              
    }
?>