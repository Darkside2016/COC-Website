<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";

    } else {
    	
    	$error_spamword = "";

        if ($_GET['show'] == "view_spam")
			{
	            if (isset($_POST['send']) AND isset($_POST['entry']))
					{
		                $y = count($_POST['entry']);
		
		                for ($x=0;$x<$y;$x++)
							{
			                    $entry_id = $_POST['entry'][$x];
			                    $gbook->query("DELETE FROM  ".$table."_spam  WHERE  id = '$entry_id'");
			                }
	            	}
	
				$sql_spamwords = $gbook->query("SELECT * FROM ".$table."_spam");

				$sql_spamtest_gbook	 = $gbook->query("SELECT no_spam_entries FROM ".$table."_properties");
				$sql_spamtest		 = $sql_spamtest_gbook->fetch_assoc();

				if ($sql_spamwords->num_rows == 0 )
					{
						echo "
							<div class=\"zentriert\"><br /><br /><strong>".$amsg[45]."</strong></div>
							";
							
						if ($sql_spamtest['no_spam_entries'] != 0)
							{
								$gbook->query("UPDATE ".$table."_properties SET no_spam_entries = '0'");
							}
					}
				else
					{
						$sql_gbspam_aktiviert 	= $gbook->query("SELECT no_spam_entries FROM ".$table."_properties");
						$spam_gb_aktiviert 		= $sql_gbspam_aktiviert->fetch_assoc();
						$gb_schluesselwort 		= $spam_gb_aktiviert['no_spam_entries'];
						
						if ($gb_schluesselwort)
							{
								$spam_gb_gesperrt = '<img src="../images/ok.png" width="14" height="14" alt="" />';
							}
						else
							{
								$spam_gb_gesperrt = '<img src="../images/delete.png" width="14" height="14" alt="" />';
							}

						echo "
							<fieldset>
							<legend><strong>".$amsg[46]."</strong></legend>
								<p>&nbsp;</p>
								<div class=\"zentriert\">
									<strong>".$amsg[47]."&nbsp;&nbsp;&nbsp;&nbsp;$spam_gb_gesperrt</strong><br /><br />
									<div style=\"font-size:10px;font-weight:normal;\">
										(".$amsg[48].")
									</div>
								</div>
								<p>&nbsp;</p>
								<form method=\"post\" action=\"".$url."admin/admin.php?action=spamwords&#38;show=view_spam&#38;".session_name()."=".session_id()."\">
									<table style=\"width:320px;\" cellpadding=\"4\" cellspacing=\"1\" border=\"1\" rules=\"rows\" frame=\"below\" class=\"guestbook_table2 tableCenter\">
										<tr>
											<td align=\"left\" style=\"width:87%\" class=\"tdinstall1\"><strong>".$amsg[49]."</strong></td>
											<td align=\"center\" style=\"width:13%\"  class=\"tdinstall1\"><input type=\"checkbox\" class=\"checkboxloeschen\" name=\"all\" value=\"1\" onclick=\"select_all(this.checked,this.form)\" /></td>
										</tr>";
		
			                $i = 1;
		
			                while ($spamwords = $sql_spamwords->fetch_assoc())
								{
				                    $color = ($i % 2) ? "tdinstall2" : "tdinstall2";
				                    echo "
										<tr>
											<td align=\"left\" style=\"width:87%;font-weight:normal;\" class=\"".$color."\">".$spamwords['spamword']."</td>
											<td	align=\"center\" class=\"".$color."\"><input type=\"checkbox\" name=\"entry[]\" value=\"".$spamwords['id']."\" /></td>
										</tr>";

				                    $i++;
				                }
			
			                echo "
									</table>
									<p>&nbsp;</p>
									<p class=\"aligncenter\"><br /><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[166]."\" /><br /></p>
								</form>
							</fieldset>";
					}
        	}

		elseif ($_GET['show'] == "insert_spam")
			{
	            if (isset($_POST['send']))
					{
						if ($_POST['spamword'] == "")
							{
								$error_spamword = '<p class="zentriert red"><strong>- '.$emsg[0].'</strong></p>';
							}
						else
							{
								$sql_insert_spamword = $gbook->query("INSERT INTO ".$table."_spam (spamword, id) VALUES ('".$_POST['spamword']."', '')");
										
			                    if ($sql_insert_spamword)
									{
                        				echo "<meta http-equiv=\"Refresh\" content=\"0; url=admin.php?action=spamwords&#38;show=view_spam&#38;".session_name()."=".session_id()."\" />";
                    				}
							}
					}

	            echo "
	            	<fieldset>
	            		<legend><strong>".$amsg[50]."</strong></legend>
						<p>&nbsp;</p>".$error_spamword."
						<p>&nbsp;</p>
						<form method=\"post\" action=\"".$url."admin/admin.php?action=spamwords&#38;show=insert_spam&#38;".session_name()."=".session_id()."\">
							<table style=\"width:210px\" class=\"guestbook_table2 tableCenter\" cellpadding=\"4\" cellspacing=\"0\" border=\"0\">
								<tr>
									<td align=\"left\"><strong>".$amsg[49].":</strong></td>
									<td align=\"left\"><input type=\"text\" class=\"insert\" name=\"spamword\" /></td>
								</tr>
								<tr>
									<td align=\"center\" colspan=\"2\">
										<p>&nbsp;</p>
										<p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[55]."\" /></p>
									</td>
								</tr>
							</table>
						</form>
					</fieldset>";
        	}
        
		//gesperrte IPs zur Insert-Seite
		
 		elseif ($_GET['show'] == "ip_forbidden")
			{
				$sql_ipgbook_sperre 	= $gbook->query("SELECT ip FROM ".$table."_forbidden_ip");
				$count_ipgbook_sperre 	= $sql_ipgbook_sperre->num_rows;

				echo"<fieldset>
					<legend><strong>".$amsg[51]."</strong></legend>
					<br /><br />
					<form method=\"post\" action=\"".$url."admin/admin.php?action=spamwords&#38;show=ip_forbidden&#38;".session_name()."=".session_id()."\">";
					
					if ($count_ipgbook_sperre < 1)
						{
							echo"
								<p class=\"zentriert\"><strong>".$amsg[52]."</strong></p>";
						}
			
					else
						{
							echo"
								<p class=\"zentriert\">".$amsg[53]."</p>
								<br />
								<table style=\"width:520px\" border=\"1\" rules=\"rows\" frame=\"below\" cellspacing=\"0\" cellpadding=\"0\" class=\"guestbook_table2 tableCenter\">
									<tr class=\"tdinstall1\">
										<td align=\"center\">
											<p>".$amsg[54]."</p>
										</td>
										<td style=\"width:130px\" align=\"center\">
											<p>".$amsg[55]."</p>
										</td>
										<td style=\"width:100px\" align=\"center\">
											<p>".$amsg[56]."</p>
										</td>
										<td style=\"width:60px\" align=\"center\">
											".$amsg[57]."
										</td>
										<td style=\"width:40px\" align=\"center\">
											<p><img title=\"".$amsg[58]."\" src=\"../images/delete.png\" width=\"14\" height=\"14\" alt=\"\" /></p>
										</td>
									</tr>";
						
							            if (isset($_POST['send_ip']) AND isset($_POST['entry_id']))
											{
								                $y = count($_POST['entry_id']);
												
								                for ($x=0;$x<$y;$x++)
													{
									                    $entry_id = $_POST['entry_id'][$x];
									                    $update_ipgbook_sperre = $gbook->query("DELETE FROM `".$table."_forbidden_ip` WHERE `id` = '$entry_id'");
						
														if ($update_ipgbook_sperre)
															{		
						                        				echo "<meta http-equiv=\"Refresh\" content=\"0; url=admin.php?action=spamwords&#38;show=ip_forbidden&#38;".session_name()."=".session_id()."\" />";
															}
									                }
							            	}
						
										$sql_ipgbook_sperre = $gbook->query("SELECT * FROM `".$table."_forbidden_ip` ORDER BY `id` DESC");
						
										while ($select_ipgbook = $sql_ipgbook_sperre->fetch_assoc())
											{
												echo"
													<tr style=\"height:30px\">
														<td align=\"center\" class=\"tdinstall2\">&nbsp;&nbsp;".$select_ipgbook['ip']."</td>
														<td align=\"center\" class=\"tdinstall2\">".$select_ipgbook['datum']."</td>
														<td align=\"center\" class=\"tdinstall2\">".$select_ipgbook['uhrzeit']."</td>
														<td align=\"center\" class=\"tdinstall2\">
															<a href=\"?action=spamwords&#38;show=ip_forbidden&#38;make=no_del&#38;id=".$select_ipgbook['id']."\">";
															
															if (!$select_ipgbook['no_del'])
																{
																	echo"<img title=\"".$amsg[60]."\" src=\"../images/ok.png\" width=\"14\" height=\"14\" alt=\"\" /></a>";
																}
															else
																{
																	echo"<img title=\"".$amsg[61]."\" src=\"../images/delete.png\" width=\"14\" height=\"14\" alt=\"\" /></a>";
																}
															
														echo"</td>
														<td align=\"center\" class=\"tdinstall2\"><input type=\"checkbox\" name=\"entry_id[]\" value=\"".$select_ipgbook['id']."\" /></td>
													</tr>";
								           }
						
							echo"
									</table>
									<p>&nbsp;</p>
									<hr />
									<hr />";
						
							if(isset($_GET['make']) == "no_del")
								{
									$no_del_query = $gbook->query("SELECT `no_del` FROM `".$table."_forbidden_ip` WHERE `id` = '".$_REQUEST['id']."'");
									list($no_del) = $no_del_query->fetch_row();
						
									if ($no_del != 1)
										{
						            		$update_del_sperre = $gbook->query("UPDATE `".$table."_forbidden_ip` SET `no_del` = '1' WHERE `id` = '".$_REQUEST['id']."'");
										}
									else
										{
						            		$update_del_sperre = $gbook->query("UPDATE `".$table."_forbidden_ip` SET `no_del` = '0' WHERE `id` = '".$_REQUEST['id']."'");				
										}
						
									if ($update_del_sperre)
										{		
						       				echo "<meta http-equiv=\"Refresh\" content=\"0; url=admin.php?action=spamwords&#38;show=ip_forbidden&#38;".session_name()."=".session_id()."\" />";
										}
								}
						}

				//weitere IPs hinzufügen
			
				echo"
					<p>&nbsp;</p>
					<table style=\"width:400px\" class=\"guestbook_table2 tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
						<tr>
							<td align=\"center\">
								<p>".$amsg[62]."</p>
							</td>
						</tr>";
			
				       		if (isset($_POST['send_ip']) AND !isset($_POST['entry_id']))
								{
				           			$fehler 	= "";
				
									if ($_POST['ipsperren'] == "")
										{
											$fehler .= "- ".$emsg[44]."";
										}
									elseif (!preg_match("/^[a-z0-9 .:]*$/is", $_POST['ipsperren']))
										{
											$fehler .= "- ".$emsg[43]."";
										}
									else
										{
											while (substr_count ($_POST['ipsperren'], " ") > 0)
												{
													$_POST['ipsperren'] = str_replace (" ", "", $_POST['ipsperren']);
												}
			
											$update = $gbook->query("INSERT INTO `".$table."_forbidden_ip` (`id`,`ip`,`datum`,`uhrzeit`,`www_time`,`no_del`) VALUES ('','".$_POST['ipsperren']."','".date("d.m.Y")."','".date("H:i")."','".time()."','0')");
			
											if ($update)
												{					                        
													echo "<meta http-equiv=\"Refresh\" content=\"0; url=admin.php?action=spamwords&#38;show=ip_forbidden&#38;".session_name()."=".session_id()."\" />";
												}
										}
			
									if (!$fehler == "")
										{ 
											echo "<tr><td colspan=\"3\"><br /><br /><p class=\"error\">".$fehler."</p></td></tr>";
										}
								}
					
					echo"
						<tr>
							<td align=\"center\">
								<p><input type=\"text\" class=\"insert\" name=\"ipsperren\" value=\"\" /></p>
							</td>
						</tr>";
				echo"
					</table>
					<p>&nbsp;</p>
					<p class=\"aligncenter\"><input type=\"submit\" class=\"button\" name=\"send_ip\" value=\"".$amsg[63]."\" /></p>		
					</form>
					</fieldset>
					";			
			}
    }
?>