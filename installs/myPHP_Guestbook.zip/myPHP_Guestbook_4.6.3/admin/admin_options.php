<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    03.07.2016
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    }
    else {
    	$msg_admin_options = "";
    	
        if (isset($_POST['send'])) {
            $error_msg = "";

            if ($_POST['username'] == "" OR $_POST['password'] == "" OR $_POST['admin_email'] == "") {
                $error_msg = "- ".$emsg[0]."";
            }

			if ($_POST['admin_email'] != "" && !validate_mail($_POST['admin_email'])) {
                $error_msg = "- ".$emsg[2]."";
            }

            if (!$error_msg == "") {
				$msg_admin_options = "<tr><td colspan=\"2\" align=\"center\"><p class=\"red\"><strong>".$error_msg."</strong></p></td></tr>";

            }
            
            else {
            	$_POST['admin_email'] = trim($_POST['admin_email']);
            	
                if ($_POST['password'] === $_POST['password2']) {
					$sql_update_properties = $gbook->query("UPDATE ".$table."_properties SET admin_email='".$_POST['admin_email']."', password='".md5($_POST['password'])."', username='".$_POST['username']."'");
					$msg_admin_options = "<tr><td colspan=\"2\" align=\"center\"><p class=\"green size-14\"><strong>- ".$amsg[158]."</strong></p></td></tr>";
                }
                else {
                    $msg_admin_options = "<tr><td colspan=\"2\" align=\"center\"><p class=\"red\"><strong>- ".$emsg[3]."</strong></p></td></tr>";
                }
            }
        }

        $sql_properties = $gbook->query("SELECT admin_email, username FROM ".$table."_properties");

        $properties = $sql_properties->fetch_assoc();

        echo "<fieldset>
			<legend><strong>".$fmsg[0]."</strong></legend><br />
			<form method=\"post\" action=\"".$url."admin/admin.php?action=admin_options&#38;".session_name()."=".session_id()."\">
			<table style=\"width:360px\" class=\"guestbook_table2 tableCenter\">
			".$msg_admin_options."<tr>
			<td align=\"left\" style=\"width:170px\"><br />".$fmsg[1]."</td>
			<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"username\" style=\"width:100%\" value=\"".$properties['username']."\" /></td>
			</tr>
			<tr>
			<td align=\"left\" ><br />".$fmsg[53]."</td>
			<td align=\"left\"><br /><input type=\"password\" class=\"insert\" name=\"password\" style=\"width:100%\" /></td>
			</tr>
			<tr>
			<td align=\"left\"><br />".$fmsg[54]."</td>
			<td align=\"left\"><br /><input type=\"password\" class=\"insert\" name=\"password2\" style=\"width:100%\" /></td>
			</tr>
			<tr>
			<td align=\"left\"><br />".$fmsg[8]."</td>
			<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"admin_email\" style=\"width:100%\" value=\"".$properties['admin_email']."\" /></td>
			</tr>
			<tr>
			<td align=\"center\" colspan=\"2\"><br /><br /><p><input class=\"button\" type=\"submit\" name=\"send\" value=\"".$fmsg[55]."\" /></p></td>
			</tr>
			</table>  
			</form>
			</fieldset>";
    }
?>