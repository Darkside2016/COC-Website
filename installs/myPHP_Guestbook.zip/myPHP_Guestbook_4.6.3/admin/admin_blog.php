<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

   if (!isset($_SESSION['sid'])) {
       echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
		$count_entries = "";
		$output = "";
		$bad = "";
		$good = "";
		$mark_name = "";
		$mark_email = "";
		$mark_hp = "";
		$mark_icq = "";
		$mark_subject = "";
		$mark_text = "";
		$mark_town = "";
		$mark_country = "";
		$origin = "";
		$div_c = "dsR3";
		$div_t = "dsR3";
		$div_h = "dsR3";
		$div_i = "dsR3";
		$slash = "";
		$short_town = "30";
		$hidden_email = "";
		$rows = 13;
		$allowed_characters = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿß';
		$placeholder = $fmsg[337];
		
		isset($_POST['betreff']) ? ($_POST['betreff'] = $_POST['betreff']) : ($_POST['betreff'] = "");
		isset($_POST['email']) ? ($_POST['email'] = $_POST['email']) : ($_POST['email'] = "");
		isset($_POST['homepage']) ? ($_POST['homepage'] = $_POST['homepage']) : ($_POST['homepage'] = "");
		isset($_POST['icq']) ?  ($_POST['icq'] = $_POST['icq']) : ($_POST['icq'] = "");
		isset($_POST['town']) ? ($_POST['town'] = $_POST['town']) : ($_POST['town'] = "");
		isset($_POST['country']) ? ($_POST['country'] = $_POST['country']) : ($_POST['country'] = "");
			
		$sql_properties = $gbook->query("SELECT `admin_email`, `antiflood_ban`, `bbcode`, `check_email`, `check_homepage`, `check_icq`, `deactivate_html`, `guestbook_status`, `guestbook_title`, `images_in_entries`, `max_word_length`, `notification_entries`, `release_entries`, `show_ip`, `smilies`, `statistic`, `statistic_ban`, `check_subject`, `check_town`, `check_country`, `check_free`, `button_link` 
											 FROM `".$table."_properties`");
		$properties = $sql_properties->fetch_assoc();

		if ($properties['check_town'] == 0 && $properties['check_country'] == 1) {
			$div_t = "town";
		}
		elseif ($properties['check_town'] == 1 && $properties['check_country'] == 0) {
			$div_c = "country";
		}
		elseif ($properties['check_town'] == 0 && $properties['check_country'] == 0) {
			$div_c = "country-plus";
			$div_t = "town-plus";
		}
		
		if ($properties['check_homepage'] == 0 && $properties['check_icq'] == 1) {
			$div_h = "homepage";
		}
		elseif ($properties['check_homepage'] == 1 && $properties['check_icq'] == 0) {
			$div_i = "icq";
		}
		elseif ($properties['check_homepage'] == 0 && $properties['check_icq'] == 0) {
			$div_h = "homepage-plus";
			$div_i = "icq-plus";
		}
		
		if ($properties['check_email'] == 2 || $properties['check_email'] == 3) {
			$hidden_email = "<span class=\"size-12\">".$fmsg[125]."</span>";
		}

		($properties['button_link'] == '2') ? ($blog = '<img class="img-ok" title="YES" src="../images/ok.png" width="14" height="14" alt="YES" />') : ($blog = '<img class="img-ok" title="NO" src="../images/delete.png" width="14" height="14" alt="NO" />');

		echo"<fieldset><legend><strong>".$amsg[178]."</strong></legend>";
		
		echo"
			<table class=\"tableCenter\" style=\"width:220px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
				<tr>
					<td align=\"left\">
						<br /><p><strong>".$amsg[179]."</strong></p>
					</td>
					<td align=\"right\">
						<br /><p>".$blog."&nbsp;&nbsp;&nbsp;<a class=\"cursor underline gray\" title=\"".$amsg[180]."\" href=\"javascript:{}\" onclick=\"document.getElementById('entry_link').style.display='inline';return false;\">(".$amsg[119].")</a></p>
					</td>
				</tr>";
			echo"
				<tr>
					<td colspan=\"2\" align=\"center\">
						<div id=\"entry_link\" class=\"lightbox\" style=\"display:none\" onclick=\"document.getElementById('entry_link').style.display='none';\">
						<table class=\"lightbox_table\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
							<tr>
								<td align=\"center\">
									<div style=\"width:410px;height:auto;background-color:white;text-align:left;padding:20px;font-size:16px;\"><span class=\"aligncenter\"><strong>".$amsg[180]."</strong></span>".$amsg[181]."</div>
								</td>
							</tr>
						</table>
						</div>
					</td>
				</tr>";
		echo"
			</table>
			<hr style=\"width:70%;\"/>";
            
		echo "
			<div>";

			if ($properties['guestbook_status']){
				echo"
					<p><br /><strong>".$fmsg[5]."</strong></p>";

				if (isset($_POST['send']) OR isset($_POST['preview'])){
		           	$error_msg	 = "";
		
					$_POST['name'] = trim($_POST['name']);
					$_POST['text'] = trim($_POST['text']);
					
		            if ($_POST['name'] == "") {
		            	$mark_name = " no-insert";
		                $error_msg .= "<p class=\"error\"><strong>- ".$emsg[9]."</strong></p>";
		            }
		
					elseif (!preg_match("/^[0-9a-zA-Z".$allowed_characters."' ().-]*$/is", $_POST['name'])) {
							$mark_name = " no-insert";
							$error_msg .= "<p class=\"error\"><strong>- ".$emsg[81]."</strong></p>";
					}

		            if ($properties['check_town'] == 0 && $_POST['town'] != "") {
		            	$_POST['town'] = trim($_POST['town']);
		            	
						if (!preg_match("/^[0-9a-zA-Z".$allowed_characters."\/ '():.,-]*$/is", $_POST['town'])) {
							$mark_town = " no-insert";
							$error_msg .= "<p class=\"error\"><strong>- ".$emsg[76]."</strong></p>";
						}
		            }
		
		            if ($properties['check_country'] == 0 && $_POST['country'] != "") {
		            	$_POST['country'] = trim($_POST['country']);
		            	
						if (!preg_match("/^[0-9a-zA-Z".$allowed_characters."\/ '():.,-]*$/is", $_POST['country'])) {
							$mark_country = " no-insert";
							$error_msg .= "<p class=\"error\"><strong>- ".$emsg[77]."</strong></p>";
						}
		            }
		            
		            if ($_POST['town'] != "" && $_POST['country'] != "") {
		    			$slash = " | ";
					}

					if ($properties['check_email'] != 4){
		            	$_POST['email'] = trim($_POST['email']);
						
			            if (($properties['check_email'] == 1 || $properties['check_email'] == 2) AND !validate_mail($_POST['email'])) {
			            	$mark_email = " no-insert";
			                $error_msg .= "<p class=\"error\"><strong>- ".$emsg[2]."</strong></p>";
			            }
			
						elseif($_POST['email'] != "" AND !validate_mail($_POST['email'])){
							$mark_email = " no-insert";
				   			$error_msg .= "<p class=\"error\"><strong>- ".$emsg[2]."</strong></p>";
				   		}
					}
					else {
						$_POST['email'] = "";
					}

					if ($properties['check_homepage'] == 0){
		            	$_POST['homepage'] = trim($_POST['homepage']);
		
						if ($_POST['homepage'] != "" && $_POST['homepage'] != "http://") {
							$hpcount_http = substr_count(strtolower($_POST['homepage']), 'http://', 0);
							$hpcount_https = substr_count(strtolower($_POST['homepage']), 'https://', 0);
							
							if ($hpcount_http == 0 && $hpcount_https == 0) {
								$_POST['homepage'] = "http://".$_POST['homepage']."";
							}
						
							include("../includes/idna_convert.class.php");      
		
							$IDN = new idna_convert();     
							$output = $IDN->encode($_POST['homepage']);
						}
		      
						if ($output != "" && $output != "http://" && !validate_url($output)){
							$mark_hp = " no-insert";
							$error_msg .= "<p class=\"error\"><strong>- ".$fmsg[207]."</strong></p>";
						}
					}
					else {
						$_POST['homepage'] = "";
					}
				
					if ($properties['check_icq'] == 0){
		            	$_POST['icq'] = trim($_POST['icq']);
		
						if ($_POST['icq'] != "" && !preg_match("/^[0-9]*$/is", $_POST['icq'])) {
							$mark_icq = " no-insert";
							$error_msg .= "<p class=\"error\"><strong>- ".$emsg[36]."</strong></p>";
						}
					}
					else {
						$_POST['icq'] = "";
					}
			
		            if ($properties['check_subject'] == 0 && $_POST['betreff'] != "") {
		            	$_POST['betreff'] = trim($_POST['betreff']);
		            	
						if (!preg_match("/^[0-9a-zA-Z".$allowed_characters."\/ '():.,!?-]*$/is", $_POST['betreff'])) {
							$mark_subject = " no-insert";
							$error_msg .= "<p class=\"error\"><strong>- ".$emsg[56]."</strong></p>";
						}
		            }
            
		            if ($_POST['text'] == "") {
		            	$mark_text = " no-insert";
		                $error_msg .= "<p class=\"error\"><strong>- ".$emsg[10]."</strong></p>";
		            }
            
		            if (!$error_msg == ""){
						echo "<div class=\"error-width gb-align break\">".$error_msg."</div>";
					}
            
					else {
							if (isset($_POST['send'])) {
								if ($properties['release_entries'] == 1) {
									$status = 0;
								}
								else {
									$status = 2;
								}
		
								mt_srand((double)microtime()*1000000);
								$activation_code     = mt_rand(1000000,9999999);
								$activation_hashcode = md5($activation_code);

								$_POST['name']     = $gbook->real_escape_string($_POST['name']);
								$_POST['town']     = $gbook->real_escape_string($_POST['town']);
								$_POST['country']  = $gbook->real_escape_string($_POST['country']);
								$_POST['email']    = $gbook->real_escape_string($_POST['email']);
								$_POST['homepage'] = $gbook->real_escape_string($_POST['homepage']);
								$_POST['icq']      = $gbook->real_escape_string($_POST['icq']);
								$_POST['betreff']  = $gbook->real_escape_string($_POST['betreff']);
								$_POST['text']     = $gbook->real_escape_string($_POST['text']);
		
								$origin  = $_POST['town'];
								$origin .= $slash;
								$origin .= $_POST['country'];

								($_POST['betreff'] != "") ? ($entry  = "[b]".$_POST['betreff']."[/b]\r\n\r\n") : $entry  = "";		                
								$entry .= $_POST['text'];
		
							    $sql_insert_entry  = $gbook->query("INSERT INTO `".$table."_entries` (`date`, `email`, `homepage`, `icq`, `ip`, `status`, `name`, `activation_code`, `text`, `time`, `origin`, `marker`) VALUES ('".date("d.m.Y")."', '".$_POST['email']."', '".$_POST['homepage']."', '".$_POST['icq']."', '".$_SERVER['REMOTE_ADDR']."', '".$status."', '".$_POST['name']."', '$activation_hashcode', '".$entry."', '".date("H:i")."', '".$origin."', '0')");
					
							    if ($sql_insert_entry AND !$properties['release_entries']) {
									echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=guestbook&#38;".session_name()."=".session_id()."\"";
							
									if (isset($get_lang)) {
										echo "?lang=".$_GET['lang']."";
									}
											
									echo "\">";
								}
								elseif ($properties['release_entries']) {
									echo "<meta http-equiv=\"Refresh\" content=\"3; url=".$url."admin/admin.php?action=guestbook&#38;".session_name()."=".session_id()."\"";
											
									if (isset($get_lang)) {
										echo "?lang=".$_GET['lang']."";
									}
											
									echo "\">
										<div class=\"error-width gb-align break\"><p class=\"error\">".$fmsg[11]."</p></div>";
								}
								else {
									echo "<div class=\"error-width gb-align break\"><p class=\"error\">".$emsg[11]."</p></div>";
								}
							}

						if (isset($_POST['preview'])) {
							$bad  = array("(",")","{","}","@");
							$good = array("&#40;","&#41;","&#123;","&#125;","&#64;");
		
							$name = $_POST['name'];
							$name = nobadwords($name);
							$name = htmlentities(strip_tags($name), ENT_QUOTES, "UTF-8");
							$name = stripslashes($name);
							$name = str_replace($bad, $good, $name);
		
							$town = $_POST['town'];
							$town = nobadwords($town);
							$town = htmlentities(strip_tags($town), ENT_QUOTES, "UTF-8");
							$town = stripslashes($town);
		                    $town = shortWords($town, $short_town);
		
							$country = $_POST['country'];
							$country = nobadwords($country);
							$country = htmlentities(strip_tags($country), ENT_QUOTES, "UTF-8");
							$country = stripslashes($country);
		
							$email = $_POST['email'];
							$email = htmlentities(strip_tags($email), ENT_QUOTES, "UTF-8");
							$email = stripslashes($email);
							$email = noInjektion($email);
		      				$email = noSpam02($email);
		
							$homepage = $_POST['homepage'];
							$homepage = htmlentities(strip_tags($homepage), ENT_QUOTES, "UTF-8");
							$homepage = stripslashes($homepage);
							
							$subject = $_POST['betreff'];
							$subject = nobadwords($subject);
							$subject = htmlentities(strip_tags($subject), ENT_QUOTES, "UTF-8");
							$subject = stripslashes($subject);
							
							if($_POST['betreff'] != "")	{
								$subject = "<strong>".$subject."</strong>
											<br /><br />
											";
							}
					
							$text = $_POST['text'];
		 				    $text = preg_replace('/(\r\n)(\\1{1,1})\\1*/sS', '$1$2', $text);
		                    $text = nobadwords($text);
		                    $text = shortWords($text, $properties['max_word_length']);
		
		                    if ($properties['deactivate_html']){
		                       	 $text = htmlentities(strip_tags($text), ENT_QUOTES, "UTF-8");
		                    }
		
		                    $text  = nl2br($text);
		                    $text  = stripslashes($text);
		
							$_POST['icq'] = htmlentities(strip_tags($_POST['icq']), ENT_QUOTES, "UTF-8");
		                   	$_POST['icq'] = stripslashes($_POST['icq']);
		
		                    if ($properties['bbcode']) {
		                        $text = bbcode($text);
		                        
								$sql_picture = $gbook->query("SELECT `pic_name`, `width`, `height`, `title` FROM `".$table."_pictures`");
						
							    	while ($picture = $sql_picture->fetch_assoc()){
							    		$maxpicwidth = '490';
										$newwidth = $picture['width'];
										$newheight = $picture['height'];
										
										if ($picture['width'] > $maxpicwidth){
											$prozent = $maxpicwidth/$picture['width'];
											$newwidth = floor($picture['width']*$prozent);
											$newheight = floor($picture['height']*$prozent);
										}
					
										$text = preg_replace("/\[img\](".$picture['pic_name'].")\[\/img\]/si", "<img class=\"centered\" title=\"".$picture['title']."\" src=\"".$url."img_guest/\\1\" alt=\"".$picture['title']."\" width=\"".$newwidth."\" height=\"".$newheight."\" />", $text);
									}
		                    }
		
		                    if ($properties['smilies']) {
		                        $text 	= smilies($text);
		                    }
		
						    $text = preg_replace('/(.)(\\1{1,2})\\1*/sS', '$1$2', $text);
						    $text = str_replace($bad, $good, $text);
		
							$post  = $subject;
							$post .= $text;

							(($town != "") && ($properties['check_town'] == 0)) ? $town = $town : $town = "";		                
							(($country != "") && ($properties['check_country'] == 0)) ? $country = $country : $country = "";		                
							$origin  = $town;
							$origin .= $slash;
							$origin .= $country;
		
				           	$sql_count_entries	= $gbook->query("SELECT  `id`  FROM  `".$table."_entries`  WHERE  `status` != '0'");
				            $count_entries 		= $sql_count_entries->num_rows;
				            $count_entries 		= $count_entries+1;

							echo "
								<table style=\"width:520px\" class=\"guestbook-table03 edit_table tableCenter\" cellpadding=\"3\" cellspacing=\"1\" border=\"0\">
								<tr class=\"headpost tdinstall1\">
								<td align=\"left\" style=\"width:43%\" class=\"headpad\">
									<strong>&nbsp;".$name."</strong>";
								
								if ($origin != "") {
									echo "<br />&nbsp;<span class=\"size-10\">".$origin."</span>";
								}
								
								echo"			
								</td>
								<td align=\"center\" style=\"width:22%\" class=\"headpad\">
								";
					
					            if ($email == "" OR $properties['check_email'] == 4) {
					                echo "&nbsp;";
					            } else {
					                echo "<a href=\"mailto:".$email."\"><img class=\"ico\" src=\"".$url."images/icons/email/emailnew.gif\" alt=\"".$email."\" /></a>";
					            }
					
					            if ($homepage == "" OR $homepage == "http://" OR $properties['check_homepage']) {
					                echo "&nbsp;";
					            } else {
					                echo "<a href=\"".$homepage."\" rel=\"external\"><img class=\"ico\" src=\"".$url."/images/icons/homepage/homepage.gif\" alt=\"".$homepage."\" /></a>";
					            }
					
					            if ($_POST['icq'] == "" OR $_POST['icq'] == 0 OR $properties['check_icq']) {
					                echo "&nbsp;";
					            } else {
					                echo " <a href=\"http://www.icq.com/people/".$_POST['icq']."&#38;lang=de\" rel=\"external\"><img class=\"ico\" src=\"http://wwp.icq.com/scripts/online.dll?icq=".$_POST['icq']."&#38;img=5\" alt=\"".$_POST['icq']."\" /></a>";
					            }    
					
					            echo "</td>
									<td align=\"right\" style=\"width:37%\" class=\"headpad beitragnr\"><strong>".$amsg[84]." # ".$count_entries."</strong><br />".$amsg[85]." ".date("d.m.Y")." ".date("H:i")."</td>
									</tr>
									<tr class=\"tdinstall2\">
									<td align=\"left\" colspan=\"3\" style=\"padding:10px;\">";
									
									 if ($properties['show_ip']) {
									 	echo "<span class=\"size-10\">IP: ".$_SERVER['REMOTE_ADDR']."</span><br /><br />";
									 }

								echo "".$post."
									";
					
					            echo "</td></tr>
									</table>
									";

						}
					}
				}
        
		         echo"
					<form action=\"".$url."admin/admin.php?action=adminblog&#38;".session_name()."=".session_id()."\" method=\"post\" name=\"insert\">
					<table style=\"width:500px\" class=\"guestbook_table2 tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\">
						<tr>
							<td align=\"left\">
								<div class=\"insert-height\">
									<strong class=\"lineheight\">".$fmsg[7]."<span class=\"red\">*</span></strong>
									<input class=\"insert insert-blog".$mark_name."\" type=\"text\" name=\"name\" size=\"25\" maxlength=\"27\" placeholder=\"(".$fmsg[334].")\" value=\"";
									
							        if (isset($_POST['name']) AND $_POST['name'] != "") {
							            echo stripslashes(htmlspecialchars(strip_tags($_POST['name']), ENT_QUOTES));
							        }
							        
									echo "\" />
								</div>
								<div class=\"break\"></div>";
				
						if(isset($properties['check_email']) AND $properties['check_email'] != 4){
							echo"
								<div class=\"insert-height\">
										<strong class=\"lineheight\">".$fmsg[8]."";
							
								        if (isset($properties['check_email']) AND ($properties['check_email'] == 1 || $properties['check_email'] == 2)) {
								            echo "<span class=\"red\">*</span>";
								            $placeholder = $fmsg[334];
										}
										echo"</strong> ".$hidden_email."
										<input class=\"insert insert-blog".$mark_email."\" type=\"text\" name=\"email\" size=\"25\" maxlength=\"50\" placeholder=\"(".$placeholder.")\" value=\"";
								
								        if (isset($_POST['email']) AND $_POST['email'] != "") {
								            echo stripslashes(htmlspecialchars(strip_tags($_POST['email']), ENT_QUOTES));
								        }
								
										echo"\" />
									</div>
									<div class=\"break\"></div>";
						}
			
						if((isset($properties['check_town']) && $properties['check_town'] == 0) OR (isset($properties['check_country']) && $properties['check_country'] == 0)) {
							echo"
								<div class=\"insert-height\">
										<div class=\"".$div_t."\">";
								
										if($properties['check_town'] == 0){
											echo"
											<strong class=\"lineheight\">".$fmsg[346]."</strong>
											<input class=\"insert insert-blog".$mark_town."\" type=\"text\" name=\"town\" size=\"15\" maxlength=\"60\" placeholder=\"(".$fmsg[337].")\" value=\"";
									
									        if (isset($_POST['town']) AND $_POST['town'] != "") {
									            echo stripslashes(htmlspecialchars(strip_tags($_POST['town']), ENT_QUOTES));
									        }
									
											echo"\" />";
										}
							
									echo"
										</div>
										<div class=\"".$div_c."\">";
								
										if($properties['check_country'] == 0){
											echo"
											<strong class=\"lineheight\">".$fmsg[347]."</strong>
											<input class=\"insert insert-blog".$mark_country."\" type=\"text\" name=\"country\" size=\"15\" maxlength=\"35\" placeholder=\"(".$fmsg[337].")\" value=\"";
									
									        if (isset($_POST['country']) AND $_POST['country'] != "") {
									            echo stripslashes(htmlspecialchars(strip_tags($_POST['country']), ENT_QUOTES));
									        }
									
											echo"\" />";
										}
										
									echo"
										</div>
									</div>";
									
									if(($properties['check_town'] == 0) && ($properties['check_country'] == 0)) {
										echo"<p class=\"pad-10\"><br /></p>";
									}
									
									echo"
										<div class=\"break\"></div>";
						}

						if((isset($properties['check_homepage']) && $properties['check_homepage'] == 0) OR (isset($properties['check_icq']) && $properties['check_icq'] == 0)){
							echo"
								<div class=\"insert-height\">
										<div class=\"".$div_h."\">";
								
										if($properties['check_homepage'] == 0){
											echo"
											<strong class=\"lineheight\">".$fmsg[9]."</strong>
											<input class=\"insert insert-blog".$mark_hp."\" type=\"text\" name=\"homepage\" size=\"25\" maxlength=\"80\" placeholder=\"(".$fmsg[337].")\" value=\"";
									
										    if (isset($_POST['homepage']) AND $_POST['homepage'] != "") {
									            echo stripslashes(htmlspecialchars(strip_tags($_POST['homepage']), ENT_QUOTES));
									        }
								
											echo "\" />";
										}
							
									echo"
										</div>
										<div class=\"".$div_i."\">";
								
										if($properties['check_icq'] == 0){
											echo"
											<strong class=\"lineheight\">ICQ:</strong>
											<input class=\"insert insert-blog".$mark_icq."\" type=\"text\" name=\"icq\" size=\"25\" maxlength=\"9\" placeholder=\"(".$fmsg[337].")\" value=\"";
										
									        if (isset($_POST['icq']) AND $_POST['icq'] != "") {
									            echo stripslashes(htmlspecialchars(strip_tags($_POST['icq']), ENT_QUOTES));
									        } 
										
											echo "\" />";
										}
										
									echo"
										</div>
									</div>
									<div class=\"break\"></div>";
						}

						if(isset($properties['check_subject']) && $properties['check_subject'] == 0){
							echo "
								<div class=\"insert-height\">
										<strong class=\"lineheight\">".$fmsg[313]."</strong>
										<input class=\"insert insert-blog".$mark_subject."\" type=\"text\" name=\"betreff\" size=\"25\" maxlength=\"70\" placeholder=\"(".$fmsg[337].")\" value=\"";
							
											if (isset($_POST['betreff']) AND $_POST['betreff'] != "") {
							            		echo stripslashes(htmlspecialchars(strip_tags($_POST['betreff']), ENT_QUOTES));
											}
							
										echo "\" />
								</div>
								<div class=\"break\"></div>";
						} else {
							$_POST['betreff'] = "";
							echo "<br />";
						}

						if ($properties['bbcode'] OR $properties['smilies'])
							{
								echo "
									<div class=\"bbc-space lineheight\">";
										
											if ($properties['bbcode']){
												echo"
													<a class=\"sprite-bold\" title=\"".$fmsg[185]."\" href=\"javascript:insert('[b]','[/b]');\">&nbsp;</a>
													<a class=\"sprite-italic\" title=\"".$fmsg[186]."\" href=\"javascript:insert('[i]','[/i]');\">&nbsp;</a>
													<a class=\"sprite-underline\" title=\"".$fmsg[187]."\" href=\"javascript:insert('[u]','[/u]');\">&nbsp;</a>
													<a class=\"sprite-shadow\" title=\"".$fmsg[188]."\" href=\"javascript:insert(' [shadow]','[/shadow] ');\">&nbsp;</a>
													<a class=\"sprite-crossed\" title=\"".$fmsg[280]."\" href=\"javascript:insert(' [cross]','[/cross] ');\">&nbsp;</a>
													<a class=\"sprite-justify\" title=\"".$fmsg[281]."\" href=\"javascript:insert(' [justify]',' [/justify] ');\">&nbsp;</a>
													<a class=\"sprite-center\" title=\"".$fmsg[309]."\" href=\"javascript:insert(' [center]',' [/center] ');\">&nbsp;</a>
													<a class=\"sprite-right\" title=\"".$fmsg[282]."\" href=\"javascript:insert(' [right]',' [/right] ');\">&nbsp;</a>
													<a class=\"sprite-sup\" title=\"".$fmsg[283]."\" href=\"javascript:insert('[sup]','[/sup]');\">&nbsp;</a>
													<a class=\"sprite-quote\" title=\"".$fmsg[191]."\" href=\"javascript:insert(' [quote]',' [/quote] ');\">&nbsp;</a>
													<a class=\"sprite-code\" title=\"Code\" href=\"javascript:insert(' [code]',' [/code] ');\">&nbsp;</a>
													<a class=\"sprite-list\" title=\"".$fmsg[284]."\" href=\"javascript:insert(' [list] [-]', ' [/-] [-] [/-] [/list] ');\">&nbsp;</a>
													<a class=\"sprite-numlist\" title=\"".$fmsg[285]."\" href=\"javascript:insert(' [numlist] [-]', ' [/-] [-] [/-] [/numlist] ');\">&nbsp;</a>
													<a class=\"sprite-hr\" title=\"".$fmsg[286]."\" href=\"javascript:insert('[hr]','');\">&nbsp;</a>
													<a class=\"sprite-link\" title=\"".$fmsg[287]."\" href=\"".$url."bbcodes.php\" onclick=\"return PopUp(335,330,this.href);\">&nbsp;</a>
													<a class=\"sprite-email\" title=\"".$fmsg[288]."\" href=\"".$url."bbcodes.php?action=step4\" onclick=\"return PopUp(325,300,this.href)\">&nbsp;</a>";
															
													if ($properties['images_in_entries']){
														echo"
															<a class=\"sprite-img\" title=\"".$fmsg[310]."\" onclick=\"javascript:NewWindow('".$url."pic.upload.php','upload','510','740','custom','front');return true;\">&nbsp;</a>";
													}
																
												echo"
													</div>
													<div class=\"margtop-ten\">
														<span class=\"bbc-space lineheight\">
															<select class=\"select\" name=\"Color\" size=\"1\" onchange=\"InsertColorSize(this.form.Color.options[this.form.Color.selectedIndex].value,'[/color] ');\">
																<option value=\"\">".$fmsg[289]."</option>
																<option value=\" [color=gray]\">".$fmsg[274]."</option>
																<option value=\" [color=red]\">".$fmsg[306]."</option>
																<option value=\" [color=green]\">".$fmsg[307]."</option>
																<option value=\" [color=blue]\">".$fmsg[308]."</option>
																<option value=\" [color=yellow]\">".$fmsg[290]."</option>
																<option value=\" [color=orange]\">".$fmsg[291]."</option>
																<option value=\" [color=lime]\">".$fmsg[292]."</option>
																<option value=\" [color=pink]\">".$fmsg[293]."</option>
																<option value=\" [color=brown]\">".$fmsg[294]."</option>
															</select>&nbsp;
															<select class=\"select\" name=\"Size\" size=\"1\" onchange=\"InsertColorSize(this.form.Size.options[this.form.Size.selectedIndex].value,'[/size] ');\">
																<option value=\"\">".$fmsg[295]."</option>
																<option value=\" [size=8]\">8px</option>
																<option value=\" [size=10]\">10px</option>
																<option value=\" [size=14]\">14px</option>
																<option value=\" [size=16]\">16px</option>
																<option value=\" [size=18]\">18px</option>
																<option value=\" [size=20]\">20px</option>
															</select>
														</span>";
												}
						    
											if ($properties['smilies']){
												$sql_smilies_count = $gbook->query("SELECT `id` FROM `".$table."_smilies`");
											    $count_smilies = $sql_smilies_count->num_rows;
											            	
											    if ($count_smilies > 0 AND $properties['bbcode']){
													echo"<span class=\"vertikal-linie\">||</span>";
												}
												
												echo"<span class=\"bbc-space lineheight\">";
						
											    ($properties['bbcode']) ? ($show_smilies = '12') : ($show_smilies = '19');
						            			$sql_smilies = $gbook->query("SELECT `bbcode`, `filename`, `height`, `name`, `width` FROM `".$table."_smilies` ORDER BY `id` ASC LIMIT 0,".$show_smilies."");
						
											    while ($smilies = $sql_smilies->fetch_assoc()){
													echo"<a href=\"javascript:insert(' ".$smilies['bbcode']." ','');\"><img class=\"smilies\" src=\"".$url."images/smilies/".$smilies['filename']."\" width=\"".$smilies['width']."\" height=\"".$smilies['height']."\" alt=\"".$smilies['name']."\" /></a>
														";
											    }
						
												if ($count_smilies > 12){
													echo "<a class=\"sprite-more\" title=\"".$fmsg[15]."\" href=\"javascript:NewWindow('".$url."smilies.php";
											
											        if (isset($get_lang)) {
														echo "?lang=".$_GET['lang']."";
											        }
											
													echo "','Smilies','380','620','custom','front');\">&nbsp;</a>";
												}
											            
										        echo"<br /></span>
													";
											}
						
										echo"</div>
											<noscript>".$emsg[55]."</noscript>";
								}

								echo"<br />
									<textarea rows=\"".$rows."\" id=\"text\" name=\"text\" class=\"insert insert-blog".$mark_text."\" cols=\"25\" placeholder=\"(".$fmsg[348].")\">";
						
							        if (isset($_POST['text'])) {
							            echo stripslashes(htmlspecialchars(strip_tags($_POST['text']), ENT_QUOTES));
							        }
							        
								echo "</textarea>
									<p class=\"marg-five\">&nbsp;</p>";

					echo"
					<table class=\"tableCenter\" style=\"width:90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
						<tr>
							<td align=\"center\"><input class=\"button\" type=\"submit\" title=\"".$fmsg[16]."\" name=\"send\" value=\"".$fmsg[16]."\" /></td>
							<td align=\"center\"><input class=\"button\" type=\"submit\" title=\"".$fmsg[179]."\" name=\"preview\" value=\"".$fmsg[179]."\" /></td>
							<td align=\"center\">
								<input class=\"button\" type=\"button\" title=\"".$fmsg[269]."\" name=\"abbruch\" value=\"".$fmsg[269]."\" onclick=\"self.location.href='admin.php?action=adminblog&#38;".session_name()."=".session_id()."'\" />
							</td>
						</tr>
					</table>
					<div class=\"break\"><br /></div>";
			        
			    } else {
					echo "<form action=\"#\" method=\"post\">
						<table class=\"tableCenter\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
						<tr>
						<td algin=\"center\">
						<div class=\"insert-table gb-align\">
						<p class=\"text-center\"><br /><strong>".$emsg[17]."</strong></p>
						</div>
						<div class=\"break\"><br /></div>";
			    }

			echo"
					</td>
				</tr>
			</table>
			</form>
			</div>
			</fieldset>";
        }
?>