<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    01.05.2016
*/

	$_GET['free_code'] = $gbook->real_escape_string($_GET['free_code']);

    $sql_entry = $gbook->query("SELECT `id`, `status` FROM `".$table."_entries` WHERE `activation_code` = '".$_GET['free_code']."'");
	$free_entry = $sql_entry->fetch_assoc();
	$free_status = $free_entry['status'];

	$sql_adminmail 	= $gbook->query("SELECT `admin_email` FROM `".$table."_properties`");
	$sperr_mail 	= $sql_adminmail->fetch_assoc();
	$empfaenger_admin = $sperr_mail['admin_email'];
	
	$betreff_admin = "".$amsg[75]." - ".$_SERVER['SERVER_NAME']."\n";
	$header  = "MIME-Version: 1.0\n";
	$header .= "Content-type: text/html; charset=utf-8\n";
	$header .= "Content-Transfer-Encoding: 8bit\n";
	$header .= "X-Mailer: PHP\n";
	$header .= "From: \"".$properties['guestbook_title']."\" <".$properties['admin_email'].">\r\n";
								
	$nachricht01_admin = "".$fmsg[264]."";

	$nachricht02_admin = "".$fmsg[265]."";

    if ($sql_entry->num_rows == 1 && $free_status != 2)
		{
	        $gbook->query("UPDATE `".$table."_entries` SET `status` = '2' WHERE `id` = '".$free_entry['id']."'");

       		mail($empfaenger_admin, $betreff_admin, $nachricht01_admin, $header);
	    }
	if ($sql_entry->num_rows != 1 && $free_status != 2)
		{
       		mail($empfaenger_admin, $betreff_admin, $nachricht02_admin, $header);
    	}

?>