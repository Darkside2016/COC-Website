<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    01.05.2015
*/

	$allowed_attemps = 5; 	// erlaubte Fehlversuche zum Admin-Login, bevor der Login-Bereich gesperrt wird
	$barrier_days = 7;		// Anzahl der Tage, nach denen eine Sperre des Login-Bereich automatisch wieder aufgehoben wird

	$activate_email = 0;
	
	if (isset($_GET['action']))
		{
			$_GET['action'] = $gbook->real_escape_string($_GET['action']);

			if (!preg_match("/^[_\a-z]*$/is", $_GET['action']))
				{
					$_GET['action'] = "login";
				}
		}
	else
		{
			$_GET['action'] = "login";
		}

	if ($_GET['action'] == "activatelogin")
		{
			$_GET['logincode'] = $gbook->real_escape_string($_GET['logincode']);
			
			$sql_free_login = $gbook->query("SELECT `id` FROM `".$table."_login_counter` WHERE `login_code` = '".$_GET['logincode']."'");

		    if ($sql_free_login->num_rows != 0)
				{
			        $gbook->query("DELETE FROM `".$table."_login_counter`");
			        
			        echo'<meta http-equiv="Refresh" content="0; url='.$url.'admin/admin.php?action=login" />';
				}
		}

	$login_query = $gbook->query("SELECT `login_time`, `counter`, `login_code` FROM `".$table."_login_counter`");
	list($login_time, $login_counter, $login_code) = $login_query->fetch_row();
	
	$login_free = time()-(86400*$barrier_days);

	if ($login_time < $login_free)
		{
			$gbook->query("DELETE FROM `".$table."_login_counter`");
		}

	if ($login_counter >= $allowed_attemps)
		{
			define('ADMIN_LOGIN', false);
			
			($login_counter == $allowed_attemps) ? $activate_email = 1 : "";
		}
	else
		{
			define('ADMIN_LOGIN', true);
		}
	
	if (ADMIN_LOGIN)
		{
		    if ($_GET['action'] == "login")
				{
					if (isset($_POST['send']))
						{
							$_POST['username'] = $gbook->real_escape_string($_POST['username']);
							$_POST['password'] = $gbook->real_escape_string($_POST['password']);
							$error_msg = "";
		
							if ($_POST['username'] == "" OR $_POST['password'] == "")
								{
		                			$error_msg .= "<p class=\"red\"><strong>- ".$emsg[0]."</strong></p><br />";
		            			}
		
		            		if (!$error_msg == "")
		            			{
		                			echo "".$error_msg."";
		            			}
		            		else
		            			{
		                			$sql_properties = $gbook->query("SELECT `username`, `password` FROM `".$table."_properties` WHERE `username` = '".$_POST['username']."'");
		                			$properties = $sql_properties->fetch_assoc();
		
		                			if ($properties['username'] === $_POST['username'] AND $properties['password'] === md5($_POST['password']))
		                				{
		                    				$_SESSION['sid'] = $_POST['username'];
		                    
		                    				$gbook->query("DELETE FROM `".$table."_login_counter`");
		
											echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=guestbook&#38;".session_name()."=".session_id()."\" />";
		                				}
		                			else
		                				{
		                					if ($login_counter != "")
		                						{
		                							$gbook->query("UPDATE `".$table."_login_counter` SET `login_time` = '".time()."', `counter` = counter+1, `login_code` = ''") or die();
		                						}
		                					else
		                						{
		                							$gbook->query("INSERT INTO `".$table."_login_counter` (`id`, `login_time`, `counter`, `login_code`)   VALUES   ('',  '".time()."',  '1', '')") or die();
		                						}
		                	
		                    				sleep(3);
		
											echo "<p class=\"red\"><strong>- ".$fmsg[135]."</strong></p><br />";
		                				}
		            			}
						}
		
					echo "<br/>
						<form method=\"post\" action=\"".$url."admin/admin.php?action=login\">
						<table style=\"width:270px\" class=\"guestbook_table2 tableCenter\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">
							<tr>
								<td align=\"left\"><br />".$fmsg[1]." </td>
								<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"username\" autofocus=\"autofocus\" autocomplete=\"off\" /></td>
							</tr>
							<tr>
								<td align=\"left\"><p>".$fmsg[20]."</p></td>
								<td align=\"left\"><p><input type=\"password\" class=\"insert\" name=\"password\" /></p></td>
							</tr>
							<tr>
								<td align=\"center\" colspan=\"2\"><br/><strong><a href=\"".$url."admin/admin.php?action=password_forget\">".$fmsg[216]."</a></strong><br/><br/></td>
							</tr>
							<tr>
								<td colspan=\"2\" align=\"center\"><p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[136]."\" /></p></td>
							</tr>
						</table>
						</form>
						<br/>";
				}
		
		    if ($_GET['action'] == "password_forget")
				{
			        if (isset($_POST['send_password_forget']))
						{
							$_POST['admin_email'] = $gbook->real_escape_string($_POST['admin_email']);
							$error_msg = "";
			
			            	if ($_POST['admin_email'] == "")
			            		{
									$error_msg .= "<p class=\"red\"><strong>- ".$emsg[2]."</strong></p><br />";
			            		}
			
			            	if (!$error_msg == "")
			            		{
									echo "".$error_msg."";
			            		}
			            	else
								{
									$sql_properties = $gbook->query("SELECT `admin_email`, `guestbook_title` FROM `".$table."_properties` WHERE `admin_email` = '".$_POST['admin_email']."'");
									$properties = $sql_properties->fetch_assoc();
				
									mt_srand(makeRandomName());
									$hash              = md5(mt_rand());
				                	$new_password      = substr($hash, 0, 8);
					                $new_password_hash = md5($new_password);
				
					                if ($_POST['admin_email'] === $properties['admin_email'])
										{
						                    $gbook->query("UPDATE `".$table."_properties` SET `password` = '".$new_password_hash."' WHERE `admin_email` = '".$_POST['admin_email']."'");
					
											$empfaenger = "".$properties['admin_email']."";
											$betreff = "".$fmsg[221]." - ".$_SERVER['SERVER_NAME']."\n";
											$header  = "MIME-Version: 1.0\n";
											$header .= "Content-type: text/html; charset=utf-8\n";
									        $header .= "Content-Transfer-Encoding: 8bit\n";
									        $header .= "X-Mailer: PHP\n";
											$header .= "From: \"".$properties['guestbook_title']."\" <".$properties['admin_email'].">\n"; 
																								
											$nachricht = "".$fmsg[223]." <b>".$new_password."</b><br /><br />".$fmsg[217]."";
																
											$send_mail = mail($empfaenger, $betreff, $nachricht, $header);
										
											if ($send_mail)
												{
													echo'<p class="red"><strong>'.$amsg[153].'</strong></p><br />
														<meta http-equiv="Refresh" content="3; url='.$url.'admin/admin.php?action=login" />';
												}
										}
				                	else
				                		{
											echo "<p class=\"red\"><strong>- ".$emsg[1]."</strong></p><br />";
											
		                					if ($login_counter != "")
		                						{
		                							$gbook->query("UPDATE `".$table."_login_counter` SET `login_time` = '".time()."', `counter` = counter+1, `login_code` = ''") or die();
		                						}
		                					else
		                						{
		                							$gbook->query("INSERT INTO `".$table."_login_counter` (`id`, `login_time`, `counter`, `login_code`)   VALUES   ('',  '".time()."',  '1', '')") or die();
		                						}
				                		}
								}
						}
		
					echo "<p><strong>".$fmsg[222]."</strong></p><br />
						<form method=\"post\" action=\"".$url."admin/admin.php?action=password_forget\">
						<table style=\"width:270px\" class=\"guestbook_table2 tableCenter\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\">
							<tr>
								<td align=\"left\">".$fmsg[8]."</td>
								<td align=\"left\"><input type=\"text\" class=\"insert\" name=\"admin_email\" size=\"30\" autofocus=\"autofocus\" autocomplete=\"off\" /></td>
							</tr>
							<tr>
								<td colspan=\"2\" align=\"center\">
									<p><br /><input type=\"submit\" class=\"button\" title=\"".$fmsg[3]."\" name=\"send_password_forget\" value=\"".$fmsg[3]."\" /></p>
									<p><br /><input type=\"button\" class=\"button\" title=\"".$fmsg[4]."\" name=\"abbruch\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='admin.php?action=login'\" /></p>
									<p>&nbsp;</p>
								</td>
							</tr>
						</table>
						</form>";
				}
		}
	else
		{
			if ($activate_email == 1)
				{
					mt_srand(makeRandomName());
					$logincode = md5(mt_rand());

					$gbook->query("UPDATE `".$table."_login_counter` SET `counter` = counter+1, `login_code` = '".$logincode."'");

					$sql_properties = $gbook->query("SELECT `admin_email`, `guestbook_title` FROM `".$table."_properties`");
					$properties = $sql_properties->fetch_assoc();

					$sql_select_noreply = $gbook->query("SELECT `noreply` FROM `".$table."_thankyou` WHERE `status` = 1");
					$select_noreply = $sql_select_noreply->fetch_assoc();

					($select_noreply['noreply'] != "") ? ($abs = $select_noreply['noreply']) : ($abs = $properties['admin_email']);
					$empfaenger = "".$properties['admin_email']."";
					
					$betreff = "Login-Sperre - ".$_SERVER['SERVER_NAME']."\n";
					$header  = "MIME-Version: 1.0\n";
					$header .= "Content-type: text/html; charset=utf-8\n";
					$header .= "Content-Transfer-Encoding: 8bit\n";
					$header .= "X-Mailer: PHP\n";
					$header .= "From: \"".$properties['guestbook_title']."\" <".$abs.">\n"; 
					$nachricht = "".$amsg[155]."".$allowed_attemps."".$amsg[156]."".$barrier_days."".$amsg[157]."<br /><br />".$url."admin/admin.php?action=activatelogin&logincode=".$logincode."";
															
					mail($empfaenger, $betreff, $nachricht, $header);
				}


			echo"<p>&nbsp;</p>
				<p>&nbsp;</p>
				<img class=\"aligncenter\" title=\"NO ENTRY\" src=\"".$url."images/noentry.png\" width=\"70\" height=\"70\" alt=\"NO ENTRY\" />
				<p class=\"zentriert red size-18\"><strong>".$amsg[154]."</strong></p>
				<p>&nbsp;</p>
				<p>&nbsp;</p>";
		}

?>