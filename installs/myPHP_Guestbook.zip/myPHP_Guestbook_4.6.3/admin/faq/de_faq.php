<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/
	
	if (!isset($_SESSION['sid'])) {
		echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
	} else {
		echo'
			<p>Diese Dokumentation soll Ihnen dabei helfen, die Features von <span class="italic">myPHP Guestbook</span> zu verstehen und offene Fragen zu beantworten. Ergänzende Erläuterungen finden Sie auch in der dem Download beigefügten <span class="italic">ReadMe.pdf</span>.</p>
			<hr /><hr />
			<a id="anchor-top" name="anchor-top"></a>
			<h1><br />Inhaltsverzeichnis:</h1>
			<h2><br /><a href="#anchor-Intro">I. Einführung, Haftungsausschluss</a></h2>
			<h2><a href="#anchor-Aktuell">II. Aktuelle Änderungen</a></h2>
			<h2><a href="#anchor-Install">III. Vorbeitung und Installation oder Updates von <span class="italic">myPHP Guestbook</span></a></h2>
			<ol>
				<li><a href="#anchor-Update">Neuinstallation oder Update von V.3.x auf V.4.x</a>
				<li><a href="#anchor-Webdesign">&quot;Responsive Webdesign&quot; und die Einbindung per &quot;iframe&quot;</a>
				<li><a href="#anchor-Ordner">Besondere Rechte bestimmter Ordner  -- <strong>WICHTIG!!</strong></a>
				<li><a href="#anchor-htaccess">Nutzung von .htaccess-Dateien -- <strong>WICHTIG!!</strong></a>
			</ol>
			<h2><a href="#anchor-Config">IV. Nutzungshinweise</a></h2>
			<ol>
				<li><a href="#anchor-Config">Config.inc.php</a>
					<ol>
						<li class="sub-main"><a href="#anchor-timezone">Von <span class="italic">myPHP Guestbook</span> verwendete Zeitzone</a></li>
						<li class="sub-main"><a href="#anchor-save">Nachträgliche Umstellung auf eine gesicherte Internet-Verbindung</a> (http ==&gt; https)</li>
					</ol>
				<li><a href="#anchor-Gaestebuch">Gästebuch</a>
					<ol>
						<li><a href="#anchor-Gaestebuch">Gästebuchseite</a>
							<ol>
								<li class="sub-main"><a href="#anchor-Changes">Änderungen von Schriftfarbe, Hintergründen, Breite des Gästebuchs, Icos für E-Mail und Homepage, Rahmenfarben.</a></li>
								<li class="sub-main"><a href="#anchor-Copy">Copyrighthinweis</a></li>
							</ol>
						<li><a href="#anchor-Eintragsseite">Eintragsseite</a>
							<ol>
								<li class="sub-main"><a href="#anchor-Entry">Eingabemöglichkeiten</a></li>
								<li class="sub-main"><a href="#anchor-Smiley">Smilies</a></li>
								<li class="sub-main"><a href="#anchor-BBC">BBCodes</a></li>
								<li class="sub-main"><a href="#anchor-Photo">Fotos in Gästebucheinträgen</a></li>
								<li class="sub-main"><a href="#anchor-Quote">Zitieren von Gästebucheinträgen</a></li>
								<li class="sub-main"><a href="#anchor-ComInfo">Gast über Kommentar zu seinem Eintrag informieren</a></li>
								<li class="sub-main"><a href="#anchor-IPBar">IP-Sperre der Eintragsseite</a></li>
							</ol>
					</ol>
				<li><a href="#anchor-Admin">Admin-Control-Panel</a><br />
				<span class="sub-main"><a href="#anchor-Noentry">Schutz des Admin-Bereichs vor unberechtigten Zugriffen Dritter</a></span>
					<ol>
						<li><a href="#anchor-Gaestebucheintraege">Gästebucheinträge</a>
							<ol>
								<li class="sub-main"><a href="#anchor-Edit">Einträge verwalten, editieren, kommentieren</a></li>
								<li class="sub-main"><a href="#anchor-Grafik">Hochgeladene Grafikdateien verwalten und editieren</a></li>
								<li class="sub-main"><a href="#anchor-Blog">Admin Blog</a></li>
								<li class="sub-main"><a href="#anchor-Front">Frontend anzeigen</a></li>
							</ol>
						<li><a href="#anchor-Einstellungen">Einstellungen</a>
							<ol>
								<li class="sub-main"><a href="#anchor-AdminEdit">Admin-Einstellungen</a></li>
								<li class="sub-main"><a href="#anchor-Konfig">Allgemeine Konfiguration</a><br />
								<span class="sub-main"><strong>esp:</strong> <a href="#anchor-LinkButton">Link zur Eintragsseite (Text, Button, Link entfernen)</a></span></li>
								<li class="sub-main"><a href="#anchor-Upload">Konfiguration Datei-Uploads</a></li>
								<li class="sub-main"><a href="#anchor-Thankyou">Individuelle &quot;Danke-E-Mail&quot; an den Gast</a></li>
								<li class="sub-main"><a href="#anchor-MoreKonfig">Weitere Konfigurationsmöglichkeiten, insbesondere bei Verwendung des Gästebuch in einem zugangsgeschützten Mitgliederbereich</a></li>
							</ol>
						<li><a href="#anchor-Template">Template</a>
							<ol>
								<li class="sub-main"><a href="#anchor-StandTempl">Standard Template</a></li>
								<li class="sub-main"><a href="#anchor-EditTempl">Template editieren<br />(inkl. Hintergründe, Textfarbe, Breite u.ä.)</a></li>
								<li class="sub-main"><a href="#anchor-MakeTempl">Template erstellen</a></li>
								<li class="sub-main"><a href="#anchor-DelTempl">Template löschen</a></li>
							</ol>
						<li><a href="#anchor-Styles">CSS-Style</a>
							<ol>
								<li class="sub-main"><a href="#anchor-StandStyle">Standard Style</a></li>
								<li class="sub-main"><a href="#anchor-EditStyle">Style editieren<br />(inkl. div. Anwendungs-Beispielen)</a></li>
								<li class="sub-main"><a href="#anchor-MakeStyle">Style erstellen</a></li>
								<li class="sub-main"><a href="#anchor-DelStyle">Style löschen</a></li>
							</ol>
						<li><a href="#anchor-Smilies">Smilies</a>
							<ol>
								<li class="sub-main"><a href="#anchor-ShowSmil">Smilies anzeigen</a></li>
								<li class="sub-main"><a href="#anchor-PlusSmil">Smilies hinzufügen</a></li>
								<li class="sub-main"><a href="#anchor-DelSmil">Smilies löschen</a></li>
								<li class="sub-main"><a href="#anchor-EditSmil">Smilies editieren</a></li>
							</ol>
						<li><a href="#anchor-Badwords">Badwords</a>
							<ol>
								<li class="sub-main"><a href="#anchor-ShowBadw">Badwords anzeigen und löschen</a></li>
								<li class="sub-main"><a href="#anchor-PlusBadw">Badwords hinzufügen</a></li>
							</ol>
						<li><a href="#anchor-Spamfilter">Spamfilter</a>
							<ol>
								<li class="sub-main"><a href="#anchor-ShowSpamWo">Spamwords anzeigen und löschen</a></li>
								<li class="sub-main"><a href="#anchor-PlusSpamWo">Spamwords hinzufügen</a></li>
								<li class="sub-main"><a href="#anchor-ShowIpBar">IP-Sperren nach Spameinträgen</a></li>
							</ol>
						<li><a href="#anchor-Backup">Backup</a>
							<ol>
								<li class="sub-main"><a href="#anchor-BackUpEdit">Backups verwalten und Einträge wiederherstellen</a></li>
								<li class="sub-main"><a href="#anchor-MakeBackUp">Backup erstellen</a></li>
							</ol>
						<li><a href="#anchor-Statistik">Statistik</a>
							<ol>
								<li class="sub-main"><a href="#anchor-ShowStats">Statistik anzeigen</a></li>
								<li class="sub-main"><a href="#anchor-DelStats">Statistik löschen</a></li>
							</ol>
						<li><a href="#anchor-Hilfe">Hilfe</a>
						<li><a href="#anchor-Logout">Logout</a>
					</ol>
				<li><a href="#anchor-Repair">Diagnose- und Reparatur-Tool</a>
			</ol>
			<h2><a href="#anchor-lang">V. Sonstiges</a></h2>
			<ol>
				<li><a href="#anchor-lang">Sprachen</a>
				<li><a href="#anchor-Credits">Credits</a>
				<li><a href="#anchor-Copyright">Copyright, Lizenz</a>
				<li><a href="#anchor-History">Version History</a>
				<li><a href="#anchor-Kontakt">Kontakt</a>
			</ol><br />
			<hr /><hr />
			<a id="anchor-Intro" name="anchor-Intro"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<h2><br />I. Einführung, Haftungsausschluss</h2>
			<p><span class="italic">myPHP Guestbook</span> ist ein Open Source Gästebuch und unterliegt der GNU General Public License.</p>
			<p>Bevor Sie das Gästebuch benutzen, sollten Sie die <span class="italic">license.txt</span> durchlesen (zu finden im Ordner "license").</p>
			<p>Mit der Installation und Benutzung von <span class="italic">myPHP Guestbook</span> akzeptieren Sie die GNU General Public License.</p>
			<p>Nach den Lizenzbedingungen kann jeder selbstständig den Code von <span class="italic">myPHP Guestbook</span> ändern oder Teile des Codes für andere Projekte benutzen. Dies ist allerdings nur dann gestattet, wenn die Lizenzbestimmungen eingehalten werden, siehe hier: &lt;www.gnu.org/licenses&gt;</p>
			<p>Damit das Programm <span class="italic">myPHP Guestbook</span> weiter verbessert werden kann, ist auch Ihre Mithilfe gefragt. Sie können gerne Wünsche für zukünftige Features mitteilen oder gefundene Fehler melden. Nutzen Sie hierfür am besten das <a href="https://www.php-guestbook.de/start.gbook.php" title="Link öffnet ein neues Fenster" rel="external">Demo-Gästebuch</a> auf "www.php-guestbook.de", damit auch andere User profitieren und sich an Diskussionen beteiligen können. Ich werde bestrebt sein, ggf. entdeckte Bugs umgehend zu beheben.</p>
			<p>Da es sich bei <span class="italic">myPHP Guestbook</span> um ein relativ kleines Projekt handelt, werden keine Patches angeboten, um ggf. aufgetretene Sicherheitslücken zu schliessen. Daher sollten Sie stets die jeweils <a href="https://www.php-guestbook.de/index.php#anchor-newvers" title="Link öffnet ein neues Fenster" rel="external">aktuellste Version</a> herunterladen und installieren, um immer auf dem neuesten Stand zu sein. Achten Sie bitte auf Hinweise zu Updates unter <a href="https://www.php-guestbook.de" title="Link öffnet ein neues Fenster" rel="external">www.php-guestbook.de</a> oder melden Sie sich einfach zum <a href="https://www.php-guestbook.de/mail.reg.php" title="Link öffnet ein neues Fenster" rel="external">Newsletterversand</a> an.</p>
			<p class="text-shadow zentriert"><br /><strong>HAFTUNGSAUSSCHLUSS:</strong></p>
			<p><strong>Es ist nicht möglich, eine immer und überall fehlerfrei arbeitende Software anzubieten oder gar eine Haftung für fehlerhafte Software oder eventuelle Sicherheitslücken und daraus ggf. resultierende Schäden und/oder Folgeschäden zu übernehmen, die daher grundsätzlich ausgeschlossen wird.</strong></p>
			<p><strong><span class="italic">myPHP Guestbook</span> wird &quot;so wie es ist&quot; angeboten und mit der Installation von Ihnen akzeptiert, unter Ausschluss jeglicher Gewährleistung und unter Ausschluss jeglicher Haftung. Für weiteres siehe auch die GNU-Lizenz.</strong></p>
			<a id="anchor-Aktuell" name="anchor-Aktuell"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<h2><br />II. Aktuelle Änderungen</h2>
			<p>Für Hinweise über Art und Umfang der Programmänderungen in den Gästebuch-Versionen ab 4.6.0 lesen Sie bitte die <span class="italic">&quot;ReadMe-Update.pdf&quot;</span>.</p>
			<p>Dort ist auch näher beschrieben, welche Dateien Sie im einzelnen austauschen bzw. neu hochladen müssen, wenn Sie bereits eine der früheren Versionen 4.x installiert haben.</p>
			<p>Eine komplette Darstellung aller Programmänderungen ab der Version 4.0.0 finden Sie auf "www.php-guestbook.de" unter <a href="https://www.php-guestbook.de/start.changelog.php" title="Link öffnet ein neues Fenster" rel="external">Changelog</a></p>
			<a id="anchor-Install" name="anchor-Install"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<h2><br />III. Vorbereitung und Installation oder Update des <span class="italic">myPHP Guestbook</span></h2>
			<p>Voraussetzungen zum Betrieb von <span class="italic">myPHP Guestbook '.$version.'</span>:</p>
			<ul>
				<li>Apache Server
				<li>MySQL 5.x
				<li>PHP 5.5.x oder höher (getestet auch unter PHP 5.6.x und 7.0.x)
				<li>serverseitig aktivierte MySQLi Unterstützung
				<li>nur für die Nutzung der Foto-Upload-Funktion:
					<ul>
						<li>serverseitig aktivierter GD Support
						<li style="list-style-type:none">(Das Gästebuch ohne Foto-Upload kann ohne GD-Modul genutzt werden.)
					</ul>
				<li>nur für die Nutzung der Foto-Upload- und Smilie-Upload-Funktion:
					<ul>
						<li>serverseitig: - file_uploads = On
					</ul>
				<li>Für die Funktion des Gästebuchs ebenfalls nicht zwingend erforderlich, aus Sicherheitsgründen aber wünschenswert:
					<ul>
						<li>vom Provider zugelassene Nutzung eigener .htaccess-Dateien
					</ul>
				<li>Für das automatische Zippen (komprimieren) der mit dem Programm erstellten BackUps:
					<ul>
						<li>serverseitig: - zlib Support
						<li style="list-style-type:none">(Das Gästebuch kann einschließlich der BackUp-Fertigung auch ohne diesen Support installiert und genutzt werden, die BackUps werden dann nur nicht automatisch komprimiert.)
					</ul>
			</ul>
			<a id="anchor-Update" name="anchor-Update"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />1. Neuinstallation oder Update:</strong></p>
			<p>Ausführliche Hinweise und Erläuterungen mit einer Schritt für Schritt Anleitung, was bei einer Installation oder einem Update des Programms <span class="italic">myPHP Guestbook</span> zu beachten ist und welche Schritte im Einzelnen notwendig sind, finden Sie in der dem Download beigefügten <strong class="italic">ReadMe.pdf</strong>. Für ein Update lesen Sie bitte ergänzend auch die beigefügte <strong class="italic">ReadMe-Update.pdf</strong>.</p>
			<p class="zentriert red"><strong>ACHTUNG:</strong></p>
			<p class="red"><strong>Achten Sie bitte darauf, nach erfolgreicher Installation oder Update den &quot;install-Ordner&quot; aus Sicherheitsgründen mit allen darin befindlichen Dateien wieder von Ihrem Server zu löschen!</strong></p>
			<a id="anchor-Webdesign" name="anchor-Webdesign"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2. Beim Einbinden des Gästebuchs per &quot;iframe&quot; zu beachten:</strong></p>
			<p>Wenn Ihre Website, in die das Gästebuch eingebunden wird, eine feste Breite hat, müssen Sie bei der Einbindung per &quot;iframe&quot; nichts besonderes beachten, alles bleibt bzw. wird umgesetzt wie üblich. Hat Ihre Website jedoch eine flexible Breite, sollten Sie, um die Möglichkeiten der automatischen Grössenanpassung des Gästebuchs je nach Endgerät vollständig auszunutzen, insbesondere zwei Punkte beachten:</p>
			<ol>
				<li type="a">Die Breite des iframes darf <strong>nicht absolut</strong> festgelegt werden, sondern nur relativ zum Elternelement. Das bedeutet, dass für das iframe <strong>keine</strong> Breitenangabe mit px oder pt sondern mit % erfolgen sollte; also <strong>nicht</strong> z.B.: &quot;width:500px&quot; sondern &quot;width:100%&quot; !
				<li type="a">Das iframe sollte auf der Seite so eingebunden werden, dass es deren <strong>volle Breite</strong> einnimmt, also ohne irgendeine Navigation oder sonstige Texte o.ä. rechts oder links daneben und allenfalls mit einem Innenabstand (padding) zum Elternelement rechts und links bis zu maximal 5px. Nur dann kann die minimale Breite von 320px auf einem Smartphone erzielt werden !
			</ol>
			<a id="anchor-Ordner" name="anchor-Ordner"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3. Besondere Rechte bestimmter Ordner:</strong></p>
			<p>Gleichgültig ob Sie zu diesem Absatz gelangt sind, weil der Installer Ihnen angezeigt hat, dass bestimmte Ordner nicht beschreibbar sind, Sie Fehlermeldungen beim Foto-Upload oder der BackUp-Erstellung bekommen haben oder einfach nur sorgfältig vorgehen: Lesen Sie sich diesen (und auch den folgenden) Abschnitt aufmerksam durch und erschrecken Sie nicht sofort, wenn Ihnen das eine oder andere zunächst unverständlich erscheint; alles ist lösbar. <span class="td-nowrap">:-)</span></p>
			<p>In den Hinweisen älterer <span class="italic">myPHP Guestbook</span>-Dokumentationen hieß es bislang stets, die backup- und smilie-Ordner müssten die CHMOD Rechte 0777 erhalten. Das ist jedoch so nicht unbedingt richtig und vernachlässigt den Sicherheitsaspekt.</p>
			<p>Zum besseren Verständnis: Die Verzeichnisse (Ordner) &quot;images/smilies&quot;, &quot;backup&quot; und &quot;img_guest&quot; müssen so angelegt sein, dass von PHP in diesen Ordnern Dateien abgelegt werden und diese Dateien dann auch &quot;gelesen&quot; werden können. Dafür werden bestimmte Rechte benötigt, nämlich die sogen. CHMOD Rechte 0755 oder bei <span class="italic">manchen</span> Server-Konfigurationen sogar 0777, weil sonst die Erstellung von BackUps oder das Hochladen von neuen Smilies oder der seit V.4.4.0 mögliche Foto-Upload nicht funktionieren.</p>
			<p>Grundsätzlich sollte ein Ordner aus Sicherheitsgründen jedoch so wenig Rechte wie möglich bekommen. Also besser, weil sicherer, CHMOD 0755 und nur wenn es nicht anders geht CHMOD 0777. Auf der Website von "wiki.selfhtml.org" wird es so ausgedrückt: &quot;777 ist (sicherheitstechnisch) böse.&quot;</p>
			<p>Das Prüfen und ggf. Ändern von Rechten eines Ordners auf dem Webspace kann mit einem FTP-Clienten, wie z.B. dem bekannten FileZilla o.ä. erfolgen. Oft funktioniert das so, dass man den Verzeichnisbaum des eigenen Webspace auf dem Webserver öffnet, mit der Mouse den gewünschten Ordner anklickt (je nach Programm mit der linken oder auch rechten Mousetaste) und in dem sich dann öffnenden Fenster den Punkt &quot;Dateiattribute ändern&quot; oder &quot;Dateiberechtigungen&quot; oder &quot;Eigenschaften&quot; oder ähnlich benannte Verweise anklickt. Es öffnet sich dann meist ein weiteres Fenster, in dem man sehen und bei Bedarf ändern kann, welche Rechte der betreffende Ordner hat oder bekommen soll.</p>
			<p>Ob in Ihrem Fall die drei bezeichneten Ordner die Rechte 0777 bekommen müssen oder die –vorzuziehenden- geringeren Rechte 0755 genügen, muss im Zweifel ausprobiert werden, weil dies auch davon abhängt, ob der Apache-Server und die Dateien unter demselben Benutzer laufen (was sie heutzutage tun sollten) oder nicht.</p>
			<p>Nach dem Hochladen aller Dateien und Ordner aus dem Download-Paket sollten die Ordnerrechte im Normalfall 0755 betragen. Auf 0755 ist auch der Installer mit der eingebauten Prüfung einer Beschreibbarkeit dieser drei Ordner ausgerichtet. Wenn dort die Ordner in grüner Schrift mit dem Hinweis: &quot;vorhanden, beschreibbar&quot; angezeigt wurden, sollte alles Ordnung sein. - <span class="italic">Eine eigenverantwortliche Prüfung ersetzt dies jedoch nicht!</span></p>
			<p>Wurde Ihnen vom Installer angezeigt, dass die drei oder einer der drei Ordner &quot;images/smilies&quot;, &quot;backup&quot; und/oder &quot;img_guest&quot; zwar vorhanden, aber nicht beschreibbar sind, können Sie das Gästebuch trotzdem nutzen, es wird aber folgendes nicht funktionieren:</p>
			<ol>
				<li type="a">Es kann kein BackUp der Gästebucheinträge mit diesem Script erstellt werden,
				<li type="a">es können keine neuen Smilies mit diesem Script hochgeladen werden
				<li type="a">und der Fotoupload wird nicht funktionieren.
			</ol>
			<p>Um dies zu beheben, müssen Sie entweder die CHMOD Rechte des/der betroffenen Ordner ändern, wie oben beschrieben, oder, falls nicht gewünscht oder möglich, eine der folgenden Optionen prüfen:</p>
			<ul>
				<li>für a) Lösung: ein anderes, externes BackUp-Programm für die Datenbankeinträge, wie z.B. myphpAdmin, mySQLDumper o.ä. benutzen und in den &quot;Allgemeinen Konfigurationseinstellungen&quot; hier im Admin-Bereich des Gästebuchs die Option: &quot;BackUp nach dem Versand per E-Mail wieder vom Server löschen?&quot; aktivieren;
				<li>für b) Lösung: zunächst einmal sind eine ganze Reihe von Smilies nach der Erstinstallation schon vorhanden. Nur wem die nicht genügen UND der Ordner &quot;smilies&quot; als nicht beschreibbar angezeigt wird, muss ggf. gewünschte neue Smilies per FTP hochladen und in die Datenbanktabelle &quot;*_smilies&quot; eintragen;
				<li>für c) Lösung: in den &quot;Allgemeinen Konfigurationseinstellungen&quot; hier im Admin-Bereich des Gästebuchs die Option: &quot;Bilder in Gästebucheinträgen anzeigen, Foto-Upload aktivieren:?&quot; deaktivieren. 
			</ul>
			<a id="anchor-htaccess" name="anchor-htaccess"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />4. Nutzung von .htaccess-Dateien:</strong></p>
			<p>Dem Download-Paket sind drei teils unterschiedliche .htaccess-Dateien beigefügt, nämlich in den Ordnern &quot;backup&quot;, &quot;includes&quot; und &quot;img_guest&quot;. Sie dienen ebenfalls dazu, die Sicherheit vor schädlichen Eingriffen Dritter zu erhöhen.</p>
			<p>Dateien mit dem Namen .htaccess (das erste Zeichen ist ein Punkt) sind Bestandteile der Konfiguration des Apache Webservers. Der Server-Administrator, also im Zweifel ihr Website-Hoster/Provider, legt in der zentralen Konfiguration fest, welche Berechtigungen er welchen Benutzern oder auch welchen Webangeboten (virtuellen Hosts) zugestehen möchte. Ausserdem lässt sich in der zentralen Konfiguration des Apache (an die Sie als normaler User nicht herankommen, es sei denn, Sie betreiben Ihren eigenen Server) auch ein beliebiger anderer Dateiname einstellen, weshalb der Name einer solchen Datei nicht unbedingt .htaccess lauten muss (wenn es auch üblich und daher meistens so ist).</p>
			<p><strong>Mit einem Satz:</strong> Sie können die .htaccess-Dateien aus dem <span class="italic">myPHP Guestbook</span> nutzen, wenn Ihr Provider Ihnen diese Möglichkeit bei Ihrem Hostingpaket eingeräumt hat.</p>
			<p>Bei den aktuellen großen Providern sollte das der Fall sein. Grundsätzlich wäre mehr möglich, als in den beigefügten Dateien hinterlegt, aber eben nicht überall erlaubt. Die Anweisungen in diesen Dateien beschränken sich daher auf das, was Provider im Normalfall zulassen.</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Sollten Sie nach dem Hochladen von Fotos Fehlermeldungen erhalten, insbesondere solche mit <span class="italic">&quot;500 server error&quot;</span>, oder sollten trotz fehlerfreiem Upload die hochgeladenen Fotos nicht angezeigt werden, beachten Sie bitte die Tipps in der <strong class="italic">&quot;ReadMe.pdf&quot;</strong>!</p>
			<p>Wenn Sie damit nicht weiterkommen, löschen Sie als letzten Ausweg notfalls die .htaccess aus dem Verzeichnis &quot;img_guest&quot; wieder vom Server und machen Sie sich über entsprechende FAQ, E-Mails, Anrufe o.ä. bei Ihrem Provider schlau, was bei Ihrem Hostingpaket möglich ist und was nicht.</p>
			<p><strong><span class="red">TIPP:</span></strong> Testen Sie, ob die hochgeladene &quot;.htaccess&quot; macht, was sie soll, in dem Sie den folgenden Link aufrufen:</p>
			<p class="zentriert italic"><a href="'.$url.'img_guest/index.php" title="Anklicken zum Testen - Link öffnet ein neues Fenster" rel="external">'.$url.'img_guest/index.php</a></p>
			<p>... es sollte dann in Ihrem Browser ein &quot;HTTP-403-Fehler&quot; angezeigt werden, in etwa mit dem Inhalt:</p>
			<p class="zentriert italic"><strong>&quot;Forbidden You don\'t have permission to access ... on this server.&quot;</strong></p>
			<p>Wenn das der Fall ist und hochgeladene Bilder angezeigt werden, funktioniert es ordnungsgemäß.</p>
			<p>Sollten Sie hingegen nach Anklicken des Links auf der Gästebuch-Index-Seite landen, funktioniert es offenkundig <span class="italic">nicht</span> und auf den Inhalt des Ordners kann von außen zugegriffen werden.
			<p>Sollten Sie keine .htaccess-Dateien nutzen können bzw. diese nicht den gewünschten Effekt erzeugen und womöglich auch noch gezwungen sein, den im vorherigen Abschnitt beschriebenen drei Ordnern &quot;images/smilies&quot;, &quot;backup&quot; und &quot;img_guest&quot; die CHMOD Rechte 0777 zuweisen zu müssen, rate ich dringend dazu =&gt;</p>
			<ol>
				<li type="a">unter dem Link &quot;Allgemeinen Konfigurationseinstellungen&quot; die Option: &quot;Bilder in Gästebucheinträgen anzeigen, Foto-Upload aktivieren:?&quot; zu <strong>de</strong>aktivieren und
				<li type="a">ebenfalls in den &quot;Allgemeinen Konfigurationseinstellungen&quot; die Option: &quot;BackUp nach dem Versand per E-Mail wieder vom Server löschen?&quot; zu <strong>ak</strong>tivieren und
				<li type="a">den Anbieter zu wechseln, und zwar nicht nur wegen diesem Gästebuchscript, sondern weil er offensichtlich mit seinem Angebot noch hinter dem Mond lebt.
			</ol>
			<a id="anchor-Config" name="anchor-Config"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<h2><br />IV. Nutzungshinweise:</h2>
			<p class="text-shadow"><strong>1. config.inc.php (Verzeichnis &quot;includes&quot;):</strong></p>
			<p>Das Gästebuch benötigt eine SQL-Datenbank, in der z.B. die Einträge der Besucher, aber auch die Konfigurationsdaten und vieles mehr gespeichert werden. Damit das Gästebuch überhaupt läuft, müssen daher die Datenbankzugangsdaten (die erhalten Sie von Ihrem Websitehoster) korrekt in der Datei &quot;config.inc.php&quot; eingetragen sein.</p>
			<p>Dank dem Installations-Script, in dem alle benötigten Daten in einer übersichtlichen Maske abgefragt werden, ist die Einrichtung der Verbindung zur Datenbank und die Anlage der benötigten Datenbanktabellen einfach. Mit der Umstellung auf MySQLi habe ich in das Script ferner eine automatische Prüfung eingebaut, ob die benötigte PHP-Erweiterung MySQLi auf Ihrem Webspace verfügbar ist.</p>
			<p>Das Installer-Script befindet sich ebenso wie das Script zum Update der Datenbank im Ordner "install".</p>
			<p><strong><span class="red">TIPP:</span></strong> Sollte die "config.inc.php" beschädigt oder überschrieben werden oder sollten sonstige nicht definierbare Verbindungsprobleme zur Datenbank entstehen, kann dies mit dem Diagnose- und Reparatur-Tool zu <span class="italic">myPHP Guestbook</span> geprüft und in den meisten Fällen behoben werden. Näheres hier siehe unten <a href="#anchor-Repair">Abschnitt IV. 4., "Diagnose- und Reparatur-Tool"</a>.</p>
			<a id="anchor-timezone" name="anchor-timezone"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />1.1. Zeitzonen:</strong></p>
			<p>Wenn Sie bei der Installation ab v.4.5.6 eines der Länder ausgewählt haben, die im DropDown-Menü angeboten werden, wird in der &quot;config.inc.php&quot; auch die Zeitzone gespeichert, unter der Ihre Homepage mit dem Gästebuch läuft. Für nachträgliche Änderungen der Zeitzone muss also die &quot;config.inc.php&quot; mit einem Editor geöffnet und der Variablen &quot;$timezone&quot; eine ggf. gewünschte andere Zeitzone zugewiesen werden.</p>
			<p>Alle von PHP erkannten und verwendbaren Zeitzonen finden Sie unter:</p>
			<p class="zentriert">&lt; php.net/manual/timezones.php &gt;.</p>
			<p>Wenn die Variable &quot;$timezone&quot; leer ist, ihr also keine bestimmte Zeitzone zugewiesen wird, wird vom Programm auf die &quot;default settings&quot; des Servers zurückgegriffen.</p>
			<p>Falls Sie die Installation des Gästebuchs mit einer der früheren Gästebuch-Versionen (v.4.5.5 oder kleiner) vorgenommen haben, wird in der &quot;config.inc.php&quot; Ihrer Installation keine Variable &quot;$timezone&quot; existieren. Sollten Sie bisher keine Unstimmigkeiten in der Zeiterfassung (z.B. Datum und Zeit von Gästebucheinträgen) festgestellt haben, wird der Server, auf dem Ihr Gästebuchscript läuft, für Ihre Bedürfnisse korrekt konfiguriert sein und Sie müssen sich darum nicht weiter kümmern. Andernfalls laden Sie die &quot;config.inc.php&quot; vom Server auf Ihren Rechner, öffnen sie mit einem Editor und fügen nach den Zugangsdaten für Ihre Datenbank z.B. für Deutschland folgendes ein:</p>
			<p class="zentriert blue">$timezone = &quot;Europe/Berlin&quot;;</p>
			<p>Für Zeitzonen anderer Länder siehe Link oben. Die Zeitzone ist in Anführungszeichen zu setzen, wie im Beispiel. Das Semikolon am Ende nicht vergessen!</p>
			<a id="anchor-save" name="anchor-save"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />1.2. Nachträgliche Umstellung auf eine gesicherte (verschlüsselte) Internetverbindung:</strong></p>
			<p>Wer seine Website nach der Installation des Gästebuchs auf eine gesicherte Internetverbindung umstellt (Wechsel von &quot;http&quot; auf &quot;https&quot;), muss auch den Pfad für die Verweise innerhalb des Gästebuchs umstellen.</p>
			<p>Hierzu die &quot;config.inc.php&quot; (zu finden im Ordner "includes") vom Server auf den eigenen Rechner runterladen, mit einem Editor öffnen und beim &quot;Domainpath&quot; zu den Variablen &quot;<span class="blue">$url</span>&quot; und &quot;<span class="blue">$url02</span>&quot; das &quot;http://&quot; in &quot;http<strong>s</strong>://&quot; ändern/ergänzen. Abspeichern und die &quot;config.inc.php&quot; wieder auf den Server laden. - Fertig.</p>
			<a id="anchor-Gaestebuch" name="anchor-Gaestebuch"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2. Gästebuch</strong></p>
			<p class="text-shadow"><strong>2.1. Gästebuchseite:</strong></p>
			<p>Auf der "index"-Seite in der obersten Ebene des Gästebuchordners werden alle Beiträge, die in das Gästebuch eingetragen wurden, angezeigt. Die Anzahl der Beiträge pro Seite kann hier im Admin-Bereich ebenso individuell selber festgelegt werden, wie die Anzahl der Links zum Durchblättern der einzelnen Seiten. - Wer unschöne Umbrüche bei der Anzeige des Gästebuchs auf einem Smartphone verhindern möchte, sollte bei der Anzahl der angezeigten Links zum Durchblättern nicht über die Voreinstellung von max. 9 hinausgehen.</p>
			<p>Das Gästebuch verfügt über ein Template- und Style-Management, mit dem Sie das Aussehen des Gästebuch ganz einfach verändern können. Insgesamt zehn vorgefertigte, mit den passenden CSS-Styles versehene Templates werden mit installiert und können nach Ihrem persönlichen Geschmack genutzt werden. Mehr hierzu unten im Abschnitt 3.3.</p>
			<p>Falls Sie das Gästebuch über PHP includen, sollten Sie beachten, dass die GET-Variable &quot;$page&quot; bereits vom Script verwendet wird.</p>
			<p>Die Gästebuchseite kann mit entsprechenden Kenntnissen in PHP und HTML selbst angepasst werden, um z.B. zusätzliche Links oder einen eigenen Header einzufügen. Für weniger erfahrene PHP-Nutzer steht auf <a href="https://www.php-guestbook.de" title="Link öffnet ein neues Fenster" rel="external">www.php-guestbook.de</a> ein Ergänzungspaket zum Download bereit. Mit den dort enthaltenen angepassten Dateien und zwei Demo-Seiten sollte das includen des Gästebuch-Scripts kein Problem mehr sein, wobei allerdings Grundkenntnisse in HTML, PHP und CSS sowie über den Aufbau einer Website im Allgemeinen vorhanden sein sollten.</p>
			<a id="anchor-Changes" name="anchor-Changes"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.1.1. Änderungen von Schriftfarbe, Hintergründen, Breite des Gästebuchs, Symbole für E-Mail und Homepage eines Gasteintrages, Rahmen der Input-Felder:</strong></p>
			<p>Die Schriftfarbe für die Gästebucheinträge, die Hintergrundfarben, die Breite das Gästebuchs und dessen Ausrichtung auf der Seite (rechts-links-mittig), können ebenso wie die Symbole (Icos) für E-Mail-Anschrift und Homepage eines Besuchers ganz einfach unter dem Link &quot;Template editieren&quot; geändert werden. Näheres siehe unten <a href="#anchor-EditTempl">Abschnitt IV. 3.3.2, "Template editieren"</a>.</p>
			<p>Auf der Seite für die Gästebucheinträge bekommen die Input- und das Textarea-Feld beim Setzen des Cursors programmseitig einen grauen Rahmen mit entsprechendem äußerem Schatten gesetzt. Um dies auf Wunsch individuell anzupassen, siehe unten <a href="#anchor-EditStyle">Abschnitt IV. 3.4.2, "Style editieren"</a>.</p>
			<a id="anchor-Copy" name="anchor-Copy"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.1.2. Copyrighthinweis:</strong></p>
			<p>Der sichtbare Copyrighthinweis auf der Index- und Insert-Seite darf laut der General Public License entfernt werden.</p>
			<p>Sie sollten jedoch bedenken, dass <span class="italic">myPHP Guestbook</span> vor allem durch den Link im Copyrighthinweis an neue User kommt.</p>
			<p>Der Copyrighthinweis im Quellcode darf in keiner Datei entfernt werden.</p>
			<a id="anchor-Eintragsseite" name="anchor-Eintragsseite"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.2. Eintragsseite:</strong></p>
			<p>Damit Beiträge im Gästebuch erfasst werden, müssen sie auf der Eintragsseite durch den Besucher eingetragen werden. Es handelt sich hierbei um die &quot;insert.php&quot; auf der obersten Ebene des Gästebuchordners.</p>
			<p>Je nachdem, wie das Gästebuch konfiguriert ist, stehen dort mehr oder weniger Features zur Auswahl. Die Wichtigsten davon sind …</p>
			<a id="anchor-Entry" name="anchor-Entry"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.2.1. Eingabemöglichkeiten:</strong></p>
			<p>Nach der Installation sind ab Version 4.6.0 sämtliche Eingabefelder, außer denen für den Namen und den Beitrag des Gastes, hier unter dem Link "Allgemeine Konfiguration" getrennt voneinander ein- und ausblendbar.</p>
			<p>Zur Platzersparnis sind die Input-Felder für Ort und Land einerseits, sowie für Homepage und ICQ-Link andererseits, nebeneinander angeordnet. Wird nur eins der beiden jeweils nebeneinander liegenden Input-Felder deaktiviert, erstreckt sich anschließend das verbliebene Feld automatisch über die gesamte Breite des Eingabeformulars, um ein optisch einheitliches Aussehen zu erhalten.</p>
			<a id="anchor-Smiley" name="anchor-Smiley"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.2.2. Smilies:</strong></p>
			<p><span class="italic">myPHP Guestbook</span> unterstützt Smilies, d.h. Sie können z.B. ":angry:" bei einem neuen Gästebucheintrag eintippen und in der Gästebuchseite wird das ":angry:" durch ein Bild mit einem wütenden Smiley ersetzt.</p>
			<p>Das Einfügen solcher Smilies wurde in v. 4.x geändert: Wurde bei einer der Versionen vor 4.1 ein angeklickter Smiley stets ans Ende des getippten Textes im Eintragsformular gesetzt, wird er jetzt dort eingefügt, wo sich der Cursor im Textfeld befindet, jeweils mit einem Leerzeichen davor und dahinter.</p>
			<a id="anchor-BBC" name="anchor-BBC"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.2.3. BBCodes:</strong></p>
			<p>Anhand von BBCodes kann der Gast seinen Eintrag formatieren. Dadurch wird z.B. Text zwischen den beiden Tags [b]<strong>Irgendein Text</strong>[/b] fett dargestellt.</p>
			<p>Neben diesem einfachen BBCode können in <span class="italic">myPHP Guestbook</span> noch viele weitere verwendet werden für farbige Texte, Zitate und mehr.</p>
			<p>Wenn der Gast mit der Mouse einen bestimmten Textbereich im Formularfeld markiert und dann auf den gewünschten BBCode klickt, werden die benötigten Tags automatisch an den Anfang und das Ende des markierten Textes gesetzt.</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Anklickbare Links und E-Mail-Adressen können jetzt nur noch bei Verwendung der Tags, wie sie von den neu angelegten Eingabemasken mitgeliefert werden, in Beiträge eingefügt werden. Die Eingabemasken werden über die entsprechenden BBCode-Buttons aufgerufen. Wenn eine URL z.B. in der Form: &quot;http://www.example.com&quot; ohne die bei Nutzung der Eingabemaske mitgelieferten Tags in einen Gästebucheintrag geschrieben wird, wirft das Programm einen Warnhinweis für den Gast aus und verweigert die Speicherung des Eintrags bis zur Änderung. - Alleine damit werden nach meinen Beobachtungen schon mehr als 3/4 aller Spamversuche geblockt, denn Spam-Bots rufen keine Eingabemasken auf und ein anklickbarer Verweis auf irgendeine Pornoseite durch einen nachtaktiven Bot ist damit praktisch ausgeschlossen.</p>
			<p>Das komfortable Einfügen von BBCodes mit einem Klick funktioniert nur -ebenso wie die vergleichbare Funktion zum Einfügen der Smilies-, wenn der Nutzer Javascript aktiviert hat. Wenn nicht, wird ein entsprechender Hinweis eingeblendet.</p>
			<a id="anchor-Photo" name="anchor-Photo"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.2.4. Fotos in Gästebucheinträgen:</strong></p>
			<p>In den Gästebuchversionen bis 4.3.x konnten Bilder in Einträgen nur eingestellt werden, wenn sie verlinkt waren, also irgendwo, sei es bei einem der vielen Fotoportale, sei es auf dem eigenen Webspace des Gastes oder wo auch immer, bereits online gestellt waren. Das hatte eine Reihe von Nachteilen sowohl haftungsrechtlicher Natur wie auch insofern, dass erfahrungsgemäß diese Fotos dort, von wo sie verlinkt waren, über kurz oder lang wieder verschwanden und dann im Gästebuch recht unschöne &quot;Lücken&quot; hinterliessen.</p>
			<p>Mit der ab Version 4.4.0 bereitgestellten Upload-Funktion kann ein Gast Fotos vom eigenen Rechner in einen Ordner auf dem Webspace, auf dem sich auch das Gästebuchscript befindet, hochladen, die dann im Gästebuchbeitrag angezeigt werden. Auch vom Admin können Fotos in einen Kommentar zu einem Gästebucheintrag hochgeladen und eingestellt werden. Da diese Dateien anschliessend auf dem eigenen Webspace liegen, können sie nicht mehr einfach von dritter Seite unkontrolliert gelöscht werden.</p>
			<p>Ferner kann eine individuelle Kurzbeschreibung des Fotos, die später beim Überfahren des Bildes mit der Mouse eingeblendet wird, ein sogen. &quot;title&quot;, eingegeben werden.</p>
			<p>Für die Nutzung dieser Funktionen müssen in den Konfigurationseinstellungen sowohl &quot;BBCodes&quot; wie auch die Funktion: &quot;Bilder in Gästebucheinträgen anzeigen, Foto-Uploads zulassen?&quot; aktiviert werden. Nach der Neuinstallation ist die Funktion Foto-Uploads und Bildanzeige in Einträgen zunächst deaktiviert.</p>
			<p>Serverseitig müssen insbesondere folgende Einstellungen vorliegen (im Zweifel bei Ihrem Hoster nachfragen oder über <span class="italic">php.info</span> prüfen):</p>
			<ul>
				<li>file_uploads = On
				<li>aktivierter GD-Support
			</ul>
			<p>Sollte bei Ihrem Webspace kein GD-Support durch den Provider zur Verfügung gestellt werden, ist das Programm so eingerichtet, dass sich die Funktion &quot;Foto-Upload&quot; in den allgemeinen Konfigurationseinstellungen nicht aktivieren lässt.</p>
			<p>Damit nicht über Nacht irgendwelche anstößigen Bilder eingestellt werden, wurden zwei Sicherheitsschranken eingepflegt: </p>
			<ul>
				<li>Der Admin bekommt automatisch jedes Mal, wenn ein Foto hochgeladen wird, eine E-Mail mit dem hochgeladenen Bild zur sofortigen Kontrolle übermittelt. (Diese Mail kommt, sobald die Upload-Funktion vom Admin freigeschaltet wurde, aus Sicherheitsgründen immer, unabhängig von den sonstigen E-Mail-Einstellungen.)
				<li>Hochgeladene Fotos können vom Gast zwar in der Eintragsvorschau sofort betrachtet werden, sind aber nach dem Speichern des Beitrags zunächst noch für die Öffentlichkeit unsichtbar. Es wird statt dessen ein Platzhalter im Beitrag angezeigt mit dem Hinweis, dass ein dort eingestelltes Bild vom Admin erst freigeschaltet werden muss. Sobald der Admin sich über die ihm übermittelte E-Mail mit der hochgeladenen Datei von deren Unbedenklichkeit überzeugen konnte, kann er ebenfalls mit einem Klick auf den Link in der gesonderten Mail über den Hinweis auf einen neuen Gästebucheintrag das Bild freischalten. Ein vorheriges Einloggen hier in den Admin-Bereich ist nicht notwendig. Voraussetzung ist lediglich, dass die Upload-Funktion und die Funktion &quot;Admin per E-Mail von neuem Gästebucheintrag informieren&quot; in den allgemeinen Konfigurationseinstellungen aktiviert wurden.
					<ul>
						<li style="list-style-type:none"><br /><strong>Hinweis:</strong> Die Notwendigkeit einer Prüfung und Freischaltung jedes neu hochgeladenen Fotos kann in besonderen Ausnahmefällen deaktiviert werden. Für weitere Erläuterungen hierzu siehe unten <a href="#anchor-MoreKonfig">Abschnitt IV. 3.2.5, "Weitere Konfigurationsmöglichkeiten"</a>.
						<li style="list-style-type:none"><br />Ggf. vom Admin in einen Kommentar zu einem Gästebucheintrag eingefügte Fotos sind auch ohne Freigabe sofort öffentlich sichtbar; der Admin als Kommentator muss wissen, was er macht.
					</ul>
			</ul>
			<p><strong>Weitere Features:</strong></p>
			<ul>
				<li>Je nach Einstellung in der php.ini können Dateien bis zu 5 MB hochgeladen werden. Unter dem Link "Upload Konfiguration" kann diese Grenze selbstverständlich auch niedriger bis auf 1 MB reduziert werden. Die Voreinstellung ist auf 2 MB.
				<li>Hochgeladene Fotos werden automatisch in der Grösse angepasst! Unter dem Link "Upload Konfiguration" können hierzu die gewünschte maximale Breite und Höhe des Fotos festgelegt werden. Die hierbei grösste einstellbare Bildbreite wird vom Programm automatisch nach dem vom Admin gewählten Template bzw. der eingestellten Breite des Gästebuchs ermittelt und angezeigt, so dass es gleichgültig davon, wie groß das hochgeladene Foto ist, keine Probleme mit dem Layout des Gästebuchs gibt. Wenn das Gästebuch auf dem kleinen Bildschirm z.B. eines Smartphones betrachtet wird, werden die eingestellten Bilder in der Darstellung automatisch verkleinert.
				<li>Die Bildqualität von jpg-Dateien (und damit letztlich auch die anschliessende Ladezeit) kann genauso individuell unter dem Link "Upload Konfiguration" zwischen 10 und 100% eingestellt werden.
				<li>Da der Admin-Bereich unabhängig von der Einstellung zum öffentlichen Bereich des Gästebuchs eine feste Grösse hat, werden die Fotos für die Anzeige im Backend noch einmal gesondert passend skaliert.
				<li>Es können ausschliesslich Dateien im Format .jpg und .png hochgeladen werden, alle anderen Dateien sind gesperrt.
				<li>Die hochgeladenen Dateien werden zur Sicherheit mehreren automatischen Prüfungen unterworfen, um sicherzustellen, dass tatsächlich nur Bilddateien hochgeladen werden können.
				<li>Das, was später im Ordner mit den Gästebuchbildern abgelegt wird, ist stets eine -in Grösse und Qualität angepasste und mit einem neuem Dateinamen versehene- Kopie der hochgeladenen Datei; das Original wird nach Fertigung der Kopie umgehend wieder gelöscht, auch um zu vermeiden, dass später Bilddateien im Gästebuch gezeigt werden, die Schadcode über den EXIF-Header einschleusen.
				<li>Die maximale Anzahl der von einem User zu seinem Eintrag hochgeladenen und im Gästebuchbeitrag eingefügten Dateien kann in einem Bereich zwischen "1" und "10" unter dem Link "Upload Konfiguration" eingestellt werden. - Die Voreinstellung nach der Installation ist "2".
				<li>Wegen weiterer Sicherheitshinweise lesen Sie die <strong class="italic">&quot;ReadMe.pdf&quot;</strong>.
			</ul>
			<a id="anchor-Quote" name="anchor-Quote"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.2.5. Zitieren von Gästebucheinträgen:</strong></p>
			<p>Ebenfalls in den Konfigurationseinstellungen gesondert deaktivierbar* ist eine neue Zitierfunktion. (*Diese Funktion ist nach einer Neuinstallation aktiviert.)</p>
			<p>Wird dieses Feature vom Admin nicht gesperrt, wird am Ende eines jeden Gästebucheintrags, gleichgültig ob &quot;alt&quot; bzw. schon vorhanden oder erst neu verfasst, ein verlinktes &quot;Zitat&quot;-Symbol eingeblendet.</p>
			<p>Für die Nutzung dieser Funktion müssen nicht zwingend gleichzeitig auch die sonstigen BBCodes freigeschaltet sein bzw. bleiben.</p>
			<p>Nach dem Anklicken des Zitatsymbols zu dem vom Gast gewählten Eintrag, wird dieser Gästebuchbeitrag als Zitat mit Hinweis auf Verfasser sowie Datum und Zeit des Eintrags in das Formular für einen neuen Gästebucheintrag übernommen zur komfortablen, eindeutigen Beantwortung oder Diskussion. Mehrfachzitate (Zitat in Zitat in Zitat usw.) sind nahezu unbeschränkt möglich. In einem zitierten Beitrag ggf. enthaltenen Fotos werden aus Platzgründen und zur besseren Übersicht aus dem Zitat automatisch entfernt. Ggf. zu einem Beitrag verfasste Admin-Kommentare werden nicht mit zitiert.</p>
			<p>Im sogen. "Blog-Modus" des Gästebuchs (neue Einträge nur durch den Admin über das Admin-Control-Panel) wird die Zitatfunktion automatisch deaktiviert bzw. lässt sich nicht aktivieren.</p>
			<a id="anchor-ComInfo" name="anchor-ComInfo"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.2.6. Gast über Kommentar zu seinem Eintrag automatisch informieren:</strong></p>
			<p>Wenn unter "Allgemeiner Konfiguration" die Option: "Check-Box für "Info-E-Mail" an Gast bei Kommentierung seines Eintrags" nicht deaktiviert wird, erscheint auf der "insert.php" unter dem Textfeld für einen neuen Gästebucheintrag ein Feld, das der Gast anklicken kann, wenn er über einen Kommentar zu seinem Eintrag per E-Mail informiert werden möchte.</p>
			<p>Die E-Mail wird automatisch an die vom Gast zu seinem Eintrag angegebene E-Mail-Adresse verschickt, sobald entweder im Admin-Panel ein Kommentar zu dem betreffenden Gästebucheintrag abgespeichert oder der Gastbeitrag im öffentlichen Bereich des Gästebuchs zitiert wird. Es ist sichergestellt, dass nur beim <strong>ersten</strong> Speichern eines Admin-Kommentars und beim <strong>ersten</strong> Zitat des Gastbeitrags eine Info-E-Mail an den Gast geht; späteres erneutes Aufrufen und Speichern von Korrekturen oder Änderungen zu einem einmal verfassten Kommentar oder erneutes Zitieren eines Eintrags veranlassen keine weiteren Info-E-Mails mehr.</p>
			<p><span class="italic">Dass</span> der Gast die Check-Box aktiviert hat und per E-Mail informiert werden möchte, erkennt der Admin auf der zentralen Seite zur Verwaltung von Einträgen und Kommentaren daran, dass hinter dem Link zum Abfassen eines Kommentars ein kleines "e" für E-Mail eingeblendet wird: <span class="blue">[e]</span>. Beim Überfahren dieses Links mit der Mouse wird als Title eingeblendet, bei welchen Aktionen der Gast eine entsprechende Info-Mail erhält.</p>
			<p>Die Option "Info-E-Mail an Gast" wird automatisch deaktiviert bzw. lässt sich nicht aktivieren, wenn der Admin festlegt, dass das Eingabefeld für eine E-Mail-Adresse des Gastes ausgeblendet wird und daher der Gast eine E-Mail-Anschrift, an die die Info-Mail geschickt werden könnte, nicht hinterlegen kann.</p>
			<a id="anchor-IPBar" name="anchor-IPBar"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2.2.7. IP-Sperre der Eintragsseite:</strong></p>
			<p>Es gibt zwei Ansätze, bei denen das Programm <span class="italic">myPHP Guestbook</span> die IP des Users nutzt, um weitere Einträge im Gästebuch unter derselben IP temporär zu verhindern:</p>
			<p>Einmal zum Schutz vor automatisierten Masseneinträgen binnen kurzer Zeit und zum Anderen zum Schutz vor Spameinträgen.</p>
			<p>Der Schutz vor automatisierten Masseneinträgen mittels IP-Sperre funktioniert so, dass die IP eines Users, der einen Gästebucheintrag verfasst hat, für eine gewisse, einstellbare Zeitspanne gespeichert bleibt und unter derselben IP innerhalb dieser Zeitspanne weitere Gästebucheinträge verhindert werden. Das Ganze nennt sich "Flood Sperre" und wird manchen Usern gerade nach der Neuinstallation des Gästebuchs lästig, nämlich wenn sie versuchen, per "copy and paste" binnen kürzester Zeit Einträge aus einem anderen, zuvor genutzten Gästebuch in das <span class="italic">myPHP Guestbook</span> zu übertragen.</p>
			<p>Eine Lösung ist einfach: Die Einträge einfach im Admin-Control-Panel unter dem Link "Admin Blog" vornehmen, dort gibt es keine "Flood Protection", siehe unten <a href="#anchor-Blog">Abschnitt IV. 3.1.3., "Admin Blog"</a>.</p>
			<p>Wegen der IP-Sperre, die durch einen Spameintrag verursacht wird und programmseitig für 7 Tage aufrecht erhalten bleibt, siehe unten <a href="#anchor-ShowIpBar">Abschnitt IV. 3.7.3., "Spamfilter - IP-Sperren"</a>.</p>
			<a id="anchor-Admin" name="anchor-Admin"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3. Admin-Control-Panel</strong></p>
			<p>Das ganze Gästebuch wird kinderleicht über das <span class="italic">myPHP Guestbook</span> Admin-Control-Panel verwaltet. Zugriff auf das Admin-Panel gibt es nur mit einem korrekten Benutzernamen und Passwort.</p>
			<p>Falls Sie Ihr Passwort zum Einloggen in das Admin-Control-Panel einmal vergessen haben sollten, können Sie über den Link "Passwort vergessen" ein neues Passwort generieren und sich an Ihre Admin-E-Mail-Adresse schicken lassen.</p>
			<p>Wenn Sie von dieser Möglichkeit Gebrauch gemacht haben, sollten Sie sich anschließend mit dem neu generierten Passwort einloggen und sogleich ein neues Passwort vergeben.</p>
			<a id="anchor-Noentry" name="anchor-Noentry"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p>Der Schutz des Admin-Bereichs wurde mit v.4.6.1 erheblich ausgeweitet:</p>
			<p>Jeder Versuch, sich in das Admin-Control-Panel mit einem falschen Nutzernamen oder einem falschen Passwort einzuloggen und auch jede Eingabe einer falschen Admin-E-Mail-Adresse bei der "Passwort vergessen"-Funktion wird erfasst und hochgezählt. Nach fünf Versuchen mit unrichtigen Eingaben wird der Login-Bereich für jegliche Eingaben komplett gesperrt.</p>
			<p>Die Möglichkeit zum Login bleibt danach aus Sicherheitsgründen für 7 Tage gesperrt und wird erst nach deren Ablauf automatisch wieder freigegeben.</p>
			<p>Damit der Admin jedoch auch die Möglichkeit hat, sich vor Ablauf dieser 7 Tage bei Bedarf wieder einzuloggen, geht gleichzeitig mit der Sperre des Login-Bereichs eine E-Mail an den Admin mit einem Link zur sofortigen Freigabe des Login.</p>
			<p>Ferner wird für den Fall, dass Sie sich selbst ein- oder zweimal bei der Eingabe der Daten zum Login vertippt haben, die Zählung von Eingaben falscher Login-Daten nach jedem erfolgreichen Login wieder auf Null gesetzt.</p>
			<p>Bei Inaktivität im Admin-Bereich von mehr als 30 Minuten wird schließlich aus Sicherheitsgründen die mit dem Einloggen angelegte Session zerstört und der Admin muss sich neu einloggen. Jeder Klick auf einen Link im Admin-Bereich setzt diese Zeitmessung wieder auf Null, sodass die vollen 30 Minuten nach jedem Klick wieder zur Verfügung stehen.</p>
			<a id="anchor-Gaestebucheintraege" name="anchor-Gaestebucheintraege"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.1. Gästebucheinträge:</strong></p>
			<a id="anchor-Edit" name="anchor-Edit"></a>
			<p class="text-shadow"><strong>3.1.1. Einträge verwalten, editieren, kommentieren:</strong></p>
			<p>Auf der Seite &quot;Einträge und Kommentare&quot; verwalten Sie die Gästebucheinträge oder fügen bei Bedarf einen Kommentar zu einem Beitrag hinzu. Hierzu einfach auf den entsprechenden Link "Bearbeiten" oder "Kommentar" unter dem jeweiligen Gästebucheintrag klicken und die gewünschte Aktion ausführen.</p>
			<p>Auch innerhalb eines Admin-Kommentars können Sie selbstverständlich BBCodes und Smilies nutzen oder Fotos hochladen und einfügen.</p>
			<p>Sie sehen zu Beginn der Seite, ob bestimmte IPs zum Aufruf der Eintragsseite gesperrt wurden, ob alle Einträge freigegeben sind und wann das letzte BackUp erstellt wurde.</p>
			<p>Unter jedem Beitrag sehen Sie dann noch einmal separat, ob nur der Text eines Beitrags oder auch dort ggf. eingestellte Fotos freigegeben oder noch gesperrt sind.</p>
			<p>Ferner können Sie hier auf zwei möglichen Wegen Beiträge sperren, endgültig löschen oder gesperrte Beiträge bzw. noch gesperrte Fotos freigeben:</p>
			<ul>
				<li>Die eine Möglichkeit ist, die Check-Box, die sich oben rechts bei jedem Eintrag befindet, zu markieren, dann auf der Seite oben im Drop-Down-Menü die gewünschte Aktion auswählen und anschließend auf "OK" klicken. Wenn Sie die Check-Box links neben dem Drop-Down-Menü für "Alle auswählen" markieren, werden automatisch alle Beiträge <strong>auf der jeweiligen Seite</strong> markiert und können so schnell und einfach in einem Arbeitsgang z.B. aktiviert oder deaktiviert werden.
				<li>Die zweite Möglichkeit besteht darin, auf die Grafik (grüner Haken bzw. rotes Sperrsymbol) rechts unten bei jedem Eintrag neben den Hinweisen "Text freigegeben?" bzw. "Foto freigegeben?" zu klicken. Dann wird der betreffende Eintrag, abhängig von seinem aktuellen Status, nach je einem Klick: Gesperrt ==&gt; Nur der Text wird freigegeben ==&gt; Text und Foto werden freigegeben ==&gt; Gesperrt ... usw..
			</ul>
			<a id="anchor-Grafik" name="anchor-Grafik"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.1.2. Hochgeladene Grafikdateien verwalten und editieren:</strong></p>
			<p>Hier werden alle mit der Funktion &quot;Foto-Upload&quot; hochgeladenen Grafikdateien angezeigt und verwaltet. Ob das Bild im öffentlichen Bereich des Gästebuchs freigeben oder noch gesperrt ist, ist hierbei gleichgültig.</p>
			<p>Die mögliche Bearbeitung beinhaltet z.B. das Löschen von hochgeladenen Dateien oder auch das Editieren einer eingegebene Beschreibung (&quot;title&quot;) des Fotos.</p>
			<p>Ebenso können ggf. vom Admin per FTP gesondert hochgeladene Bilder hier in die Datenbanktabelle des Bilderordners eingegeben werden.</p>
			<p>Sollte einmal ein Foto hochgeladen worden sein, das der Admin wegen eines von ihm als kritisch/rechtswidrig eingestuften Inhalts nicht freischaltet, sollte die Datei gelöscht werden, auch um Fremdverlinkungen zu vermeiden!</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Sie haften als Websitebetreiber für den Inhalt aller Darstellungen auf Ihrer Website. Das gilt selbstverständlich auch für dort veröffentlichte Bilder. Falls Sie z.B. Anhaltspunkte dafür haben, dass es sich bei einem hochgeladenen/eingestellten Foto um eine unerlaubte Kopie aus dem Internet handelt, dort Personen ohne deren Einverständnis abgebildet wurden o.ä., sind Sie verpflichtet, das Foto umgehend zu löschen. Vergleichbares gilt für kritische Fotomotive, wie z.B. gewaltverherrlichende, rassistische, pornografische o.ä. rechtswidrige Darstellungen / Inhalte.</p>
			<a id="anchor-Blog" name="anchor-Blog"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.1.3. Admin Blog:</strong></p>
			<p>Es besteht ebenfalls die Möglichkeit, das Gästebuch als Blog, Reisetagebuch o.ä. zu betreiben, in dem dann ausschließlich der Admin selbst Einträge veröffentlichen kann, kein außenstehender Dritter.</p>
			<p>Aber auch wenn das Gästebuch <span class="italic">nicht</span> im sogen. "Blog-Modus" betrieben wird, können selbstverständlich Einträge im Gästebuch vom Admin hier eingegeben werden.</p>
			<p>Bei Einträgen, die im Admin-Control-Panel unter dem Link "Admin Blog" vorgenommen werden,</p>
			<ul>
				<li>findet <span class="italic">keine</span> Prüfung auf Spam statt, es geht <span class="italic">keine</span> E-Mail an den Admin über den dort neu verfassten Eintrag;
				<li>ggf. im Beitrag vom Admin eingestellte Fotos sind <span class="italic">sofort freigeschaltet</span> und für die Öffentlickeit sichtbar;
				<li>neue Einträge können in beliebiger Anzahl ohne Wartezeit hier eingegeben und gespeichert werden, die sogen. "Flood-Protection" ist hierbei <span class="italic">nicht</span> aktiv.
			</ul>
			<p>Für den Betrieb des Gästebuchs im "Blog-Modus" muss unter "Einstellungen" ==&gt; "Allgemeine Konfiguration" ==&gt; "Link zur Seite für Gästebucheinträge" der Radio-Button für "Link entfernen (Blog-Modus)" ausgewählt und diese Einstellung gespeichert werden.</p>
			<p>Daraus ergeben sich dann u.a. folgende weitere Besonderheiten:</p>
			<ul>
				<li>Die Links zur Eintragsseite "insert.php", die auf der "index"-Seite für die Gästebucheinträge ober- und unterhalb der schon veröffentlichten Einträge vorhanden sind, werden deaktiviert/ausgeblendet.
				<li>Die Eintragsseite "insert.php" ist im Web nicht mehr aufrufbar (automatische Umleitung zur "index"-Seite), neue Einträge können nur noch im Admin-Control-Panel vorgenommen werden.
				<li>Die Zitatfunktion zu vorhandenen Gästebucheinträgen wird automatisch deaktiviert bzw. lässt sich nicht aktivieren.
			</ul>
			<a id="anchor-Front" name="anchor-Front"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.1.4. Frontend anzeigen:</strong></p>
			<p>Mit einem Klick auf diesen Link wird die Gästebuchseite geöffnet, wie sie auf Ihrem Webspace veröffentlicht ist, sodass etwaige Editierungen, Kommentierungen etc. sofort überprüft werden können.</p>
			<a id="anchor-Einstellungen" name="anchor-Einstellungen"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.2. Einstellungen:</strong></p>
			<p>Allgemeine Gästebuch-Einstellungen können hier in vier Unterkategorien vorgenommen werden:</p>
			<a id="anchor-AdminEdit" name="anchor-AdminEdit"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.2.1. Admin Einstellungen:</strong></p>
			<p>Hier werden Ihre persönlichen Daten als Admin verwaltet. Die E-Mail-Adresse wird dazu benötigt, bei neuen Einträgen eine Benachrichtigung an den Admin zu senden (falls aktiviert), auch erstellte Backups werden nach dort automatisch geschickt und Mitteilungen über etwaige Versuche von Spameinträgen und Foto-Uploads. Ebenso kann hier ein vergessenes Passwort zurück gesetzt werden.</p>
			<a id="anchor-Konfig" name="anchor-Konfig"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.2.2. Allgemeine Konfiguration:</strong></p>
			<p>Die grundlegenden Einstellungen vom Gästebuch werden hier von Ihnen festgelegt.</p>
			<p>Das beinhaltet z.B.:</p>
			<ul>
				<li>ob Smilies und/oder BBCodes,
				<li>die Zitierfunktion und/oder
				<li>der Fotoupload aktiviert sind,
				<li>ab welcher Grenze der Spamfilter einen Beitrag verwirft oder nur sperrt,
				<li>wieviel Links ein Besucher in seinen Beitrag einstellen darf, ohne dass dies als Spamversuch gewertet wird,
				<li>das komplette Gästebuch und
				<li>die Gästebuch-Statistik können hier jeweils mit einem Klick aktiviert oder deaktiviert werden,
				<li>die Anzeige und Eintragsmöglichkeit für eine E-Mail-Adresse des Besuchers,
				<li>für den Herkunftsort oder
				<li>das Herkunftsland des Besuchers,
				<li>für einen Link zur Homepage oder
				<li>einen ICQ-Link und auch
				<li>das Eingabefeld für einen &quot;Betreff&quot; zum Eintrag des Gastes können ebenso einzeln an- oder abgeschaltet werden,
				<li>wie das Eintragsfeld für E-Mail-Adressen des Gastes als Pflichtfeld bestimmt werden kann ...
			</ul>
			<p>... und vieles mehr.</p>
			<a id="anchor-LinkButton" name="anchor-LinkButton"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />esp: Auswahl Text-Link oder Button zur Eintragsseite bzw. Link ausblenden (Blog-Modus):</strong></p>
			<p>U.a. besteht hier auch die Möglichkeit, die Links zur Seite für neue Gästebucheinträge, die oberhalb und unterhalb der schon veröffentlichten Einträge angezeigt werden, individuell auszugestalten, entweder als Text-Link, als Html-Button oder aber diese Links ganz auszublenden.</p>
			<p><strong>Text-Link (Voreinstellung):</strong> Geben Sie in das entsprechende Eingabefeld den Text ein, der als Ankertext des Links im Gästebuch erscheinen soll. Der Eintrag kann bis zu 35 Zeichen lang sein. Wegen einer individuellen Einfärbung dieses Links siehe unten <a href="#anchor-EditStyle">Abschnitt IV. 3.4.2, Style editieren</a>.</p>
			<p><strong>Button:</strong> Falls Sie anstatt eines Text-Links einen anklickbaren Html-Button als Anker für den Link einbinden möchten, markieren Sie die entsprechende Radio-Box und klicken auf speichern.</p>
			<p>Die Beschriftung des Buttons entspricht wieder der Eingabe im Feld "Text des Links/Buttons".</p>
			<p>Wenn Sie keinen abweichenden Text eingeben, wird die Vorgabe aus der Sprachdatei für den Link bzw. die Beschriftung des Buttons verwendet.</p>
			<p>Für Änderungen an der Hintergrund- und Schriftfarbe des Buttons siehe erneut das Beispiel unten <a href="#anchor-EditStyle">Abschnitt IV. 3.4.2, "Style editieren"</a></p>
			<p><strong>Link entfernen:</strong> User, die das Gästebuch als eine Art Blog, Reisetagebuch oder ähnliches verwenden möchten und die keine Einträge von Dritten dort wünschen, wählen bitte die Option "Link entfernen (Blog-Modus)". Für weitere Erläuterungen zu dieser Option siehe oben: <a href="#anchor-Blog">Abschnitt IV. 3.1.3, Admin Blog</a></p>
			<a id="anchor-Upload" name="anchor-Upload"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.2.3. Konfiguration Datei-Uploads:</strong></p>
			<p>Hier können grundlegende Einstellungen zum Dateiupload vorgenommen werden, wie z.B.:</p>
			<ul>
				<li>die maximale Grösse des Uploads in MB (die absolute Obergrenze wird serverseitig von der "php.ini" festgelegt, siehe hierzu &quot;upload_max_filesize&quot; und &quot;post_max_size&quot;),
				<li>die maximale Breite und Höhe des Bildes in Pixel u.ä. (die maximale Breite eines Fotos wird von der eingestellten Breite des Gästebuchs abzüglich gewisser Innenabstände begrenzt).
				<li>Auch die maximale Anzahl der von einem User zu seinem Eintrag hochgeladenen und im Gästebuchbeitrag eingefügten Dateien kann hier seit v.4.5.3 in einem Bereich zwischen &quot;1&quot; und &quot;10&quot; eingestellt werden. - Die Voreinstellung nach der Installation ist &quot;2&quot;. Die (IP-)Sperre zum Upload von über dem eingestellten Limit hinausgehenden weiteren Dateien ist auf 20 Minuten festgelegt, danach beginnt die Zählung wieder von vorne.
			</ul>
			<p>Damit die automatische Ermittlung der höchstmöglichen Breite einer hochgeladenen Grafikdatei je nach gewähltem Template funktioniert, dürfen die Namen der verschiedenen vorinstallierten Templates nicht geändert werden!</p>
			<a id="anchor-Thankyou" name="anchor-Thankyou"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.2.4. Individuelle &quot;Danke-E-Mail&quot; an den Gast</strong></p>
			<p>In den &quot;Allgemeinen Konfigurationseinstellungen&quot; können Sie auch festlegen, ob ein Gast, wenn er einen Eintrag ins Gästebuch verfasst und dabei seine E-Mail-Adresse mit angegeben hat, vom Programm automatisch eine E-Mail mit einem kleinen &quot;Danke-Schön&quot; erhält.</p>
			<p>Unter dem o.g. Link wird Ihnen zunächst angezeigt, welchen Text der Gast mit dieser E-Mail standardmäßig erhält. Sie können den Text dann individuell auf Ihre Bedürfnisse und Wünsche anpassen. Voraussetzung ist, dass die Option "Per E-Mail für Eintrag bedanken" aktiviert ist.</p>
			<p><strong><span class="red">TIPP:</span></strong> Ebenso kann (und sollte) an dieser Stelle eine von der Admin-E-Mail-Adresse abweichende E-Mail-Adresse eingegeben werden, die dem Gast als Absender der &quot;Danke-E-Mail&quot; angezeigt wird.</p>
			<a id="anchor-MoreKonfig" name="anchor-MoreKonfig"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.2.5. Weitere Konfigurationsmöglichkeiten, insbesondere bei Verwendung des Gästebuch in einem zugangsgeschützten Mitgliederbereich</strong></p>
			<p>Der Spamschutz und die Einzelfallprüfung mit anschliessender separater Freigabe jedes neu hochgeladenen Bildes durch den Admin sollten grundsätzlich aktiviert bleiben!</p>
			<p>Gleichwohl sind Fälle denkbar, in denen dies nicht gewünscht oder notwendig ist, z.B. wenn das Gästebuch nur in einem zugangsgeschützten Bereich für namentlich bekannte Mitglieder betrieben wird o.ä..</p>
			<p>Der (gesamte) Spamfilter und die Notwendigkeit einer Prüfung und Freischaltung jedes neu hochgeladenen Fotos durch den Admin können daher in besonderen Ausnahmefällen wie folgt deaktiviert werden:</p>
			<ul>
				<li>Im Ordner &quot;includes&quot; die Datei &quot;functions.inc.php&quot; mit einem Editor öffnen.
				<li>Oben in der Datei direkt unter den Copyright-Hinweisen sind zwei Konstanten definiert. - Die &quot;SPAM_PROTECT&quot; für den Spamschutz und die &quot;PIC_CHECK&quot; für die notwendige Freigabe jedes hochgeladenen Fotos durch den Admin.
				<li>Je nach dem, was gewünscht ist, die entsprechende Konstante von &quot;<span class="blue">true</span>&quot; auf &quot;<span class="blue">false</span>&quot; ändern, speichern, Datei neu hochladen, fertig.
			</ul>
			<p>In den &quot;Allgemeinen Konfigurationseinstellungen&quot; wird angezeigt, falls der Spam-Schutz deaktiviert ist und/oder hochgeladene Grafik-Dateien ohne vorherige Prüfung und Freigabe durch den Admin sofort im öffentlichen Bereich des Gästebuchs angezeigt werden.</p>
			<a id="anchor-Template" name="anchor-Template"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.3. Template</strong></p>
			<p>Die Darstellung der Einträge im Gästebuch wird entscheidend durch das verwendete Template bestimmt. Um mit Templates zu arbeiten (editieren und erstellen), sind (mit Einschränkungen, s.u.) HTML-Kenntnisse erforderlich.</p>
			<a id="anchor-StandTempl" name="anchor-StandTempl"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.3.1. Standard Template</strong></p>
			<p>Hier werden alle vorhandenen Templates auf einen Blick dargestellt und können durch einen Klick auf einen der zugehörigen Radio-Buttons und anschliessendes Speichern gewechselt werden. Das gerade verwendete Template ist gekennzeichnet.</p>
			<p>Um die Auswahl zwischen den verschiedenen vorinstallierten Templates zu erleichtern, können Ansichten mit einem Klick auf den Button &quot;Show example&quot; aufgerufen werden.</p>
			<p><strong><span class="red">TIPP:</span></strong> Das vorinstallierte Template &quot;myPHP-GBook4_wide-R&quot; sollte aus optischen Gründen nicht mit einer Breite des Gästebuchs von weniger als 600px gewählt werden, da sonst die linke Spalte mit Namen etc. je nach Eintrag zu schmal werden kann. Ausserdem funktioniert die automatische Verkleinerung von ggf. eingestellten Fotos in Gästebucheinträgen bei diesem Template &quot;Wide&quot; derzeit im Edge, Chrome, Opera, Safari und Android, nicht im IE oder FF. Diejenigen, die die Anzeige von Fotos im Gästebuch ermöglichen möchten, müssen sich daher überlegen, ob sie das Template „Wide“ gleichwohl nutzen oder lieber auf eines der neun anderen Templates ausweichen.</p>
			<p><strong><span class="red">TIPP:</span></strong> Bei dem vorinstallierten Template &quot;myPHP-GBook4_color-R&quot; kann die Rahmenfarbe um einen Gästebucheintrag ganz einfach unter dem Link &quot;Template editieren&quot; und der Auswahl &quot;myPHP-GBook4_color-R&quot; geändert/nach Wunsch angepasst werden.</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Zu den zehn vorinstallierten Templates gehören zehn abgestimmte CSS-Styles. Die zugehörigen Styles haben jeweils die identische Bezeichnung wie die Templates. Wird ein Template ohne das zugehörige Style verwendet, kann es zu Darstellungsfehlern kommen, die zwar keine Schäden verursachen (ausser im Auge des Betrachters), das Erscheinungsbild des Gästebuchs aber empfindlich stören. Wenn Sie also ein Template wechseln, sollten Sie in einem zweiten Schritt stets auch den zugehörigen Style einstellen.</p>
			<a id="anchor-EditTempl" name="anchor-EditTempl"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.3.2. Template editieren (inkl. Textfarbe, Breite, Hintergründe u.ä.)</strong></p>
			<p>Die einzelnen Templates können hier nach Ihren Wünschen angepasst werden.</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Eine Anpassung der grundlegenden Einstellungen von Hintergrundfarben für die gesamte Gästebuchseite und die Gästebucheinträge, für die Schriftfarbe, die maximale Breite des Gästebuchs und dessen Ausrichtung auf der Website (Rechts-Links-Mittig) sollte und braucht der CSS-Code nicht geändert zu werden; diese Einstellungen können schneller und einfacher ebenfalls unter „Template editieren“ vorgenommen werden.</p>
			<a id="anchor-MakeTempl" name="anchor-MakeTempl"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.3.3. Template erstellen</strong></p>
			<p>Diese Option kann nur voll ausgenutzt werden, wenn auch HTML Kenntnisse vorhanden sind, da hier das ganze Aussehen von den Gästebucheinträgen selbst bestimmt werden kann.</p>
			<p>Sie sollten beachten, dass der von Ihnen eingefügte HTML Code nur für einen Eintrag bestimmt ist und sich mit jedem weiteren Eintrag wiederholt. Also können Sie nicht den Code einer ganzen HTML Seite dort einfügen.</p>
			<p>Wenn Sie ein Grundgerüst des HTML Codes erstellt haben, müssen Sie die Gästebuch-Variablen am richtigen Ort einsetzen. So ist z.B. &lt;$name$&gt; der Platzhalter für den Namen des Gastes, der sich ins Gästebuch einträgt.</p>
			<p>Für Anfänger wird empfohlen, vorhandene Templates zu editieren und so den Wünschen nach anzupassen. Voransichten für selbstgefertigte Templates funktionieren selbstverständlich nicht.</p>
			<a id="anchor-DelTempl" name="anchor-DelTempl"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.3.4. Template löschen</strong></p>
			<p>Ungebrauchte Templates können hier einfach und endgültig(!) gelöscht werden.</p>
			<p>Ich empfehle allerdings, keines der vorinstallierten Templates zu löschen, es sei denn, der zugehörige CSS-Style wird ebenfalls entfernt.</p>
			<p>Damit nicht versehentlich alle Templates gelöscht werden, kann das letzte in der Datenbank vorhandene Template nicht entfernt werden.</p>
			<p>Sollte(n) einmal ein oder mehrere Templates gelöscht worden sein und später der Wunsch entstehen, sie wieder herzustellen, kann dies mit dem Diagnose- und Reparatur-Tool zu <span class="italic">myPHP Guestbook</span> problemlos erfolgen. Näheres hier siehe unten <a href="#anchor-Repair">Abschnitt IV. 4., "Diagnose- und Reparatur-Tool"</a>.</p>
			<a id="anchor-Styles" name="anchor-Styles"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.4. CSS-Styles</strong></p>
			<p>Neben dem verwendeten Template wird das Aussehen von <span class="italic">myPHP Guestbook</span> auch vom genutzten CSS-Style bestimmt.</p>
			<p>Falls Sie noch nicht genau wissen, was CSS ist, sollten Sie sich unbedingt Tutorials (finden Sie im Internet) anschauen, damit Sie über ein gewisses Grundwissen verfügen.</p>
			<a id="anchor-StandStyle" name="anchor-StandStyle"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.4.1. Standard Style</strong></p>
			<p>Hier werden alle vorhandenen Styles auf einen Blick dargestellt und können durch einen Klick auf einen der zugehörigen Radio-Buttons und anschliessendes Speichern gewechselt werden. Der gerade verwendete Style ist gekennzeichnet.</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Zu den zehn vorinstallierten CSS-Styles gehören zehn abgestimmte Templates. Die zugehörigen Templates haben jeweils die identische Bezeichnung wie die Styles. Wird ein Style ohne das zugehörige Template verwendet, kann es zu Darstellungsfehlern kommen, die zwar keine Schäden verursachen (Sie wissen schon: ausser im Auge des Betrachters), das Erscheinungsbild des Gästebuchs aber mehr oder weniger empfindlich stören. Wenn Sie also einen Style wechseln, sollten Sie stets auch das entsprechende Template wechseln.</p>
			<a id="anchor-EditStyle" name="anchor-EditStyle"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.4.2. Style editieren</strong></p>
			<p>Falls kleine Änderungen am Style vorgenommen werden sollen, kann hier ein vorhandener Style editiert werden.</p>
			<p>Achten Sie unbedingt auf die richtige Klassenwahl zum jeweils verwendeten Template!</p>
			<p>Im Style können einige Variablen genutzt werden, die auf den Seiten &quot;Style erstellen&quot; bzw. &quot;Style editieren&quot; unter dem Textfeld zur Eingabe beschrieben sind. Die Inhalte dieser Variablen sind bei dem jeweiligen Template erfasst und werden auch dort geändert (siehe oben unter &quot;Template editieren&quot;).</p>
			<p><strong><span class="red">TIPP:</span> Hier einige CSS-Code-Beispiele für Layout-Änderungen, nach denen immer wieder gefragt wird:</strong></p>
			<p>Zunächst unter "CSS-Style" &#62; "Style editieren" anklicken und den von Ihnen aktuell verwendeten Style öffnen, indem Sie auf den Button "Bearbeiten" klicken. Am Ende des vorhandenen Styles den alternativ gewünschten Code einsetzen und speichern:</p>
			<p>a) Breite der Input- und des Textarea-Felds auf der "insert.php" ändern (Voreinstellung max. 500px):</p>
			<ul>
				<li>Größere Breite, hier z.B. 900px:<br />
				<span class="blue">.insert-table{max-width:900px;}</span><br /><br />
				<li>Kleinere Breite, hier z.B. 400px:<br />
				<span class="blue">.insert-table{max-width:400px;}</span>
			</ul>
			<p>b) Auf der Seite für die Gästebucheinträge bekommen die Input- und das Textarea-Feld beim Setzen des Cursors programmseitig einen grauen Rahmen mit entsprechendem äußerem Schatten gesetzt. Einen farblich angepassten Schatten hat auch das Feld, bei dem der Gast anklicken kann, wenn er über eine Antwort zu seinem Eintrag per E-Mail informiert werden möchte. Die Farben von Rahmen und Schatten kann man u.a. wie folgt individuell anpassen:</p>
			<ul>
				<li>Kein Schatten, unveränderte Rahmenfarbe:<br />
				<span class="blue">.insert:focus, textarea:focus, .comment-info{border:solid 1px #9e9e9e;-webkit-box-shadow: 0 0 0 0;-moz-box-shadow: 0 0 0 0;box-shadow: 0 0 0 0;}</span><br /><br />
				<li>Für weißen Rahmen mit Schatten (bei schwarzen/sehr dunklen Hintergründen):<br />
				<span class="blue">.insert:focus, textarea:focus, .comment-info{border:solid 1px #f2f2f2;-webkit-box-shadow: 0 0 5px 4px rgba(255,255,255, 0.3);-moz-box-shadow: 0 0 5px 4px rgba(255,255,255, 0.3);box-shadow: 0 0 5px 4px rgba(255,255,255, 0.3);}</span><br /><br />
				<li>Für grünen Rahmen mit Schatten:<br />
				<span class="blue">.insert:focus, textarea:focus{border:solid 1px #00cc66;-webkit-box-shadow: 0 0 5px 4px rgba(31,248,20, 0.12);-moz-box-shadow: 0 0 5px 4px rgba(31,248,20, 0.12);box-shadow: 0 0 5px 4px rgba(31,248,20, 0.12);}</span><br /><br />
				<li>Für roten Rahmen mit Schatten:<br />
				<span class="blue">.insert:focus, textarea:focus{border:solid 1px #ff0000;-webkit-box-shadow: 0 0 5px 4px rgba(219,28,28, 0.12);-moz-box-shadow: 0 0 5px 4px rgba(219,28,28, 0.12);box-shadow: 0 0 5px 4px rgba(219,28,28, 0.12);}</span><br /><br />
				<li>Für blauen Rahmen mit Schatten:<br />
				<span class="blue">.insert:focus, textarea:focus{border:solid 1px #0066ff;-webkit-box-shadow: 0 0 5px 4px rgba(0,0,255, 0.12);-moz-box-shadow: 0 0 5px 4px rgba(0,0,255, 0.12);box-shadow: 0 0 5px 4px rgba(0,0,255, 0.12);}</span>
			</ul>
			<p>c) Änderung der Farben für die Text-Links zur Eintragsseite und der Seitenzahlen zum Blättern oberhalb und unterhalb der Gästebucheinträge:</p>
			<ul>
				<li>Im Beispiel unten ist der Link in Normalzustand blau (= #0000ff) und im aktiven Zustand rot (= #ff0000):<br /> 
				<span class="blue">.this-page,.navi-page:link,.navi-page:visited{color:#0000ff;}<br />
				.navi-page:hover,.navi-page:active{color:#ff0000;}</span></li>
			</ul>
			<p>d) Änderung der Hintergrund- und Schriftfarbe des Html-Buttons zur Eintragsseite:</p>
			<ul>
				<li>Im Beispiel unten ist die Hintergrundfarbe des Buttons dunkelblau (= #3300ff), die Schriftfarbe weiß (= #fff):<br />
				<span class="blue">a:link.insert-button,a:visited.insert-button{color:#fff;background-color:#3300ff;background:#3300ff;}</span></li>
			</ul>
			<p>e) Schatten um eingestellte Fotos anzeigen und Ecken abrunden:</p>
			<ul>
				<li><span class="blue">img.centered{border-radius:3px;-webkit-border-radius:3px;-moz-border-radius:3px;-khtml-border-radius:3px;box-shadow:0px 0px 10px #474747;-webkit-box-shadow:0px 0px 10px #474747;-moz-box-shadow:0px 0px 10px #474747}</span>
			</ul>
			<p>f) Textgröße (Voreinstellung je nach Template 13 - 15px) oder Schriftart ändern:</p>
			<ul>
				<li>Beim "body"-Tag (i.d.R. die erste Zeile des CSS-Codes) den Wert "<span class="blue">font-size:13px;</span>" zur Änderung der Schriftgröße wie gewünscht anpassen,<br /><br />zur Anpassung der Schriftart an Stelle von "<span class="blue">font-family:arial,Verdana,Helvetica;</span>" die gewünschte Schriftenfamilie einsetzen.
			</ul>
			<p class="zentriert"><br /><strong>Achtung!</strong></p>
			<p><strong>Die im vorinstallierten CSS-Code eingesetzten Variablen sollten unverändert bleiben, um die Einstellmöglichkeiten unter "Template editieren" nicht zu zerstören.</strong></p>
			<a id="anchor-MakeStyle" name="anchor-MakeStyle"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.4.3. Style erstellen</strong></p>
			<p>Für Anwender mit entsprechenden Kenntnissen in CSS bietet dieses Feature die Möglichkeit, einen eigenen Style von Grund auf selber zu erstellen.</p>
			<a id="anchor-DelStyle" name="anchor-DelStyle"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.4.4. Style löschen</strong></p>
			<p>Nicht benötigte Styles können hier ebenso einfach wie endgültig (!) gelöscht werden.</p>
			<p>Ich empfehle allerdings, keinen der vorinstallierten Styles zu löschen, es sei denn, das zugehörige Template wird ebenfalls entfernt.</p>
			<p>Damit nicht versehentlich alle Styles gelöscht werden, kann der letzte in der Datenbank vorhandene Style nicht entfernt werden.</p>
			<p>Sollte(n) einmal ein oder mehrere Styles gelöscht worden sein und später der Wunsch entstehen, sie wieder herzustellen, kann dies mit dem Diagnose- und Reparatur-Tool zu <span class="italic">myPHP Guestbook</span> problemlos erfolgen. Näheres hier siehe unten <a href="#anchor-Repair">Abschnitt IV. 4., "Diagnose- und Reparatur-Tool"</a>.</p>
			<a id="anchor-Smilies" name="anchor-Smilies"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.5. Smilies</strong></p>
			<p>Smilies sind in Gästebüchern und Foren Standard. Auch in <span class="italic">myPHP Guestbook</span> steht Ihnen dieses Feature zur Verfügung.</p>
			<p>Smilies funktionieren wie folgt:</p>
			<p>Jedes Smiley besitzt einen eigenen BBCode (der BBCode für ein wütendes Smiley ist z.B. &quot;:angry:&quot;, was natürlich geändert werden kann). Wenn nun im Gästebuch &quot;:angry:&quot; in einen Eintrag geschrieben wurde und Smilies im Gästebuch aktiviert sind, erscheint anstelle von &quot;:angry:&quot; der wütende Smiley.</p>
			<p>Der &quot;normale&quot; User wird, wenn er nicht gerade Javascript in seinem Browser abgeschaltet hat, einen Smiley durch einfaches Anklicken in seinen Textbeitrag einfügen. Der Smiley erscheint nach dem Anklicken stets dort, wo sich zuvor der Cursor der Mouse im Text befunden hat.</p>
			<a id="anchor-ShowSmil" name="anchor-ShowSmil"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.5.1. Smilies anzeigen</strong></p>
			<p>Alle vorhandenen Smilies werden hier zur Übersicht angezeigt und können bei Bedarf gelöscht oder editiert werden.</p>
			<a id="anchor-PlusSmil" name="anchor-PlusSmil"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.5.2. Smiley hinzufügen</strong></p>
			<p>Wenn Ihnen die vorinstallierten Smilies nicht ausreichen oder nicht gefallen, können Sie hier Ihre eigenen Smilies hochladen und BBCode sowie weitere Eigenschaften bestimmen.</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Die ersten 12 (oder 19) Smilies, die auf der Seite für die Gästebucheinträge &quot;insert.php&quot; im Anschluss an oder anstelle der BBCodes-Select-Drop-Downs angezeigt werden, haben eine Grösse von 15 x 15px. Wenn Sie dort andere Smilies mit abweichenden Größen einfügen, insbesondere solche mit einer Breite von mehr als 15px, kann dies zu für das Layout unschönen Zeilenumbrüchen führen. Eine Lösungsmöglichkeit besteht dann ggf. darin, die Datei &quot;insert.php&quot; zu öffnen und die Anzahl der dort direkt angezeigten Smilies zu verringern, beispielsweise auf nur noch 10 Stück oder auch weniger. Denken Sie in einem solchen Fall daran, auch in der &quot;smilies.php&quot; eine korrespondierende Änderung vorzunehmen.</p>
			<a id="anchor-DelSmil" name="anchor-DelSmil"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.5.3. Smilies löschen</strong></p>
			<p>Smilies, die Ihnen nicht gefallen, können ganz einfach unter &quot;Smilies anzeigen&quot; gelöscht werden. über Checkboxen können Sie schnell und unkompliziert die zur Entfernung gewünschten Smilies markieren.</p>
			<a id="anchor-EditSmil" name="anchor-EditSmil"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.5.4. Smilies editieren</strong></p>
			<p>Bei kleinen Änderungen an Smilies ist dieses Feature sehr hilfreich. So kann z.B. der BBCode geändert werden, ohne dass der Smiley gelöscht und neu hinzugefügt werden muss.</p>
			<a id="anchor-Badwords" name="anchor-Badwords"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.6. Badwords und deren Ersetzung</strong></p>
			<p>Schimpfwörter, sowie andere nicht erwünschte Wörter können mit diesem Feature im Gästebuch zensiert werden.</p>
			<p>Zwar lässt sich die Zensur durch Tricks auch umgehen, aber ein erster Schutz wird dadurch bereits geboten.</p>
			<p>In den Versionen ab v. 3.2.x wurden die Badwords durch ein vom Admin bestimmtes, frei wählbares Ersatzwort ausgetauscht, wobei diese Textänderung auf der öffentlichen Gästebuchseite für Dritte nicht erkennbar war. In einem von einem Dritten veröffentlichten Text ohne jeden Hinweis Textteile auszutauschen, und seien es auch nur ungehörige Textteile wie Kraftausdrücke o.ä., ist aus meiner Sicht nicht akzeptabel. Daher wurde die Badword-Filterung wieder dahingehend geändert, dass von Ihnen in der Datenbank eingetragene unerwünschte Wörter/Begriffe deutlich erkennbar erneut durch Sterne (***) ersetzt werden.</p>
			<p><strong><span class="red">TIPP:</span></strong> Setzen Sie die Möglichkeiten dieses Filters gut überlegt ein! Der Filter erkennt eingegebene Begriffe auch dann, wenn diese nur Teil eines Wortes sind und filtert sie aus.</p>
			<p>Wenn Sie also z.B. aus verständlichen Gründen nicht möchten, dass in einem Beitrag auf Ihrer Seite plötzlich das Wort &quot;Scheisse&quot; auftaucht, reicht es aus, wenn Sie als Badword in die Liste &quot;scheiss&quot; eintragen; der Filter macht dann aus &quot;Scheisse&quot; ein &quot;***e&quot;. - Tragen Sie aber z.B. &quot;arsch&quot; in die Badword-Liste ein, wird der Filter damit u.a. auch z.B. aus den Wörtern &quot;Wasser marsch&quot; ein &quot;Wasser m***&quot; machen.</p>
			<a id="anchor-ShowBadw" name="anchor-ShowBadw"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.6.1. Badwords anzeigen und löschen</strong></p>
			<p>Alle unerwünschte Worte (Badwords) sehen Sie hier. Falls Sie Badwords löschen möchten, dann markieren Sie die zu löschenden und klicken auf „markierte löschen“.</p>
			<a id="anchor-PlusBadw" name="anchor-PlusBadw"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.6.2. Badwords hinzufügen</strong></p>
			<p>Um Wörter zu ersetzen, müssen Sie natürlich zuerst in der Datenbank gespeichert werden.</p>
			<p><strong><span class="red">TIPP:</span></strong> Achten Sie darauf, dass das Wort mindestens aus 3 Zeichen besteht, sonst kann es zu leicht passieren, dass Buchstabenfolgen innerhalb von normalen Wörtern ersetzt werden.</p>
			<a id="anchor-Spamfilter" name="anchor-Spamfilter"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.7. Spamfilter</strong></p>
			<p>Der Spamschutz in den v.3.x, der das unsägliche Captcha ersetzte, stützte sich ausschliesslich auf die Überwachung eines Kontroll-Merkmals und war damit recht erfolgreich.</p>
			<p>Aber ich hatte auch Meldungen von Nutzern, wo er eben nicht gereicht hat und teilweise täglich mehrere Spameinträge eingingen.</p>
			<p>Der neue Spamschutz verarbeitet sowohl die bisherige, erfolgreiche Methode wie auch eine Reihe weiterer Prüfungen, von denen die Prüfung auf kritische Schlüsselwörter, von mir als &quot;Spamwörter&quot; bezeichnet, wiederum nur ein Aspekt ist. So kann der Filter bei Bedarf zukünftig leicht ausgebaut werden.</p>
			<p>Wer an den Einzelheiten interessiert ist, mag sich den Quellcode der entsprechenden Datei anschauen, für den "normalen" User ist hierbei m.E. folgendes zum besseren Handling wichtig zu wissen:</p>
			<p>Der Spamfilter arbeitet mit einem System von &quot;Strafpunkten&quot;. D.h. er erfasst bestimmte typische Merkmale für Spam und vergibt dann dafür Punkte.</p>
			<p>So wird z.B. jeder Eintrag beim Klick auf den Speichern-Button nach Spamwörtern aus der Liste durchsucht und bei jeder Übereinstimmung wird jedes erkannte Spamwort mit je einem Strafpunkt gewertet. Auch die in einem Beitrag enthaltenen Links werden gezählt und beim Überschreiten einer (in den Konfigurationseinstellungen einstellbaren) Höchstgrenze mit je einem (weiteren) Strafpunkt belegt.</p>
			<p>Diese und eine Reihe weiterer Prüfungen vollzieht der Spamfilter automatisch, wobei manche Spammerkmale, wie z.B. der bisherige Spamschutz, dabei auf einen Schlag mit 5 Punkten belegt werden, andere eben nur mit 1 Punkt, je nach Erheblichkeit. (So ist z.B. nicht jeder Beitrag, in dem das Wort &quot;Viagra&quot; vorkommt, immer Spam.)</p>
			<p>Alle Strafpunkte werden vom Programm addiert. Wenn nun die Summe der Strafpunkte bestimmte Grenzen übersteigt, wird unterschieden:</p>
			<ul>
				<li>Beim Überschreiten der Höchstgrenze wird der Beitrag sofort verworfen, also gar nicht erst gespeichert. Die IP des Absenders wird gespeichert und für einen sofortigen erneuten Aufruf der Eintragsseite gesperrt. Es geht eine E-Mail an den Admin, in der neben dem verworfenen Eintrag die Anzahl der vom Programm ermittelten &quot;Strafpunkte&quot; und die Kriterien, aus denen die einzelnen &quot;Strafpunkte&quot; gebildet wurden, mitgeteilt werden.
				<li>Wenn das Programm zwar &quot;Strafpunkte&quot; durch Spam-verdächtige Inhalte ermittelt, diese aber in der Summe nicht die kritische Höchstgrenze erreichen, wird der Beitrag in der Datenbank gespeichert, aber als &quot;Deaktiviert&quot; markiert. D.h., der Beitrag ist zwar vorhanden, aber zunächst im öffentlichen Bereich nicht sichtbar. Es geht erneut eine E-Mail an den Admin mit dem Inhalt des Beitrags, den ermittelten &quot;Strafpunkten&quot; und deren Ursache(n), sowie einem Link zur eventuellen Freischaltung des gesperrten Beitrags per E-Mail.
				<li>Werden keinerlei Spammerkmale festgestellt, bleibt alles wie gehabt: der Beitrag wird normal gespeichert und ist –je nach Einstellung in der Konfigurationsdatei- entweder sofort freigegen oder auch zunächst gesperrt, ganz nach Ihren Vorgaben. Wie üblich geht auch in diesem Fall eine E-Mail mit dem Inhalt des Beitrags an den Admin (es sei denn, Sie haben diese Funktion ausdrücklich abgeschaltet), die jedoch vorsorglich auch einen Link zur &quot;Fernsperre&quot; des veröffentlichten Beitrags per E-Mail hat.
				<li>Die oben angesprochene &quot;Höchstgrenze&quot; an zulässigen &quot;Strafpunkten&quot;, die nicht überschritten werden darf, kann in den Konfigurationseinstellungen des Admin-Panels im Bereich zwischen &quot;1&quot; als Mindestwert und &quot;20&quot; als Höchstwert von Ihnen selbst festgelegt werden. – Nach der Installation ist die Voreinstellung zunächst &quot;5&quot;.
				<li>Die ebenfalls erwähnte &quot;Höchstgrenze&quot; an unverdächtigen Links in einem Beitrag kann genauso in den Konfigurationseinstellungen des Admin-Bereichs im Bereich zwischen &quot;0&quot; (=jeder Link ist verdächtig) und maximal &quot;20&quot; von Ihnen bestimmt werden. – Nach der Installation ist die Voreinstellung zunächst &quot;2&quot;. Die Linkprüfung lässt die in der entsprechenden Spalte eingegebene Homepage des Besuchers unberücksichtigt und prüft nur Eingaben im Textfeld; hierbei erkennt und zählt sie Links sowohl in der Form: &quot;http://www.example.org&quot; wie auch in: &quot;www.example.org&quot; oder in: &quot;http://example.org&quot; und schliesslich in &quot;[url=http:// www.example.org]LINK[/url]&quot;. 
				<li>Die Prüfung eines Eintrags auf Spamwörter und die Prüfung der Anzahl im Textbeitrag eingestellter Links können in den Konfigurationseinstellungen vollständig abgeschaltet werden.
			</ul>
			<ul>
				<li><strong>Hinweis:</strong> Der komplette Spamschutz ist grundsätzlich nicht dafür vorgesehen, deaktiviert zu werden. Ausnahmsweise ist dies im Einzelfall dennoch möglich. Für Einzelheiten hierzu siehe oben <a href="#anchor-MoreKonfig">Abschnitt IV. 3.2.5, "Weitere Konfigurationsmöglichkeiten"</a>.
			</ul>
			<a id="anchor-ShowSpamWo" name="anchor-ShowSpamWo"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.7.1 Spamwords anzeigen und löschen</strong></p>
			<p>Spam-typische Wörter oder auch Wortgruppen werden hier angezeigt und können genauso durch markieren wieder gelöscht werden.</p>
			<p>Wenn alle Spamwörter in der Liste gelöscht werden, wird die Funktion &quot;Eintrag auf Spamwörter prüfen&quot; in den Konfigurationseinstellungen automatisch deaktiviert. Werden dann zu einem späteren Zeitpunkt wieder ein oder mehrere Spamwörter in die Liste eingetragen, bitte nicht vergessen, die Spamwort-Prüfung in den Konfigurationseinstellungen wieder zu aktivieren. Eine entsprechende Warnung wird auf der Seite mit den Spamwörtern angezeigt.</p>
			<a id="anchor-PlusSpamWo" name="anchor-PlusSpamWo"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.7.2 Spamwords hinzufügen</strong></p>
			<p>Hat es doch mal ein Spambot geschafft, alle Prüfungen des Spamfilters zu überwinden und seinen sinnlosen Wortmüll in Ihr Gästebuch zu schmuggeln, schauen Sie sich sorgfältig den Text an.</p>
			<p>Sie werden in der Regel einige Begriffe finden, die sich mehrfach wiederholen und die in &quot;normalen&quot; Texten von &quot;echten&quot; Gästebuchschreibern entweder gar nicht oder allenfalls vereinzelt vorkommen. Speichern Sie dieses Wort oder auch eine Wortgruppe hier in der Datenbank zu zukünftigen Kontrolle durch den Filter.</p>
			<p><strong><span class="red">TIPP:</span></strong> Groß- und Kleinschreibung sind für die Prüfung eines Beitrags auf Spamwörter dann gleichgültig, wenn das Schlüsselwort in der entsprechenden &quot;Spamwort-Liste&quot; kleingeschrieben gespeichert wird; wird es dort großgeschrieben eingetragen, wird es im zu überprüfenden Text nicht als Übereinstimmung gefunden werden. <strong>Also stets alles kleingeschrieben in der Spamwort-Liste abspeichern.</strong></p>
			<p>Ausserdem wird ein &quot;normal&quot; in die Liste eingetragenes Spamwort im Beitrag eines Gastes ebenso erkannt, wenn es nur ein Teil eines Wortes ist. Wenn also z.B. &quot;sex&quot; als Schlüsselwort in der Spamwortliste vorhanden ist, erkennt das Programm im Text:</p>
			<p class="zentriert italic">&quot;Der Peter wurde ausgezeichnet als sexiest man alive,<br />dabei ist er genauso sexy wie Rumpelstilzchen und Sex hatte er noch nie.&quot;</p>
			<p>... drei Spammerkmale und vergibt drei Punkte, egal ob &quot;sex&quot; im Text groß- oder kleingeschrieben und einmal nur als Teil eines Wortes bzw. mit angehängtem &quot;y&quot;. Wer das im Einzelfall verhindern möchte, trägt das Schlüsselwort in die Liste jeweils mit einem Leerzeichen davor und dahinter ein, also (natürlich ohne die Anführungszeichen): &quot; sex &quot;. Dann wird auch nur exakt danach gesucht.</p>
			<p>Aber Obacht, wie beim "Badword-Filter" gilt auch hier: Erst denken, dann handeln. Wird ein Schlüsselwort mit einem Leerzeichen davor und dahinter in die Spamwortliste aufgenommen, wird es vom Programm nicht erkannt werden, wenn es am Satzanfang (kein Leerzeichen davor) oder am Satzende (kein Leerzeichen danach) eingesetzt ist.</p> 
			<p><strong><span class="red">TIPP:</span></strong> Ein Spamword kann in die entsprechende Liste mehrfach eingetragen und dadurch entsprechend höher gewichtet werden, weil es bei mehrfachem Eintrag ebenso oft als Spammerkmal gezählt wird.</p>
			<p>Beispiel: Wird das Wort &quot;sex&quot; zweimal in der Spamwortliste abgespeichert und ein Gästebuch-Eintrag enthält einmal das Wort &quot;Sex&quot;, werden dennoch sofort zwei &quot;Strafpunkte&quot; erfasst.</p>
			<a id="anchor-ShowIpBar" name="anchor-ShowIpBar"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.7.3 IP-Sperren nach Spameinträgen</strong></p>
			<p>Wie oben schon vermerkt, werden die IPs, unter denen eine Spammer Ihr Gästebuch aufgesucht hat, in dieser Liste automatisch gespeichert, wenn der Spambeitrag derart dumm-dreist war, dass er vom Spamfilter sofort verworfen und eine Speicherung verhindert wurde. Alle hier erfassten Ips sind sodann gehindert, die Eintragseite erneut aufzurufen.</p>
			<p>Die Spambots arbeiten jedoch meist mit dynamischen, d.h. wechselnden IPs. Die Sperre wirkt also nur eine begrenzte Zeit, bis der Robot über eine andere IP wiederkommt, weshalb es i.d.R keinen Sinn macht, die gesperrten IPs dauerhaft zu speichern, zumal mit einer zu langen Liste irgendwann die Performance leiden würde.</p>
			<p>Daher werden die IPs in der Sperrliste nach 7 Tagen automatisch mit dem nächsten Aufruf der &quot;insert.php&quot; gelöscht. In den Versionen &lt; 4.3.2 erfolgte diese Überwachung und Bereinigung der Datenbanktabelle mit den gesperrten IPs noch beim Einloggen in den Admin-Bereich. Da es aber User geben soll, die sich nur alle paar Monate einmal dort einloggen, was dazu führen kann, dass die IP-Sperrliste je nach Spam-Aktivitäten mehr oder weniger gewaltige Dimensionen annimmt, wurde diese Kontrolle mit v.4.3.2 in die &quot;insert.php&quot; verlegt.</p>
			<p>Falls eine IP aus irgendwelchen Gründen länger gespeichert bleiben soll, ist dies möglich durch Anklicken des grünen Hakens hinter der betroffenen IP; der Haken wandelt sich dann als Zeichen der dauerhaften Sperre in ein rotes Kreuz. Erneutes Anklicken macht den Vorgang rückgängig.</p>
			<p>Selbstverständlich können Sie eine gesperrte IP aus der Liste auch durch markieren manuell wieder löschen.</p>
			<a id="anchor-Backup" name="anchor-Backup"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.8. Backup</strong></p>
			<p>Wer will schon gerne seine ganzen Gästebucheinträge durch einen Server Crash o.ä. verlieren?</p>
			<p>Um sich hiervor zu schützen, können Sie über diese Funktion BackUps erstellen sowie beschädigte oder gelöschte Beiträge aus einem solchen BackUp wieder herstellen.</p>
			<p><strong><span class="red">TIPP:</span> Es empfiehlt sich grundsätzlich, nach jedem neuen Eintrag im Gästebuch ein aktuelles BackUp anzufertigen.</strong></p>
			<p><strong>Wenn Sie die BackUps auf dem Server verwalten, also die Funktion: "BackUp nach dem Versand per E-Mail wieder vom Server löschen?" <span class="italic">nicht</span> aktiviert haben, wird Ihnen auf der zentralen Seite zur Verwaltung der "Einträge und Kommentare" eingangs ein Warnhinweis in Form des Icos: <img src="'.$url.'images/ausruf.png" height="14" width="14" alt="" /> angezeigt, falls das letzte BackUp älter ist als der letzte Gästebucheintrag. Klicken Sie einfach auf dieses Ico, um ein aktuelles BackUp zu erstellen.</strong></p>
			<p>Seit der v.4.5.4 wird mit der BackUp-Funktion des <span class="italic">myPHP Guestbook</span> neben dem Inhalt der Tabelle &quot;entries&quot; mit den Gästebucheinträgen auch der Inhalt der Tabelle &quot;pictures&quot; mit Dateinamen, Bildgrössen, Title-Bezeichnungen etc. von Fotouploads gesichert und im Bedarfsfall wieder hergestellt.</p>
			<p><strong>HINWEIS:</strong> Die in den Ordner &quot;img_guest&quot; hochgeladenen Dateien selbst können und werden auf diesem Weg selbstverständlich <strong>NICHT</strong> gesichert! Die in diesem Ordner abgelegten Fotos sollten in regelmässigen Abständen per FTP heruntergeladen und zur Sicherheit noch einmal auf dem eigenen PC gespeichert werden.</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Es kann generell zu Fehlern kommen, wenn eine Wiederherstellung aus einem BackUp erfolgen soll, das nicht mit der gleichen Gästebuch-Version erstellt wurde. Eine volle Kompabilität ist jedoch in der Regel gegeben zwischen den BackUps ab Version 3.0.0 bis Version 4.5.3, dann wieder ab Version 4.5.4 bis Version 4.5.6 und schliesslich ab Version 4.6.0 aufwärts.</p>
			<p>Es wird zu Fehlern kommen, wenn Sie ein Backup unter einer Version &lt; 3.x erstellt haben und in einer Version &#8805; 3.x hieraus Beiträge ohne weitere Bearbeitung wieder herstellen möchten. In der Regel werden diese Probleme durch die Verwendung eines anderen Prefix verursacht: Bis v.2.0.5 wurde standardmässig der Prefix "myphpgb" verwendet, ab Version 3.0.0 lautet der Prefix &quot;guestbook&quot;. Um dies zu lösen, können Sie entweder in Ihrer Backup-Datei mit einem guten Texteditor das Prefix entsprechend ändern, oder Sie laden sich einfach das Tool &quot;<span class="italic">myPHP Guestbook BackUp Converter</span>&quot; von <a href="https://www.php-guestbook.de" title="Link öffnet ein neues Fenster" rel="external">www.php-guestbook.de</a> herunter, um alte Backups auf die neuen Versionen des Gästebuch-Scripts umzuschreiben und anschliessend zur Wiederherstellung von Einträgen zu nutzen.</p>
			<p>Ab der Version 3.x wurden erstellte Backups mit dem Ausloggen aus dem Admin-Bereich automatisch wieder vom Server gelöscht, so dass das zuvor gefertigte Backup jeweils auf den eigenen Computer heruntergeladen und bei Bedarf von dort wieder hochgeladen werden musste. Eine der Folgen war, dass eine Verwaltung mit mobilen Endgeräten praktisch nicht möglich war.</p>
			<p>Seit Version 4.1 ist das wie folgt gelöst: Backup-Dateien bleiben jetzt im entsprechenden Backup-Ordner auf dem Server liegen, gegen unberechtigten Download oder unerwünschte Einsichtnahme geschützt mit einer entsprechenden htaccess-Datei (ist im Paket enthalten).</p>
			<p>BackUps bleiben bis zu einer Anzahl von 3 Stück bestehen, die älteren, über dieses Limit hinausgehenden BackUps werden automatisch gelöscht.</p>
			<p>Zur Wiederherstellung beschädigter oder verlorener Einträge im Gästebuch kann dann die gewünschte BackUp-Datei durch einen Klick bestimmt und direkt vom Server genutzt werden, was letztlich beinhaltet, dass dies auch von unterwegs geht und nicht nur Zuhause am heimischen Rechner. Als weitere Sicherheit wird zusätzlich eine Kopie des BackUps an den Admin per E-Mail verschickt.</p>
			<p>Die BackUps werden automatisch gezippt (wichtig besonders wegen dem E-Mail-Versand), Wiederherstellungen können unmittelbar aus der gezippten Datei erfolgen. Falls bei Ihrem Webspace das gzip-Modul nicht verfügbar sein sollte, (was gleichfalls automatisch geprüft wird), erstellt und verarbeitet das Programm jedoch auch ungezippte Versionen.</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Wenn Ihr Website-Hoster die Nutzung von .htaccess-Dateien nicht zulassen sollte, so dass die auf dem Server liegenden BackUp-Dateien nicht vor dem Zugriff Dritter geschützt werden können, ist es möglich und wird für diesen Fall auch dringend empfohlen, die Speicherung der BackUps auf dem Server durch eine entsprechende Einstellung auf der Seite &quot;Allgemeine Konfiguration&quot; zu unterbinden; dann muss auf die per E-Mail verschickten BackUps im Notfall zurückgegriffen werden (und Sie sollten den Website-Hoster wechseln). - Die Voreinstellung nach der Installation dieser Version ist zunächst auf: &quot;BackUps auf dem Server speichern&quot;.</p>
			<a id="anchor-BackUpEdit" name="anchor-BackUpEdit"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.8.1. BackUps verwalten und Einträge wiederherstellen</strong></p>
			<p>Das Wiederherstellen von Beiträgen aus einem von Ihnen hergestellten Backups geht kinderleicht:</p>
			<p>Wählen Sie aus der Backup-Liste das gewünschte Backup aus (sortiert nach Datum und Zeit) und klicken Sie auf den Button &quot;Wiederherstellen&quot;. <span class="italic">myPHP Guestbook</span> fügt dann die alten Gästebucheinträge und die alten Einträge aus der Tabelle &quot;_pictures&quot; wieder in die Datenbank ein.</p>
			<p>Falls Sie einmal eine ältere Ausfertigung eines BackUps nutzen wollen, können Sie diese per FTP in den Backup-Ordner auf dem Server hochladen, den Dateinamen im entsprechenden Eingabefeld einfügen und in die Backup-Liste abspeichern, um die Datei dann aufzurufen und zu verwenden.</p>
			<p class="zentriert"><strong>Achtung!</strong></p>
			<p>Alle im Zeitpunkt einer Wiederherstellung aus einem BackUp vorhandenen Einträge in den Tabellen &quot;_entries&quot; und &quot;_pictures&quot; werden gelöscht und mit den Daten aus der BackUp-Datei neu befüllt. Sollte das zur Wiederherstellung verwendete BackUp jedoch aus einer der vorherigen Gästebuch-Versionen &lt; 4.5.4 stammen, bleibt der Inhalt der Tabelle &quot;_pictures&quot; unverändert, wird also auch nicht gelöscht, da in den älteren BackUp-Dateien nichts ist, womit die Tabelle &quot;_pictures&quot; wieder befüllt werden könnte. Sie sollten also nach einem Update von einer Gästebuchversion &lt; 4.5.4 auf die Version 4.5.4 (oder höher) sofort ein neues BackUp erstellen, damit auch eine Sicherungsdatei der Tabelle &quot;_pictures&quot; vorhanden ist und notfalls verwendet werden kann.</p>
			<a id="anchor-MakeBackUp" name="anchor-MakeBackUp"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.8.2. Backup erstellen</strong></p>
			<p>Um eine aktuelle Sicherung der Datenbank-Tabellen mit Ihren Gästebucheinträgen und den Inhalten der Tabelle &quot;_pictures&quot; zu erstellen, müssen Sie nur diese Option aufrufen.</p>
			<p>Das Backup wird auf dem Sever gespeichert und eine gezippte Kopie wird Ihnen zusätzlich per E-Mail übermittelt, wie eingangs beschrieben.</p>
			<a id="anchor-Statistik" name="anchor-Statistik"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.9. Statistik</strong></p>
			<p>Damit Sie einen Überblick haben, wie häufig Ihr Gästebuch aufgerufen wurde, ist eine kleine Statistik in <span class="italic">myPHP Guestbook</span> eingebaut.</p>
			<p>Diese funktioniert wie viele andere Features nur, wenn Sie die Statistik unter "Allgemeine Konfiguration" aktiviert haben.</p>
			<a id="anchor-ShowStats" name="anchor-ShowStats"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.9.1. Statistik anzeigen</strong></p>
			<p>Hier sehen Sie die Anzahl der gesamten Besucher sowie der gesamten Aufrufe des Gästebuches. Weiter unten gibt es eine kleine genauere Statistik der letzten 15 Tage.</p>
			<a id="anchor-DelStats" name="anchor-DelStats"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.9.2. Statistik löschen</strong></p>
			<p>Ältere Einträge als die der letzten 15 Tage werden automatisch in der Datenbank gelöscht. Die Anzeige der Summen von Aufrufen und Besuchern bleibt davon unberührt.</p>
			<p>Wenn Sie jedoch auf den Link: &quot;Statistik löschen&quot; klicken, werden nicht nur die Statistik der letzten 15 Tage unwiderruflich gelöscht, sondern auch die Summen werden wieder auf Null gesetzt.</p>
			<a id="anchor-Hilfe" name="anchor-Hilfe"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.10. Hilfe</strong></p>
			<p>Diese Seite.</p>
			<a id="anchor-Logout" name="anchor-Logout"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3.11. Logout</strong></p>
			<p>Nach Abschluss der Arbeiten im Admin-Bereich das Ausloggen nicht vergessen.</p>
			<p>Nach spätestens 30 Minuten Inaktivität im Admin-Control-Panel wird aus Sicherheitsgründen die Session für den Aufenthalt im Admin-Bereich zerstört, was einem "Zwangs-Logout" gleichkommt.</p>
			<a id="anchor-Repair" name="anchor-Repair"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />4. Diagnose- und Reparatur-Tool:<br />(Datenbanktabellen oder Konfigurationsdatei wiederherstellen)</strong></p>
			<p>Es kommt immer mal wieder vor, dass einzelne Datenbanktabellen verändert wurden, z.B. indem vorinstallierte Templates oder CSS-Styles irrtümlich gelöscht oder vom User verändert wurden o.ä. und später der Wunsch entsteht, diese wieder in den Original-Zustand zurückzuversetzen.</p>
			<p>Um eine komplette Neuinstallation entbehrlich zu machen, kann für diese Fälle unter <a href="https://www.php-guestbook.de/repair.php" title="Link öffnet ein neues Fenster" rel="external">www.php-guestbook.de/repair.php</a> ein "Reparatur-Tool" heruntergeladen werden. Damit ist es problemlos möglich, gezielt ausgewählte, beliebige Datenbank-Tabellen des <span class="italic">myPHP Guestbook</span> wieder in den Zustand und mit den Inhalten wie nach der Installation herzustellen.</p>
			<p>Weiterhin kann mit diesem Tool auch die Konfigurations-Datei ("config.inc.php") neu geschrieben werden oder es können Verbindungsprobleme zur Datenbank untersucht werden.</p>
			<a id="anchor-lang" name="anchor-lang"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>';
			echo'
			<h2><br />V. Sonstiges</h2>
			<p class="text-shadow"><strong><br />1.Sprachen:</strong></p>
			<p>Damit <span class="italic">myPHP Guestbook</span> nicht nur auf deutschsprachigen Webseiten zum Einsatz kommt, wurden ab Version 2.0.0 Sprachdateien eingebaut.</p>
			<p>Die Unterschiede in den Sprachdateien &quot;de.php&quot;, &quot;at.php&quot; und &quot;ch.php&quot; (zu finden im Ordner /lang/) liegen nur in den eingebunden Landesflaggen.</p>
			<p>Ich bin stets auf der Suche nach Übersetzern, um <span class="italic">myPHP Guestbook</span> in weitere Sprachen zu übersetzen. Wer Lust, Zeit und entsprechende Fremdsprachenkenntnisse hat, bitte bei mir melden: <a href="mailto:post@php-guestbook.de">post@php-guestbook.de</a>.</p>
			<a id="anchor-Credits" name="anchor-Credits"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />2. Credits</strong></p>
			<p>Nachfolgend -soweit bekannt- einige Personen, die bei der Entwicklung von <span class="italic">myPHP Guestbook</span> eine grössere Rolle gespielt haben.</p>
			<p class="text-shadow"><strong><br />2.1 Hauptentwickler</strong></p>
			<p>Claudio Pose (Schweiz) - Der wesentliche Quellcode von <span class="italic">myPHP Guestbook</span> wurde von Claudio Pose geschrieben.</p>
			<p>Einzelne Teile des Codes wurden von anderen Projekten eingebaut, welche aber im Vergleich zum ganzen Script eine untergeordnete Rolle spielen.</p>
			<p>Da Claudio Pose ca. in 2006 den Support und die Webseite eingestellt hat, das <span class="italic">myPHP Guestbook</span> jedoch sehr beliebt ist und daher weiterentwickelt werden sollte, wurde von Christian Thomas, www.hostonline.de, auf Basis der letzten Version 2.0.5 die Version 3.0.0 geschaffen.</p>
			<p>2012 wurde dort die Version 3.2.0, Ende Oktober 2014 die Version 3.2.1 zum Download bereitgestellt, danach gab Herr Christian Thomas die Weiterentwicklung des Scripts zugunsten der vorliegenden Versionen 4.x auf.</p>
			<p>Spätestens mit der Einstellung der Bereitstellung von Bugfixes für PHP 5.3 im August 2014 und der gleichzeitigen Bereitstellung von PHP 5.6 wurde es notwendig, den erneut in die Jahre gekommenen PHP-Code für das Handling der Datenbankanbindung umfassend zu überarbeiten.</p>
			<p>Hierzu wurde die im Dezember 2012 von Christian Thomas erstellte Version 3.2.0 bei erneut teilweiser Verwendung des Originalcodes, jedoch mit Umstellung der Datenbankanbindung auf MySqli von Wolfgang Leverberg <a href="https://www.php-guestbook.de" title="Link öffnet ein neues Fenster" rel="external">www.php-guestbook.de</a> umgeschrieben und ab 03.10.2014 zum Download eingestellt.</p>
			<p class="text-shadow"><strong><br />2.2. Übersetzer</strong></p>
			<ul>
				<li>portugiesisch:
				<ul>
					<li>Harry Tartsch (Deutschland) (Sprach-File, ReadMe und "Hilfe"-Datei)
					<li style="list-style-type:none">tartsch@arcor.de
					<li>Christoph Schnell (Mozambique) (Sprach-File)
					<li style="list-style-type:none">cwschnell@gmail.com
				</ul>
			</ul>
			<p class="text-shadow"><strong><br />2.3. Sonstige Entwickler oder Mithelfer</strong></p>
			<p>Egal ob Programmierer, Bug-Reporter oder Grafiker, bei der Erstellung von <span class="italic">myPHP Guestbook</span> haben viele weitere Personen mitgeholfen, wie z.B.:</p>
			<ul>
				<li>David Vignoni (Italien)
				<li style="list-style-type:none">dave@icon-king.com
			</ul>
			<ul>
				<li>Turthra Leinir (Dänemark)
				<li style="list-style-type:none">leinir2002@hotmail.com
			</ul>
			<ul>
				<li>Felix Maduakor (Deutschland)
				<li style="list-style-type:none">felix.maduakor@rub.de
			</ul>
			<hr style="width:75%;" />
			<p>Teile der Datei-Upload Funktionen stammen mit freundlicher Genehmigung von:</p>
			<ul>
				<li>ISP Image Upload und Resize PHP Programm
				<li style="list-style-type:none">© Joachim Patten (ISP), 2013
				<li style="list-style-type:none">isp_image_resize Ver.1.5 : Version vom 08.02.2013
				<li style="list-style-type:none">Copyright Joachim Patten (ISP)
				<li style="list-style-type:none">URL: &lt;www.neusser-marktplatz.de&gt;
			</ul>
			<hr style="width:75%;" />
			<p>Teile des Spamfilters stammen von:</p>
			<ul>
				<li>&lt;www.naturfotografie-digital.de/impressum/impressum.php&gt;
			</ul>
			<hr style="width:75%;" />
			<p>Die Funktion &quot;shortWords&quot; (Originalbezeichnung &quot;MakeBreakable&quot;) stammt von:</p>
			<ul>
				<li>Herrn Werner Rumpeltesz, &lt;www.gaijin.at&gt;
				<li style="list-style-type:none">angepasst/geändert für die Nutzung unter den Anforderungen des <span class="italic">myPHP Guestbook</span>
			</ul>
			<a id="anchor-Copyright" name="anchor-Copyright"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />3. Copyright, Lizenz</strong></p>
			<ul>
				<li><span class="italic">myPHP Guestbook</span> v. 2.0.5 Copyright © 2003 - 2006 Claudio Pose,
				<li style="list-style-type:none"><span class="italic">myPHP Guestbook</span> v. 2.0.5 was an open source project of Networkarea.ch
				<li>Version 3.2.1 Copyright © 2011 - 2014
				<li style="list-style-type:none">Christian Thomas, &lt;www.hostonline.de&gt;
				<li><span class="italic">myPHP Guestbook</span> v. '.$version.' (MySQLi) Copyright © 2014 - 2016
				<li style="list-style-type:none">Wolfgang Leverberg, <a href="https://www.php-guestbook.de" title="Link öffnet ein neues Fenster" rel="external">www.php-guestbook.de</a>
			</ul>
			<p><span class="italic">myPHP Guestbook</span> is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.</p>
			<p><span class="italic">myPHP Guestbook</span> is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.</p>
			<p>You should have received a copy of the GNU General Public License along with this program. - If not, see &lt;www.gnu.org/licenses&gt;</p>
			<hr style="width:75%;" />
			<p><span class="italic">myPHP Guestbook</span> ist freie Software; Sie können es unter den Bedingungen der GNU General Public License, wie von der Free Software Foundation veröffentlicht, Version 3 der Lizenz oder (nach Ihrer Wahl) jeder neüren veröffentlichten Version, weiterverbreiten und/oder modifizieren.</p>
			<p><span class="italic">myPHP Guestbook</span> wird in der Hoffnung, dass es nützlich sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; auch ohne die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR EINEN BESTIMMTEN ZWECK. Siehe die GNU General Public License für weitere Details.</p>
			<p>Sie sollten eine Kopie der GNU General Public License zusammen mit myPHP Guestbook erhalten. - Wenn nicht, siehe &lt;www.gnu.org/licenses&gt;.</p>
			<a id="anchor-History" name="anchor-History"></a><div class="top"><a href="#anchor-top" title="Zum Inhaltsverzeichnis">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />4. Version History</strong></p>
			<ul>
				<li>1.0.6 Final 13.03.2004&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Claudio Pose
				<li>1.1.0 Final 17.03.2004
				<li>1.2.0 Final 25.03.2004
				<li>1.3.3 Final 07.04.2004
				<li>1.4.2 Final 14.04.2004
				<li>1.5.1 Final 06.05.2004
				<li>1.6.2 Final 10.06.2004
				<li>1.7.1 Final 02.08.2004
				<li>1.8.3 Final 20.08.2004
				<li>1.9.1 Final 18.09.2004
				<li>1.9.2 Final 16.10.2004
				<li>2.0.0 Final 06.04.2005
				<li>2.0.1 Final 10.04.2006
				<li>2.0.2 Final 29.04.2006
				<li>2.0.3 Final 06.05.2006
				<li>2.0.4 Final 06.05.2006
				<li>2.0.5 Final 30.06.2006
				<li>3.0.0 Final 24.09.2011&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Christian Thomas
				<li>3.0.1 Final 12.02.2012
				<li>3.1.0 Final 15.04.2012
				<li>3.2.0 Final 21.12.2012
				<li>3.2.1 Final 25.10.2014
				<li>4.0.0 Final 10.03.2014&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wolfgang Leverberg
				<li>4.1.0 Final 01.04.2014
				<li>4.2.0 MySQLi Final 03.10.2014
				<li>4.2.1 MySQLi Final 28.10.2014
				<li>4.2.2 MySQLi Final 02.11.2014
				<li>4.2.3 MySQLi Final 16.11.2014
				<li>4.3.0 MySQLi Final 28.11.2014
				<li>4.3.1 MySQLi Final 13.12.2014
				<li>4.3.2 MySQLi Final 02.01.2015
				<li>4.4.0 MySQLi Final 21.02.2015
				<li>4.4.1 MySQLi Final 07.03.2015
				<li>4.4.2 MySQLi Final 20.03.2015
				<li>4.5.0 MySQLi Final 01.05.2015
				<li>4.5.1 MySQLi Final 20.06.2015
				<li>4.5.2 MySQLi Final 26.06.2015
				<li>4.5.3 MySQLi Final 18.07.2015
				<li>4.5.4 MySQLi Final 04.09.2015
				<li>4.5.5 MySQLi Final 03.10.2015
				<li>4.5.6 MySQLi Final 02.01.2016
				<li>4.6.0 MySQLi Final 06.02.2016
				<li>4.6.1 MySQLi Final 01.05.2016
				<li>4.6.2 MySQLi Final 03.07.2016
				<li>4.6.3 MySQLi Final 08.10.2016
			</ul>
			<a id="anchor-Kontakt" name="anchor-Kontakt"></a><div class="top"><a href="#anchor-pagetop" title="Zum Seitenanfang">&Lambda;</a></div>
			<p class="text-shadow"><strong><br />5. Kontakt</strong></p>
			<p><span class="italic">myPHP Guestbook</span> war ein Projekt von Claudio Pose - Networkarea.ch.</p>
			<p>Die Versionen 3.x wurden entwickelt von Christian Thomas, Kuhstr.8, 45701 Herten-Westerholt - www.hostonline.de - admin@westerhost.de.</p>
			<p>Die Versionen 4.x (MySQLi) wurden geschrieben von Wolfgang Leverberg, Martin-Luther-Str. 46, 42853 Remscheid<br /><a href="https://www.php-guestbook.de" title="Link öffnet ein neues Fenster" rel="external">www.php-guestbook.de</a> - <a href="mailto:post@php-guestbook.de">post@php-guestbook.de</a></p>
			<p>&nbsp;</p>
			<p class="italic">Remscheid, im Oktober 2016</p>';
	}
    
?>


