<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    02.01.2015
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
        if ($_GET['show'] == "edit_smilies") {
            if (isset($_POST['send'])) {
                $error_msg = "";

                if ($_POST['name'] == "" OR $_POST['bbcode'] == "") {
                    $error_msg .= "<strong>- ".$fmsg[50]."</strong><br />";
                }

                if (!$error_msg == "") {
                    echo $error_msg;
                } else {
                    $sql_update_smiley = $gbook->query("UPDATE ".$table."_smilies SET bbcode='".$_POST['bbcode']."', name='".$_POST['name']."' WHERE id='".$_POST['id']."'");

                    if ($sql_update_smiley) {
                        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=smilies&#38;show=view_smilies&#38;".session_name()."=".session_id()."\" />";
                    }
                }
            }

            $sql_select_smiley = $gbook->query("SELECT bbcode, height, name, width FROM ".$table."_smilies WHERE id='".$_REQUEST['id']."'");

            $select_smiley = $sql_select_smiley->fetch_assoc();

            echo "
			<fieldset>
			<legend><strong>Smilie-edit hardcoded in smilies.php</strong></legend>
			<form method=\"post\" action=\"".$url."admin/admin.php?action=smilies&#38;show=edit_smilies&#38;".session_name()."=".session_id()."\">
			<table style=\"width:350px\" class=\"guestbook_table2 tableCenter\">
			<tr>
			<td align=\"left\"><br />".$fmsg[7]."</td>
			<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"name\" value=\"".$select_smiley['name']."\" /></td>
			</tr>
			<tr>
			<td align=\"left\"><br />BBCode:</td>
			<td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"bbcode\" value=\"".$select_smiley['bbcode']."\" /></td>
			</tr>
			<tr>
			<td align=\"center\" colspan=\"2\"><br /><p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[55]."\" /></p><br /><p><input type=\"button\" class=\"button\" title=\"".$fmsg[4]."\" name=\"abbruch\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='admin.php?action=smilies&#38;show=view_smilies&#38;".session_name()."=".session_id()."'\" /></p>
			<input type=\"hidden\" name=\"id\" value=\"";

            if (isset($_GET['id'])) {
                echo "".$_GET['id']."";
            } elseif (isset($_POST['id'])) {
                echo "".$_POST['id']."";
            }

            echo "\" /></td>
			</tr>
			</table>
			</form>
			</fieldset>";
            
        } elseif ($_GET['show'] == "view_smilies") {
        
            if (isset($_POST['send']) AND isset($_POST['entry'])) {
                $y = count($_POST['entry']);

                for ($x=0;$x<$y;$x++) {
                
                    $entry_id = $_POST['entry'][$x];
                    $sql_select_filename = $gbook->query("SELECT filename FROM ".$table."_smilies WHERE id='$entry_id'");
                    $select_filename = $sql_select_filename->fetch_assoc();

                    unlink("../images/smilies/".$select_filename['filename']."");

                    $gbook->query("DELETE FROM ".$table."_smilies WHERE id='$entry_id'");
                }
            }

            $sql_smilies = $gbook->query("SELECT bbcode, filename, height, id, name, width FROM ".$table."_smilies");

            if ($sql_smilies->num_rows == 0 ) {
                echo "<br /><p class=\"zentriert\"><strong>".$emsg[31]."</strong></p><br />
                	";
                
            } else {
            
                echo "<fieldset>
				<legend><strong>".$fmsg[168]."</strong></legend>
				<br/><br/>
				<form method=\"post\" action=\"".$url."admin/admin.php?action=smilies&#38;show=view_smilies&#38;".session_name()."=".session_id()."\">
				<table style=\"width:350px\" class=\"guestbook_table tableCenter\" cellpadding=\"2\" cellspacing=\"1\" border=\"0\">
				<tr>
				<td align=\"center\" class=\"tdinstall1\" style=\"width:25%\">
				<strong>".$fmsg[56]."</strong>
				</td>
				<td align=\"center\" class=\"tdinstall1\" style=\"width:20%\">
				<strong>BBCode:</strong>
				</td>
				<td align=\"center\" class=\"tdinstall1\" style=\"width:25%\">
				<strong>".$fmsg[7]."</strong>
				</td>
				<td align=\"center\" class=\"tdinstall1\" style=\"width:20%\">
				<strong>".$fmsg[169]."</strong>
				</td>
				<td align=\"center\" class=\"tdinstall1\" style=\"width:10%\">
				<input type=\"checkbox\" class=\"checkboxloeschen\" name=\"all\" value=\"1\" onclick=\"select_all(this.checked,this.form)\" />
				</td>
				</tr>
				";

                $i = 1;
                while ($smilies = $sql_smilies->fetch_assoc()) {
                    $color = ($i % 2) ? "tdinstall2" : "tdinstall3";
                    
                    echo "<tr>
					<td align=\"center\" class=\"".$color."\" style=\"width:25%\">
					<img src=\"".$url."images/smilies/".$smilies['filename']."\" alt=\"".$smilies['name']."\" width=\"".$smilies['width']."\" height=\"".$smilies['height']."\" />
					</td>
					<td align=\"center\" class=\"".$color."\" style=\"width:20%\">".$smilies['bbcode']."</td>
					<td align=\"center\" class=\"".$color."\" style=\"width:25%\">".$smilies['name']."</td>
					<td align=\"center\" class=\"".$color."\" style=\"width:20%\"><a href=\"".$url."admin/admin.php?action=smilies&#38;show=edit_smilies&#38;id=".$smilies['id']."\">Go</a></td>
					<td align=\"center\" class=\"".$color."\" style=\"width:10%\"><input type=\"checkbox\" name=\"entry[]\" value=\"".$smilies['id']."\" /></td>
					</tr>";
                    $i++;
                }

                echo "</table>
					<p>&nbsp;</p>
					<p class=\"aligncenter\"><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[166]."\" /></p>
					</form>
					</fieldset>";
                
            }
            
        } elseif ($_GET['show'] == "insert_smilies") {
            if (isset($_POST['send'])) {
                $error_msg = "";

                if ($_FILES['url']['size'] > "20000") {
                    $error_msg .= "<strong>".$emsg[26]."</strong><br />";
                }

                if ($_POST['name'] == "" OR $_POST['bbcode'] == "" OR $_FILES['url']['name'] == "") {
                    $error_msg .= "<strong>- ".$emsg[0]."</strong>";
                }

                if (!$error_msg == "") {
                    echo "<br /><p class=\"zentriert red\">".$error_msg."</p><br />
                    	";
                } else {
                    $sql_check_bbcode = $gbook->query("SELECT id FROM ".$table."_smilies WHERE bbcode='".$_POST['bbcode']."'");

                    if ($sql_check_bbcode->num_rows == 0) {
                        move_uploaded_file($_FILES['url']['tmp_name'], "../images/smilies/".$_FILES['url']['name']."");
                        $size = getimagesize("../images/smilies/".$_FILES['url']['name']."");

                        $sql_insert_smiley = $gbook->query("INSERT INTO ".$table."_smilies (bbcode, filename, height, id, name, width) VALUES
                                                              ('".$_POST['bbcode']."',
                                                               '".$_FILES['url']['name']."',
                                                               '".$size[1]."',
                                                               '',
                                                               '".$_POST['name']."',
                                                               '".$size[0]."')");
                        if ($sql_insert_smiley) {
                            echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=smilies&show=view_smilies&".session_name()."=".session_id()."\" />";
                        }

                    } else {
                        echo "<br /><p class=\"zentriert red\"><strong>- ".$emsg[27]."</strong></p><br />
                        	";
                    }
                }
            }

            echo "<fieldset>
				<legend><strong>".$fmsg[131]."</strong></legend>
				<br /><br />
				<form enctype=\"multipart/form-data\" method=\"post\" action=\"".$url."admin/admin.php?action=smilies&#38;show=insert_smilies&#38;".session_name()."=".session_id()."\">
				<table style=\"width:350px\" class=\"guestbook_table2 tableCenter\">
				<tr>
				<td align=\"left\"><br />".$fmsg[7]."</td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"name\" value=\"";

            if (isset($_POST['name'])) {
                echo $_POST['name'];
            }

            echo "\" />
				</td>
				</tr>
				<tr>
				<td align=\"left\"><br />BBCode:</td><td align=\"left\"><br /><input type=\"text\" class=\"insert\" name=\"bbcode\" value=\"";

            if (isset($_POST['bbcode'])) {
                echo $_POST['bbcode'];
            }

            echo "\" /></td>
				</tr>
				<tr>
				<td align=\"left\"><br />".$fmsg[56]."</td><td align=\"left\"><br /><input size=\"15\" type=\"file\" name=\"url\" /></td>
				</tr>
				<tr>
				<td align=\"center\" colspan=\"2\"><br /><p><input type=\"submit\" class=\"button\" name=\"send\" value=\"".$fmsg[132]."\" /></p><br /></td>
				</tr>
				</table>
				</form>
				</fieldset>";
        }
    }
?>