<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    03.07.2016
*/

    if (!isset($_SESSION['sid'])) {
        echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."admin/admin.php?action=login\" />";
    } else {
		$sql_entries = $gbook->query("SELECT `date`, `time` FROM `".$table."_entries` WHERE `id` = (SELECT max(id) FROM `".$table."_entries`)");
		list($last_entrie_date,$last_entrie_time) = $sql_entries->fetch_row();
	
		$last_day = substr ($last_entrie_date, 0, 2);
		$last_month = substr ($last_entrie_date, 3, 2);
		$last_year = substr ($last_entrie_date, 6, 4);
		$last_hour = substr ($last_entrie_time, 0, 2);
		$last_minute = substr ($last_entrie_time, 3, 2);
		
		$last_backup = $gbook->query("SELECT `datum`,`uhrzeit` FROM `".$table."_backup` WHERE `id` = (SELECT max(id) FROM `".$table."_backup`)");
		list($last_backup_date,$last_backup_time) = $last_backup->fetch_row();
	
		$backup_day = substr ($last_backup_date, 0, 2);
		$backup_month = substr ($last_backup_date, 3, 2);
		$backup_year = substr ($last_backup_date, 6, 4);
		$backup_hour = substr ($last_backup_time, 0, 2);
		$backup_minute = substr ($last_backup_time, 3, 2);
		
		if ($last_entrie_date && $last_backup_date) {
			$entrie_time =  mktime($last_hour, $last_minute, 0, $last_month, $last_day, $last_year);
			$backup_time =  mktime($backup_hour, $backup_minute, 0, $backup_month, $backup_day, $backup_year);
		
			if ($entrie_time > $backup_time) {
				$new_backup = '&nbsp;&nbsp;&nbsp;<a href="'.$url.'admin/admin.php?action=backup&#38;show=make_backup&#38;'.session_name().'='.session_id().'"><img class="img-ok" title="Make a new BackUp! - Click!" src="../images/ausruf.png" width="14" height="14" alt="Make a new BackUp!" /></a>';
			}
			else {
				$new_backup = '&nbsp;&nbsp;&nbsp;<img class="img-ok" src="../images/ok.png" width="14" height="14" alt="OK" />';
			}
		}
		else {
			$new_backup = '';
		}
		
		echo"
		<p class=\"aligncenter\">
			<strong>";
				if (!$last_backup_date) {
					echo"<span class=\"red\">".$amsg[87]."</span>";
				}
				else {
					echo"".$amsg[44]." ".$last_backup_date." || ".$last_backup_time." $new_backup";
				}
						
			echo"</strong>
		</p>";
	}
?>