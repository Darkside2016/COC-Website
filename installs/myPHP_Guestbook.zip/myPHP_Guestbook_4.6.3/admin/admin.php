<?php
	header("X-Robots-Tag: noindex");
	header( 'content-type: text/html; charset=UTF-8' );
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Pragma: no-cache");

/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    03.07.2016
*/
    
    session_start();

	//maximale Dauer der Session: 30 Min. => bei jedem Klick auf einen Link im Admin-Control-Panel beginnt die Frist neu
	$lifetime = 60*30;
	
	if (isset($_SESSION['last_activity']) && ((time() - $lifetime) > $_SESSION['last_activity'])){
		unset($_SESSION['sid']);
		session_destroy();
	}
	
	$_SESSION['last_activity'] = time();

	require_once("../includes/functions.inc.php");

	$erfassungstage = 15;
	$ablauf 		= mktime(0, 0, 0, date("m"), date("d")-($erfassungstage-1), date("Y"));
	$ablauftag 		= date ("d.m.Y", $ablauf);
	$loeschen = mktime(0, 0, 0, date("m"), date("d")-$erfassungstage, date("Y"));
	$gbook->query("DELETE FROM `".$table."_statistic` WHERE `id` != '1' AND `zeit` <= ".$loeschen."");

	$error_02 = "";
	$entries_gesperrt =  "";
    $count_entries = "";
	$js_limit = "";
	$select_template = "";
	$short_town = "30";

    $sql_language = $gbook->query("SELECT language FROM ".$table."_properties");
    $language  = $sql_language->fetch_assoc();

	timezoneGBook();

    require_once("../lang/".$language['language'].".php");

	echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
	<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"".$lang_short."\" lang=\"".$lang_short."\">
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=".$encoding."\" />
	<meta name=\"viewport\" content=\"width=770\" />
	<meta http-equiv=\"content-script-type\" content=\"text/javascript\" />
	<meta http-equiv=\"content-style-type\" content=\"text/css\" />
	<title>myPHP Guestbook - Admin-Control-Panel ".$version."</title>
	<link rel=\"stylesheet\" type=\"text/css\" href=\"".$url."admin/style.css\" />
	</head>
	<body>
	<div class=\"aligncenter\">
	<table style=\"width:750px\" class=\"guestbook_table tableCenter\" cellpadding=\"4\" cellspacing=\"1\" border=\"0\">
	<tr>
	<td colspan=\"2\" style=\"height:12\" class=\"tdinstall1\">";

    if (isset($_SESSION['sid'])) {
    
	echo "
		<div class=\"aligncenter\">
			<img src=\"".$url."includes/flags/".$flag.".png\" alt=\"\" width=\"16\" height=\"11\" />&nbsp;&nbsp;&nbsp;<strong>".$amsg[0]." - myPHP Guestbook ".$version."</strong>
		</div>"; 

    } else {
    
	echo"
		<div class=\"aligncenter\">
			<img src=\"".$url."includes/flags/".$flag.".png\" alt=\"\" width=\"16\" height=\"11\" />&nbsp;&nbsp;&nbsp;<strong>".$amsg[1]."</strong>
		</div>"; }
    
	echo"
		</td>
		</tr>";  
    
    if (isset($_SESSION['sid'])) {
    
	echo"
		<tr>
		<td align=\"left\" style=\"width:170px\" valign=\"top\" class=\"tdinstall2\">
			<fieldset>
			<legend><strong>".$amsg[2]."</strong></legend>
			<a href=\"".$url."admin/admin.php?action=guestbook&#38;".session_name()."=".session_id()."\">".$amsg[3]."</a><br />
			<a href=\"".$url."admin/admin.php?action=guest_pictures&#38;".session_name()."=".session_id()."\">".$amsg[91]."</a><br />
			<a href=\"".$url."admin/admin.php?action=adminblog&#38;".session_name()."=".session_id()."\">".$amsg[177]."</a><br />
			<a rel=\"external\" href=\"".$url."\">".$fmsg[50]."</a><br />
			</fieldset>				
			<fieldset>
			<legend><strong>".$amsg[4]."</strong></legend>
			<a href=\"".$url."admin/admin.php?action=admin_options&#38;".session_name()."=".session_id()."\">".$amsg[5]."</a><br />
			<a href=\"".$url."admin/admin.php?action=guestbook_options&#38;".session_name()."=".session_id()."\">".$amsg[6]."</a><br />
			<a href=\"".$url."admin/admin.php?action=upload_options&#38;".session_name()."=".session_id()."\">".$amsg[103]."</a><br />
			<a href=\"".$url."admin/admin.php?action=thanks_email&#38;show=guest_mail&#38;".session_name()."=".session_id()."\">".$amsg[130]."</a><br />
			</fieldset>
			<fieldset>
			<legend><strong>".$amsg[12]."</strong></legend>
			<a href=\"".$url."admin/admin.php?action=default_template&#38;".session_name()."=".session_id()."\">".$amsg[13]."</a><br />
			<a href=\"".$url."admin/admin.php?action=edit_template&#38;".session_name()."=".session_id()."\">".$amsg[16]."</a><br />
			<a href=\"".$url."admin/admin.php?action=make_template&#38;".session_name()."=".session_id()."\">".$amsg[14]."</a><br />
			<a href=\"".$url."admin/admin.php?action=delete_template&#38;".session_name()."=".session_id()."\">".$amsg[15]."</a><br />
			</fieldset>
			<fieldset>
			<legend><strong>".$amsg[7]."</strong></legend>
			<a href=\"".$url."admin/admin.php?action=style&#38;show=default_style&#38;".session_name()."=".session_id()."\">".$amsg[8]."</a><br />
			<a href=\"".$url."admin/admin.php?action=style&#38;show=edit_style&#38;".session_name()."=".session_id()."\">".$amsg[11]."</a><br />
			<a href=\"".$url."admin/admin.php?action=style&#38;show=make_style&#38;".session_name()."=".session_id()."\">".$amsg[9]."</a><br />
			<a href=\"".$url."admin/admin.php?action=style&#38;show=delete_style&#38;".session_name()."=".session_id()."\">".$amsg[10]."</a><br />
			</fieldset>
			<fieldset>
			<legend><strong>".$amsg[17]."</strong></legend>
			<a href=\"".$url."admin/admin.php?action=smilies&#38;show=view_smilies&#38;".session_name()."=".session_id()."\">".$amsg[18]."</a><br />
			<a href=\"".$url."admin/admin.php?action=smilies&#38;show=insert_smilies&#38;".session_name()."=".session_id()."\">".$amsg[19]."</a><br />
			</fieldset>
			<fieldset>
			<legend><strong>".$amsg[20]."</strong></legend>
			<a href=\"".$url."admin/admin.php?action=badwords&#38;show=view_badwords&#38;".session_name()."=".session_id()."\">".$amsg[21]."</a><br />
			<a href=\"".$url."admin/admin.php?action=badwords&#38;show=insert_badwords&#38;".session_name()."=".session_id()."\">".$amsg[22]."</a><br />
			</fieldset>
			<fieldset>
			<legend><strong>".$amsg[38]."</strong></legend>
			<a href=\"".$url."admin/admin.php?action=spamwords&#38;show=view_spam&#38;".session_name()."=".session_id()."\">".$amsg[35]."</a><br />
			<a href=\"".$url."admin/admin.php?action=spamwords&#38;show=insert_spam&#38;".session_name()."=".session_id()."\">".$amsg[36]."</a><br />
			<a href=\"".$url."admin/admin.php?action=spamwords&#38;show=ip_forbidden&#38;".session_name()."=".session_id()."\">".$amsg[37]."</a><br />
			</fieldset>
			<fieldset>
			<legend><strong>".$amsg[23]."</strong></legend>
			<a href=\"".$url."admin/admin.php?action=backup&#38;show=restore_backup&#38;".session_name()."=".session_id()."\">".$amsg[25]."</a><br />
			<a href=\"".$url."admin/admin.php?action=backup&#38;show=make_backup&#38;".session_name()."=".session_id()."\">".$amsg[24]."</a><br />
			</fieldset>
			<fieldset>
			<legend><strong>".$amsg[26]."</strong></legend>
			<a href=\"".$url."admin/admin.php?action=statistic&#38;".session_name()."=".session_id()."\">".$amsg[27]."</a><br />
			<a href=\"".$url."admin/admin.php?action=help&#38;".session_name()."=".session_id()."\">".$amsg[82]."</a><br />
			<a href=\"".$url."admin/admin.php?action=logout&#38;".session_name()."=".session_id()."\">".$amsg[29]."</a>  
			</fieldset>";
    }
    
    ((isset($_GET['action']) AND $_GET['action'] == "login") OR (isset($_GET['action']) AND $_GET['action'] == "password_forget")) ? $write = "<tr>" : $write = "</td>" ;

	echo"
		$write
		<td valign=\"top\" class=\"tdinstall3\">";
    
   // Aktionen

    if (!isset($_SESSION['sid'])) {
        $file = "login.php";
    } else {
        $file = "guestbook.php";
    }

    if (isset($_GET['action'])) {
        $_GET['action'] = $gbook->real_escape_string($_GET['action']);

        if (!preg_match("/^[_\a-z]*$/is", $_GET['action'])) {
            $_GET['action'] = "guestbook";
        }
    } else {
        $_GET['action'] = "guestbook";
    }
    
    (isset($_GET['show'])) ? ($_GET['show'] = $gbook->real_escape_string($_GET['show'])) : $_GET['show'] = "";

    switch($_GET['action']) {
	
    case "admin_options";
        require_once("admin_options.php");
        break;

    case "backup";
        require_once("backup.php");
        break;

    case "badwords";
        require_once("badwords.php");
        break;

    case "comment";
        require_once("comment.php");
        break;

    case "spamwords";
        require_once("spamwords.php");
        break;

    case "default_template";
        require_once("default_template.php");
        break;

    case "delete_template";
        require_once("delete_template.php");
        break;

    case "edit";
        require_once("edit.php");
        break;

    case "edit_template";
        require_once("edit_template.php");
        break;

    case "edit_template_action";
        require_once("edit_template_action.php");
        break;

    case "adminblog";
        require_once("admin_blog.php");
        break;

    case "guestbook";
        require_once("guestbook.php");
        break;

    case "guestbook_options";
        require_once("guestbook_options.php");
        break;

    case "guest_pictures";
        require_once("guest_pictures.php");
        break;

    case "edit_guest_pictures";
        require_once("edit_guest_pictures.php");
        break;

    case "upload_options";
        require_once("upload_options.php");
        break;

    case "thanks_email";
        require_once("edit_thanks_email.php");
        break;

    case "logout";
        require_once("logout.php");
        break;

    case "make_template";
        require_once("make_template.php");
        break;

    case "make_template_action";
        require_once("make_template_action.php");
        break;

    case "password_forget";
        require_once("login.php");
        break;

    case "statistic";
        require_once("statistic.php");
        break;

    case "smilies";
        require_once("smilies.php");
        break;

    case "style";
        require_once("style.php");
        break;

    case "help";
        require_once("help.php");
        break;

    default:
        require_once($file);
        break;
    }
   // Ende Aktionen

	echo "</td>
	</tr>
	<tr>
		<td colspan=\"2\" align=\"center\" class=\"tdinstall1\">
			<a href=\"https://www.php-guestbook.de\" title=\"Download myPHP Guestbook ".$version."\" rel=\"external\"><img title=\"Download 'myPHP Guestbook ".$version."'\" src=\"".$url."images/myphpGuestbook.png\" width=\"110\" height=\"20\" alt=\"myPHP Guestbook ".$version."\" /></a>
		</td>
	</tr>
	</table>
	</div>
	<script type=\"text/javascript\" src=\"".$url."js/functions.js\"></script>
	</body>
</html>";
    
?>