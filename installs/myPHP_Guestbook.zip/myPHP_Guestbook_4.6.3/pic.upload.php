<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    ################################################################################################
    
	Wesentliche Teile des Quellcodes dieser Datei "pic.upload.php" stammen von:
	
	ISP Image Upload und Resize PHP Programm
	(c) Joachim Patten (ISP), 2013
	isp_image_resize Ver.1.5 : Version vom 08.02.2013
	
	COPYRIGHT NOTICE
	Copyright Joachim Patten (ISP)
	URL: http://www.neusser-marktplatz.de
	
	isp_image_resize.php darf kostenlos benutzt und geaendert werden.
	
	Mit dem Einsatz dieses Skripts akzeptieren Sie, dass ISP, Joachim Patten,
	von jeglicher Haftung und Gewaehrleistung hinsichtlich des Einsatzes befreit ist.
	
	By using this script you accept that ISP, Joachim Patten,
	from any liability and warranty for the use thereof.

	##################################################################################################

    08.10.2016
*/

	define('UPLOAD_INFO', false);		// Falls der Datei-Upload im Einzelfall nicht funktioniert, kann eine Aktivierung weiterer Prüfungen dem Admin hierzu hilfreiche Infos über den Grund liefern.
										// Siehe auch: <http://php.net/manual/de/features.file-upload.errors.php>. Im Normalfall sollte diese Funktion deaktiviert bleiben (Konstante "UPLOAD_INFO" = false).
										// Weitere Prüfungen aktivieren (=> true) / deaktivieren (=> false)
	
	require_once("includes/functions.inc.php");

	//Vorbereitung Ausschluss dauerhaft gesperrter IPs gem. Tabelle mit Umleitung zum Gästebuch
	$ip_sperre = $gbook->query("SELECT `ip` FROM `".$table."_forbidden_ip` WHERE `ip` = '".$_SERVER['REMOTE_ADDR']."'");

	if ($ip_sperre != ""){
		$sperre = $ip_sperre->num_rows;
	}

	//Wenn Gästebuch oder Uploads in den Konfigurationseinstellungen von GBook gesperrt => Vorbereitung Umleitung zur Startseite
	$sql_no_upload  = $gbook->query("SELECT `guestbook_status`, `images_in_entries` FROM `".$table."_properties`") or die("SQL-Fehler = ".$gbook->error);
	$no_upload 		= $sql_no_upload->fetch_assoc();
	
	timezoneGBook();

	isset($_SERVER['HTTP_REFERER']) ? $woher = htmlspecialchars($_SERVER['HTTP_REFERER']) : $woher = "";
	isset($_SERVER['SERVER_NAME']) ? $hostname = $_SERVER['SERVER_NAME'] : $hostname = "";

	$count_entries = "";
	$ausgabe01 = "";
	$ausgabe02 = "";
	$ausgabe03 = "";
	$ausgabe04 = "";
	$ausgabe05 = "";
	$ergebnis_upload = "";
	$fehler = "";
	
	if (isset($_GET['action']))
		{
			$_GET['action'] = $gbook->real_escape_string($_GET['action']);
										
			if (!preg_match("/^[_\a-z]*$/is", $_GET['action']))
				{
					$_GET['action'] = "step1";
				}
		}
	else
		{
			$_GET['action'] = "step1";
		}
	
    switch($_GET['action'])
		{
		    case "step1";
	        $_GET['action'] = "step1";
	        break;

		    case "step2";
	        $_GET['action'] = "step2";
	        break;

		    case "step3";
	        $_GET['action'] = "step3";
	        break;

		    default:
			$_GET['action'] = "step1";
	        break;
		}

	require_once("includes/lang.inc.php");

	$upload_konfig 	= $gbook->query("SELECT `max_filesize`, `max_width`, `max_height`, `jpg_quality`, `upload_max` FROM `".$table."_upload`");
	$upload			= $upload_konfig->fetch_assoc();
	
	//Ueberwachung der Anzahl hochgeladener Dateien und Sperre beim Ueberschreiten der max. zulaessigen Uploads
	$new_upload_time = time()-1200;	// 20 Minuten IP-Sperre fuer Datei-Uploads
	$gbook->query("DELETE FROM `".$table."_upload_counter` WHERE `upload_time` <= '$new_upload_time'");
		                    
	$sql_count_upload = $gbook->query("SELECT `counter` FROM `".$table."_upload_counter` WHERE `ip` = '".$_SERVER['REMOTE_ADDR']."'");
	$count_upload = $sql_count_upload->fetch_assoc();

	($count_upload['counter'] < $upload['upload_max']) ? $freeupload = true : $freeupload = false;
	
	$sql_properties = $gbook->query("SELECT `guestbook_title`, `admin_email`, `button_link` FROM `".$table."_properties`");
	$properties		= $sql_properties->fetch_assoc();
	
    if($freeupload != true && ($_GET['action'] == "step1" OR $_GET['action'] == "step2"))
    	{
			$ausgabe05 ="<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p class=\"text-center\"><strong>".$pmsg[30]." ".$upload['upload_max']." ".$pmsg[31]."; ".$pmsg[33].".</strong></p>
						<div class=\"aligncenter\">
							<br />
							<form action=\"#\" method=\"post\">
								<p><input class=\"button-gb\" title=\"".$amsg[118]."\" type=\"button\" value=\"".$amsg[118]."\" onclick=\"window.close();\" /></p>
							</form>		
						</div>";
		}

	else
		{
			if ($_GET['action'] == "step1")
				{
					$ausgabe01 .=
						"".$pmsg[1]."<br />
						<form action=\"?action=step2\" method=\"post\">
							<p class=\"aligncenter\"><button name=\"accept_02\" type=\"submit\" class=\"button-gb\" title=\"".$pmsg[2]."\" value=\"".$pmsg[2]."\">".$pmsg[2]."</button></p>
							<p class=\"dsR3\"><input type=\"hidden\" name=\"accept\" value=\"1\" /><input type=\"hidden\" name=\"woher\" value=\"".$woher."\" /><input type=\"hidden\" name=\"control\" value=\"".time()."\" /></p>
						</form>
						<div class=\"aligncenter\">
							<br />
							<form action=\"#\" method=\"post\">
								<p><input class=\"button-gb\" title=\"".$pmsg[3]."\" type=\"button\" value=\"".$pmsg[3]."\" onclick=\"window.close();\" /></p>
							</form>		
						</div>";
					}

			elseif ($_GET['action'] == "step2")
				{
					// kein direkter Aufruf des Upload-Formulars (step2) ohne Bestätigung der Nutzungsbedingungen (step1)
					(isset($_POST['woher'])) ? $pic_referrer = htmlspecialchars($_POST['woher']) : $pic_referrer = "";
					(isset($_POST['accept'])) ? $accept = htmlspecialchars($_POST['accept']) : $accept = "0";
		
					// Extrawurst für IE
					$_POST['control'] = isset($_POST['control']) ? htmlspecialchars($_POST['control']) : "";
					($_POST['control'] >= (time()-60)) ? $cc = 7 : $cc = "";
		
					if (((substr_count($pic_referrer, $hostname) == 1) OR ($_POST['control'] != "" && ($cc == '7'))) && $accept == '1')
						{
							$maxfilesize = ''.$upload['max_filesize'].'';
							$maxfilesize_kb = $maxfilesize*1024;
							$maxfilesize_by = $maxfilesize_kb*1024;
							$fieldname = 'bild'; 
							$uploaddir = 'img_guest'; 
							$allowedfiletype = array('jpg','jpeg','png','JPG','JPEG');
							$upload_blacklist = array('.php', '.pl', '.cgi', '.aspx', '.sh', '.php3');
							isset($_FILES[$fieldname]["name"]) ? $filename = htmlspecialchars($_FILES[$fieldname]["name"]) : $filename = '';
							$quality = ''.$upload['jpg_quality'].'';
							$dirname = dirname(htmlspecialchars($_SERVER['PHP_SELF'])); 
							$outfile = 'http://'.$_SERVER['SERVER_NAME'].(substr($dirname, 0, 1) == '\\' ? substr($dirname, 1):$dirname).'/'.$uploaddir.'/';
							
							$dateiname	= '';
							$endung		= '';
							$filetyp	= '';
							$orgname	= '';
							$allesok	= ''; 
							$fehler		= '';
							$table_pic	= ''.$table.'_pictures';
							$ausgabe02 .= "<p class=\"text-center\"><strong>".$pmsg[4]."</strong></p>
											<br />";
				
							$image_prop = "ja";
					
							// Maximale Foto-Dimensionen in Pixel
							$uploadMaxWidth = ''.$upload['max_width'].'';
							$uploadMaxHeight = ''.$upload['max_height'].'';
							
							// Funktion Grafikverkleinerung und EXIF-Header-Bereinigung
							function ResizeImage($filename, $outfile, $new_img_max_x, $new_img_max_y)
								{
									global $image_prop;
									global $quality;
									global $filetyp;
							
									$file = basename($filename);
		
									// Welche Version von GDLIB ist installiert?
									if(@imagecreatetruecolor(1,1)) $GDLIB_VERS = 2;
									else $GDLIB_VERS = 1;
					
									//-----------------------------------------------------------------------------
									// Verkleinerung jpg-Dateien
							
									if($filetyp == "jpg")
										{
											if(function_exists("ImageCreateFromJPEG"))
												{
													$imgA = ImageCreateFromJPEG($filename);
							
													$org_x = ImageSX($imgA);
													$org_y = ImageSY($imgA);
														
													if($org_x >= $org_y && $image_prop == "ja")
														{
															$new_img_max_x = $new_img_max_x;
															$new_img_max_y = $org_y / ($org_x / $new_img_max_x);
															$new_img_max_y = floor($new_img_max_y);
														}
													
													if($org_x < $org_y && $image_prop == "ja")
														{
															$new_img_max_y = $new_img_max_y;
															$new_img_max_x = $org_x / ($org_y / $new_img_max_y);
															$new_img_max_x = floor($new_img_max_x);
														}
				
													if($GDLIB_VERS == 2)
														{
															$imgB = imagecreatetruecolor($new_img_max_x,$new_img_max_y);
															imagecopyresampled($imgB, $imgA,0,0,0,0, $new_img_max_x, $new_img_max_y, $org_x ,$org_y);
														}
							
													if($GDLIB_VERS == 1)
														{
															$imgB = imagecreate($new_img_max_x,$new_img_max_y);
															imagecopyresized($imgB, $imgA,0,0,0,0, $new_img_max_x, $new_img_max_y, $org_x ,$org_y);
														}
													imagejpeg($imgB, $outfile, $quality);
												}
											else
												{
													return false;
												}
										}
							
									// Ende Verkleinerung jpg
									//-----------------------------------------------------------------------------
									// Verkleinerung png-Dateien
							
									if($filetyp == "png")
										{
											if(function_exists ("ImageCreateFromPNG"))
												{
													$imgA = ImageCreateFromPNG($filename);
							
													$org_x = ImageSX($imgA);
													$org_y = ImageSY($imgA);
							
													if($org_x >= $org_y && $image_prop == "ja")
														{
															$new_img_max_x = $new_img_max_x;
															$new_img_max_y = $org_y / ($org_x / $new_img_max_x);
															$new_img_max_y = floor($new_img_max_y);
														}
							
													if($org_x < $org_y && $image_prop == "ja")
														{
															$new_img_max_y = $new_img_max_y;
															$new_img_max_x = $org_x / ($org_y / $new_img_max_y);
															$new_img_max_x = floor($new_img_max_x);
														}
							
													if($GDLIB_VERS == 2)
														{
															$imgB = imagecreatetruecolor($new_img_max_x,$new_img_max_y);
															imagecopyresampled($imgB, $imgA,0,0,0,0, $new_img_max_x, $new_img_max_y, $org_x ,$org_y);
														}
							
													if($GDLIB_VERS == 1)
														{
															$imgB = imagecreate($new_img_max_x,$new_img_max_y);
															imagecopyresized($imgB, $imgA,0,0,0,0, $new_img_max_x, $new_img_max_y, $org_x ,$org_y);
														}
							
													imagepng($imgB, $outfile);
							
												}
											else
												{
													return false;
												}
										}
							
										// Ende Verkleinerung png
							
									// Wenn die Funktion zur Verkleinerung von jpg- und png-Dateien nicht verfügbar ist => Fehler
							
									if(!$imgA)
										{
											return false;
										}
							
									return true;
								}
									
							// Ende Funktion Grafikverkleinerung und EXIF-Header-Bereinigung

							// Funktion EXIF-Header-Bereinigung bei Dateien, die die maximale Breite und Höhe nicht(!) überschreiten	
							function CleanImage($filename, $outfile, $org_x, $org_y)
								{
									global $image_prop;
									global $quality;
									global $filetyp;
							
									$file = basename($filename);
		
									// Welche Version von GDLIB ist installiert?
									if(@imagecreatetruecolor(1,1)) $GDLIB_VERS = 2;
									else $GDLIB_VERS = 1;
							
									//-----------------------------------------------------------------------------
									// Bereinigung jpg-Dateien
							
									if($filetyp == "jpg")
										{
											if(function_exists("ImageCreateFromJPEG"))
												{
													$imgA = ImageCreateFromJPEG($filename);
							
													$org_x = ImageSX($imgA);
													$org_y = ImageSY($imgA);
		
													if($GDLIB_VERS == 2)
														{
															$imgB = imagecreatetruecolor($org_x,$org_y);
															imagecopyresampled($imgB, $imgA,0,0,0,0, $org_x, $org_y, $org_x ,$org_y);
														}
							
													if($GDLIB_VERS == 1)
														{
															$imgB = imagecreate($org_x,$org_Y);
															imagecopyresized($imgB, $imgA,0,0,0,0, $org_x, $org_Y, $org_x ,$org_y);
														}
													imagejpeg($imgB, $outfile, $quality);
												}
											else
												{
													return false;
												}
										}
							
									// Ende Bereinigung jpg-Dateien
									//-----------------------------------------------------------------------------
									// Bereinigung png-Dateien
							
									if($filetyp == "png")
										{
											if(function_exists("ImageCreateFromPNG"))
												{
													$imgA = ImageCreateFromPNG($filename);
							
													$org_x = ImageSX($imgA);
													$org_y = ImageSY($imgA);
							
													if($GDLIB_VERS == 2)
														{
															$imgB = imagecreatetruecolor($org_x,$org_y);
															imagecopyresampled($imgB, $imgA,0,0,0,0, $org_x, $org_y, $org_x ,$org_y);
														}
							
													if($GDLIB_VERS == 1)
														{
															$imgB = imagecreate($org_x,$org_y);
															imagecopyresized($imgB, $imgA,0,0,0,0, $org_x, $org_y, $org_x ,$org_y);
														}
							
													imagepng($imgB, $outfile);
							
												}
											else
												{
													return false;
												}
										}
		
										// Ende Bereinigung png
							
									if(!$imgA)
										{
											return false;
										}
							
									return true;
								}
		
							// Ende Funktion EXIF-Header-Bereinigung

							// Variablen absichern
							function quote_smart($value)
								{
									if (get_magic_quotes_gpc())
										{
											$value = stripslashes($value);
										}
								
									// In Anfuehrungszeichen setzen, sofern keine Zahl oder ein numerischer String vorliegt
									if (!is_numeric($value))
										{
											$value = "'".$gbook->real_escape_string($value)."'";
										}
									return $value;
								}
				
							// Wenn id übergeben wird, dann absichern und laden des Datensatzes
							if (isset($_REQUEST['id'])) {
								$id = strip_tags(trim($_REQUEST['id']));
								$id = $gbook->real_escape_string($id);
								$id = (is_numeric($id) && !empty($id) && (intval($id) == $id)) ? $id : '';
							}
							else {
								$id = '';
							}
								
							if(!empty($id))
								{
									$asql	=	$gbook->query("SELECT pic_name FROM $table_pic WHERE id = $id") or die("SQL-Fehler = ".$gbook->error); 
									$bildrs =	$uploaddir."/".$gbook->result($asql);
								}
				
							$ausgabe03 .= "".$pmsg[5]."
											<p class=\"text-center\"><strong>$maxfilesize MB (= $maxfilesize_kb KB)</strong><br />
											<p>".$pmsg[6]."<strong> ";
							
							if(count($allowedfiletype) > 1)
								{ 
									$last = array_pop($allowedfiletype);
				 
									$ausgabe03 .= implode(', ', $allowedfiletype); 
									$ausgabe03 .= ' + '.$last; 
								}
							elseif(count($allowedfiletype) == 1)
								{
									$ausgabe03 .= $allowedfiletype[0];
								}
								
							$ausgabe03 .= "</strong></p>
											<p>".$pmsg[30]." ".$upload['upload_max']." ".$pmsg[31]." ".$pmsg[32].".</p>
											".$pmsg[7]."
											";
									
							// Vorbereitung zum Speichern der Grafikdaten in die Datenbank		
							function uploaddb($dateiname,$new_width,$new_height,$table_pic,$id,$file)
								{
									global $gbook;
									global $table;
									
									if(!empty($id))
										{
											if (file_exists($file))
												{
													unlink($file); 
												} 
											                
											$sql = sprintf("UPDATE $table_pic SET ip = '".$_SERVER['REMOTE_ADDR']."', pic_name = '$dateiname', width = '$new_width', height = '$new_height', title = 'Upload: ".date("d.m.Y")."','".date("d.m.Y")."', date = '".date("d.m.Y")."', time = '".date("H:i")."'  WHERE id = '".$id."'") or die ("SQL-Fehler = ".$gbook->error);
										}
									else
										{    
											$sql = sprintf("INSERT INTO $table_pic (id, ip, pic_name, width, height, title, date, time) VALUES ('','".$_SERVER['REMOTE_ADDR']."','$dateiname','$new_width','$new_height','Upload: ".date("d.m.Y")."','".date("d.m.Y")."','".date("H:i")."')") or die ("SQL-Fehler = ".$gbook->error);
										}          
											           
									$rs = $gbook->query($sql);
											 
									if($rs)
										{ 
											return "<p>&nbsp;</p>"; 
										}
									else
										{ 
											return "<p class=\"text-center red\">".$pmsg[8]."</strong></p>"; 
										}         
								} 
						
							// Abfrage, ob Formular abgeschickt und neuen Dateinamen sowie Dateiendung generieren
							if(isset($_POST['send']))
								{
									$allesok = 1;
									$darray  = explode('.', str_replace('/', '.', $_FILES[$fieldname]['name']));
									
									mt_srand(makeRandomName());
									$orgname = md5(mt_rand());
									$orgname = substr($orgname, 0, 12);
									$orgname = preg_replace('/(.)(\\1{1,2})\\1*/sS', '$1$2', $orgname);
											
									// Fehlerüberprüfung
									if($_FILES[$fieldname]['error'] == 2)
										{
											$allesok=0; 
											$fehler =''.$pmsg[14].'<br />'.$pmsg[10].''; 
										} 
									if($_FILES[$fieldname]['error'] == 0 AND $allesok == 1)
										{
											$image_typ = getimagesize($_FILES[$fieldname]['tmp_name']);
											$image_mimetyp = $image_typ['mime'];
		
											if ($image_mimetyp != 'image/jpeg' && $image_mimetyp != 'image/png')
												{
													$allesok=0; 
													$fehler = ''.$pmsg[22].'';
												}
											elseif (($image_typ['0'] < 10) && ($image_typ['1'] < 10))
												{
													$allesok=0;
													$fehler = ''.$pmsg[34].'';
												}
											elseif ($image_mimetyp == 'image/jpeg')
												{
													$filetyp = 'jpg';
												}
											elseif ($image_mimetyp == 'image/png')
												{
													$filetyp = 'png';
												}
										} 
									if (count($darray) > 1 AND $allesok == 1)
										{
											$endung  = trim(strtolower($darray[1]));
											
											foreach($upload_blacklist as $blacklist)
												{					
													$count_blacklist = substr_count(strtolower($_FILES[$fieldname]['name']), ''.$blacklist.'', 0);
															
													if($count_blacklist > 0)
														{
															$allesok=0;  
															$fehler=''.$pmsg[28].''; 
														} 
												}
										}

									if (UPLOAD_INFO)
										{
											if($_FILES[$fieldname]['error'] == 4 AND $allesok == 1)
												{
													$allesok=0;  
													$fehler='Es wurde keine Datei hochgeladen.<br />No file was uploaded.'; 
												} 
											if($_FILES[$fieldname]['error'] == 6 AND $allesok == 1)
												{
													$allesok=0;  
													$fehler='Fehlender temporärer Ordner.<br />Missing a temporary folder.'; 
												} 
											if($_FILES[$fieldname]['error'] == 7 AND $allesok == 1)
												{
													$allesok=0;  
													$fehler='Speichern der Datei auf die Festplatte ist fehlgeschlagen.<br />Failed to write file to disk.'; 
												} 
											if($_FILES[$fieldname]['error'] == 8 AND $allesok == 1)
												{
													$allesok=0;  
													$fehler='Eine PHP Erweiterung hat den Upload der Datei gestoppt. PHP bietet keine Möglichkeit an, um festzustellen welche Erweiterung das Hochladen der Datei gestoppt hat. Überprüfung aller geladenen Erweiterungen mittels phpinfo() könnte helfen.<br />
															A PHP extension stopped the file upload. PHP does not provide a way to ascertain which extension caused the file upload to stop; examining the list of loaded extensions with phpinfo() may help.'; 
												}
										}

									if($_FILES[$fieldname]['error'] == 1 AND $allesok == 1)
										{
											$allesok=0;  
											$fehler=''.$pmsg[9].' ('.ini_get('upload_max_filesize').')!<br />'.$pmsg[10].''; 
										} 
									if($_FILES[$fieldname]['error'] == 3 AND $allesok == 1)
										{
											$allesok=0; 
											$fehler = ''.$pmsg[11].''; 
										} 
									if($_FILES[$fieldname]['error'] != 0 AND $allesok == 1)
										{
											$allesok=0; 
											$fehler ='<strong>'.$pmsg[12].'</strong>'; 
										} 
									if(!in_array($endung, $allowedfiletype) AND $allesok == 1)
										{
											$allesok=0;           
											$fehler = ''.$pmsg[13].''; 
										} 
									if(filesize($_FILES[$fieldname]['tmp_name'])/1024/1024 >= $maxfilesize AND $allesok == 1)
										{
											$allesok=0; 
											$fehler = ''.$pmsg[14].'<br />'.$pmsg[10].''; 
										}
								}
		   
							// wenn alles ok dann Upload des Bildes
							if($allesok && $filetyp != '')
								{
									// Upload-Counter
									$select_counter_ip = $gbook->query("SELECT `ip` FROM `".$table."_upload_counter` WHERE `ip` = '".$_SERVER['REMOTE_ADDR']."'");
									$counter_ip = $select_counter_ip->num_rows;
		
									if ($counter_ip > 0) {
										$gbook->query("UPDATE `".$table."_upload_counter` SET `upload_time` = ".time().", `counter` = `counter` + 1  WHERE `ip` = '".$_SERVER['REMOTE_ADDR']."'");
									}
									else {
										$gbook->query("INSERT INTO `".$table."_upload_counter` (id, ip, upload_time, counter) VALUES ('','".$_SERVER['REMOTE_ADDR']."','".time()."','1')");
									}
													
									// neuen Dateinamen zusammensetzen
									$dateiname = $orgname.'.'.$filetyp;
									
									// Upload
									move_uploaded_file($_FILES[$fieldname]['tmp_name'], $uploaddir.'/'.$dateiname);
							
									// erneute Überprüfung nach dem Upload, ob der Mimetyp zulässig ist
									// und ob die Bildgröße geändert werden muss, ggf. Verkleinerung, sonst Bereinigung
									$image_file_pfad = "{$uploaddir}/{$dateiname}";
									
									$size = getimagesize($image_file_pfad);
									$width = $size[0];
									$height = $size[1];
									$mimetype = $size[2];
									$value = true;
		
									if ($mimetype == '2' OR $mimetype == '3')  //Typ der Grafik: 2 = JPG, 3 = PNG
										{
											if ($width > $uploadMaxWidth || $height > $uploadMaxHeight)
												{
													$value = ResizeImage($image_file_pfad, $image_file_pfad, $uploadMaxWidth, $uploadMaxHeight);
												}
		
											else
												{
													$value = CleanImage($image_file_pfad, $image_file_pfad, $width, $height);
												}

											if ($value == true)
												{
													//Breite und Höhe des verkleinerten bzw. bereinigten Bildes ermitteln
													$new_size = getimagesize($image_file_pfad);
													$new_width = $new_size[0];
													$new_height = $new_size[1];
				
													// Formularwerte der Grafik in der Datenbank speichern
													$ergebnis_upload = uploaddb($dateiname,$new_width,$new_height,"".$table."_pictures",$id,$image_file_pfad);
													
													//Wenn Gästebuch nicht im Blog-Modus => Benachrichtigungsmail über Dateiupload an Admin
													if ($properties['button_link'] != 2)
														{
															$empfaenger = "".$properties['admin_email']."";
															$betreff = "".$pmsg[17]." - ".$_SERVER['SERVER_NAME']."\n";
															$header  = "MIME-Version: 1.0\n";
															$header .= "Content-type: text/html; charset=utf-8\n";
													        $header .= "Content-Transfer-Encoding: 8bit\n";
													        $header .= "X-Mailer: PHP\n";
															$header .= "From: \"".$properties['guestbook_title']."\" <".$properties['admin_email'].">\n"; 
																					
															$nachricht = "".$pmsg[18]."<br /><br />
																		<img src=\"".$outfile."".$dateiname."\" alt=\"\" width=\"".$new_width."\" height=\"".$new_height."\" /><br /><br />
																		".$outfile."".$dateiname."";
													
															mail($empfaenger, $betreff, $nachricht, $header);
														}
											
													$ausgabe01 = "";
													$ausgabe02 = "";
													$ausgabe03 = "";
													$ausgabe04 = "";
													$ausgabe05 ="<p class=\"text-center\">".$pmsg[19]."</p>
																".$pmsg[20]."
																<p>&nbsp;</p>
																<form action=\"?action=step3\" method=\"post\">
																	<p class=\"dsR3\"><input type=\"hidden\" name=\"send\" value=\"send\" /><input type=\"hidden\" name=\"accept\" value=\"1\" /><input type=\"hidden\" name=\"woher\" value=\"".$woher."\" /></p>
																	<p class=\"aligncenter\"><input class=\"button-gb\" title=\"".$pmsg[21]."\" type=\"submit\" value=\"".$pmsg[21]."\" onclick=\"opener.document.getElementById('text').value += ' [img]".$dateiname."[/img] ';\" /></p>
																</form>
																<div class=\"aligncenter\">
																	<br />
																	<form action=\"#\" method=\"post\">
																		<p><input class=\"button-gb\" title=\"".$pmsg[3]."\" type=\"button\" value=\"".$pmsg[3]."\" onclick=\"window.close();\" /></p>
																	</form>		
																</div>";
												}
											else
												{
													if (file_exists($image_file_pfad))
														{
															unlink($image_file_pfad); 
														} 
						
													$fehler = ''.$pmsg[29].'';
						
													$ausgabe04 ="<br />
																<div class=\"aligncenter\">
																	<form action=\"?action=step2\" enctype=\"multipart/form-data\" method=\"post\">
																		<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"".$maxfilesize_by."\" />
																		<div><input class=\"button-gb\" name=\"".$fieldname."\" type=\"file\" size=\"30\" /></div> 
																		<p class=\"dsR3\"><input type=\"hidden\" name=\"send\" value=\"send\" /><input type=\"hidden\" name=\"id\" value=\"".$id."\" /><input type=\"hidden\" name=\"accept\" value=\"1\" /><input type=\"hidden\" name=\"woher\" value=\"".$woher."\" /></p>
																		<p>&nbsp;</p>
																		<p><input class=\"button-gb\" title=\"".$pmsg[23]."\" type=\"submit\" name=\"laden\" value=\"".$pmsg[23]."\" /></p>
																	</form>
																</div>";
												}
										}

									else 
										{
											if (file_exists($image_file_pfad))
												{
													unlink($image_file_pfad); 
												} 
				
											$fehler = ''.$pmsg[22].'';
				
											$ausgabe04 ="<br />
														<div class=\"aligncenter\">
															<form action=\"?action=step2\" enctype=\"multipart/form-data\" method=\"post\">
																<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"".$maxfilesize_by."\" />
																<div><input class=\"button-gb\" name=\"".$fieldname."\" type=\"file\" size=\"30\" /></div> 
																<p class=\"dsR3\"><input type=\"hidden\" name=\"send\" value=\"send\" /><input type=\"hidden\" name=\"id\" value=\"".$id."\" /><input type=\"hidden\" name=\"accept\" value=\"1\" /><input type=\"hidden\" name=\"woher\" value=\"".$woher."\" /></p>
																<p>&nbsp;</p>
																<p><input class=\"button-gb\" title=\"".$pmsg[23]."\" type=\"submit\" name=\"laden\" value=\"".$pmsg[23]."\" /></p>
															</form>
														</div>";
										}
								}

							else
								{ 
									// Formularausgabe
									$ausgabe04 ="<br />
												<div class=\"aligncenter\">
													<form action=\"?action=step2\" enctype=\"multipart/form-data\" method=\"post\">
														<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"".$maxfilesize_by."\" />
														<div><input class=\"button-gb\" name=\"".$fieldname."\" type=\"file\" size=\"30\" /></div> 
														<p class=\"dsR3\"><input type=\"hidden\" name=\"send\" value=\"send\" /><input type=\"hidden\" name=\"id\" value=\"".$id."\" /><input type=\"hidden\" name=\"accept\" value=\"1\" /><input type=\"hidden\" name=\"woher\" value=\"".$woher."\" /></p>
														<p>&nbsp;</p>
														<p><input class=\"button-gb\" title=\"".$pmsg[23]."\" type=\"submit\" name=\"laden\" value=\"".$pmsg[23]."\" /></p>
													</form>
												</div>
												<div class=\"aligncenter\">
													<br />
													<form action=\"#\" method=\"post\">
														<p><input class=\"button-gb\" title=\"".$pmsg[3]."\" type=\"button\" value=\"".$pmsg[3]."\" onclick=\"window.close();\" /></p>
													</form>		
												</div>";
							 	}
						}
					else
						{
							$ausgabe04 ="<p class=\"text-center\"><strong>".$pmsg[4]."</strong></p>
										<br />
										".$pmsg[16]."
										<br />
										<br />
										<div class=\"aligncenter\">
										<form action=\"?action=step1\" method=\"post\">
											<p><button name=\"zurück\" type=\"button\" class=\"button-gb\" title=\"".$fmsg[4]."\" value=\"".$fmsg[4]."\" onclick=\"location.href='pic.upload.php?action=step1'\">".$fmsg[4]."</button></p>
										</form>
										</div>
										<div class=\"aligncenter\">
											<br />
											<form action=\"#\" method=\"post\">
												<p><input class=\"button-gb\" title=\"".$pmsg[3]."\" type=\"button\" value=\"".$pmsg[3]."\" onclick=\"window.close();\" /></p>
											</form>		
										</div>";
						}
				}

			elseif ($_GET['action'] == "step3")
				{
					//Title der hochgeladenen Datei erfassen und in Datenbank eintragen
					(isset($_POST['send'])) ? $pic_referrer = htmlspecialchars($_POST['woher']) : $pic_referrer = "";
					(isset($_POST['send'])) ? $accept = htmlspecialchars($_POST['accept']) : $accept = "0";
		
					if ((substr_count($pic_referrer, $hostname) == 1) && ($accept == '1')) 
						{
							$last_entrie = $gbook->query("SELECT `id`, `title` FROM `".$table."_pictures` WHERE `id` = (SELECT max(id) FROM `".$table."_pictures`)");
							list($last_id, $last_title) = $last_entrie->fetch_row();
				
							if (isset($_POST['send_title']))
								{
									$ausgabe05 = "";
									$error_title = "";
				
							        $_POST['description'] = $gbook->real_escape_string($_POST['description']);
		
									if (($_POST['description'] != "") AND (!preg_match("/^[a-zA-ZÄäÜüÖöß0-9 :?!,.-]*$/is", $_POST['description']))) 
										{
											$error_title .="- ".$emsg[61]."";
										}
				
						            if ($error_title == "")
										{
											$update_pic_title = $gbook->query("UPDATE `".$table."_pictures` SET `title` = '".$_POST['description']."' WHERE `id` = '".$last_id."'");
											
											if ($update_pic_title)
												{
													$ausgabe05 ="<p>&nbsp;</p>
																<p>&nbsp;</p>
																<p class=\"text-center\"><strong>".$pmsg[24]."</strong></p>
																<p>&nbsp;</p>
																<p>&nbsp;</p>
																<p>&nbsp;</p>
																<form method=\"post\" action=\"#\">
																	<p class=\"aligncenter\"><input class=\"button-gb\" title=\"".$pmsg[25]."\" type=\"button\" value=\"".$pmsg[25]."\" onclick=\"self.location.href='pic.upload.php?action=step1'\" /></p>
																	<p>&nbsp;</p>
																	<p class=\"aligncenter\"><input class=\"button-gb\" title=\"".$pmsg[26]."\" type=\"button\" value=\"".$pmsg[26]."\" onclick=\"window.close();\" /></p>
																</form>
																<br />
																";
												}
										}
									else
										{
											$ausgabe05 = "<p>&nbsp;</p>
														<p class=\"text-center red\"><strong>".$error_title."</strong></p><br />
														<p>&nbsp;</p>
														<p class=\"text-center\"><strong>".$pmsg[15]."</strong></p>
														<p class=\"text-center\">(".$pmsg[27].")</p>
														<br />
														<form method=\"post\" action=\"?action=step3\">
															<p class=\"aligncenter\"><input type=\"text\" class=\"insert\" name=\"description\" autofocus=\"autofocus\" autocomplete=\"off\" size=\"40\" maxlenght=\"60\" value=\"";
															
														        if (isset($_POST['description']) AND $_POST['description'] != "") {
														            $ausgabe05 .= stripslashes(htmlspecialchars(strip_tags($_POST['description']), ENT_QUOTES));
														        }
		        												else {
		        													$ausgabe05 .= stripslashes(htmlspecialchars(strip_tags($last_title), ENT_QUOTES));
		        												}
															
													$ausgabe05 .="\" /></p>
															<p class=\"dsR3\"><input type=\"hidden\" name=\"send\" value=\"send\" /><input type=\"hidden\" name=\"accept\" value=\"1\" /><input type=\"hidden\" name=\"woher\" value=\"".$woher."\" /></p>
															<p>&nbsp;</p>
															<p>&nbsp;</p>
															<p class=\"aligncenter\"><input class=\"button-gb\" title=\"".$fmsg[55]."\" type=\"submit\" name=\"send_title\" value=\"".$fmsg[55]."\" /></p>
														</form>
														<br />
														";
										}
								}
							else
								{
									$ausgabe05 ="<p>&nbsp;</p>
												<p>&nbsp;</p>
												<p class=\"text-center\"><strong>".$pmsg[15]."</strong></p>
												<p class=\"text-center\">(".$pmsg[27].")</p>
												<br />
												<form method=\"post\" action=\"?action=step3\">
													<p class=\"aligncenter\"><input type=\"text\" class=\"insert\" name=\"description\" autofocus=\"autofocus\" autocomplete=\"off\" size=\"40\" maxlenght=\"60\" value=\"";
													
												        if (isset($_POST['description']) AND $_POST['description'] != "") {
												            $ausgabe05 .= stripslashes(htmlspecialchars(strip_tags($_POST['description']), ENT_QUOTES));
												        }
		        										else {
		        											$ausgabe05 .= stripslashes(htmlspecialchars(strip_tags($last_title), ENT_QUOTES));
		        										}
															
											$ausgabe05 .="\" /></p>
													<p class=\"dsR3\"><input type=\"hidden\" name=\"send\" value=\"send\" /><input type=\"hidden\" name=\"accept\" value=\"1\" /><input type=\"hidden\" name=\"woher\" value=\"".$woher."\" /></p>
													<p>&nbsp;</p>
													<p>&nbsp;</p>
													<p class=\"aligncenter\"><input class=\"button-gb\" title=\"".$fmsg[55]."\" type=\"submit\" name=\"send_title\" value=\"".$fmsg[55]."\" /></p>
												</form>
												<br />
												";
									}
						}
					else
						{
							$ausgabe05 ="<p class=\"text-center\"><strong>".$pmsg[4]."</strong></p>
										<br />
										".$pmsg[16]."
										<br />
										<br />
										<div class=\"aligncenter\">
										<form action=\"?action=step1\" method=\"post\">
											<p><button name=\"zurück\" type=\"button\" class=\"button-gb\" title=\"".$fmsg[4]."\" value=\"".$fmsg[4]."\" onclick=\"location.href='pic.upload.php?action=step1'\">".$fmsg[4]."</button></p>
										</form>
										</div>
										<div class=\"aligncenter\">
											<br />
											<form action=\"#\" method=\"post\">
												<p><input class=\"button-gb\" title=\"".$pmsg[3]."\" type=\"button\" value=\"".$pmsg[3]."\" onclick=\"window.close();\" /></p>
											</form>		
										</div>";
						}
				}
				
			else
				{
					$ausgabe05 ="<p class=\"text-center\"><strong>".$pmsg[4]."</strong></p>
								<br />
								".$pmsg[16]."
								<br />
								<br />
								<div class=\"aligncenter\">
								<form action=\"?action=step1\" method=\"post\">
									<p><button name=\"zurück\" type=\"button\" class=\"button-gb\" title=\"".$fmsg[4]."\" value=\"".$fmsg[4]."\" onclick=\"location.href='pic.upload.php?action=step1'\">".$fmsg[4]."</button></p>
								</form>
								</div>
								<div class=\"aligncenter\">
									<br />
									<form action=\"#\" method=\"post\">
										<p><input class=\"button-gb\" title=\"".$pmsg[3]."\" type=\"button\" value=\"".$pmsg[3]."\" onclick=\"window.close();\" /></p>
									</form>		
								</div>";
				}
		}
		
	header("X-Robots-Tag: noindex");
    header("content-type: text/html; charset=\"".$encoding."\"" );
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Pragma: no-cache");
	echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
	<!--[if IE 9]><html id=\"ie9\" dir=\"ltr\" lang=\"".$lang_short."\"><![endif]-->
	<!--[if IE 8]><html id=\"ie8\" dir=\"ltr\" lang=\"".$lang_short."\"><![endif]-->
	<!--[if IE 7]><html id=\"ie7\" dir=\"ltr\" lang=\"".$lang_short."\"><![endif]-->
	<!--[if !(IE 7) | !(IE 8) | !(IE 9) ]><!-->
	<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"".$lang_short."\" lang=\"".$lang_short."\">
	<!--<![endif]-->
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=".$encoding."\" />
	<meta name=\"viewport\" content=\"width=device-width\" />
	<link href=\"".$url."gbook.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
	<style type=\"text/css\">body{font-family:arial,Verdana,Helvetica;font-size:13px;color:#000000;background-color:#eeeeee;}li{margin-bottom:15px;}</style>
	<title>".$properties['guestbook_title']."</title>
	</head>
	";

	if(!$no_upload['images_in_entries'] OR !$no_upload['guestbook_status'] OR $sperre)	{
		echo "<meta http-equiv=\"Refresh\" content=\"0; url=".$url."\">";
		die();
	}

	echo"<body>
		<div id=\"upload\">
		";
			echo $ausgabe01;
			echo $ausgabe02;
			echo $ausgabe03;
			echo"<div class=\"text-center red\">".$fehler."</div>";
			echo $ergebnis_upload;
			echo $ausgabe04;
			echo $ausgabe05;
	echo"
		</div>
	</body>
	</html>";
?>