<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

    require_once("includes/functions.inc.php");

	$sql_properties = $gbook->query("SELECT `bbcode`, `guestbook_status` FROM `".$table."_properties`");
	$properties    = $sql_properties->fetch_assoc();

    $count_entries = "";
	$error_msg = "";

    require_once("includes/lang.inc.php");

    (isset($_POST['name']) ? ($_POST['name'] = stripslashes(htmlspecialchars(strip_tags($_POST['name']), ENT_QUOTES))) : ($_POST['name'] = ""));
    (isset($_POST['url']) ? ($_POST['url'] = stripslashes(htmlspecialchars(strip_tags($_POST['url']), ENT_QUOTES))) : ($_POST['url'] = ""));
	(isset($_POST['email']) ? ($_POST['email'] = stripslashes(htmlspecialchars(strip_tags($_POST['email']), ENT_QUOTES))) : ($_POST['email'] = ""));
	
	header("Content-Type: text/html;charset=\"".$encoding."\"");
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Pragma: no-cache");
	header("X-Robots-Tag: noindex");

    echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
	<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"".$lang_short."\" lang=\"".$lang_short."\">
	<head>
	<meta http-equiv=\"content-type\" content=\"text/html;charset=".$encoding."\" />
	<meta name=\"viewport\" content=\"width=device-width\" />
	<link href=\"".$url."gbook.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
	<style type=\"text/css\">body{font-family:arial,Verdana,Helvetica;font-size:13px;color:#000000;background-color:#eeeeee;}</style>
	<title>".$fmsg[296]."</title>
	<meta name=\"robots\" content=\"noindex, nofollow\" />
	</head>
	<body>
		<div>";
		
	if ($properties['bbcode'] && $properties['guestbook_status'])
	    {
			if (isset($_GET['action']))
				{
					$_GET['action'] = $gbook->real_escape_string($_GET['action']);
	
					if (!preg_match("/^[_\a-z]*$/is", $_GET['action']))
						{
							$_GET['action'] = "step1";
						}
				}
			else
				{
					$_GET['action'] = "step1";
				}
			
		    switch($_GET['action'])
				{
				    case "step1";
			        $_GET['action'] = "step1";
			        break;
		
				    case "step2";
			        $_GET['action'] = "step2";
			        break;
		
				    case "step3";
			        $_GET['action'] = "step3";
			        break;
		
				    case "step4";
			        $_GET['action'] = "step4";
			        break;
		
				    case "step4";
			        $_GET['action'] = "step4";
			        break;
		
				    case "step5";
			        $_GET['action'] = "step5";
			        break;
		
				    default:
			        $_GET['action'] = "step1";
			        break;
				}

			if ($_GET['action'] == "step1")
				{
					echo"
					<p>&nbsp;</p>
					<p class=\"text-center\"><strong>".$fmsg[297]."</strong><br /><br />
					<span class=\"text-center size-10\">".$fmsg[298]."</span><br /></p>
					<p>&nbsp;</p>
					<form action=\"".$url."bbcodes.php?action=step2\" method=\"post\">
						<table style=\"width:300px\" class=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
							<tr>
								<td align=\"center\">
									<input class=\"insert\" type=\"text\" name=\"name\" autofocus=\"autofocus\" size=\"31\" value=\"";
									
										if (isset($_POST['name']) AND $_POST['name'] != "")
											{
												echo $_POST['name'];
											}
									echo "\" />
								</td>
							</tr>
							<tr>
					 			<td align=\"center\">
					 				<p>&nbsp;</p>
					 				<p><input class=\"button-gb\" type=\"submit\" title=\"".$fmsg[14]."\" name=\"send01\" value=\"".$fmsg[14]."\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					 				<input class=\"button-gb\" type=\"button\" title=\"".$fmsg[269]."\" name=\"abbruch\" value=\"".$fmsg[269]."\" onclick=\"window.close();\" />
					 				<input type=\"hidden\" name=\"link_name\" value=\"".$_POST['name']."\" /></p>
					 			</td>
							</tr>
						</table>
				    </form>";
				}
			if ($_GET['action'] == "step2")
				{
					if ($_POST['name'] == "")
						{
							echo"<p>&nbsp;</p>
								<p>&nbsp;</p>
								<p class=\"text-center\"><strong>".$fmsg[302]."</strong></p>
								<meta http-equiv=\"Refresh\" content=\"2; url=".$url."bbcodes.php?action=step1\">";
						}
					else
						{
							echo"<p>&nbsp;</p>
							<p>&nbsp;</p>
							<p class=\"text-center\"><strong>".$fmsg[299]."</strong><br />
							<span class=\"text-center size-10\">".$fmsg[303]."</span></p>
							<p>&nbsp;</p>
							<form action=\"".$url."bbcodes.php?action=step3\" method=\"post\">
								<table style=\"width:300px\" class=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
									<tr>
										<td align=\"center\">
											<input class=\"insert\" type=\"text\" name=\"url\" autofocus=\"autofocus\" size=\"31\" maxlength=\"80\" value=\"";
											
												if (isset($_POST['url']) AND $_POST['url'] != "")
													{
														echo $_POST['url'];
													}
											echo "\" />
											
										</td>
									</tr>
									<tr>
										<td align=\"center\">
											<p>&nbsp;</p>
											<p><input class=\"button-gb\" type=\"submit\" title=\"".$fmsg[14]."\" name=\"send02\" value=\"".$fmsg[14]."\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					 							<input class=\"button-gb\" type=\"button\" title=\"".$fmsg[269]."\" name=\"abbruch\" value=\"".$fmsg[269]."\" onclick=\"window.close();\" />
												<input type=\"hidden\" name=\"name\" value=\"".$_POST['name']."\" /><input type=\"hidden\" name=\"link_url\" value=\"".$_POST['url']."\" /></p>
										</td>
									</tr>
								</table>
							</form>";
						}
				}
			if ($_GET['action'] == "step3")
				{
					$link_name = stripslashes(htmlspecialchars(strip_tags($_POST['name']), ENT_QUOTES));
					$link_url = stripslashes(htmlspecialchars(strip_tags($_POST['url']), ENT_QUOTES));
					
					$count_http	= substr_count(strtolower($link_url), 'http://', 0);
					$count_https = substr_count(strtolower($link_url), 'https://', 0);
					
					if ($count_http == 0 && $count_https == 0)
						{
							$link_url = "http://".$link_url."";
						}
		
					include("includes/idna_convert.class.php");      
						
					$IDN = new idna_convert();     
					$output = $IDN->encode($link_url);
								      
					if ($output == "")
						{
							echo "<p>&nbsp;</p>
								<p>&nbsp;</p>
								<p class=\"text-center red\"><strong>- ".$emsg[53]."</strong></p>
								<p>&nbsp;</p>
								<form action=\"#\" method=\"post\">
									<p class=\"aligncenter\"><button name=\"back\" type=\"button\" class=\"button-gb\" title=\"".$fmsg[4]."\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='bbcodes.php?action=step1'\">".$fmsg[4]."</button></p>
								</form>";
						}
					elseif (!validate_url($output))
						{
							echo "<p>&nbsp;</p>
								<p>&nbsp;</p>
								<p class=\"text-center red\"><strong>- ".$emsg[54]."</strong></p>
								<p>&nbsp;</p>
								<form action=\"#\" method=\"post\">
									<p class=\"aligncenter\"><button name=\"back\" type=\"button\" class=\"button-gb\" title=\"".$fmsg[4]."\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='bbcodes.php?action=step1'\">".$fmsg[4]."</button></p>
								</form>";
						}
					else
						{
						    echo"
						    <p>&nbsp;</p>
						    <p>&nbsp;</p>
							<p class=\"text-center\"><strong>".$fmsg[300]."</strong></p>
							<p>&nbsp;</p>
							<form action=\"".$url."bbcodes.php\" method=\"post\">
								<table style=\"width:300px\" class=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
									<tr>
							 			<td align=\"center\">
							 				<input class=\"button-gb\" type=\"submit\" title=\"".$fmsg[300]."\" name=\"send03\" value=\"".$fmsg[16]."\" onclick=\"opener.insert(' [url=".$link_url."]".$link_name."[/url] ','');window.close();\" />
							 			</td>
									</tr>
								</table>
						    </form>";
				    	}
				}
			if ($_GET['action'] == "step4")
				{
				    echo"
						    <p>&nbsp;</p>
							<p class=\"text-center\"><strong>".$fmsg[301]."</strong></p>
							<p>&nbsp;</p>
							<form action=\"".$url."bbcodes.php?action=step5\" method=\"post\">
								<table style=\"width:300px\" class=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
									<tr>
										<td align=\"center\">
											<input class=\"insert\" type=\"text\" name=\"email\" autofocus=\"autofocus\" size=\"31\" maxlength=\"50\" value=\"";
											
												if (isset($_POST['email']) AND $_POST['email'] != "")
													{
														echo $_POST['email'];
													}
											echo "\" />
										</td>
									</tr>
									<tr>
							 			<td align=\"center\">
							 				<p>&nbsp;</p>
							 				<p><input class=\"button-gb\" type=\"submit\" title=\"".$fmsg[14]."\" name=\"send04\" value=\"".$fmsg[14]."\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					 						<input class=\"button-gb\" type=\"button\" title=\"".$fmsg[269]."\" name=\"abbruch\" value=\"".$fmsg[269]."\" onclick=\"window.close();\" />
							 				<input type=\"hidden\" name=\"email_name\" value=\"".$_POST['email']."\" /></p>
							 			</td>
									</tr>
								</table>
							</form>";
				}
		 	if ($_GET['action'] == "step5")
				{
					$email = stripslashes(htmlspecialchars(strip_tags($_POST['email']), ENT_QUOTES));
		
					if ($_POST['email'] == "")
						{
							echo"<p>&nbsp;</p>
								<p>&nbsp;</p>
								<p class=\"text-center\"><strong>".$fmsg[305]."</strong></p>
								<meta http-equiv=\"Refresh\" content=\"2; url=".$url."bbcodes.php?action=step4\">";
						}
		
					elseif (!validate_mail($_POST['email']))
						{
							echo "<p>&nbsp;</p>
								<p>&nbsp;</p>
								<p class=\"text-center red\"><strong>- ".$emsg[2]."</strong></p>
								<p>&nbsp;</p>
								<form action=\"#\" method=\"post\">
									<p class=\"aligncenter\"><button name=\"back\" type=\"button\" class=\"button-gb\" title=\"".$fmsg[4]."\" value=\"".$fmsg[4]."\" onclick=\"self.location.href='javascript:history.back()'\">".$fmsg[4]."</button></p>
								</form>";
						}
		
					else
						{
						    echo"
						    <p>&nbsp;</p>
						    <p>&nbsp;</p>
							<p class=\"text-center\"><strong>".$fmsg[300]."</strong></p>
							<p>&nbsp;</p>
							<form action=\"".$url."bbcodes.php?action=step5\" method=\"post\">
								<table style=\"width:300px\" class=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
									<tr>
							 			<td align=\"center\">
							 				<input class=\"button-gb\" type=\"submit\" title=\"".$fmsg[300]."\" name=\"send05\" value=\"".$fmsg[16]."\" onclick=\"opener.insert(' [email=".$email."] ','');window.close();\" />
							 			</td>
									</tr>
								</table>
						    </form>";
						}
				}
		}
	else
		{
			echo"
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p class=\"text-center\"><strong>".$fmsg[335]."</strong></p>";
		}
   
    echo"
	</div>
	</body>
	</html>";
?>