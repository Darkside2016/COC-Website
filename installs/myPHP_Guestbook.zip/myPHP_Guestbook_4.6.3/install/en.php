<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

    // Neue Variablen

    $version    = "V 4.6.3";
    $encoding   = "utf-8";
    $language   = "English";
    $lang_short = "en";
    $flag		= "en";
    
    //Intro
    
    $stmsg[0] = 'Installation and update tool to the database binding SQL<br />from myPHP Guestbook '.$version.'';
    $stmsg[1] = '<p>With this file you can carry out either a complete first or new installation of myPHP Guestbook or just an update of one of the former guestbook versions from 3.0 on the most topical version '.$version.'.</p>
<p>Before you start, read and obey please carefully the instructions in the ReadMe file.</p>
<p>For a <strong>first installation or new installation</strong> you should have uploaded all files on your webspace, which are in the downloaded guestbook folder from "www.php-guestbook.de".</p>
<p>For an <strong>update</strong> you should have uploaded also all the new files from the package on your webspace, <strong style="color:red">with the exception of the file "config.inc.php"</strong> in the folder "includes" and the tables in the database, how they were required for the guestbook versions 3.x, must still exist.</p>';
    $stmsg[2] = 'Please, choose:';
    $stmsg[3] = 'I wish a complete new installation of myPHP Guestbook '.$version.':';
    $stmsg[4] = 'My database is at least on the state of one of the versions 3.x.<br />Hence, I would want only the database update on version '.$version.':';
    $stmsg[5] = 'complete installation myPHP Guestbook '.$version.'';
    $stmsg[6] = 'Database-Update for myPHP Guestbook '.$version.'';
    $stmsg[7]  = '';
    $stmsg[8]  = '';
    $stmsg[9]  = '';
    $stmsg[10] = '';
    
    // Installer - Phrasen

    $imsg[0]  = 'myPHP Guestbook installation tool';
    $imsg[1]  = 'URL';
    $imsg[2]  = 'Document Root'; 
    $imsg[3]  = 'The URL and the server path of your myPHP Guestbook installation on your server.<br />Do not change, please.';
    $imsg[4]  = 'Database Host';
    $imsg[5]  = 'Hostname of your MySQL database.<br />Often localhost, some hosters use separate database server.';
    $imsg[6]  = 'Database Username';
    $imsg[7]  = 'Database password';
    $imsg[8]  = 'Databasename';
    $imsg[9]  = 'Username, password and databasename of your database<br />(Your hoster will tell you this data.)';
    $imsg[10]  = 'Database-Prefix';
    $imsg[11]  = 'The Prefix from the myPHP-Guestbook-Tables in database.';
    $imsg[12]  = 'Language';
    $imsg[13]  = 'The language to be used by myPHP-Guestbook<br />(German, English, Portuguese).<br /><strong>The choices made here also applies to the rest of the installation (German - English).</strong>';
//    $imsg[13]  = 'The language to be used by myPHP-Guestbook<br />(German, English, Portuguese, Dutch).<br /><strong>The choices made here also applies to the rest of the installation (German - English).</strong>';
    $imsg[14]  = 'Email address:';
    $imsg[15]  = 'The guestbook-admin email-address';
    $imsg[16]  = 'Admin username:';
    $imsg[17]  = 'Your Admin username. <strong style="color:red;">For safety, please change individually!</strong>';
    $imsg[18]  = 'Admin-Password';
    $imsg[19]  = 'Your Admin-Password.';
    $imsg[20]  = 'Folder and file tests:';
    $imsg[21]  = 'available';
    $imsg[22]  = 'writable';
    $imsg[23]  = 'not writable';
    $imsg[24]  = 'not available';
    $imsg[25]  = 'GD Support:';
    $imsg[26]  = 'BC Math Support:';
    $imsg[27]  = 'Complete';
    $imsg[28]  = 'Cannot connect to ';
    $imsg[29]  = 'with the supplied username and password';
    $imsg[30]  = 'Go Back';
    $imsg[31]  = 'Step 1';
    $imsg[32]  = 'Writing configuration file and review the database connection ...<br /><br />';
    $imsg[33]  = ' <strong style="color:green; font-size:16px;">Complete!</strong><br /><br />Now to '; 
    $imsg[34]  = ' Step 2';
    $imsg[35]  = 'Installation complete now.<br /><strong style="color:red;">Remove the install folder from your server!</strong>';
    $imsg[36]  = 'go to Admin-Control-Panel';
    $imsg[37]  = 'go to Guestbook Frontend';
    $imsg[38]  = 'or';
    $imsg[39]  = 'Install';
    $imsg[40]  = 'Cannot select database';
    $imsg[41]  = 'MySQLi Support:'; 
    $imsg[42]  = 'Cancel installation, the necessary MySQLi extension is not available';
    $imsg[43]  = 'GZip Support';
    $imsg[44]  = 'The necessary MySQLi extension is not available.';
    $imsg[45]  = 'Please, check the availability of MySQLi with "phpinfo(INFO_MODULES)"';
    $imsg[46]  = 'Unfortunately, their browser can indicate no embedded Frames.<br />They can call the embedded side about the following link:';
    $imsg[47]  = 'The Guestbook-Installer cannot provide the config file. Please, give the necessary data by hand in config.inc.php.';
    $imsg[48]  = 'After this is finished, you can continue with ';
    $imsg[49]  = 'The Zip module does not seem to be available.<br />The installation can be carried out, nevertheless, however, backups are not compressed';
    $imsg[50]  = 'The module GDLIB does not seem to be available.<br />The installation can be carried out, nevertheless, however, no Foto-Upload is possible with automatic dimensions adaptation.';
    $imsg[51]  = 'Please, upload the folders from the download package by using FTP.';
    $imsg[52]  = 'Read please the segment: "Special folder rights" in the enclosed "ReadMe. pdf".';
    $imsg[53]  = 'The time zone of your<br />Internet presence';        
    $imsg[54]  = 'Select here your homeland after whose time zone then the entries are stored in the guestbook.<br /><br />Because of changes after installation , see the "ReadMe.pdf"';        
    $imsg[55]  = 'You have not filled all the fields';        
    $imsg[56]  = '';        
    $imsg[57]  = '';        
        
    $emsg[0]  = 'You have not filled all the fields';

    $fmsg[196]  = 'Give now your user name and your password with which you want to log in in future according to the Admin-Kontrollpanel.<br />E-mail address is required, so that you are informed above new guestbook entries or photo-uploads and backups can be transmitted.';
    
	//Database Update Stand 4.6.2, 4.6.3
	
	$dbmsg[0]  = 'Now your database is on the state to the use for the Script myPHP Guestbook '.$version.'.';
	$dbmsg[1]  = 'A mistake has appeared.<br />Please, get in touch with me: <a href="mailto:post@php-guestbook.de">post@php-guestbook.de</a></a>';
	$dbmsg[2]  = 'Database extension for myPHP-Guestbook';
	$dbmsg[3]  = '<p>This script is tuned to the database tables and their entries, as they exist after installing myPHP-Guestbook from one of the versions <strong>3.x</strong> on '.$version.' to change. <strong>The script is not suitable for the older guestbook versions 1.x and 2.x !</strong></p>';
	$dbmsg[4]  = '<p><strong>If you have previously used a version 4.6.1 or less:</strong> With this script the database will be expanded to your guestbook. That means, that additional tables will be created, as well as already existing tables will be rewritten with the addition of new columns. With an update of a version smaller than 4.6.0, three new columns are added to the table with the guestbook entries, otherwise it remains unchanged in its structure, thus retaining all previous entries under normal circumstances after the update.</p>';
	$dbmsg[5]  = '<p>The intervention in an existing database, however, always involves the potential risk of data loss or other operational problems. Therefore, please read the "ReadMe" file and note the following:</p>';
	$dbmsg[6]  = 'I take no responsibility for any loss of data or otherwise malfunction of any kind by using this script. If you have in this regard concerns, you should break off and use the version, that you have!';
	$dbmsg[7]  = 'The script has been tested several times and runs on an Apache server under PHP 5.5.x , PHP 5.6.x and PHP 7.0.x without problems.';
	$dbmsg[8]  = 'To care for all cases, please backup the guestbook entries before the start of the script, and save these BackUp sure!';
	$dbmsg[9]  = 'If you have myPHPAdmin, MySQLDumper or a similar program, you should make a complete backup of the existing database .';
	$dbmsg[10] = '';
	$dbmsg[11] = '<p>Even with the call of the script it was examined whether the necessary database connection can be established and whether the equally indispensable expansion MySQLi is available in your PHP configuration. It was found that ...</p>';
	$dbmsg[12] = '.. the MySQLi extension of PHP is not available on your server, which is imperative for a function of guestbook script.';
	$dbmsg[13] = 'Before you have not discussed with your provider, you must cancel at this point.';
	$dbmsg[14] = '.. MySQLi is available on your server, but ..';
	$dbmsg[15] = '.. no connection to the database exists. The update is not possible.';
	$dbmsg[16] = 'Check the file "config.inc.php" in the includes folder.';
	$dbmsg[17] = '.. everything is in order; the database connection is made and the automatic check has shown that the MySQLi extension of PHP is available on your server.';
	$dbmsg[18] = 'Make sure now, which version from <span style="font-style:italic;">myPHP Guestbook</span> you have installed topically and select then from the different database-updates what you need. - Choose carefully! The choice of a "wrong" database-update can lead to problems. Especially if you already have installed a guestbook version 4.4.0 or later and now you use incorrectly one of the first subsequent database updates, that are determined for guestbook versions through 4.3 and smaller, this would, inter alia, lead to a loss of all entries in the table "_pictures".';
	$dbmsg[19] = 'Here we go';
	$dbmsg[20] = 'I currently have one of the myPHP-Guestbook versions';
	$dbmsg[21] = 'Adapt database from';
	$dbmsg[22] = 'on';
	$dbmsg[23] = 'Of the existing tables are deleted and rewritten:';
	$dbmsg[24] = 'additional tables are anew put on.';
	$dbmsg[25] = 'Of the existing tables are extended by new columns:';
	$dbmsg[26] = 'In the table "* _entries" the status of the entries is put on "1".';
	$dbmsg[27] = 'The available entries in the old table "* _properties" for "Admin email", "language", "password" and "user\'s name" are taken over, the rest is anew written.';
	$dbmsg[28] = 'By the available entries in the old table "* _properties" are changed: "Title of the guestbook", "Maximum word length", "Number of links at the scrolling function" and the examination on "Minimum / maximum entry length" is activated, the other pre-settings are preserved.';
	$dbmsg[29] = 'to';
	$dbmsg[30] = 'from';
	$dbmsg[31] = 'installed.<br />I now want to update to the current version';
	$dbmsg[32] = 'By the available entries in the old table "* _properties" are changed: "Title of the guestbook" and "Maximum word length", the other pre-settings are preserved.';
	$dbmsg[33] = 'I currently have the myPHP-Guestbook version';
	$dbmsg[34] = 'By the available entries in the old table "* _properties" is changed: "Title of the guestbook", the other tables and pre-settings are preserved.';
	$dbmsg[35] = 'adapt database';
	$dbmsg[36] = 'An error has occurred.';
	$dbmsg[37] = 'Please contact me';
	$dbmsg[38] = 'Your database is now up to the state to use for the script myPHP Guestbook';
	$dbmsg[39] = 'Select the <span style="font-style:italic;">myPHP Guestbook</span> Version, that you have installed and click on the button below.';
	$dbmsg[40] = 'You have made no selection.';
	$dbmsg[41] = 'Back to start page';
	$dbmsg[42] = 'I would like to update on '.$version.' and have installed currently the following version:';
	$dbmsg[43] = 'Adapt database tables to '.$version.'.';
	$dbmsg[44] = '<strong>Please note: For an update from Version 4.6.2 to '.$version.' this script is not needed, because no changes are necessary at the database.</strong>';
	$dbmsg[45] = '';
	
?>