<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

	isset($_POST['language']) ? $install_language = $_POST['language'] : $install_language = "de";
	include("".$install_language.".php");
	$result = '';
	$error_db = '<div style="text-align:justify;padding:8px;">'.$dbmsg[39].'</div>';
	
	if (extension_loaded("mysqli"))
		{
			include '../includes/config.inc.php';
			$gbook = new mysqli($host, $username, $password, $database);
			$gbook->set_charset('utf8');
		}

	$_POST['choose_version'] = (isset($_POST['choose_version'])) ? $_POST['choose_version'] : '';

	if (isset($_POST['send_options']) && $_POST['choose_version'] == '') {
		$error_db = '<p class="aligncenter"><strong style="color:red;">'.$dbmsg[40].'</strong></p>';
	}
	else {
		if ((isset($_POST['send_options']) && isset($_POST['choose_version'])) && $_POST['choose_version'] == 1)
			{
				$update_properties = $gbook->query("SELECT `admin_email`,`language`,`password`,`username` FROM `".$table."_properties`");
				list($oldEmail,$oldLang,$oldAdminPass,$oldAdminName) = $update_properties->fetch_row();
			
				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_forbidden_ip`;";
				$sql[] = "CREATE TABLE `" . $table . "_forbidden_ip` (
						`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
						`ip` varchar(40) NOT NULL, 
						`datum` varchar(10) NOT NULL, 
						`uhrzeit` varchar(5) NOT NULL,
						`www_time` int(11) NOT NULL,
						`no_del` tinyint(1) NOT NULL);";
						
				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_spam`;";
				$sql[] = "CREATE TABLE `" . $table . "_spam` (
			            `id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY,
			            `spamword` varchar(25) NOT NULL);";
						
				$sql[] = "INSERT INTO `" . $table . "_spam` (`id`, `spamword`) VALUES ('', 'viagra'),('', 'porn'),('', 'erotik'),('', 'sex '),('', 'massage'),('', 'bitcoin'),('', 'casino'),('', 'mail.ru'),('', 'yandex.ru'),('', 'nice site'),('', 'good site'),('', 'good project'),('', 'cool site'),('', 'good design'),('', 'perfectly site'),('', 'very good internet site'),('', 'beautiful website'),('', 'like your site design'),('', 'cheap goods'),('', 'special offer'),('', 'louis vuitton'),('', 'cheap replica'),('', 'designer watches'),('', 'tramadol'),('', 'alprazolam'),('', 'amoxcillin')";
						
				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_backup`;";
				$sql[] = "CREATE TABLE `" . $table . "_backup` (
						`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY,
						`dateiname` varchar(30) NOT NULL,
						`datum` varchar(10) NOT NULL,
						`uhrzeit` varchar(5) NOT NULL);";
						
				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_statistic`;";
				$sql[] = "CREATE TABLE `" . $table . "_statistic` (
						`date` varchar(15) NOT NULL,
						`zeit` int(15) NOT NULL,
						`hits` mediumint(7) NOT NULL,
						`id` smallint(5) NOT NULL AUTO_INCREMENT PRIMARY KEY,
						`visits` mediumint(7) NOT NULL) ;";

				$sql[] = "INSERT INTO `" . $table . "_statistic` VALUES ('".date("d.m.Y")."', '0', '0', '1', '0');";

				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_pictures`;";
				$sql[] = "CREATE TABLE `" . $table . "_pictures` (
						`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
						`ip` varchar(40) NOT NULL, 
						`pic_name` varchar(20) NOT NULL UNIQUE, 
						`width` smallint(5) NOT NULL,
						`height` smallint(5) NOT NULL,
						`title` varchar(60) NOT NULL,
						`date` varchar(10) NOT NULL,
						`time` varchar(5) NOT NULL) ;";

				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_properties`;";
				$sql[] = "CREATE TABLE `" . $table . "_properties` (`admin_email` varchar(50) NOT NULL, `antiflood_ban` smallint(5) NOT NULL, `bbcode` tinyint(1) NOT NULL, `check_email` tinyint(1) NOT NULL, `check_homepage` tinyint(1) NOT NULL, `check_icq` tinyint(1) NOT NULL, `deactivate_html` tinyint(1) NOT NULL, `clean_backup` tinyint(1) NOT NULL, `default_style` tinyint(3) NOT NULL, `default_template` tinyint(3) NOT NULL, `entries_per_site` tinyint(3) NOT NULL, `entry_length_limit` tinyint(1) NOT NULL, `entry_length_maximum` mediumint(7) NOT NULL, `entry_length_minimum` tinyint(3) NOT NULL, `guestbook_status` tinyint(1) NOT NULL, 
`no_spam_entries` tinyint(1) NOT NULL, `spam_marker` tinyint(2) NOT NULL, `no_spam_links` tinyint(1) NOT NULL, `max_links` tinyint(2) NOT NULL, `guestbook_title` varchar(50) NOT NULL, `images_in_entries` tinyint(1) NOT NULL, `language` varchar(10) NOT NULL, `links_in_sitefunction` tinyint(3) NOT NULL, `max_word_length` tinyint(3) NOT NULL, `notification_entries` tinyint(1) NOT NULL, `password` varchar(32) NOT NULL, `release_entries` tinyint(1) NOT NULL, `show_ip` tinyint(1) NOT NULL, `smilies` tinyint(1) NOT NULL, `thanks_email` tinyint(1) NOT NULL, `statistic` tinyint(1) NOT NULL, `statistic_ban` smallint(5) NOT NULL, `quote_func` tinyint(1) NOT NULL, `username` varchar(15) NOT NULL);";
				
				$sql[] = "INSERT INTO `" . $table . "_properties` VALUES ('".$oldEmail."', '10', '1', '0', '0', '1', '1', '0', '1', '1', '10', '1', '1500', '10', '1', '1', '5', '1', '2', 'myPHP-Guestbook ".$version."', '0', '".$oldLang."', '9', '36', '1', '".$oldAdminPass."', '0', '0', '1', '1', '1', '720', '1', '".$oldAdminName."');";

				$sql[] = "UPDATE `" . $table . "_entries` SET `status` = '1'";

				$queries = count($sql);

				for ($i = 0; $i < $queries; $i++)
					{
						$result01 = $gbook->query($sql[$i]); 
					}
						
				flush();
									
				if (!$result01)
					{
						echo'<div class="aligncenter">
							<p>&nbsp;</p>
							<p><strong style="color:red;">'.$dbmsg[36].' Code: 01.<br />'.$dbmsg[37].': <a href="mailto:post@php-guestbook.de">post@php-guestbook.de</a></strong></p>
							<p>&nbsp;</p>
							<form method="post" action="'.getdomainpath().'/install/index.php">
								<p><input class="gb-button" type="submit" value="'.$dbmsg[41].'" /></p>
							</form>
							</div>';
						die();
					}
			}
			
		if ((isset($_POST['send_options']) && isset($_POST['choose_version'])) && $_POST['choose_version'] == 2)
			{
				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_pictures`;";
				$sql[] = "CREATE TABLE `" . $table . "_pictures` (
						`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
						`ip` varchar(40) NOT NULL, 
						`pic_name` varchar(20) NOT NULL UNIQUE, 
						`width` smallint(5) NOT NULL,
						`height` smallint(5) NOT NULL,
						`title` varchar(60) NOT NULL,
						`date` varchar(10) NOT NULL,
						`time` varchar(5) NOT NULL) ;";

				$sql[] = "ALTER TABLE `" . $table . "_properties` ADD COLUMN `quote_func` tinyint(1) NOT NULL AFTER `statistic_ban`";

				$sql[] = "UPDATE `" . $table . "_properties` SET `entry_length_limit` = '1', `entry_length_maximum` = '1500', `entry_length_minimum` = '10', `links_in_sitefunction` = '9', `quote_func` = '1'";

				$queries = count($sql);

				for ($k = 0; $k < $queries; $k++)
					{
						$result02 = $gbook->query($sql[$k]); 
					}
						
				flush();
									
				if (!$result02)
					{
						echo'<div class="aligncenter">
							<p>&nbsp;</p>
							<p><strong style="color:red;">'.$dbmsg[36].' Code: 02.<br />'.$dbmsg[37].': <a href="mailto:post@php-guestbook.de">post@php-guestbook.de</a></strong></p>
							<p>&nbsp;</p>
							<form method="post" action="'.getdomainpath().'/install/index.php">
								<p><input class="gb-button" type="submit" value="'.$dbmsg[41].'" /></p>
							</form>
							</div>';
						die();
					}
			}

		if ((isset($_POST['send_options']) && isset($_POST['choose_version'])) && ($_POST['choose_version'] == 1 || $_POST['choose_version'] == 2 || $_POST['choose_version'] == 3))
			{
				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_upload`;";
				$sql[] = "CREATE TABLE `" . $table . "_upload` (
						`id` tinyint(1) NOT NULL AUTO_INCREMENT PRIMARY KEY,
						`max_filesize` tinyint(1) NOT NULL,
						`max_width` smallint(2) NOT NULL,
						`max_height` smallint(2) NOT NULL,
						`jpg_quality` tinyint(1) NOT NULL,
						`upload_max` tinyint(1) NOT NULL);";

				$sql[] = "INSERT INTO `" . $table . "_upload` VALUES ('1', '2', '460', '460', '75', '2');";
				   
				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_upload_counter`;";
				$sql[] = "CREATE TABLE `" . $table . "_upload_counter` (`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY, `ip` varchar(40) NOT NULL, `upload_time` int(15) NOT NULL, `counter` tinyint(1) NOT NULL) ;";

				$queries = count($sql);

				for ($l = 0; $l < $queries; $l++)
					{
						$result03 = $gbook->query($sql[$l]); 
					}
						
				flush();
									
				if (!$result03)
					{
						echo'<div class="aligncenter">
							<p>&nbsp;</p>
							<p><strong style="color:red;">'.$dbmsg[36].' Code: 03.<br />'.$dbmsg[37].': <a href="mailto:post@php-guestbook.de">post@php-guestbook.de</a></strong></p>
							<p>&nbsp;</p>
							<form method="post" action="'.getdomainpath().'/install/index.php">
								<p><input class="gb-button" type="submit" value="'.$dbmsg[41].'" /></p>
							</form>
							</div>';
						die();
					}
			}

		if ((isset($_POST['send_options']) && isset($_POST['choose_version'])) && ($_POST['choose_version'] == 1 || $_POST['choose_version'] == 2 || $_POST['choose_version'] == 3 || $_POST['choose_version'] == 4))
			{
				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_style`;";
				$sql[] = "CREATE TABLE `" . $table . "_style` (`id` tinyint(3) NOT NULL AUTO_INCREMENT PRIMARY KEY,`name` varchar(25) NOT NULL,`style` text NOT NULL) ;";
						
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('1', 'myPHP-GBook4_classic-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:1px solid #808080;}\r\n.ident{padding:10px 8px 8px 8px;border:1px solid #808080;background-color:<\$topcolor\$>;}\r\n.name{width:45%;float:left;}\r\n.icos{width:27%;float:left;text-align:center;}\r\n.timeline{width:28%;float:right;text-align:right;}\r\n.post{border:1px solid #808080;padding:10px 8px 20px 8px;background-color:<\$entriecolor\$>;}\r\n.quote{position:relative;right:-7px;bottom:0px;float:right;margin-top:0;}\r\n#ie7 .quote{bottom:1px;}\r\n.comment{background-color:#dfdfdf;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:415px){.ident{font-size:12px;}}\r\n@media(max-width:370px){.ico{margin-left:3px;margin-right:3px;}}');";
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('2', 'myPHP-GBook4_transp-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{padding:5px;box-shadow:0px 0px 0px transparent;-webkit-box-shadow:0px 0px 0px transparent;-moz-box-shadow:0px 0px 0px transparent;}\r\n#ie8 .guestbook-table, #ie7 .guestbook-table{border:0;}\r\n.name{width:80%;float:left;padding:5px 8px 5px 8px;}\r\n#ie7 .name{padding-bottom:0;}\r\n.icos{text-align:right;margin-right:12px;margin-top:15px;margin-bottom:0;}\r\n#ie7 .icos{margin-top:8px;}\r\n.post{padding:15px 8px 15px 8px;}\r\nhr.fine{width:98%;}\r\n#ie9 hr.fine, #ie8 hr.fine{width:98%;}\r\n.quote{position:relative;bottom:-2px;float:right;}\r\n.comment,.zitat,.code{background-color:transparent;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:360px){.name{font-size:12px}}');";
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('3', 'myPHP-GBook4_gray-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:1px solid #808080;border-radius:4px;-webkit-border-radius:4px;-moz-border-radius:4px;-khtml-border-radius:4px;box-shadow:0px 0px 5px #979393;-webkit-box-shadow:0px 0px 5px #979393;-moz-box-shadow:0px 0px 5px #979393;background-color:<\$entriecolor\$>;}\r\n.ident{padding:15px 10px 25px 10px;}\r\n.name{width:75%;float:left;}\r\n.icos{width:25%;float:right;text-align:right;}\r\n.post{padding:10px 10px 20px 10px}\r\n.quote{position:relative;bottom:1px;right:-8px;float:right;}\r\n#ie7 .quote{bottom:3px;}\r\nhr{clear:both;width:95%;}\r\n.code,.zitat{background-color:#ffffff;}\r\n.comment{background-color:#e9e9e9;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:400px){.name{font-size:12px;}.ico{margin-left:3px;margin-right:3px}}');";
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('4', 'myPHP-GBook4_left-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:solid 1px <\$topcolor\$>;background-color:<\$entriecolor\$>;}\r\n.ident{padding:8px 10px 8px 10px;background-color:<\$topcolor\$>;}\r\n.name{max-width:46%;min-width:42%;float:left;padding-top:5px;}\r\n.icos{width:22%;float:left;text-align:center;padding-top:7px;}\r\n.beitragnr{text-align:right;padding-top:0px;}\r\n#ie7 .name, #ie7 .icos{padding-top:5px;padding-bottom:1px;}\r\n#ie7 .beitragnr{padding-top:0px;padding-bottom:0px;}\r\n.post{padding:12px 10px 20px 10px;}\r\n.quote{float:right;position:relative;bottom:2px;right:-8px;}\r\n#ie7 .quote{bottom:4px;}\r\n.zitat,.code{background-color:#ffffff;}\r\n.comment{background-color:#e9e9e9;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:380px){.name{font-size:12px;}.ico{margin-left:3px;margin-right:3px}}');";
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('5', 'myPHP-GBook4_right-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:solid 1px <\$topcolor\$>;background-color:<\$entriecolor\$>;}\r\n.ident{padding:0 10px 0 10px;background-color:<\$topcolor\$>;}\r\n.name{text-align:right;}\r\n.icos{width:22%;float:left;text-align:center;padding-top:5px;}\r\n.beitragnr{max-width:37%;min-width:32%;float:left;}\r\n#ie7 .beitragnr, #ie7 .icos{padding-top:10px;padding-bottom:5px;}\r\n.post{padding:12px 10px 20px 10px;}\r\n.quote{float:right;position:relative;bottom:2px;right:-8px;}\r\n#ie7 .quote{bottom:4px;}\r\n.zitat,.code{background-color:#ffffff;}\r\n.comment{background-color:#e9e9e9;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:340px){.name{font-size:12px;}.ico{margin-left:3px;margin-right:3px}}');";
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('6', 'myPHP-GBook4_black-R', 'body{font-family:arial,Verdana,Helvetica;font-size:14px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{padding:5px;border:solid 1px #ededed;border-radius:4px;-webkit-border-radius:4px;-moz-border-radius:4px;-khtml-border-radius:4px;box-shadow:0px 0px 10px #ffffff;-webkit-box-shadow:0px 0px 10px #ffffff;-moz-box-shadow:0px 0px 10px #ffffff;}\r\n.name{width:70%;float:left;padding:10px 8px 10px 8px;}\r\n#ie7 .name{padding-top:5px;padding-bottom:0;}\r\n.icos{float:right;margin-right:8px;margin-top:20px;}\r\n#ie7 .icos{margin-top:10px;}\r\n.post{padding:5px 10px 20px 10px;}\r\n.origin{font-size:12px;}\r\n.quote{float:right;position:relative;bottom:0;right:-12px;}\r\nhr{width:97%;height:1px;border:none;color:<\$fontcolor\$>;background-color:<\$fontcolor\$>;}\r\n.red{color:#ff6600;}\r\n.zitat{background-color:#000000;}\r\n.code,.comment{background-color:#474747;}\r\n.this-page,.navi-page:link,.navi-page:visited{color:#ffffcc;}\r\n.navi-page:hover,.navi-page:active{color:#ff9900;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:340px){.ico{margin-left:3px;margin-right:3px;}}');";
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('7', 'myPHP-GBook4_color-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{padding:8px;border:solid 2px <\$topcolor\$>;border-radius:5px;-webkit-border-radius:5px;-moz-border-radius:5px;-khtml-border-radius:5px;background-color:<\$entriecolor\$>;}\r\n#ie8 .guestbook-table, #ie7 .guestbook-table{border:solid 2px <\$topcolor\$>;}\r\n.ident{padding:10px 5px 25px 5px;}\r\n.name{width:70%;float:left;}\r\n.timeline{width:30%;float:right;text-align:right;}\r\n.post{padding-top:8px;}\r\n.icos{height:28px;margin-top:10px;background-color:#eeeeee;}\r\n.emhpicq{float:left;padding-top:5px;}\r\n.quote-ico{float:right;margin-top:2px;}\r\n#ie7 .quote-ico{position:relative;top:-7px;}\r\n.quote{margin-top:0;margin-right:8px;padding-top:3px;padding-bottom:3px;}\r\nhr{width:98%;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:340px){.ident{font-size:12px;}}');";
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('8', 'myPHP-GBook4_wide-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:1px solid #808080;border-radius:5px;-webkit-border-radius:5px;-moz-border-radius:5px;-khtml-border-radius:5px;}\r\n.wide-table{width:100%;table-layout:fixed;}\r\n.top{width:25%;background-color:<\$topcolor\$>;}\r\n.ident{line-height:22px;padding-top:5px;}\r\n.td-post{width:75%;background-color:<\$entriecolor\$>;}\r\n.post{padding-top:10px;}\r\n.origin{font-size:10px;}\r\n.ico{margin-left:3px;margin-right:12px}\r\n.comment{background-color:#e9e9e9;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:420px){.comment, .zitat, .code{width:85%;}}\r\n@media(max-width:360px){.ident{font-size:11px;}.ico{margin-right:6px;}}');";
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('9', 'myPHP-GBook4_blog-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{padding:5px;box-shadow:0px 0px 0px transparent;-webkit-box-shadow:0px 0px 0px transparent;-moz-box-shadow:0px 0px 0px transparent;}\r\n#ie8 .guestbook-table, #ie7 .guestbook-table{border:0;}\r\n.entriecolor{background-color:<\$entriecolor\$>;}\r\n.name{font-size:16px;max-width:46%;min-width:42%;float:left;padding:0px 8px 0px 8px;}\r\n#ie7 .name{padding-top:8px;}\r\n.icos{width:25%;float:left;text-align:center;padding-top:2px;}\r\n#ie7 .icos{margin-top:5px;}\r\n.quote-ico{text-align:right;padding-top:7px;padding-right:8px;}\r\n#ie7 .quote-ico{padding-top:0;}\r\n.quote-ico a{text-decoration:none;}\r\n.post{padding:15px 8px 15px 8px;}\r\nhr.blog{height:1px;border:none;color:<\$fontcolor\$>;background-color:<\$fontcolor\$>;}\r\n.comment,.zitat,.code{background-color:transparent;border-color:<\$fontcolor\$>;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n.this-page,.navi-page:link,.navi-page:visited{color:<\$fontcolor\$>;}\r\n.navi-page:hover,.navi-page:active{color:#ff3300;}\r\n@media(max-width:360px){.name,.quote-ico{font-size:12px;}}');";
				$sql[] = "INSERT INTO `" . $table . "_style` VALUES ('10', 'myPHP-GBook4_s-black-R', 'body{font-family:arial,Verdana,Helvetica;font-size:15px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{box-shadow:0px 0px 0px transparent;-webkit-box-shadow:0px 0px 0px transparent;-moz-box-shadow:0px 0px 0px transparent;}\r\n#ie8 .guestbook-table, #ie7 .guestbook-table{border:0;}\r\n.name{max-width:46%;min-width:42%;float:left;padding-top:0;padding-left:8px;}\r\n#ie7 .name{padding-top:8px;}\r\n.icos{width:22%;float:left;text-align:center;margin-top:22px;}\r\n.reply{text-align:right;padding-top:5px;padding-right:8px;}\r\n#ie7 .icos, #ie7 .reply{margin-top:0;}\r\n.post{padding:15px 8px 15px 8px;}\r\n.red{color:#ff6600;}\r\n.this-page,.navi-page:link,.navi-page:visited{color:#ffffcc;}.navi-page:hover,.navi-page:active{color:#ff9900;}\r\na:link, a:visited{color:#ffffcc;font-weight:bold;}a:active, a:hover{color:#cc0000;text-decoration:none;}\r\n.reply a{font-weight:normal;text-decoration:none;}\r\n@media(max-width:360px){.name,.reply{font-size:12px;}}');";

				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_template`;";
				$sql[] = "CREATE TABLE `" . $table . "_template` (`bgcolor` varchar(15) NOT NULL, `bgimage` varchar(100) NOT NULL, `fontcolor` varchar(15) NOT NULL, `html` text NOT NULL, `id` tinyint(3) NOT NULL AUTO_INCREMENT PRIMARY KEY, `image_email` varchar(25) NOT NULL, `image_homepage` varchar(25) NOT NULL, `name` varchar(25) NOT NULL, `divalign` varchar(35) NOT NULL, `tablewidth` smallint(4) NOT NULL, `tdcolor` varchar(15) NOT NULL, `td2color` varchar(15) NOT NULL) ;";

/// CLASSIC ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
						'<div class=\"myphpgb gb-align guestbook-table\">
						<div class=\"ident\">
						<div class=\"name\"><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span></div>
						<div class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></div>
						<div class=\"timeline\"><\$date\$> | <\$time\$></div>
						<div class=\"break\"></div>
						</div>
						<div class=\"post\">
						<\$ip\$><\$text\$><\$comment\$>
						<div><\$quote_ico\$></div>
						</div>
						</div>', 
						'1', 'emailxp.gif', 'homepagexp.gif', 'myPHP-GBook4_classic-R', 'margin-left:auto;margin-right:auto;', '480', '#f2f2f2', '#ffffff');";

/// TRANSP ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('transparent', '', '#000000', 
						'<div class=\"myphpgb gb-align guestbook-table\">
						<div class=\"name\">
						Name: <strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span><br />
						<span class=\"beitragnr\"><\$nr\$> <\$wh\$> <strong><\$date\$>, <\$time\$></strong></span>
						</div>
						<p class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
						<hr class=\"fine break\" />
						<div class=\"post\">
						<\$ip\$><\$text\$><\$comment\$>
						<div><\$quote_ico\$></div>
						</div>
						<hr class=\"fine\" /><hr class=\"fine\" />
						</div>', 
						'2', 'emailxp.gif', 'homepagexp.gif', 'myPHP-GBook4_transp-R', 'margin-left:auto;margin-right:auto;', '500', 'transparent', 'transparent');";

/// GRAY ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
						'<div class=\"myphpgb gb-align guestbook-table\">
						<div class=\"ident\">
						<div class=\"name\"><strong><\$name\$></strong> <span class=\"nowrap\"><\$done\$> <\$date\$>, <\$time\$></span><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span></div>
						<div class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></div>
						</div>
						<div class=\"break\"></div>
						<hr />
						<div class=\"post\">
						<\$ip\$><\$text\$><\$comment\$>
						<div><\$quote_ico\$></div>
						</div>
						</div>', 
						'3', 'emailgrey.gif', 'homepagegrey.gif', 'myPHP-GBook4_gray-R', 'margin-left:auto;margin-right:auto;', '500', '#f2f2f2', '#f2f2f2');";

/// LEFT ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
						'<div class=\"myphpgb gb-align guestbook-table\">
						<div class=\"ident break\">
						<div class=\"name\"><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span></div>
						<div class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></div>
						<div class=\"beitragnr\"><strong><\$nr\$>  # <\$id\$></strong><br /><span class=\"nowrap\"><\$date\$> | <\$time\$></span></div>
						<div class=\"break\"></div>
						</div>
						<div class=\"post\">
						<\$ip\$><\$text\$><\$comment\$>
						<div><\$quote_ico\$></div>
						</div>
						</div>',
						'4', 'emailnew.gif', 'homepage.gif', 'myPHP-GBook4_left-R', 'margin-left:auto;margin-right:auto;', '550', '#ededed', '#ffffff');";

/// RIGHT ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
						'<div class=\"myphpgb gb-align guestbook-table\">
						<div class=\"ident break\">
						<p class=\"beitragnr nowrap\"><strong><\$nr\$>  # <\$id\$></strong><br /><\$date\$> | <\$time\$></p>
						<p class=\"icos nowrap\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
						<div class=\"name\"><br /><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span><br /><br /></div>
						<div class=\"break\"></div>
						</div>
						<div class=\"post\">
						<\$ip\$><\$text\$><\$comment\$>
						<div><\$quote_ico\$></div>
						</div>
						</div>',
						'5', 'emailnew.gif', 'homepage.gif', 'myPHP-GBook4_right-R', 'margin-left:auto;margin-right:auto;', '550', '#ededed', '#ffffff');";

/// BLACK ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('#000000', '', '#ffffff', 
						'<div class=\"myphpgb gb-align guestbook-table\">
						<div class=\"name\"><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span><br /><span class=\"beitragnr\"><strong><\$nr\$> # <\$id\$></strong> <\$wh\$> <\$date\$> | <\$time\$></span></div>
						<p class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
						<hr class=\"break\" />
						<div class=\"post\">
						<\$ip\$><\$text\$><\$comment\$>
						<div><\$quote_ico\$></div>
						</div>
						</div>', 
						'6', 'emailxp.gif', 'homepagexp.gif', 'myPHP-GBook4_black-R', 'margin-left:auto;margin-right:auto;', '550', 'transparent', 'transparent');";

/// COLOR ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
						'<div class=\"myphpgb gb-align guestbook-table\">
						<div class=\"ident\">
						<div class=\"name\"><strong><\$id\$>. <\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span></div>
						<div class=\"timeline\"><strong><\$date\$> | <\$time\$></strong></div>
						</div>
						<div class=\"break\"></div>
						<hr class=\"fine\" />
						<div class=\"post\">
						<\$ip\$><\$text\$><\$comment\$>
						<div class=\"icos\">
						<div class=\"emhpicq\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></div>
						<div class=\"quote-ico\"><\$quote_ico\$></div>
						</div>
						</div>
						</div>', 
						'7', 'emailnew.gif', 'homepage.gif', 'myPHP-GBook4_color-R', 'margin-left:auto;margin-right:auto;', '550', '#ff9900', 'transparent');";

/// WIDE ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
						'<div class=\"myphpgb gb-align guestbook-table\">
						<table class=\"wide-table\" cellpadding=\"7\" cellspacing=\"0\" border=\"0\">
						<tr>
						<td align=\"left\" class=\"top\" rowspan=\"2\">
						<div class=\"ident\">
						<strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$origin\$></span><br />
						<\$nr\$>  # <\$id\$><br />
						<\$date\$> | <\$time\$>
						<p><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
						<\$ip\$></div>
						</td>
						<td align=\"left\" valign=\"top\" class=\"td-post\">
						<div class=\"post\">
						<\$text\$><\$comment\$>
						</div>
						</td>
						</tr>
						<tr><td align=\"right\" valign=\"bottom\" class=\"td-post\"><\$quote_ico\$></td></tr>
						</table>
						</div>', 
						'8', 'emailnew.gif', 'homepage.gif', 'myPHP-GBook4_wide-R', 'margin-left:auto;margin-right:auto;', '650', '#f0f0f0', '#ffffff');";

/// BLOG ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('transparent', '', '#000000', 
						'<div class=\"myphpgb gb-align guestbook-table entriecolor\">
						<hr class=\"blog\" />
						<p class=\"name\"><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span><br /><span class=\"beitragnr\"><strong><\$date\$>, <\$time\$></strong></span></p>
						<p class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
						<p class=\"quote-ico\"><\$quote_ico\$><br /><span class=\"beitragnr\"><\$nr\$> #  <\$id\$></span></p>
						<div class=\"break\"></div>
						<div class=\"post\">
						<\$ip\$><\$text\$><\$comment\$>
						</div>
						<hr class=\"blog\" />
						</div>',
						'9', 'emailnew.gif', 'earth.png', 'myPHP-GBook4_blog-R', 'margin-left:auto;margin-right:auto;', '550', 'transparent', 'transparent');";

/// S-BLACK ok
				$sql[] = "INSERT INTO `" . $table . "_template` VALUES ('#000000', '', '#f3f3f3', 
						'<div class=\"myphpgb gb-align guestbook-table\">
						<hr class=\"white-fine\" />
						<p class=\"name\"><strong><\$name\$><span class=\"origin\"><\$br\$><\$from\$><\$origin\$></span><br /><span class=\"beitragnr\"><\$date\$>, <\$time\$></span></strong></p>
						<p class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
						<p class=\"reply\"><\$quote_ico\$><br /><span class=\"beitragnr\"><\$nr\$> #  <\$id\$></span></p>
						<hr class=\"white-fine break\" />
						<div class=\"break\"></div>
						<div class=\"post\">
						<\$ip\$><\$text\$><\$comment\$>
						</div>
						<hr class=\"white-fine\" />
						</div>',
						'10', 'emailnew.gif', 'earth.png', 'myPHP-GBook4_s-black-R', 'margin-left:auto;margin-right:auto;', '550', 'transparent', 'transparent');";

				$sql[] = "ALTER TABLE `" . $table . "_properties` ADD COLUMN `link_entry` varchar(35) NOT NULL";
				$sql[] = "ALTER TABLE `" . $table . "_properties` ADD COLUMN `check_subject` tinyint(1) NOT NULL";
				$sql[] = "ALTER TABLE `" . $table . "_properties` ADD COLUMN `check_town` tinyint(1) NOT NULL";
				$sql[] = "ALTER TABLE `" . $table . "_properties` ADD COLUMN `check_country` tinyint(1) NOT NULL";
				$sql[] = "ALTER TABLE `" . $table . "_properties` ADD COLUMN `check_free` tinyint(1) NOT NULL";
				
				$sql[] = "ALTER TABLE `" . $table . "_entries` ADD COLUMN `origin` varchar(100) NOT NULL";
				$sql[] = "ALTER TABLE `" . $table . "_entries` ADD COLUMN `marker` tinyint(1) NOT NULL";
				
				$sql[] = "UPDATE `" . $table . "_properties` SET `check_homepage` = '0', `check_icq` = '1', `max_word_length` = '36'";
				$sql[] = "UPDATE `" . $table . "_properties` SET  `link_entry` = '', `check_subject` = '0', `check_town` = '0', `check_country` = '0', `check_free` = '0'";

				$sql[] = "UPDATE `" . $table . "_entries` SET `origin` = '', `marker` = '0'";

				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_thankyou`;";
				$sql[] = "CREATE TABLE `" . $table . "_thankyou` (`id` tinyint(1) NOT NULL AUTO_INCREMENT PRIMARY KEY, `status` tinyint(1) NOT NULL, `thanks` text NOT NULL, `lang` varchar(3) NOT NULL, `noreply` varchar(50) NOT NULL);";

				$sql[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('1', '0', 'Lieber Gast,\r\n\r\nich möchte mich für Deinen Eintrag im Gästebuch von \"".hostname()."\" bedanken und hoffe, bald wieder etwas von Dir zu lesen.\r\n\r\nMit freundlichem Gruß\r\nAdministrator', 'de', '');";
				$sql[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('2', '0', 'Dear Guest,\r\n\r\nthank you for your entry in my guestbook on \"".hostname()."\".\r\n\r\nI hope I hear again from you soon!\r\n\r\nBest regards,\r\nAdministrator', 'en', '');";

				$queries = count($sql);

				for ($m = 0; $m < $queries; $m++)
					{
						$result04 = $gbook->query($sql[$m]); 
					}
						
				flush();
									
				if (!$result04)
					{
						echo'<div class="aligncenter">
							<p>&nbsp;</p>
							<p><strong style="color:red;">'.$dbmsg[36].' Code: 04.<br />'.$dbmsg[37].': <a href="mailto:post@php-guestbook.de">post@php-guestbook.de</a></strong></p>
							<p>&nbsp;</p>
							<form method="post" action="'.getdomainpath().'/install/index.php">
								<p><input class="gb-button" type="submit" value="'.$dbmsg[41].'" /></p>
							</form>
							</div>';
						die();
					}
			}
			
		if ((isset($_POST['send_options']) && isset($_POST['choose_version'])) && ($_POST['choose_version'] == 1 || $_POST['choose_version'] == 2 || $_POST['choose_version'] == 3 || $_POST['choose_version'] == 4 || $_POST['choose_version'] == 5))
			{
				$update_thanks_de = $gbook->query("SELECT `thanks`, `noreply` FROM `".$table."_thankyou` WHERE `lang` = 'de'");
				list($thanksDE,$noreplyDE) = $update_thanks_de->fetch_row();
				$update_thanks_en = $gbook->query("SELECT `thanks`, `noreply` FROM `".$table."_thankyou` WHERE `lang` = 'en'");
				list($thanksEN,$noreplyEN) = $update_thanks_en->fetch_row();
			
				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_login_counter`;";
				$sql[] = "CREATE TABLE `" . $table . "_login_counter` (`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY, `login_time` int(15) NOT NULL, `counter` tinyint(1) NOT NULL, `login_code` varchar(32) NOT NULL) ;";

				$sql[] = "ALTER TABLE `" . $table . "_properties` ADD COLUMN `button_link` tinyint(1) NOT NULL";

				$sql[] = "DROP TABLE IF EXISTS `" . $table . "_thankyou`;";
				$sql[] = "CREATE TABLE `" . $table . "_thankyou` (`id` tinyint(1) NOT NULL AUTO_INCREMENT PRIMARY KEY, `status` tinyint(1) NOT NULL, `thanks` text NOT NULL, `lang` varchar(3) NOT NULL, `noreply` varchar(50) NOT NULL);";

				$sql[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('1', '0', '".$thanksDE."', 'de', '".$noreplyDE."');";
				$sql[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('2', '0', '".$thanksEN."', 'en', '".$noreplyEN."');";
				$sql[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('3', '0', 'Caro hóspede,\r\n\r\nquero agradecer-lhe pelo seu comentário feito no Livro de Visitas de \"".hostname()."\" e espero ler em breve, mais algo seu.\r\n\r\nCom os melhores cumprimentos,\r\no Administrador', 'pt', '');";
				$sql[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('4', '0', 'Geachte gast,\r\n\r\nIk wil u bedanken voor uw vermelding in het gastenboek van \"".hostname()."\" en hopen binnenkort iets van je te lezen.\r\n\r\nMet vriendelijke groet\r\nAdministrateur', 'nl', '');";

				$sql[] = "UPDATE `" . $table . "_properties` SET `guestbook_title` = 'myPHP-Guestbook ".$version."', `button_link` = '0'";

				$queries = count($sql);

				for ($o = 0; $o < $queries; $o++)
					{
						$result05 = $gbook->query($sql[$o]); 
					}
						
				flush();
									
				if ($result05)
					{
						$result  = '<div class="aligncenter">';
						$result .= '<p>&nbsp;</p>';
						$result .= '<p><strong style="color:green;">'.$dbmsg[38].' '.$version.'.</strong></p>';
						$result .= '<p><strong style="color:red;">'.$imsg[35].'</strong></p>';
						$result .= '</div>';
					}
				else
					{
						echo'<div class="aligncenter">
							<p>&nbsp;</p>
							<p><strong style="color:red;">'.$dbmsg[36].' Code: 05.<br />'.$dbmsg[37].': <a href="mailto:post@php-guestbook.de">post@php-guestbook.de</a></strong></p>
							<p>&nbsp;</p>
							<form method="post" action="'.getdomainpath().'/install/index.php">
								<p><input class="gb-button" type="submit" value="'.$dbmsg[41].'" /></p>
							</form>
							</div>';
							die();
					}
			}
	}
		
	echo'<h1>'.$dbmsg[2].' '.$version.'</h1>';
		
	if ($result != '')
		{
			echo $result;
		}
	else
		{
			echo'
				'.$dbmsg[3].'
				'.$dbmsg[44].'
				'.$dbmsg[4].'
				'.$dbmsg[5].'
					<ul>
						<li>
							'.$dbmsg[6].'
						</li>
						<li>
							'.$dbmsg[7].'
						</li>
						<li>
							'.$dbmsg[8].'
						</li>
						<li>
							'.$dbmsg[9].'
						</li>
					</ul>
				'.$dbmsg[11].'';
	
			if (!extension_loaded("mysqli"))
				{
					echo'<p class="aligncenter"><strong style="color:red">'.$dbmsg[12].'</strong></p>
							<p>'.$dbmsg[13].'</p>';
					die();
				}
							
			elseif ($gbook->connect_error)
				{
					echo'<p class="aligncenter"><strong style="color:green">'.$dbmsg[14].'</strong></p>';
					echo'<p class="aligncenter"><strong style="color:red">'.$dbmsg[15].'</strong></p>';
					echo'<p class="aligncenter">'.$dbmsg[16].'</p>';
					die('<p class=\'aligncenter\' style=\'color:red\'>Connect Error (' . $gbook->connect_errno . ')<br />' . $gbook->connect_error . '</p><p>&nbsp;</p>');
				}
										
			else
				{
					echo'
						<div class="aligncenter">
							<p><strong style="color:green">'.$dbmsg[17].'</strong></p>
						</div>
						<p><strong>'.$dbmsg[18].'</strong></p>
						<a id="anchor-dbbottom" name="anchor-dbbottom"></a>
						<p class="aligncenter"><strong>'.$dbmsg[42].'</strong></p>
						<form method="post" action="#anchor-dbbottom">
							<table style="width:510px;margin-right:auto;margin-left:auto;" cellspacing="0" cellpadding="5">
								<tr>
									<td align="left" style="width:120px"><strong style="color:red;">3.x</strong> <sup>[1]</sup></td>
									<td style="width:20px"><input type="radio" name="choose_version" value="1"';
									
										if (isset($_POST['choose_version']) AND $_POST['choose_version'] == 1) {
											echo" checked=\"checked\"";
										}
												
									echo' /></td>
									<td rowspan="3" valign="middle">'.$error_db.'</td>
								</tr>
								<tr>
									<td align="left"><strong style="color:red;">4.0.0 '.$dbmsg[29].' 4.3.2</strong> <sup>[2]</sup></td>
									<td><input type="radio" name="choose_version" value="2"';
									
										if (isset($_POST['choose_version']) AND $_POST['choose_version'] == 2) {
											echo" checked=\"checked\"";
										}
									
									echo' /></td>
								</tr>
								<tr>
									<td align="left"><strong style="color:red;">4.4.0 '.$dbmsg[29].' 4.5.2</strong> <sup>[3]</sup></td>
									<td><input type="radio" name="choose_version" value="3"';
										
										if (isset($_POST['choose_version']) AND $_POST['choose_version'] == 3) {
											echo" checked=\"checked\"";
										}
										
									echo' /></td>
								</tr>
								<tr>
									<td align="left"><strong style="color:red;">4.5.3 '.$dbmsg[29].' 4.5.6</strong> <sup>[4]</sup></td>
									<td><input type="radio" name="choose_version" value="4"';
										
										if (isset($_POST['choose_version']) AND $_POST['choose_version'] == 4) {
											echo" checked=\"checked\"";
										}
									
									echo' /></td>
									<td rowspan="2" align="center" valign="middle">
										<input class="gb-button" type="submit" name="send_options" value="'.$dbmsg[43].'" />
										<input type="hidden" name="language" value="';
									
											if(isset($_POST['language']) && $_POST['language'] != "" && ($_POST['language'] == "de" || $_POST['language'] == "en")){
												echo''.$_POST['language'].'';
											}
											else {
												echo'de';
											}
									
										echo'" />
									</td>
								</tr>
								<tr>
									<td align="left"><strong style="color:red;">4.6.0 '.$dbmsg[29].' 4.6.1</strong> <sup>[5]</sup></td>
									<td><input type="radio" name="choose_version" value="5"';
										
										if (isset($_POST['choose_version']) AND $_POST['choose_version'] == 5) {
											echo" checked=\"checked\"";
										}
										
									echo' /></td>
								</tr>
							</table>
						</form>
						<br />';
									
					echo'
						<hr style="width:100%;" />
						<p style="font-size:11px;text-align:left;"><sup>[1]</sup> '.$dbmsg[23].' "*_template", "*_style", "*_statistic", "*_properties".<br />8 '.$dbmsg[24].'<br />'.$dbmsg[25].' "*_entries".<br />'.$dbmsg[26].'<br />'.$dbmsg[27].'</p>
						<p style="font-size:11px;text-align:left;"><sup>[2]</sup> '.$dbmsg[23].' "*_template", "*_style".<br />5 '.$dbmsg[24].'<br />'.$dbmsg[25].' "*_entries", "*_properties".<br />'.$dbmsg[28].'</p>
						<p style="font-size:11px;text-align:left;"><sup>[3]</sup> '.$dbmsg[23].' "*_template", "*_style", "*_upload".<br />3 '.$dbmsg[24].'<br />'.$dbmsg[25].' "*_entries", "*_properties".<br />'.$dbmsg[32].'</p>
						<p style="font-size:11px;text-align:left;"><sup>[4]</sup> '.$dbmsg[23].' "*_template", "*_style".<br />2 '.$dbmsg[24].' ("*__thankyou", "*_login_counter").<br />'.$dbmsg[25].' "*_entries", "*_properties".<br />'.$dbmsg[32].'</p>
						<p style="font-size:11px;text-align:left;"><sup>[5]</sup> '.$dbmsg[23].' "*__thankyou", "*_login_counter".<br />'.$dbmsg[25].' "*_properties".<br />'.$dbmsg[34].'</p>
						<p>&nbsp;</p>';
				}						
		}

?>