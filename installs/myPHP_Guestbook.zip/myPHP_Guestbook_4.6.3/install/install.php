<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

echo"<h1>$imsg[0] $version</h1>
	";

$step = (isset($_GET['step'])) ? $_GET['step'] : 0;

switch($step)
	{
		case 2:
			$siteURL = urldecode($_GET['URL']);
			$siteEmail = trim($_GET['EMail']);
			$siteAdminPass = $_GET['APass'];
			$siteAdminName = $_GET['AName'];
			$siteLang = $_GET['Lang'];
			
			($siteLang == "de" || $siteLang == "at" || $siteLang == "ch") ? $install_lang = "de" : $install_lang = "en";
			
			include '../includes/config.inc.php';
			include("".$install_lang.".php");
		
// Database entries

$query[] = "DROP TABLE IF EXISTS `" . $table . "_entries`;";
$query[] = "CREATE TABLE `" . $table . "_entries` ( `comment` text NOT NULL, `date` varchar(10) NOT NULL, `email` varchar(50) NOT NULL, `homepage` varchar(150) NOT NULL, `icq` int(9) NOT NULL, `id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY, `ip` varchar(40) NOT NULL, `status` tinyint(1) NOT NULL, `name` varchar(27) NOT NULL, `activation_code` varchar(32) NOT NULL, `text` text NOT NULL, `time` varchar(5) NOT NULL, `origin` varchar(100) NOT NULL, `marker` tinyint(1) NOT NULL);";

$query[] = "INSERT INTO `" .$table. "_entries` VALUES ('Dieser Eintrag kann im Admin-Panel geloescht werden![hr]This entry can be deleted in the admin panel!', '".date("d.m.Y")."', 'post@php-guestbook.de', 'https://www.php-guestbook.de', 0, 1, '94.0.0.0', 1, 'Wolfgang', '', 'Ihr neues Gaestebuch ist nun installiert! :coke: \r\n\r\nBitte loeschen Sie aus Sicherheitsgruenden den Installationsordner von Ihrem Server. :) \r\n\r\nAktuell ist das Template [b][i]left[/i][/b] eingestellt. Wenn Sie zu einem anderen Template wechseln, denken Sie bitte daran, [b]unbedingt auch den zugehörigen CSS-Style einzustellen[/b]!\r\n\r\n[hr]\r\nYour new guestbook is installed now! :coke: \r\n\r\nPlease delete for security reasons the installation folder from your server. :) \r\n\r\nCurrently, the template [b][i]left[/b][/i] is set. If you switch to a different template, please remember, [b]necessarily set up the associated CSS[/b]!', '".date("H:i")."', 'Remscheid | Deutschland', 0);";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_properties`;";
$query[] = "CREATE TABLE `" . $table . "_properties` (`admin_email` varchar(50) NOT NULL, `antiflood_ban` smallint(5) NOT NULL, `bbcode` tinyint(1) NOT NULL, `check_email` tinyint(1) NOT NULL, `check_homepage` tinyint(1) NOT NULL, `check_icq` tinyint(1) NOT NULL, `deactivate_html` tinyint(1) NOT NULL, `clean_backup` tinyint(1) NOT NULL, `default_style` tinyint(3) NOT NULL, `default_template` tinyint(3) NOT NULL, `entries_per_site` tinyint(3) NOT NULL, `entry_length_limit` tinyint(1) NOT NULL, `entry_length_maximum` mediumint(7) NOT NULL, `entry_length_minimum` tinyint(3) NOT NULL,`guestbook_status` tinyint(1) NOT NULL, `no_spam_entries` tinyint(1) NOT NULL, `spam_marker` tinyint(2) NOT NULL, `no_spam_links` tinyint(1) NOT NULL, `max_links` tinyint(2) NOT NULL, 
`guestbook_title` varchar(50) NOT NULL, `images_in_entries` tinyint(1) NOT NULL, `language` varchar(10) NOT NULL, `links_in_sitefunction` tinyint(3) NOT NULL, `max_word_length` tinyint(3) NOT NULL, `notification_entries` tinyint(1) NOT NULL, `password` varchar(32) NOT NULL, `release_entries` tinyint(1) NOT NULL, `show_ip` tinyint(1) NOT NULL, `smilies` tinyint(1) NOT NULL, `thanks_email` tinyint(1) NOT NULL, `statistic` tinyint(1) NOT NULL, `statistic_ban` smallint(5) NOT NULL, `quote_func` tinyint(1) NOT NULL, `username` varchar(15) NOT NULL, `link_entry` varchar(35) NOT NULL, `check_subject` tinyint(1) NOT NULL, `check_town` tinyint(1) NOT NULL, `check_country` tinyint(1) NOT NULL, `check_free` tinyint(1) NOT NULL, `button_link` tinyint(1) NOT NULL);";

$query[] = "INSERT INTO `" . $table . "_properties` VALUES ('".$siteEmail."', '10', '1', '0', '0', '1', '1', '0', '4', '4', '10', '1', '1500', '10', '1', '1', '5', '1', '2', 'myPHP-Guestbook ".$version."', '0', '".$siteLang."', '9', '36', '1', '".md5($siteAdminPass)."', '0', '0', '1', '1', '1', '720', '1', '".$siteAdminName."', '', '0', '0', '0', '0', '0');";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_style`;";
$query[] = "CREATE TABLE `" . $table . "_style` (`id` tinyint(3) NOT NULL AUTO_INCREMENT PRIMARY KEY,`name` varchar(25) NOT NULL,`style` text NOT NULL) ;";

$query[] = "INSERT INTO `" . $table . "_style` VALUES ('1', 'myPHP-GBook4_classic-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:1px solid #808080;}\r\n.ident{padding:10px 8px 8px 8px;border:1px solid #808080;background-color:<\$topcolor\$>;}\r\n.name{width:45%;float:left;}\r\n.icos{width:27%;float:left;text-align:center;}\r\n.timeline{width:28%;float:right;text-align:right;}\r\n.post{border:1px solid #808080;padding:10px 8px 20px 8px;background-color:<\$entriecolor\$>;}\r\n.quote{position:relative;right:-7px;bottom:0px;float:right;margin-top:0;}\r\n#ie7 .quote{bottom:1px;}\r\n.comment{background-color:#dfdfdf;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:415px){.ident{font-size:12px;}}\r\n@media(max-width:370px){.ico{margin-left:3px;margin-right:3px;}}');";
$query[] = "INSERT INTO `" . $table . "_style` VALUES ('2', 'myPHP-GBook4_transp-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{padding:5px;box-shadow:0px 0px 0px transparent;-webkit-box-shadow:0px 0px 0px transparent;-moz-box-shadow:0px 0px 0px transparent;}\r\n#ie8 .guestbook-table, #ie7 .guestbook-table{border:0;}\r\n.name{width:80%;float:left;padding:5px 8px 5px 8px;}\r\n#ie7 .name{padding-bottom:0;}\r\n.icos{text-align:right;margin-right:12px;margin-top:15px;margin-bottom:0;}\r\n#ie7 .icos{margin-top:8px;}\r\n.post{padding:15px 8px 15px 8px;}\r\nhr.fine{width:98%;}\r\n#ie9 hr.fine, #ie8 hr.fine{width:98%;}\r\n.quote{position:relative;bottom:-2px;float:right;}\r\n.comment,.zitat,.code{background-color:transparent;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:360px){.name{font-size:12px}}');";
$query[] = "INSERT INTO `" . $table . "_style` VALUES ('3', 'myPHP-GBook4_gray-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:1px solid #808080;border-radius:4px;-webkit-border-radius:4px;-moz-border-radius:4px;-khtml-border-radius:4px;box-shadow:0px 0px 5px #979393;-webkit-box-shadow:0px 0px 5px #979393;-moz-box-shadow:0px 0px 5px #979393;background-color:<\$entriecolor\$>;}\r\n.ident{padding:15px 10px 25px 10px;}\r\n.name{width:75%;float:left;}\r\n.icos{width:25%;float:right;text-align:right;}\r\n.post{padding:10px 10px 20px 10px}\r\n.quote{position:relative;bottom:1px;right:-8px;float:right;}\r\n#ie7 .quote{bottom:3px;}\r\nhr{clear:both;width:95%;}\r\n.code,.zitat{background-color:#ffffff;}\r\n.comment{background-color:#e9e9e9;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:400px){.name{font-size:12px;}.ico{margin-left:3px;margin-right:3px}}');";
$query[] = "INSERT INTO `" . $table . "_style` VALUES ('4', 'myPHP-GBook4_left-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:solid 1px <\$topcolor\$>;background-color:<\$entriecolor\$>;}\r\n.ident{padding:8px 10px 8px 10px;background-color:<\$topcolor\$>;}\r\n.name{max-width:46%;min-width:42%;float:left;padding-top:5px;}\r\n.icos{width:22%;float:left;text-align:center;padding-top:7px;}\r\n.beitragnr{text-align:right;padding-top:0px;}\r\n#ie7 .name, #ie7 .icos{padding-top:5px;padding-bottom:1px;}\r\n#ie7 .beitragnr{padding-top:0px;padding-bottom:0px;}\r\n.post{padding:12px 10px 20px 10px;}\r\n.quote{float:right;position:relative;bottom:2px;right:-8px;}\r\n#ie7 .quote{bottom:4px;}\r\n.zitat,.code{background-color:#ffffff;}\r\n.comment{background-color:#e9e9e9;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:380px){.name{font-size:12px;}.ico{margin-left:3px;margin-right:3px}}');";
$query[] = "INSERT INTO `" . $table . "_style` VALUES ('5', 'myPHP-GBook4_right-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:solid 1px <\$topcolor\$>;background-color:<\$entriecolor\$>;}\r\n.ident{padding:0 10px 0 10px;background-color:<\$topcolor\$>;}\r\n.name{text-align:right;}\r\n.icos{width:22%;float:left;text-align:center;padding-top:5px;}\r\n.beitragnr{max-width:37%;min-width:32%;float:left;}\r\n#ie7 .beitragnr, #ie7 .icos{padding-top:10px;padding-bottom:5px;}\r\n.post{padding:12px 10px 20px 10px;}\r\n.quote{float:right;position:relative;bottom:2px;right:-8px;}\r\n#ie7 .quote{bottom:4px;}\r\n.zitat,.code{background-color:#ffffff;}\r\n.comment{background-color:#e9e9e9;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:340px){.name{font-size:12px;}.ico{margin-left:3px;margin-right:3px}}');";
$query[] = "INSERT INTO `" . $table . "_style` VALUES ('6', 'myPHP-GBook4_black-R', 'body{font-family:arial,Verdana,Helvetica;font-size:14px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{padding:5px;border:solid 1px #ededed;border-radius:4px;-webkit-border-radius:4px;-moz-border-radius:4px;-khtml-border-radius:4px;box-shadow:0px 0px 10px #ffffff;-webkit-box-shadow:0px 0px 10px #ffffff;-moz-box-shadow:0px 0px 10px #ffffff;}\r\n.name{width:70%;float:left;padding:10px 8px 10px 8px;}\r\n#ie7 .name{padding-top:5px;padding-bottom:0;}\r\n.icos{float:right;margin-right:8px;margin-top:20px;}\r\n#ie7 .icos{margin-top:10px;}\r\n.post{padding:5px 10px 20px 10px;}\r\n.origin{font-size:12px;}\r\n.quote{float:right;position:relative;bottom:0;right:-12px;}\r\nhr{width:97%;height:1px;border:none;color:<\$fontcolor\$>;background-color:<\$fontcolor\$>;}\r\n.red{color:#ff6600;}\r\n.zitat{background-color:#000000;}\r\n.code,.comment{background-color:#474747;}\r\n.this-page,.navi-page:link,.navi-page:visited{color:#ffffcc;}\r\n.navi-page:hover,.navi-page:active{color:#ff9900;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:340px){.ico{margin-left:3px;margin-right:3px;}}');";
$query[] = "INSERT INTO `" . $table . "_style` VALUES ('7', 'myPHP-GBook4_color-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{padding:8px;border:solid 2px <\$topcolor\$>;border-radius:5px;-webkit-border-radius:5px;-moz-border-radius:5px;-khtml-border-radius:5px;background-color:<\$entriecolor\$>;}\r\n#ie8 .guestbook-table, #ie7 .guestbook-table{border:solid 2px <\$topcolor\$>;}\r\n.ident{padding:10px 5px 25px 5px;}\r\n.name{width:70%;float:left;}\r\n.timeline{width:30%;float:right;text-align:right;}\r\n.post{padding-top:8px;}\r\n.icos{height:28px;margin-top:10px;background-color:#eeeeee;}\r\n.emhpicq{float:left;padding-top:5px;}\r\n.quote-ico{float:right;margin-top:2px;}\r\n#ie7 .quote-ico{position:relative;top:-7px;}\r\n.quote{margin-top:0;margin-right:8px;padding-top:3px;padding-bottom:3px;}\r\nhr{width:98%;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:340px){.ident{font-size:12px;}}');";
$query[] = "INSERT INTO `" . $table . "_style` VALUES ('8', 'myPHP-GBook4_wide-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{border:1px solid #808080;border-radius:5px;-webkit-border-radius:5px;-moz-border-radius:5px;-khtml-border-radius:5px;}\r\n.wide-table{width:100%;table-layout:fixed;}\r\n.top{width:25%;background-color:<\$topcolor\$>;}\r\n.ident{line-height:22px;padding-top:5px;}\r\n.td-post{width:75%;background-color:<\$entriecolor\$>;}\r\n.post{padding-top:10px;}\r\n.origin{font-size:10px;}\r\n.ico{margin-left:3px;margin-right:12px}\r\n.comment{background-color:#e9e9e9;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n@media(max-width:420px){.comment, .zitat, .code{width:85%;}}\r\n@media(max-width:360px){.ident{font-size:11px;}.ico{margin-right:6px;}}');";
$query[] = "INSERT INTO `" . $table . "_style` VALUES ('9', 'myPHP-GBook4_blog-R', 'body{font-family:arial,Verdana,Helvetica;font-size:13px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{padding:5px;box-shadow:0px 0px 0px transparent;-webkit-box-shadow:0px 0px 0px transparent;-moz-box-shadow:0px 0px 0px transparent;}\r\n#ie8 .guestbook-table, #ie7 .guestbook-table{border:0;}\r\n.entriecolor{background-color:<\$entriecolor\$>;}\r\n.name{font-size:16px;max-width:46%;min-width:42%;float:left;padding:0px 8px 0px 8px;}\r\n#ie7 .name{padding-top:8px;}\r\n.icos{width:25%;float:left;text-align:center;padding-top:2px;}\r\n#ie7 .icos{margin-top:5px;}\r\n.quote-ico{text-align:right;padding-top:7px;padding-right:8px;}\r\n#ie7 .quote-ico{padding-top:0;}\r\n.quote-ico a{text-decoration:none;}\r\n.post{padding:15px 8px 15px 8px;}\r\nhr.blog{height:1px;border:none;color:<\$fontcolor\$>;background-color:<\$fontcolor\$>;}\r\n.comment,.zitat,.code{background-color:transparent;border-color:<\$fontcolor\$>;}\r\na:link, a:visited{color:<\$fontcolor\$>;font-weight:bold;}\r\na:active, a:hover{color:#C00;text-decoration:none;}\r\n.this-page,.navi-page:link,.navi-page:visited{color:<\$fontcolor\$>;}\r\n.navi-page:hover,.navi-page:active{color:#ff3300;}\r\n@media(max-width:360px){.name,.quote-ico{font-size:12px;}}');";
$query[] = "INSERT INTO `" . $table . "_style` VALUES ('10', 'myPHP-GBook4_s-black-R', 'body{font-family:arial,Verdana,Helvetica;font-size:15px;color:<\$fontcolor\$>;background-color:<\$bodycolor\$>;}\r\n.myphpgb{max-width:<\$maxwidth\$>px;min-width:270px;}\r\n.gb-align{<\$divalign\$>}\r\n.guestbook-table{box-shadow:0px 0px 0px transparent;-webkit-box-shadow:0px 0px 0px transparent;-moz-box-shadow:0px 0px 0px transparent;}\r\n#ie8 .guestbook-table, #ie7 .guestbook-table{border:0;}\r\n.name{max-width:46%;min-width:42%;float:left;padding-top:0;padding-left:8px;}\r\n#ie7 .name{padding-top:8px;}\r\n.icos{width:22%;float:left;text-align:center;margin-top:22px;}\r\n.reply{text-align:right;padding-top:5px;padding-right:8px;}\r\n#ie7 .icos, #ie7 .reply{margin-top:0;}\r\n.post{padding:15px 8px 15px 8px;}\r\n.red{color:#ff6600;}\r\n.this-page,.navi-page:link,.navi-page:visited{color:#ffffcc;}.navi-page:hover,.navi-page:active{color:#ff9900;}\r\na:link, a:visited{color:#ffffcc;font-weight:bold;}a:active, a:hover{color:#cc0000;text-decoration:none;}\r\n.reply a{font-weight:normal;text-decoration:none;}\r\n@media(max-width:360px){.name,.reply{font-size:12px;}}');";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_template`;";
$query[] = "CREATE TABLE `" . $table . "_template` (`bgcolor` varchar(15) NOT NULL, `bgimage` varchar(100) NOT NULL, `fontcolor` varchar(15) NOT NULL, `html` text NOT NULL, `id` tinyint(3) NOT NULL AUTO_INCREMENT PRIMARY KEY, `image_email` varchar(25) NOT NULL, `image_homepage` varchar(25) NOT NULL, `name` varchar(25) NOT NULL, `divalign` varchar(35) NOT NULL, `tablewidth` smallint(4) NOT NULL, `tdcolor` varchar(15) NOT NULL, `td2color` varchar(15) NOT NULL) ;";

/// CLASSIC ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000',  
'<div class=\"myphpgb gb-align guestbook-table\">
<div class=\"ident\">
<div class=\"name\"><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span></div>
<div class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></div>
<div class=\"timeline\"><\$date\$> | <\$time\$></div>
<div class=\"break\"></div>
</div>
<div class=\"post\">
<\$ip\$><\$text\$><\$comment\$>
<div><\$quote_ico\$></div>
</div>
</div>', 
'1', 'emailxp.gif', 'homepagexp.gif', 'myPHP-GBook4_classic-R', 'margin-left:auto;margin-right:auto;', '480', '#f2f2f2', '#ffffff');";

/// TRANSP ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('transparent', '', '#000000', 
'<div class=\"myphpgb gb-align guestbook-table\">
<div class=\"name\">
Name: <strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span><br />
<span class=\"beitragnr\"><\$nr\$> <\$wh\$> <strong><\$date\$>, <\$time\$></strong></span>
</div>
<p class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
<hr class=\"fine break\" />
<div class=\"post\">
<\$ip\$><\$text\$><\$comment\$>
<div><\$quote_ico\$></div>
</div>
<hr class=\"fine\" /><hr class=\"fine\" />
</div>', 
'2', 'emailxp.gif', 'homepagexp.gif', 'myPHP-GBook4_transp-R', 'margin-left:auto;margin-right:auto;', '500', 'transparent', 'transparent');";

/// GRAY ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
'<div class=\"myphpgb gb-align guestbook-table\">
<div class=\"ident\">
<div class=\"name\"><strong><\$name\$></strong> <span class=\"nowrap\"><\$done\$> <\$date\$>, <\$time\$></span><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span></div>
<div class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></div>
</div>
<div class=\"break\"></div>
<hr />
<div class=\"post\">
<\$ip\$><\$text\$><\$comment\$>
<div><\$quote_ico\$></div>
</div>
</div>', 
'3', 'emailgrey.gif', 'homepagegrey.gif', 'myPHP-GBook4_gray-R', 'margin-left:auto;margin-right:auto;', '500', '#f2f2f2', '#f2f2f2');";

/// LEFT ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
'<div class=\"myphpgb gb-align guestbook-table\">
<div class=\"ident break\">
<div class=\"name\"><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span></div>
<div class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></div>
<div class=\"beitragnr\"><strong><\$nr\$>  # <\$id\$></strong><br /><span class=\"nowrap\"><\$date\$> | <\$time\$></span></div>
<div class=\"break\"></div>
</div>
<div class=\"post\">
<\$ip\$><\$text\$><\$comment\$>
<div><\$quote_ico\$></div>
</div>
</div>',
'4', 'emailnew.gif', 'homepage.gif', 'myPHP-GBook4_left-R', 'margin-left:auto;margin-right:auto;', '550', '#ededed', '#ffffff');";

/// RIGHT ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
'<div class=\"myphpgb gb-align guestbook-table\">
<div class=\"ident break\">
<p class=\"beitragnr nowrap\"><strong><\$nr\$>  # <\$id\$></strong><br /><\$date\$> | <\$time\$></p>
<p class=\"icos nowrap\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
<div class=\"name\"><br /><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span><br /><br /></div>
<div class=\"break\"></div>
</div>
<div class=\"post\">
<\$ip\$><\$text\$><\$comment\$>
<div><\$quote_ico\$></div>
</div>
</div>',
'5', 'emailnew.gif', 'homepage.gif', 'myPHP-GBook4_right-R', 'margin-left:auto;margin-right:auto;', '550', '#ededed', '#ffffff');";

/// BLACK ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('#000000', '', '#ffffff', 
'<div class=\"myphpgb gb-align guestbook-table\">
<div class=\"name\"><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span><br /><span class=\"beitragnr\"><strong><\$nr\$> # <\$id\$></strong> <\$wh\$> <\$date\$> | <\$time\$></span></div>
<p class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
<hr class=\"break\" />
<div class=\"post\">
<\$ip\$><\$text\$><\$comment\$>
<div><\$quote_ico\$></div>
</div>
</div>', 
'6', 'emailxp.gif', 'homepagexp.gif', 'myPHP-GBook4_black-R', 'margin-left:auto;margin-right:auto;', '550', 'transparent', 'transparent');";

/// COLOR ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
'<div class=\"myphpgb gb-align guestbook-table\">
<div class=\"ident\">
<div class=\"name\"><strong><\$id\$>. <\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span></div>
<div class=\"timeline\"><strong><\$date\$> | <\$time\$></strong></div>
</div>
<div class=\"break\"></div>
<hr class=\"fine\" />
<div class=\"post\">
<\$ip\$><\$text\$><\$comment\$>
<div class=\"icos\">
<div class=\"emhpicq\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></div>
<div class=\"quote-ico\"><\$quote_ico\$></div>
</div>
</div>
</div>', 
'7', 'emailnew.gif', 'homepage.gif', 'myPHP-GBook4_color-R', 'margin-left:auto;margin-right:auto;', '550', '#ff9900', 'transparent');";

/// WIDE ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('#ffffff', '', '#000000', 
'<div class=\"myphpgb gb-align guestbook-table\">
<table class=\"wide-table\" cellpadding=\"7\" cellspacing=\"0\" border=\"0\">
<tr>
<td align=\"left\" class=\"top\" rowspan=\"2\">
<div class=\"ident\">
<strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$origin\$></span><br />
<\$nr\$>  # <\$id\$><br />
<\$date\$> | <\$time\$>
<p><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
<\$ip\$></div>
</td>
<td align=\"left\" valign=\"top\" class=\"td-post\">
<div class=\"post\">
<\$text\$><\$comment\$>
</div>
</td>
</tr>
<tr><td align=\"right\" valign=\"bottom\" class=\"td-post\"><\$quote_ico\$></td></tr>
</table>
</div>', 
'8', 'emailnew.gif', 'homepage.gif', 'myPHP-GBook4_wide-R', 'margin-left:auto;margin-right:auto;', '650', '#f0f0f0', '#ffffff');";

/// BLOG ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('transparent', '', '#000000', 
'<div class=\"myphpgb gb-align guestbook-table entriecolor\">
<hr class=\"blog\" />
<p class=\"name\"><strong><\$name\$></strong><\$br\$><span class=\"origin\"><\$from\$><\$origin\$></span><br /><span class=\"beitragnr\"><strong><\$date\$>, <\$time\$></strong></span></p>
<p class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
<p class=\"quote-ico\"><\$quote_ico\$><br /><span class=\"beitragnr\"><\$nr\$> #  <\$id\$></span></p>
<div class=\"break\"></div>
<div class=\"post\">
<\$ip\$><\$text\$><\$comment\$>
</div>
<hr class=\"blog\" />
</div>',
'9', 'emailnew.gif', 'earth.png', 'myPHP-GBook4_blog-R', 'margin-left:auto;margin-right:auto;', '550', 'transparent', 'transparent');";

/// S-BLACK ok
$query[] = "INSERT INTO `" . $table . "_template` VALUES ('#000000', '', '#f3f3f3', 
'<div class=\"myphpgb gb-align guestbook-table\">
<hr class=\"white-fine\" />
<p class=\"name\"><strong><\$name\$><span class=\"origin\"><\$br\$><\$from\$><\$origin\$></span><br /><span class=\"beitragnr\"><\$date\$>, <\$time\$></span></strong></p>
<p class=\"icos\"><\$email_icon\$><\$homepage_icon\$><\$icq_icon\$></p>
<p class=\"reply\"><\$quote_ico\$><br /><span class=\"beitragnr\"><\$nr\$> #  <\$id\$></span></p>
<hr class=\"white-fine break\" />
<div class=\"break\"></div>
<div class=\"post\">
<\$ip\$><\$text\$><\$comment\$>
</div>
<hr class=\"white-fine\" />
</div>',
'10', 'emailnew.gif', 'earth.png', 'myPHP-GBook4_s-black-R', 'margin-left:auto;margin-right:auto;', '550', 'transparent', 'transparent');";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_ip_ban`;";
$query[] = "CREATE TABLE `" . $table . "_ip_ban` (
`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY,
`ip` varchar(40) NOT NULL,
`time` int(15) NOT NULL,
`type` varchar(5) NOT NULL);";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_statistic`;";
$query[] = "CREATE TABLE `" . $table . "_statistic` (
`date` varchar(15) NOT NULL,
`zeit` int(15) NOT NULL,
`hits` mediumint(7) NOT NULL,
`id` smallint(5) NOT NULL AUTO_INCREMENT PRIMARY KEY,
`visits` mediumint(7) NOT NULL) ;";

$query[] = "INSERT INTO `" . $table . "_statistic` VALUES ('".date("d.m.Y")."', '0', '0', '1', '0');";
 
$query[] = "DROP TABLE IF EXISTS `" . $table . "_smilies`;";
$query[] = "CREATE TABLE `" . $table . "_smilies` ( `id` smallint(5) NOT NULL AUTO_INCREMENT PRIMARY KEY, `name` varchar(15) NOT NULL, `bbcode` varchar(15) NOT NULL, `filename` varchar(20) NOT NULL, `width` tinyint(3) NOT NULL, `height` tinyint(3) NOT NULL) ;";

$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (1, 'smile', ':)', 'smile.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (2, 'sad', ':(', 'sad.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (3, 'angry', ':angry:', 'angry.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (4, 'big grin', ':D', 'biggrin.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (5, 'cool', ':cool:', 'cool.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (6, 'frown', ':frown:', 'frown.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (7, 'indifferent', ':-|', 'indifferent.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (8, 'oh', ':O', 'oh.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (9, 'oh well', ':-/', 'ohwell.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (10, 'tonque', ':P', 'tongue.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (11, 'wink', ';)', 'wink.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (12, 'glasses', '8)', 'glasses.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (13, 'love', ':love:', 'love.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (14, 'shoked', ':shoked:', 'shoked.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (15, 'devil', ':devil:', 'devil.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (16, 'kiss', ':kiss:', 'kiss.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (17, 'pirate', ':pirate:', 'pirate.gif', 15, 15);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (18, 'Daumen', ':pollex:', 'daumen.gif', 23, 20);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (19, 'Kaffee', ':kaffee:', 'kaffee.gif', 18, 18);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (20, 'Bier', ':beer:', 'beer.gif', 55, 18);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (21, 'Coke', ':coke:', 'coke.gif', 45, 20);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (22, 'lachen', ':laugh:', 'laugh.gif', 30, 18);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (23, 'Sex', ':s:e:x:', 'sex.gif', 76, 23);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (24, 'Chef', ':chef:', 'chef.gif', 23, 28);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (25, 'Affe', ':monkeyl:', 'monkey.gif', 21, 18);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (26, 'Cow', ':cow:', 'cow.gif', 18, 18);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (27, 'Schwein', ':pig:', 'pig.gif', 18, 18);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (28, 'Blume', ':flower:', 'blume.gif', 16, 16);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (29, 'like', ':like:', 'like.png', 23, 20);";
$query[] = "INSERT INTO `" . $table . "_smilies` VALUES (30, 'dislike', ':dislike:', 'dislike.png', 23, 20);";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_backup`;";
$query[] = "CREATE TABLE `" . $table . "_backup` (`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY, `dateiname` varchar(30) NOT NULL, `datum` varchar(10) NOT NULL, `uhrzeit` varchar(5) NOT NULL ) ;";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_badwords`;";
$query[] = "CREATE TABLE `" . $table . "_badwords` (`badword` varchar(30) NOT NULL, `id` smallint(5) NOT NULL AUTO_INCREMENT PRIMARY KEY ) ;";

$query[] = "INSERT INTO `" . $table . "_badwords` VALUES ('ficken', '1');";      
$query[] = "INSERT INTO `" . $table . "_badwords` VALUES ('titten', '2');"; 
$query[] = "INSERT INTO `" . $table . "_badwords` VALUES ('scheiß', '3');"; 
$query[] = "INSERT INTO `" . $table . "_badwords` VALUES ('hure', '4');"; 
$query[] = "INSERT INTO `" . $table . "_badwords` VALUES ('nutte', '5');"; 
$query[] = "INSERT INTO `" . $table . "_badwords` VALUES ('nigger', '6');"; 

$query[] = "DROP TABLE IF EXISTS `" . $table . "_forbidden_ip`;";
$query[] = "CREATE TABLE `" . $table . "_forbidden_ip` (`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY, `ip` varchar(40) NOT NULL, `datum` varchar(10) NOT NULL, `uhrzeit` varchar(5) NOT NULL, `www_time` int(11) NOT NULL, `no_del` tinyint(1) NOT NULL ) ;";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_spam`;";
$query[] = "CREATE TABLE `" . $table . "_spam` (`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY, `spamword` varchar(25) NOT NULL ) ;";

$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('1', 'viagra');";      
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('2', 'porn');"; 
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('3', 'erotik');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('4', 'sex ');"; 
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('5', 'massage');"; 
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('6', 'bitcoin');"; 
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('7', 'casino');"; 
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('8', 'mail.ru');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('9', 'yandex.ru');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('10', 'nice site');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('11', 'good site');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('12', 'good project');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('13', 'cool site');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('14', 'good design');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('15', 'perfectly site');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('16', 'very good internet site');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('17', 'beautiful website');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('18', 'like your site design');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('19', 'cheap goods');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('20', 'special offer');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('21', 'louis vuitton');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('22', 'cheap replica');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('23', 'designer watches');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('24', 'tramadol');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('25', 'alprazolam');";
$query[] = "INSERT INTO `" . $table . "_spam` VALUES ('26', 'amoxcillin');";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_pictures`;";
$query[] = "CREATE TABLE `" . $table . "_pictures` (`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, `ip` varchar(40) NOT NULL, `pic_name` varchar(20) NOT NULL UNIQUE, `width` smallint(5) NOT NULL, `height` smallint(5) NOT NULL, `title` varchar(60) NOT NULL, `date` varchar(10) NOT NULL, `time` varchar(5) NOT NULL) ;";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_upload`;";
$query[] = "CREATE TABLE `" . $table . "_upload` (
`id` tinyint(1) NOT NULL AUTO_INCREMENT PRIMARY KEY,
`max_filesize` tinyint(1) NOT NULL,
`max_width` smallint(2) NOT NULL,
`max_height` smallint(2) NOT NULL,
`jpg_quality` tinyint(1) NOT NULL,
`upload_max` tinyint(1) NOT NULL);";

$query[] = "INSERT INTO `" . $table . "_upload` VALUES ('1', '2', '460', '460', '75', '2');";      

$query[] = "DROP TABLE IF EXISTS `" . $table . "_upload_counter`;";
$query[] = "CREATE TABLE `" . $table . "_upload_counter` (`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY, `ip` varchar(40) NOT NULL, `upload_time` int(15) NOT NULL, `counter` tinyint(1) NOT NULL) ;";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_thankyou`;";
$query[] = "CREATE TABLE `" . $table . "_thankyou` (`id` tinyint(1) NOT NULL AUTO_INCREMENT PRIMARY KEY, `status` tinyint(1) NOT NULL, `thanks` text NOT NULL, `lang` varchar(3) NOT NULL, `noreply` varchar(50) NOT NULL) ;";

$query[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('1', '0', 'Lieber Gast,\r\n\r\nich möchte mich für Deinen Eintrag im Gästebuch von \"".hostname()."\" bedanken und hoffe, bald wieder etwas von Dir zu lesen.\r\n\r\nMit freundlichem Gruß\r\nAdministrator', 'de', '');";
$query[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('2', '0', 'Dear Guest,\r\n\r\nthank you for your entry in my guestbook on \"".hostname()."\".\r\n\r\nI hope I hear again from you soon!\r\n\r\nBest regards,\r\nAdministrator', 'en', '');";
$query[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('3', '0', 'Caro hóspede,\r\n\r\nquero agradecer-lhe pelo seu comentário feito no Livro de Visitas de \"".hostname()."\" e espero ler em breve, mais algo seu.\r\n\r\nCom os melhores cumprimentos,\r\no Administrador', 'pt', '');";
$query[] = "INSERT INTO `" . $table . "_thankyou` VALUES ('4', '0', 'Geachte gast,\r\n\r\nIk wil u bedanken voor uw vermelding in het gastenboek van \"".hostname()."\" en hopen binnenkort iets van je te lezen.\r\n\r\nMet vriendelijke groet\r\nAdministrateur', 'nl', '');";

$query[] = "DROP TABLE IF EXISTS `" . $table . "_login_counter`;";
$query[] = "CREATE TABLE `" . $table . "_login_counter` (`id` mediumint(7) NOT NULL AUTO_INCREMENT PRIMARY KEY, `login_time` int(15) NOT NULL, `counter` tinyint(1) NOT NULL, `login_code` varchar(32) NOT NULL) ;";

// End of Database entries
		
		$queries = count($query);

		$gbook = new mysqli($host, $username, $password, $database);
		$gbook->set_charset('utf8');

		if (!$gbook)
			{
				die('<p class="aligncenter">'.$imsg[28].' '.$host.'</p><p class="aligncenter" style="color:red">Connect Error ('.$gbook->connect_errno.')<br />'.$gbook->connect_error.'</p><p>&nbsp;</p>');
			}

		echo '<div class="aligncenter">'.($_GET['n'] * 25) . '% '.$imsg[27].'<br /></div>';
		
		$from = (isset($_GET['from'])) ? $_GET['from'] : 0;
		
		$fourth = floor($queries/4);
		
		$to = ($_GET['n'] == 4) ? $queries : ($fourth * $_GET['n']);
		
		for ($i = $from; $i < $to; $i++)
			{
				$gbook->query($query[$i]) or die("SQL Error = ".$gbook->error . "\n\t" . $query[$i]); 
			}
		flush();

		if ($i < $queries)
			{
				echo '<div class="aligncenter"><script type="text/javascript">window.location="./?action=install&step=2&URL=' . urlencode($_GET['URL']) . '&EMail=' . $_GET['EMail'] . '&APass=' . $_GET['APass'] . '&AName=' . $_GET['AName'] . '&Lang=' . $_GET['Lang'] . '&n=' . ($_GET['n'] + 1) . '&from=' . $i . '";</script></div>';
			}
		else
			{
				echo '<p class="aligncenter">'.$imsg[35].'</p><br />';
			
				echo '<p class="aligncenter"><a href="' . $_GET['URL'] . 'admin/admin.php" rel="external">'.$imsg[36].'</a>  '.$imsg[38].'  <a href="' . $_GET['URL'] . 'index.php" rel="external">'.$imsg[37].'</a></p><br />';
						
						
				echo '<iframe class="aligncenter" src="' . $_GET['URL'] . 'index.php" style="width:100%; height:500px;">
						<p class="aligncenter">
							'.$imsg[46].' <a href="' . $_GET['URL'] . 'index.php" rel="external">Guestbook Frontend</a>
						</p>
					</iframe>
					';
			

			}
			
		break;

		case 1:
			if(isset($_POST['language']) && $_POST['language'] != "" && ($_POST['language'] == "de" || $_POST['language'] == "en")){
				include("".$_POST['language'].".php");
			}
			else {
				include("de.php");
			}

			if(!extension_loaded('mysqli'))
				{
					die('<div class=\'aligncenter\'><p><strong style=\'color:red\'>'.$imsg[44].'</strong></p><p>'.$imsg[45].'</p></div>');
				}

			if ((isset($_POST['DBUser']) AND $_POST['DBUser'] == "") OR (isset($_POST['DBPass']) AND $_POST['DBPass'] == "") OR (isset($_POST['DBName']) AND $_POST['DBName'] == "") OR (isset($_POST['EMail']) AND $_POST['EMail'] == "") OR (isset($_POST['AName']) AND $_POST['AName'] == "") OR (isset($_POST['APass']) AND $_POST['APass'] == ""))
				{
					die('<div class=\'aligncenter\'>
					<p><strong style=\'color:red\'>'.$imsg[55].'</strong></p>
					<form action="'.getdomainpath().'install/index.php?action=install" name="send_lang" method="post">
						<p><button class="gb-button" name="send_lang" type="submit" title="'.$imsg[30].'" value="Installation">'.$imsg[30].'</button>
						<input type="hidden" name="language" value="'.$_POST['language'].'" /></p>
					</form>
					</div>');
				}

			$gbook = new mysqli($_POST['DBHost'], $_POST['DBUser'], $_POST['DBPass'], $_POST['DBName']);

			if ($gbook->connect_error)
				{
					die('<div class=\'aligncenter\'>
					<p><strong style=\'color:red\'>'.$imsg[28].' '.$host.' '.$imsg[29].'</strong></p>
					<p class=\'aligncenter\' style=\'color:red\'>Connect Error ('.$gbook->connect_errno.')<br />'.$gbook->connect_error.'</p>
					<p>&nbsp;</p>
					<form action="'.getdomainpath().'install/index.php?action=install" name="send_lang" method="post">
						<p><button class="gb-button" name="send_lang" type="submit" title="'.$imsg[30].'" value="Installation">'.$imsg[30].'</button>
						<input type="hidden" name="language" value="'.$_POST['language'].'" /></p>
					</form>
					</div>');
				}
	
			$cats = (isset($_POST['importcats'])) ? 1 : 0;
				
			echo "<div id=\"container_install\">
				<p class=\"aligncenter\"><strong>".$imsg[31].":</strong> ".$imsg[32]."<br />";
				
			$path = (!get_magic_quotes_gpc()) ? str_replace('\\', '\\\\', $_POST['mainpath']) : $_POST['mainpath'];
			
			(isset($_POST['timezone'])) ? ($_POST['timezone'] = $_POST['timezone']) : ($_POST['timezone'] = "");

			// generate config file
			$content = '<?php' . "\n";
			$content .= '/* ' . "\n";
			$content .= '    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose' . "\n";
			$content .= '    myPHP Guestbook was an open source project of Networkarea.ch' . "\n";
			$content .= ' ' . "\n";
			$content .= '    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de' . "\n";
			$content .= ' ' . "\n";
			$content .= '    Version 4.x (MySQLi) Copyright (C) 2014 - '.date("Y").' Wolfgang Leverberg, www.php-guestbook.de' . "\n";
			$content .= ' ' . "\n";
			$content .= '    This file is a part of myPHP Guestbook.' . "\n";
			$content .= '    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the' . "\n";
			$content .= '    GNU General Public License as published by the Free Software Foundation; either version 3 of the' . "\n";
			$content .= '    License, or (at your option) any later version.' . "\n";
			$content .= ' ' . "\n";
			$content .= '    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;' . "\n";
			$content .= '    without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.' . "\n";
			$content .= ' ' . "\n";
			$content .= '    See the GNU General Public License for more details.' . "\n";
			$content .= '*/ ' . "\n";
			$content .= ' ' . "\n";
			$content .= '$host	 = "' . $_POST['DBHost'] . '"; // database host' . "\n";
			$content .= '$database = "' . $_POST['DBName'] . '"; // database name' . "\n";
			$content .= '$username	 = "' . $_POST['DBUser'] . '"; // database username' . "\n";
			$content .= '$password = "' . $_POST['DBPass'] . '"; // database password' . "\n";
			$content .= '$table	= "' . $_POST['DBPrefix'] . '"; // database prefix' . "\n";
			$content .= '$url	= "' . getdomainpath() . '"; // domainpath' . "\n";		
			$content .= '$url02	= "' . hostname() . '"; // url to use by \'include\'' . "\n";		
			$content .= '$main_path	= "' . $path . '"; // absolute path' . "\n";
			$content .= '$timezone	= "' . $_POST['timezone'] . '"; // timezone for myPHP-Guestbook; an empty option uses the default system setting' . "\n";
			$content .= ' ' . "\n";
			$content .= '/*' . "\n";
			$content .= '    Installation data "' .date("D M j G:i:s T Y"). '" ' . "\n";	
			$content .= ' ' . "\n";	
			$content .= '    You can configure all others options in the admin-panel. As soon as' . "\n";
			$content .= '    the guestbook will be installed. You can define the username and' . "\n";
			$content .= '    the password during the installation.' . "\n";
			$content .= '*/' . "\n";
			$content .= '?>';
					
			$output = makeconfigfile($content, $path);
			
			if ($output)
				{
					$check = check_installation();
							
					if ($check)
						{
							echo '?action=install</a></p></div>';
						}
					
					echo ''.$imsg[33].' ';
					echo '
						<strong><a href="./index.php?action=install&step=2&URL=' . urlencode($_POST['URL']) . '&EMail=' . $_POST['EMail'] . '&AName=' . $_POST['AName'] . '&APass=' . $_POST['APass'] . '&Lang=' . $_POST['Lang'] . '&cats=' . $cats . '&n=1">'.$imsg[34].'</a></strong></p>';
					echo '
						</div>
						';
				}
			else
				{
					echo '<p class="aligncenter">'.$imsg[47].'</p>';
					echo '<p class="aligncenter"><textarea style="width:500px; height:500px;">
							'.$content.'
						</textarea></p>';
					echo '<p class="aligncenter">'.$imsg[48].'<strong><a href="./index.php?action=install&step=2&URL=' . urlencode($_POST['URL']) . '&EMail=' . $_POST['EMail'] . '&AName=' . $_POST['AName'] . '&APass=' . $_POST['APass'] . '&Lang=' . $_POST['Lang'] . '&cats=' . $cats . '&n=1">'.$imsg[34].'</a></strong></p>
						</div>
						';
				}
				
			break;
			
			default:
				$check = check_installation();
						
				if ($check)
					{
						echo '<div id="container_install">
							<p>&nbsp;</p>
							<p>Es scheint, dass bereits eine Installation des Gästebuchs existiert.</p>
							<p>Möchten Sie prüfen, ob ein <a href="https://www.php-guestbook.de/" rel="external">Upgrade</a> verfügbar ist?</p>
							<hr style="width:60%" />
							<p>It seems that already an installation of myPHP Guestbook exists.</p>
							<p>Would like you to check whether is there an <a href="https://www.php-guestbook.de/" rel="external">Upgrade</a>?</p>
							</div>';
					}
							
				echo show_config_table(true);
				
			break;
	}

?>