<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

$count_entries = "";
$url = "";
$host = "";
$username = "";
$password = "";
$database = "";

function getFiles($directory)
	{
		if ($dh = opendir($directory))
			{
				while (($file = readdir($dh)))
					{
						if ($file != "." && $file != ".." )
							{
								$files[] = $file;
							}
					}
				closedir($dh);
				return $files;
			}
	}
    
if(isset($_POST['send_lang']) && ($_POST['language'] == "de" || $_POST['language'] == "en")){
	include("".$_POST['language'].".php");
}
else {
	include("de.php");
}

$count_entries= "";
$date = date("m.d.y");
           
function getmainpath()
	{
		$path = getcwd();
		$path = str_replace('install', '', $path);
		return $path;
	}

function getdomainpath()
     {
          $scheme = (empty($_SERVER['HTTPS'])) ? 'http://' : 'https://';
          
          $path = '' . dirname($_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
          if (strlen($path) < 5)
                {
                     $path = '' . dirname($_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);
                }
          $path = str_replace('install', '', $path);
          $path = str_replace('//', '/', $path);
          $path = ''.$scheme.''.$path;

          return $path;
     }
     
function hostname()
     {
          $scheme = (empty($_SERVER['HTTPS'])) ? 'http://' : 'https://';

          $hostname = ''.$_SERVER['SERVER_NAME'];
          $hostname = ''.$scheme.''.$hostname.'/';

          return $hostname;
     }
     
/*     
function gbookfolder()
	{  
		$uri = getdomainpath();
		$pieces = parse_url($uri);
		$folder = $pieces['path'];
		$folder = str_replace('/', '', $folder);

        return $folder;
	}
*/
    
function makeconfigfile($contents, $main_path)
	{
		$filename = $main_path . 'includes/config.inc.php';
		$altfilename = $main_path . 'includes/config.inc.php.new';

		if (!file_exists($filename))
			{
				if (file_exists($altfilename))
					{
						rename($altfilename, $filename);
					}
				else
					{
						touch($filename);
					}
			}

		@chmod($filename, 0777);

		if (is_writable($filename))
			{
				if (!$handle = fopen($filename, 'w')) 
					{
						$return = false;
					}
				else
					{
						if (fwrite($handle, $contents) === false)
							{
								$return = false;
							}
						else
							{
								$return = true;
							}
					}
				fclose($handle);
			}
		else
			{
				$return = false;
			}
		return $return;
	}

function check_installation()
	{
		global $DBPrefix, $settings_version, $main_path;

		include '../includes/config.inc.php';
		
		if(extension_loaded('mysqli'))
			{
//				$gbook = new mysqli($host, $username, $password, $database);
		
				@mysqli_connect($DbHost, $DbUser, $DbPassword);
				@mysqli_select_db($DbDatabase);
		
				$DBPrefix = (isset($DBPrefix)) ? $DBPrefix : '';
			}
	}

function show_config_table($fresh = true)
	{
		$count_entries = "";		
		$url = "";
		$language = "";
		
		if(isset($_POST['send_lang']) && $_POST['language'] != "" && ($_POST['language'] == "de" || $_POST['language'] == "en")){
			include("".$_POST['language'].".php");
			$language = $_POST['language'];
		}
		else {
			include("de.php");
		}

		$main_path = getmainpath();

		$data = '<div id="container_install">';
		$data .= '<form name="form1" method="post" action="./?action=install&#38;step=1">';
		$data .= '<table cellspacing="1" border="1" style="border-collapse:collapse;width:800px" cellpadding="6">';
		$data .= '	<tr>';
		$data .= '		<td style="width:160px">'.$imsg[1].'</td>';
		$data .= '		<td style="width:150px"><input type="text" name="URL" id="textfield" value="' . getdomainpath() . '"></td>';
		$data .= '		<td rowspan="2">'.$imsg[3].'<br /></td>';
		$data .= '	</tr>';
		$data .= '	<tr>';
		$data .= '		<td>'.$imsg[2].'</td>';
		$data .= '		<td><input type="text" name="mainpath" id="textfield" value="' . $main_path . '"></td>';
		$data .= '	</tr>';
		$data .= '	<tr>';
		$data .= '		<td>'.$imsg[53].'</td>';
		$data .= '		<td>';
		$data .= '			<select size="1" width="100" name="timezone" type="text" id="textfield">';
		$data .= '				<option selected="selected" value="Europe/Berlin">Deutschland</option>';
		$data .= '				<option value="Europe/Vienna">Österreich</option>';
		$data .= '				<option value="Europe/Zurich">Schweiz</option>';
		$data .= '				<option value="Europe/Amsterdam">BeNeLux</option>';
		$data .= '				<option value="Europe/Rome">Italien</option>';
		$data .= '				<option value="Europe/Madrid">Spanien</option>';
		$data .= '				<option value="Europe/Lisbon">Portugal</option>';
		$data .= '				<option value="Europe/London">England</option>';
		$data .= '				<option value="Europe/Dublin">Irland</option>';
		$data .= '				<option value="Europe/Paris">Frankreich</option>';
		$data .= '				<option value="Europe/Copenhagen">Dänemark</option>';
		$data .= '				<option value="Europe/Oslo">Norwegen</option>';
		$data .= '				<option value="Europe/Stockholm">Schweden</option>';
		$data .= '				<option value="Europe/Helsinki">Finnland</option>';
		$data .= '				<option value="Europe/Warsaw">Polen</option>';
		$data .= '				<option value="Europe/Tallinn">Estland</option>';
		$data .= '				<option value="Europe/Vilnius">Littauen</option>';
		$data .= '				<option value="Europe/Riga">Lettland</option>';
		$data .= '				<option value="Europe/Prague">Tschechien</option>';
		$data .= '				<option value="Europe/Bratislava">Slowakei</option>';
		$data .= '				<option value="Europe/Budapest">Ungarn</option>';
		$data .= '				<option value="Europe/Belgrade">Serbien</option>';
		$data .= '				<option value="Europe/Zagreb">Kroatien</option>';
		$data .= '				<option value="Europe/Sarajevo">Bosnien</option>';
		$data .= '				<option value="Europe/Bucharest">Rumänien</option>';
		$data .= '				<option value="Europe/Athens">Griechenland</option>';
		$data .= '				<option value="Europe/Nicosia">Zypern</option>';
		$data .= '				<option value="Europe/Istanbul">Türkei</option>';
		$data .= '				<option value="">andere/other</option>';
		$data .= '			</select>';
		$data .= '		</td>';
		$data .= '		<td>'. $imsg[54].'</td>';
		$data .= '	</tr>';
		$data .= '	<tr>';
		$data .= '		<td>'.$imsg[4].'</td>';
		$data .= '		<td><input type="text" name="DBHost" id="textfield" value="localhost"></td>';
		$data .= '		<td>'.$imsg[5].'</td>';
		$data .= '	</tr>';
		$data .= '	<tr>';
		$data .= '		<td>'.$imsg[6].'</td>';
		$data .= '		<td><input type="text" name="DBUser" id="textfield"></td>';
		$data .= '		<td rowspan="3">'.$imsg[9].'</td>';
		$data .= '	</tr>';
		$data .= '	<tr>';
		$data .= '		<td>'.$imsg[7].'</td>';
		$data .= '		<td><input type="password" name="DBPass" id="textfield"></td>';
		$data .= '  </tr>';
		$data .= '  <tr>';
		$data .= '		<td>'.$imsg[8].'</td>';
		$data .= '		<td><input type="text" name="DBName" id="textfield"></td>';
		$data .= '  </tr>';
		$data .= '  <tr>';
		$data .= '		<td>'.$imsg[10].'</td>';
		$data .= '		<td><input type="text" name="DBPrefix" id="textfield" value="guestbook"></td>';
		$data .= '		<td>'.$imsg[11].'</td>';
		$data .= '  </tr>';
		$data .= '  <tr>';	
		$data .= '		<td>'.$imsg[12].'</td>';
		$data .= '		<td>';
	  	$data .= '			<select size="1" width="100" name="Lang" type="text" id="textfield">';
		$data .= '				<option selected="selected" value="de">de</option>';
		$data .= '				<option value="at">at</option>';
		$data .= '				<option value="ch">ch</option>';
		$data .= '				<option value="en">en</option>';
//		$data .= '				<option value="nl">nl</option>';
		$data .= '				<option value="pt">pt</option>';
		$data .= '			</select>';
		$data .= '		</td>';
		$data .= '		<td>'.$imsg[13].'</td>';
		$data .= '	</tr>';
		$data .= '	<tr>';
		$data .= '		<td>'.$imsg[14].'</td>';
		$data .= '		<td><input type="text" name="EMail" id="textfield"></td>';
		$data .= '		<td>'.$imsg[15].'</td>';
		$data .= '	</tr>';
		$data .= '	<tr>';
		$data .= '		<td>'.$imsg[16].'</td>';
		$data .= '		<td><input type="text" name="AName" id="textfield" value="admin"></td>';
		$data .= '		<td>'.$imsg[17].'</td>';
		$data .= '	</tr>';
	 	$data .= '  <tr>';
	  	$data .= '		<td>'.$imsg[18].'</td>';
	  	$data .= '		<td><input type="password" name="APass" id="textfield"></td>';
	  	$data .= '		<td>'.$imsg[19].'</td>';
	  	$data .= '  </tr>';
		$data .= '	<tr>';
		$data .= '		<td colspan="2"><strong>'.$imsg[20].'</strong></td>';
		$data .= '		<td rowspan="9"></td>';
		$data .= '	</tr>';
		
		$directories = array('backup/','images/smilies/','img_guest/');
		
		umask(0);
		$passed = true;
		
		foreach ($directories as $dir)
			{
				$exists = $write = false;

				// Try to create the directory if it does not exist
				if (!file_exists($main_path . $dir))
					{
						@mkdir($main_path . $dir, 0755); //?? falls zwingend nötig 0777
						@chmod($main_path . $dir, 0755); //?? falls zwingend nötig 0777
					}

				// Now really check
				if (file_exists($main_path . $dir) && is_dir($main_path . $dir))
					{
						$exists = true;
					}

				// Now check if it is writable by storing a simple file
				$fp = @fopen($main_path . $dir . 'test_lock', 'wb');
				
				if ($fp !== false)
					{
						$write = true;
					}
				@fclose($fp);

				@unlink($main_path . $dir . 'test_lock');

				if (!$exists || !$write)
					{
						$passed = false;
					}

				$data .= '<tr>';
				$data .= '<td>' . $dir . ':</td>';
				$data .= '<td>';
				$data .= ($exists) ? '<strong style="color:green">'.$imsg[21].'</strong>' : '<strong style="color:red">'.$imsg[24].'<sup>1)</sup></strong>';
				$data .= ($exists && $write) ? ', <strong style="color:green">'.$imsg[22].'</strong>' : (($exists && !$write) ? ', <br /><strong style="color:red">'.$imsg[23].'<sup>1)</sup></strong>' : '');
				$data .= '</td>';
				$data .= '</tr>';
			}

		$directories02 = array('includes/config.inc.php');

		foreach ($directories02 as $dir02)
			{
				$write02 = $exists02 = true;
				
				if (file_exists($main_path . $dir02))
					{
						if (!@is_writable($main_path . $dir02))
							{
								$write02 = false;
							}
					}
					
				else
					{
						$write02 = $exists02 = false;
					}

				if (!$exists02 || !$write02)
					{
						$passed = false;
					}

				$data .= '<tr><td>' . $dir02 . ':</td>';
				$data .= '<td>';
				$data .= ($exists02) ? '<strong style="color:green">'.$imsg[21].'</strong>' : '<strong style="color:red">'.$imsg[24].'</strong>';
				$data .= ($write02) ? ', <strong style="color:green">'.$imsg[22].'</strong>' : (($exists02) ? ', <strong style="color:red">'.$imsg[23].'</strong>' : '');
				$data .= '</td>';
				$data .= '</tr>';
			}
			
		$data .= '<tr><td>'.$imsg[41].'</td>';
		$data .= '<td>';
		$data .= (extension_loaded('mysqli')) ? '<strong style="color:green">'.$imsg[21].'</strong>' : '<strong style="color:red">'.$imsg[24].'</strong>';
		$data .= '</td>';
		$data .= '</tr>';
		$data .= '<tr><td>'.$imsg[43].'</td>';
		$data .= '<td>';
		$data .= (extension_loaded('zlib')) ? '<strong style="color:green">'.$imsg[21].'</strong>' : '<strong style="color:red">'.$imsg[24].' <sup>3)</sup></strong>';
		$data .= '</td>';
		$data .= '</tr>';
		$data .= '<tr><td>'.$imsg[25].'</td>';
		$data .= '<td>';
		$data .= (extension_loaded('gd') && function_exists('gd_info')) ? '<strong style="color:green">'.$imsg[21].'</strong>' : '<strong style="color:red">'.$imsg[24].' <sup>4)</sup></strong>';
		$data .= '</td>';
		$data .= '</tr>';
		$data .= '<tr><td>'.$imsg[26].'</td>';
		$data .= '<td>';
		$data .= (extension_loaded('bcmath')) ? '<strong style="color:green">'.$imsg[21].'</strong>' : '<strong style="color:red">'.$imsg[24].'</strong>';
		$data .= '</td>';
		$data .= '</tr>';
		$data .= '</table>';
		$data .= '<br />';
		$data .= (!$exists) ? '<p class="aligncenter"><strong style="color:red"><sup>1)</sup> '.$imsg[51].'</strong></p>' : '';
		$data .= ($exists && !$write) ? '<p class="aligncenter"><strong style="color:red"><sup>1)</sup> '.$imsg[52].'</strong></p>' : '';
		$data .= (!extension_loaded('zlib')) ? '<p class="aligncenter"><strong style="color:red"><sup>3)</sup> '.$imsg[49].'</strong></p>' : '';
		$data .= (!extension_loaded('gd')) ? '<p class="aligncenter"><strong style="color:red"><sup>4)</sup> '.$imsg[50].'</strong></p>' : '';
		$data .= (extension_loaded('mysqli')) ? '<p class="aligncenter"><input type="submit" class="gb-button" value="'.$imsg[39].'"></p>' : '<p class="aligncenter"><strong style="color:red;font-size:18px">'.$imsg[42].'</strong></p>';
		$data .= '<input type="hidden" name="language" value="';
		$data .= (isset($_POST['language']) && ($_POST['language'] == "de" || $_POST['language'] == "en")) ? ''.$_POST['language'].'' : 'de';
		$data .= '" />';
	  	$data .= '</form>';
		$data .= '</div>';

		return $data;
	}

define('InInstaller', 1);

$main_path = getmainpath();

header('Content-Type: text/html;charset=utf-8');
header('X-Robots-Tag: noindex');
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");

echo"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
	<html xml:lang=\"$lang_short\" lang=\"$lang_short\" xmlns=\"http://www.w3.org/1999/xhtml\">
	<head>
		<meta http-equiv=\"content-type\" content=\"text/html;charset=$encoding\" />
		<meta name=\"Content-language\" content=\"$lang_short\" />
		<meta http-equiv=\"content-style-type\" content=\"text/css\" />
		<meta http-equiv=\"content-script-type\" content=\"text/javascript\" />
		<link href=\"".getdomainpath()."/install/style.css\" rel=\"stylesheet\" type=\"text/css\" media=\"screen\" />
		<style type=\"text/css\" media=\"all\"></style>
		<script type=\"text/javascript\">
			window.onload = externalLinks;function externalLinks(){if(!document.getElementsByTagName) return;var links,a,i;links = document.getElementsByTagName(\"a\");for(i=0;i<links.length;i++){a = links[i];if(a.getAttribute(\"rel\") && a.getAttribute(\"rel\").indexOf(\"external\")>-1){a.onclick = function(){window.open(this.href);return false}}}}
		</script>
		<meta name=\"robots\" content=\"noindex, nofollow\" />
		<meta name=\"author\" content=\"Wolfgang Leverberg - www.php-guestbook.de\" />
	</head>
	<body>
		<div id=\"container\">
			<a href=\"https://www.php-guestbook.de\" rel=\"external\" title=\"Link öffnet ein neues Fenster | Link opens a new window\"><img class=\"aligncenter\" src=\"".getdomainpath()."/install/myphpgb_installlogo.png\" alt=\"myPHP Guestbook $version\" border=\"0\" width=\"300\" height=\"34\" /></a>
			";

				if (isset($_GET['action']))
					{
						if (!preg_match("/^[_\a-z]*$/is", $_GET['action']))
							{
								require_once("intro.php");
							}
					}
				else
					{
						$_GET['action'] = "";
					}
					
				switch($_GET['action'])
					{
					    case "intro";
					    
						echo"<div style=\"text-align:center;\">
								<br /><strong>Bitte Sprache wählen: / Please choose language:</strong>&nbsp;
								<form style=\"float:right;position:relative;right:60px;\" method=\"post\" action=\"#\">
									<select class=\"select\" name=\"language\">
										<option"; if (isset($_POST['send_lang']) && $_POST['language'] == "de"){echo" selected=\"selected\"";} echo" value=\"de\">Deutsch</option>
										<option"; if (isset($_POST['send_lang']) && $_POST['language'] == "en"){echo" selected=\"selected\"";} echo" value=\"en\">English</option>
									</select> 
									<input type=\"submit\" class=\"ok-button\" name=\"send_lang\" value=\"OK\" /><input type=\"hidden\" name=\"send_language\" value=\"";
									
										if(isset($_POST['send_lang']) && ($_POST['language'] == "de" || $_POST['language'] == "en")){
											echo"".$_POST['language']."";
										}
										else {
											echo"de";
										}
										
										echo"\" />
									
								</form><br /><br /><hr /><br />
							</div>";
					    
				        require_once("intro.php");
				        break;
			
					    case "install";
				        require_once("install.php");
				        break;
			
					    case "update";
				        require_once("database.php");
				        break;
			
					    default:

    					echo"<div style=\"text-align:center;\">
								<br /><strong>Bitte Sprache wählen: / Please choose language:</strong>&nbsp;
								<form style=\"float:right;position:relative;right:60px;\" method=\"post\" action=\"#\">
									<select class=\"select\" name=\"language\">
										<option"; if (isset($_POST['send_lang']) && $_POST['language'] == "de"){echo" selected=\"selected\"";} echo" value=\"de\">Deutsch</option>
										<option"; if (isset($_POST['send_lang']) && $_POST['language'] == "en"){echo" selected=\"selected\"";} echo" value=\"en\">English</option>
									</select> 
									<input type=\"submit\" class=\"ok-button\" name=\"send_lang\" value=\"OK\" /><input type=\"hidden\" name=\"send_language\" value=\"";
									
										if(isset($_POST['send_lang']) && ($_POST['language'] == "de" || $_POST['language'] == "en")){
											echo"".$_POST['language']."";
										}
										else {
											echo"de";
										}
										
										echo"\" />
									
								</form><br /><br /><hr /><br />
							</div>";
					    
			    	    require_once("intro.php");
				        break;
					}

	echo'
		</div>
	</body>
	</html>';

?>