<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    03.07.2016
*/

	echo'<h1>'.$stmsg[0].'</h1>
		<p>&nbsp;</p>
		'.$stmsg[1].'
		<div class="aligncenter">
			<p><strong>'.$stmsg[2].'</strong></p>
			<p><strong>'.$stmsg[3].'</strong></p>
			<form action="index.php?action=install" name="send_lang" method="post">
				<p><input class="gb-button" type="submit" name="send_lang" title="'.$stmsg[5].'" value="'.$stmsg[5].'" />
				<input type="hidden" name="language" value="';
				
				if(isset($_POST['send_lang']) && $_POST['language'] != "" && ($_POST['language'] == "de" || $_POST['language'] == "en")){
					echo''.$_POST['language'].'';
				}
				else {
					echo'de';
				}
				
				echo'" /></p>
			</form>
			<p>&nbsp;</p>
			<p><strong>'.$stmsg[4].'</strong></p>
			<form action="index.php?action=update" method="post">
				<p><input class="gb-button" type="submit" name="update" title="'.$stmsg[6].'" value="'.$stmsg[6].'" />
				<input type="hidden" name="language" value="';
				
				if(isset($_POST['send_lang']) && $_POST['language'] != "" && ($_POST['language'] == "de" || $_POST['language'] == "en")){
					echo''.$_POST['language'].'';
				}
				else {
					echo'de';
				}
				
				echo'" /></p>
			</form>
		</div>
		<p>&nbsp;</p>';
?>
