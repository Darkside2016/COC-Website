<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

    // Variablen

    $version    = "V 4.6.3";
    $encoding   = "utf-8";
    $language   = "Deutsch";
    $lang_short = "de";
    $flag		= "de";
    
    //Intro
    
    $stmsg[0]  = 'Installations- und Update-Tool zur SQL-Datenbankanbindung<br />von myPHP Guestbook '.$version.'';
    $stmsg[1]  = '<p>Mit dieser Datei können Sie entweder eine komplette Erst- oder Neuinstallation des myPHP Guestbook vornehmen oder auch nur ein Update von einer der früheren Gästebuch-Versionen ab 3.0 auf die aktuellste Version '.$version.'</p>
<p>Bevor Sie starten, lesen und befolgen Sie bitte aufmerksam die Anweisungen in der ReadMe-Datei.</p>
<p>Für eine <strong>Erst- oder Neuinstallation</strong> sollten Sie alle Dateien aus dem von "www.php-guestbook.de" heruntergeladenen Gästebuchordner auf Ihren Webspace hochgeladen haben.</p>
<p>Für ein <strong>Update</strong> müssen <strong style="color:red">mit Ausnahme der Datei "config.inc.php"</strong> im Ordner "includes" ebenfalls alle anderen neuen Dateien aus dem Paket auf Ihren Webspace hochgeladen werden und die Tabellen in der Datenbank, wie sie für die Gästebuch-Versionen 3.x benötigt und angelegt wurden, müssen noch vorhanden sein.</p>';
    $stmsg[2]  = 'Bitte wählen Sie:';
    $stmsg[3]  = 'Ich möchte eine vollständige Neuinstallation des myPHP Guestbook '.$version.' vornehmen:';
    $stmsg[4]  = 'Meine Datenbank ist mindestens auf dem Stand von einer der Versionen 3.x.<br />Ich möchte daher nur das Datenbank-Update auf Version '.$version.':';
    $stmsg[5]  = 'komplette Installation myPHP Guestbook '.$version.'';
    $stmsg[6]  = 'Datenbank-Update für myPHP Guestbook '.$version.'';
    $stmsg[7]  = '';
    $stmsg[8]  = '';
    $stmsg[9]  = '';
    $stmsg[10] = '';
        
    // Installer - Phrasen
    
    $imsg[0]  = 'myPHP Gästebuch-Installationstool';
    $imsg[1]  = 'URL';
    $imsg[2]  = 'Document Root';
    $imsg[3]  = 'Die URL & der Serverpfad Ihrer myPHP Guestbook Installation auf Ihrem Server.<br />Bitte so wie angezeigt belassen.';
    $imsg[4]  = 'Database Host';
    $imsg[5]  = 'Hostname Ihrer MySQL Datenbank.<br />Oft localhost, einige Hoster verwenden seperate Datenbankserver.<br />Tragen Sie hier den Datenbankserver ein, der Ihnen von Ihrem Hoster genannt wurde.';
    $imsg[6]  = 'Datenbank Benutzername';
    $imsg[7]  = 'Datenbank Passwort';
    $imsg[8]  = 'Datenbank Name';
    $imsg[9]  = 'Benutzername, Passwort und Datenbankname Ihrer Datenbank<br />(Ihr Hoster teilt Ihnen diese Daten mit.)';
    $imsg[10]  = 'Datenbank-Prefix';
    $imsg[11]  = 'Der Prefix der myPHP-Gästebuch-Tabellen in der Datenbank.';
    $imsg[12]  = 'Sprache';
    $imsg[13]  = 'Die von myPHP-Guestbook zu verwendende Sprache<br />(German, English, Portuguese).<br /><strong>Die hier getroffene Auswahl bestimmt für die restliche Installation die angezeigte Sprache (Deutsch - Englisch).</strong>'; 
//    $imsg[13]  = 'Die von myPHP-Guestbook zu verwendende Sprache<br />(German, English, Portuguese, Dutch).<br /><strong>Die hier getroffene Auswahl bestimmt für die restliche Installation die angezeigte Sprache (Deutsch - Englisch).</strong>'; 
    $imsg[14]  = 'E-Mail Adresse:';
    $imsg[15]  = 'Die Gästebuchadmin E-Mail Adresse';
    $imsg[16]  = 'Admin Benutzername:';
    $imsg[17]  = 'Ihr Admin Benutzername. <strong style="color:red;">Zur Sicherheit bitte individuell ändern!</strong>';
    $imsg[18]  = 'Admin Passwort';
    $imsg[19]  = 'Ihr Admin-Passwort.';
    $imsg[20]  = 'Ordner- und Dateitests:';
    $imsg[21]  = 'vorhanden';
    $imsg[22]  = 'beschreibbar';
    $imsg[23]  = 'nicht beschreibbar';
    $imsg[24]  = 'Nicht vorhanden';
    $imsg[25]  = 'GD Support:';
    $imsg[26]  = 'BC Math Support:';
    $imsg[27]  = 'Komplett';
    $imsg[28]  = 'Keine Verbindung zu ';
    $imsg[29]  = 'mit dem angegebenen Benutzernamen und Passwort.';
    $imsg[30]  = 'zurück';
    $imsg[31]  = 'Teil 1';
    $imsg[32]  = 'Schreibe Konfigurationsdatei und prüfe Datenbankverbindung...<br />';
    $imsg[33]  = ' <strong style="color:green; font-size:16px;">Erfolgreich!</strong><br /><br />Nun zu ';
    $imsg[34]  = ' Teil 2';
    $imsg[35]  = 'Die Installation war erfolgreich.<br /><strong>Löschen Sie jetzt aus Sicherheitsgründen den kompletten Ordner "install" von Ihrem Server.</strong>';
    $imsg[36]  = 'zum Admin-Control-Panel';
    $imsg[37]  = 'zum Gästebuch-Frontend';
    $imsg[38]  = 'oder';
    $imsg[39]  = 'Installieren';
    $imsg[40]  = 'Kann Datenbank nicht auswählen';
    $imsg[41]  = 'MySQLi Support:'; 
    $imsg[42]  = 'Installation abbrechen, die notwendige MySQLi-Erweiterung ist nicht verfügbar';
    $imsg[43]  = 'GZip Support';
    $imsg[44]  = 'Die notwendige MySQLi-Erweiterung konnte nicht festgestellt werden.';
    $imsg[45]  = 'Bitte prüfen Sie die Verfügbarkeit von MySQLi mit "phpinfo(INFO_MODULES)"';
    $imsg[46]  = 'Ihr Browser kann leider keine eingebetteten Frames anzeigen:<br />Sie können die eingebettete Seite über den folgenden Verweis aufrufen:';
    $imsg[47]  = 'Der Gästebuch-Installer kann das config-file nicht erstellen. Bitte geben Sie die notwendigen Daten händisch in die config.inc.php ein.';
    $imsg[48]  = 'Nachdem das erledigt ist, können Sie fortfahren mit ';
    $imsg[49]  = 'Das Zip-Modul scheint nicht verfügbar zu sein.<br />Die Installation kann trotzdem durchgeführt werden, jedoch werden BackUps nicht komprimiert.';
    $imsg[50]  = 'Das Modul GDLIB scheint nicht verfügbar zu sein.<br />Die Installation kann trotzdem durchgeführt werden, jedoch ist kein Foto-Upload mit automatischer Größenanpassung möglich.';
    $imsg[51]  = 'Bitte den/die Ordner aus dem Download-Paket per FTP hochladen.';
    $imsg[52]  = 'Lesen Sie bitte den Abschnitt: "Besondere Ordner-Rechte" in der beigefügten "ReadMe.pfd".';
    $imsg[53]  = 'Die Zeitzone Ihres<br />Internet-Auftritts';
    $imsg[54]  = 'Wählen Sie hier Ihr Heimatland aus, nach dessen Zeitzone dann die Einträge im Gästebuch gespeichert werden.<br /><br />Wegen Änderungen nach der Installation siehe die "ReadMe.pdf".';
    $imsg[55]  = 'Sie haben nicht alle Felder ausgefüllt';
    $imsg[56]  = '';
    $imsg[57]  = '';
            
    $emsg[0]   = 'Sie haben nicht alle Felder ausgefüllt';
    $fmsg[196] = 'Geben Sie nun Ihren Benutzername und Ihr Passwort an, mit dem Sie sich in Zukunft in das Admin-Control-Panel einloggen wollen.<br />Die E-Mail Adresse wird benötigt, damit Sie bei neuen Gästebucheinträgen oder Datei-Uploads benachrichtigt und BackUps übermittelt werden können.';


	//Database Update - Stand 4.6.2, 4.6.3
	
	$dbmsg[0]  = 'Ihre Datenbank ist jetzt auf dem Stand zur Nutzung für das Script myPHP Guestbook '.$version.'.';
	$dbmsg[1]  = 'Es ist ein Fehler aufgetreten.<br />Bitte nehmen Sie Kontakt mit mir auf: <a href="mailto:post@php-guestbook.de">post@php-guestbook.de</a>';
	$dbmsg[2]  = 'Datenbankerweiterung zum myPHP-Guestbook';
	$dbmsg[3]  = '<p>Dieses Script ist darauf abgestimmt, die Datenbank-Tabellen und deren Einträge, wie sie nach einer Installation von myPHP Guestbook <strong>ab</strong> einer der Versionen 3.x bestehen, auf '.$version.' zu ändern. <strong>Für die älteren Gästebuch-Versionen 1.x und 2.x ist das Script ungeeignet!</strong></p>';
	$dbmsg[4]  = '<p><strong>Wenn Sie bisher eine Version 4.6.1 oder kleiner genutzt haben:</strong> Mit diesem Script wird die Datenbank zu Ihrem Gästebuch erweitert. D.h. es werden sowohl zusätzliche Tabellen angelegt, wie auch schon vorhandene Tabellen neu geschrieben unter Zufügung weiterer Spalten. Bei einem Update einer Version kleiner als 4.6.0, werden der Tabelle mit den Gästebucheinträgen drei neue Spalten hinzugefügt, darüber hinaus bleibt sie in ihrer Struktur unverändert, sodass nach dem Update unter normalen Umständen alle bisherigen Einträge erhalten bleiben.</p>';
	$dbmsg[5]  = '<p>Der Eingriff in eine bestehende Datenbank birgt allerdings immer die potentielle Gefahr von Datenverlusten oder sonstiger Funktionsprobleme. Daher bitte unbedingt die "ReadMe"-Datei lesen und folgende Hinweise:</p>';
	$dbmsg[6]  = 'Ich übernehme keinerlei Gewähr für etwaige Datenverluste oder anderweitiger Funktionsstörungen durch Verwendung dieses Scripts, gleich welcher Art. Wer diesbezügliche Befürchtungen hat, sollte an dieser Stelle abbrechen und mit dem leben, was er derzeit hat!';
	$dbmsg[7]  = 'Das Script wurde mehrfach getestet und läuft unter PHP 5.5.x, PHP 5.6.x und PHP 7.0.x auf einem Apache bisher stets fehlerfrei.';
	$dbmsg[8]  = 'Um dennoch Vorsorge für alle Fälle zu treffen, bitte vor dem Start dieses Scripts zunächst ein BackUp der Gästebucheinträge fertigen und sicher abspeichern!';
	$dbmsg[9]  = 'Wer von seinem Provider z.B. myPHPAdmin, mySqlDumper oder ein ähnliches Programm zur Verfügung hat, sollte eine komplette Sicherungskopie der vorhandenen Datenbank anfertigen.';
	$dbmsg[10] = '';
	$dbmsg[11] = '<p>Schon mit dem Aufruf des Scripts wurde geprüft, ob die notwendige Datenbankverbindung hergestellt werden kann und ob in Ihrer PHP-Konfiguration die ebenso unabdingbare Erweiterung MySQLi verfügbar ist. Dabei ergab sich, dass ...</p>';
	$dbmsg[12] = '.. auf Ihrem Server die MySQLi-Erweiterung von PHP nicht verfügbar ist, die für eine Funktion der Gästebuch-Scripts zwingend erforderlich ist.';
	$dbmsg[13] = 'Bevor Sie das nicht mit Deinem Provider geklärt haben, müssen Sie daher an dieser Stelle abbrechen.';
	$dbmsg[14] = '.. MySQLi auf Ihrem Server verfügbar ist, aber ...';
	$dbmsg[15] = '.. keine Verbindung zur Datenbank besteht, das Update kann daher nicht ausgeführt werden.';
	$dbmsg[16] = 'Prüfen Sie die Datei "config.inc.php" im includes-Ordner.';
	$dbmsg[17] = '.. alles in Ordnung ist; die Datenbankverbindung konnte hergestellt werden und die automatische Überprüfung hat ergeben, dass auf Ihrem Server die MySQLi-Erweiterung von PHP verfügbar ist.';
	$dbmsg[18] = 'Vergewissern Sie sich nun, welche Version von <span style="font-style:italic;">myPHP Guestbook</span> Sie aktuell installiert haben und wählen Sie dann aus den verschiedenen Datenbank-Updates das von Ihnen benötigte aus. - Gehen Sie hierbei sorgfältig vor! Die Wahl eines "falschen" Datenbank-Updates kann zu Problemen führen! Insbesondere wenn Sie bereits eine Gästebuch-Version ab 4.4.0 oder höher installiert haben und jetzt fälschlicherweise eines der beiden ersten nachfolgenden Datenbank-Updates durchführen, die für die Gästebuch-Versionen bis 4.3. und kleiner bestimmt sind, würde dies u.a. zu einem Verlust sämtlicher Einträge in der Tabelle "_pictures" führen, in der die verlinkten Foto-Uploads erfasst werden.';
	$dbmsg[19] = 'Los geht\'s';
	$dbmsg[20] = 'Ich habe derzeit eine der myPHP Guestbook Versionen';
	$dbmsg[21] = 'Datenbank für myPHP Guestbook anpassen von';
	$dbmsg[22] = 'auf';
	$dbmsg[23] = 'Von den vorhandenen Tabellen werden gelöscht und neu geschrieben:';
	$dbmsg[24] = 'weitere Tabellen werden neu angelegt.';
	$dbmsg[25] = 'Von den vorhandenen Tabellen werden um neue Spalten erweitert:';
	$dbmsg[26] = 'In der Tabelle "*_entries" wird der Status der Einträge auf "1" gesetzt.';
	$dbmsg[27] = 'Die vorhandenen Einträge in der alten Tabelle "*_properties" für "Admin-Email", "Sprachauswahl", "Password" und "Username" werden übernommen, der Rest wird neu geschrieben.';
	$dbmsg[28] = 'Von den vorhandenen Einträgen in der Tabelle "*_properties" werden geändert: "Gästebuchname", "maximale Wortlänge", "Anzahl Links bei der Blätterfunktion" und die Überprüfung auf "Minimale/maximale Eintragslänge" wird aktiviert, die anderen Voreinstellungen bleiben erhalten.';
	$dbmsg[29] = 'bis';
	$dbmsg[30] = 'ab';
	$dbmsg[31] = 'installiert.<br />Ich möchte daher die Anpassungen vornehmen auf';
	$dbmsg[32] = 'Von den vorhandenen Einträgen in der Tabelle "*_properties" werden u.a. geändert: "Gästebuchname" und "maximale Wortlänge", die anderen Voreinstellungen bleiben erhalten.';
	$dbmsg[33] = 'Ich habe derzeit die myPHP Guestbook Version';
	$dbmsg[34] = 'Von den vorhandenen Einträgen in der Tabelle "*_properties" wird geändert: "Gästebuchname", die anderen Voreinstellungen bleiben erhalten.';
	$dbmsg[35] = 'Datenbank anpassen';
	$dbmsg[36] = 'Es ist ein Fehler aufgetreten.';
	$dbmsg[37] = 'Bitte nehmen Sie Kontakt mit mir auf';
	$dbmsg[38] = 'Ihre Datenbank ist jetzt auf dem Stand zur Nutzung für das Script myPHP Guestbook';
	$dbmsg[39] = 'Markieren Sie die von Ihnen augenblicklich installierte <span style="font-style:italic;">myPHP Guestbook</span> Version und klicken Sie anschließend auf den Button unten.';
	$dbmsg[40] = 'Sie haben keine Auswahl getroffen.';
	$dbmsg[41] = 'Zurück zur Startseite';
	$dbmsg[42] = 'Ich möchte auf '.$version.' updaten und habe derzeit folgende Version installiert:';
	$dbmsg[43] = 'Datenbank-Tabellen auf '.$version.' anpassen.';
	$dbmsg[44] = '<strong>Bitte beachten: Beim Update von V 4.6.2 auf '.$version.' wird dieses Script nicht benötigt, weil keine Änderungen an der Datenbank erforderlich sind.</strong>';
	$dbmsg[45] = '';
	
?>