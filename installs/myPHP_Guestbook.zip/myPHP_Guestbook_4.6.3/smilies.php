<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    06.02.2015
*/
    
    require_once("includes/functions.inc.php");

	$sql_properties = $gbook->query("SELECT `smilies`, `guestbook_status` FROM `".$table."_properties`");
	$properties    = $sql_properties->fetch_assoc();

    $count_entries = "";
    require_once("includes/lang.inc.php");

    $sql_smilies = $gbook->query("SELECT `bbcode`, `filename`, `height`, `name`, `width` FROM `".$table."_smilies` ORDER BY `id` ASC LIMIT 12,1000");

	header("Content-Type: text/html;charset=\"".$encoding."\"");
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Pragma: no-cache");
	header("X-Robots-Tag: noindex");

    echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
	<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"".$lang_short."\" lang=\"".$lang_short."\">
	<head>
	<meta http-equiv=\"content-type\" content=\"text/html;charset=".$encoding."\" />
	<meta name=\"viewport\" content=\"width=device-width\" />
	<link href=\"".$url."gbook.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
	<style type=\"text/css\">body{font-family:arial,Verdana,Helvetica;font-size:13px;color:#000000;background-color:#eeeeee;}.td02{background-color:#f9f9f9;}</style>
	<script language=\"javascript\">
		function resize() {
		    var innerWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
		    var innerHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
		    var targetWidth = 380;
		    var targetHeight = 750;
		    window.resizeBy(targetWidth-innerWidth, targetHeight-innerHeight);
		}
	</script>
	<title>".$fmsg[35]."</title>
	<meta name=\"robots\" content=\"noindex, nofollow\" />
	</head>
	<body onload=resize();>";
	
	if ($properties['smilies'] && $properties['guestbook_status'])
	    {
			echo"
			<div class=\"text-center\">
			".$fmsg[22]."
			<br />
			<table class=\"guestbook-table center\" style=\"width:180px\" border=\"0\" cellspacing=\"0\" cellpadding=\"7\">
			<tr>
			<td align=\"center\"><strong>".$fmsg[56]."</strong></td>
			<td align=\"center\"><strong>BBCode:</strong></td>
			</tr>";
		
		    while ($smilies = $sql_smilies->fetch_assoc()) {
				echo"<tr>
					<td align=\"center\" class=\"td02\">
					<img class=\"cursor\" src=\"".$url."/images/smilies/".$smilies['filename']."\" width=\"" .$smilies['width']."\" height=\"".$smilies['height']."\" alt=\"".$smilies['name']."\"  onclick=\"opener.insert(' ".$smilies['bbcode']." ','');window.close();\" />
					</td>
					<td align=\"center\" class=\"td02\"> ".$smilies['bbcode']."</td>
					</tr>";
		    }
		
			echo"</table>
			</div>";
		}
	else
		{
			echo"
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p class=\"text-center\"><strong>".$fmsg[336]."</strong></p>";
		}
		
	echo"
	</body>
	</html>";
?>