﻿Achtung!

Bei den Updates v.4.x wurden bisher nur die deutschen
("de.php", "at.php", "ch.php"), das englische ("en.php")
und seit 4.6.3 das portugiesische Sprachfile angepasst.

Bei den anderen Sprachfiles fehlen eine Reihe von Phrasen!

Wenn Sie eine Fremdsprache perfekt beherrschen und bei der Übersetzung
der Sprachdateien von „myPHP Guestbook“ in eine andere Sprache behilflich
sein möchten, kontaktieren Sie mich bitte unter post@php-guestbook.de.

If you would like to help to translate the linguistic files from
"myPHP Guestbook" from german to another foreign language, which you
have mastered, please contact me: post@php-guestbook.de.

WL