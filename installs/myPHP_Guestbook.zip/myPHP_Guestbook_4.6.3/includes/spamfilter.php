<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    Teile des Quellcodes des Spamfilters stammen von www.naturfotografie-digital.de/impressum/gaestebuch-spam-php-tipps.php

    08.10.2016
*/

	$ref = 1;	// Prüfung, ob die Gästebuch-Eintragsseite direkt oder über einen Link auf der eigenen Homepage aufgerufen wurde: => 1 für Prüfung aktiv; 0 für Prüfung deaktiviert 

	$filtered = 0;
	$gefiltert = "";
	$warning = "";
	$count_spamwords = 0;
	$count_http = 0;
	$count_www = 0;
	$count_both = 0;
	$hostname = $_SERVER['SERVER_NAME'];
	
	if($properties['no_spam_entries'])
		{
			//geposteten Beitrag aus allen Input- und Textfeldern aufbereiten
			$website = str_replace ("http://","", $_POST['homepage']);
			$eintrag = " ".$_POST['name']." ".$_POST['email']." ".$_POST['town']." ".$_POST['country']." ".$website." ".$_POST['icq']." ".$_POST['betreff']." ".$_POST['text']." ";
												
			//Sonderzeichen entfernen
			$erlaubte = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzÄÖÜßäöü 0123456789.";
												
			$anzahl = strlen($eintrag);
			
			for ($i=0; $i<$anzahl; $i++)
				{
					$zeichen = substr ( $eintrag, $i, 1 );
					$c= substr_count($erlaubte, $zeichen);
					
					if ( $c < 1 )
						{
							$eintrag = str_replace ($zeichen, " ", $eintrag);
						}
				}
												
			//Eintrag von aneinandergereihten Leerzeichen befreien
			while (substr_count ($eintrag, "  ") > 0)
				{
					$eintrag = str_replace ("  "," ", $eintrag);
				}
												
			//Spam-Wörter der Blacklist aus Datenbank auslesen
			$sql_select_spam = $gbook->query("SELECT spamword  FROM  ".$table."_spam");
							
			//Einträge auf Spam-Wörter durchsuchen und Anzahl der gefundenen hochzählen
			while ($blacklist = $sql_select_spam->fetch_assoc())
				{
					$spamword = $blacklist['spamword'];
					
					$count_spamwords = substr_count(strtolower($eintrag), $spamword, 0);

					if ($count_spamwords > 0)
						{
							$filtered = $filtered + $count_spamwords;
							$gefiltert = $gefiltert.$spamword."<br />"; //Liste der Wörter, die den Spammerkmalen entsprechen, zur ev. Ausgabe und Kontrolle
						}
				}
				
			if ($filtered > 0)
				{
					$warning .= "".$fmsg[252]."<br /><br />".$fmsg[253]."<br /><br />".$gefiltert."<br />".$fmsg[254]." -".$filtered."- <br /><br />";
				}
		}
		
	if((isset($_POST['repeat_email']) && $_POST['repeat_email']) OR (isset($_POST['website_url']) && $_POST['website_url'])) //verstecktes input-Feld ausgefüllt = Robot !
		{
			$filtered = $filtered + 5;
			$warning .= "".$fmsg[251]."<br /><br />";
		}
		

	//Prüfen, ob Eintragsseite über Link der Webseite aufgerufen wurde => ok  oder  Direktaufruf der Eintragsseite => Spam
	//Übertragung des Referrer im Browser deaktivierbar, kein absolut sicheres Merkmal, daher "nur" 3 Pkte.
	//Dieser Teil der Spam-Prüfung kann komplett abgeschaltet werden, wenn oben in diesem Script die Variable $ref auf "0" gesetzt wird.

	$insert_referrer = $_POST['woher'];

	if ($ref == 1)
		{
			if (substr_count($insert_referrer, $hostname) != 1)
				{
					$filtered = $filtered + 3;
					$warning .= "".$fmsg[278]."<br /><br />";
				}
		}

	if($properties['no_spam_links'])
		{
			//Textbeitrag auf Anzahl der eingestellten Links prüfen
			$count_http	= substr_count(strtolower($_POST['text']), 'http://', 0);
			$count_www 	= substr_count(strtolower($_POST['text']), 'www.', 0);
			$count_both	= substr_count(strtolower($_POST['text']), 'http://www.', 0);
		
			$count_links 	= $count_http + $count_www - $count_both;
			$max_links 		= $properties['max_links'];
			$spam_links 	= $count_links - $max_links;
			
			if ($count_links > $max_links)
				{
					$filtered = $filtered + $spam_links;
					$warning .= "".$fmsg[242]."".$spam_links."-.<br /><br />";
				}
		}

	//Textbeitrag auf Position eines eingefügten Links prüfen => wenn Link an erster Stelle: Spamverdacht!
	$findMe   = '[url=';
	$pos = stripos(($_POST['text']), $findMe);

	if ($pos === 0)
		{
	    	$filtered = $filtered + 1;
	    	$warning .= "".$amsg[182]."<br /><br />";
		}

	//Prüfung der Geschwindigkeit, in der ein Beitrag verfasst und abgesendet wurde
	$time_start = $_POST['startzeit'];
	$time_diff =  $time - $time_start;

	if ($time_diff == 0)
		{
			$time_diff = 0.1;
		}
	elseif ($time_diff < 0) //Schutz vor dem fälschlichem Verwerfen eines Beitrags nach preview
		{
			$time_diff = 300;
		}

	if ($time_diff < 4)	//Eintrag unter 4 Sekunden = Robot !
		{
			$filtered = $filtered + 5;
			$warning .= "".$fmsg[243]."<br /><br />";
		}
		
	elseif ($time_diff >= 4 AND $time_diff < 9)	//Eintragsdauer mind. 4 aber weniger als 9 Sekunden = Robot ?
		{
			$filtered++;
			$warning .= "".$fmsg[244]."<br /><br />";
		}

	if ($time_diff > 3600)	//Eintrag mehr als 1 Stunde = geduldiger Robot ?
		{
			$filtered++;
			$warning .= "".$fmsg[245]."<br /><br />";
		}

	$gesamteintr = $_POST['name'].$_POST['town'].$_POST['country'].$_POST['email'].$_POST['homepage'].$_POST['icq'].$_POST['betreff'].$_POST['text']; //Anzahl aller Tastenanschläge

	$laenge_eintrag = strlen($gesamteintr); 		//Anschläge
	$chars_per_second= $laenge_eintrag/$time_diff; 	//Anschl. pro Sekunde

	if ($chars_per_second > 30) //mehr als 30 Zeichen pro Sekunde getippt = Robot ?
		{
			$filtered++;
			$warning .= "".$fmsg[246]."<br /><br />".$fmsg[247]." ".$time_diff." ".$fmsg[248]."<br />".$fmsg[249]." ".$laenge_eintrag."<br />".$fmsg[250]." ".$chars_per_second."<br /><br />";
		}

?>