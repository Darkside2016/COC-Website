<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    02.01.2015
*/

    $time = time();
    $date = date("d.m.Y", $time);
    $del  = $time-($properties['statistic_ban']*60);

	$tag_ablauf = substr ($date, 0, 2);
	$monat_ablauf = substr ($date, 3, 2);
	$jahr_ablauf = substr ($date, 6, 4);
	$timestamp_ablauf = mktime(0,0,0,$monat_ablauf,$tag_ablauf,$jahr_ablauf);

    $gbook->query("DELETE FROM ".$table."_ip_ban WHERE time <= '$del' AND type='stats'");

    $sql_check_date = $gbook->query("SELECT date FROM `".$table."_statistic` WHERE `date` = '$date' AND `id` != '1'");

    if ($sql_check_date->num_rows == 0) {
        $gbook->query("INSERT INTO ".$table."_statistic (id, date, zeit, visits, hits) VALUES ('','$date','$timestamp_ablauf','0','0')");
    }

    $gbook->query("UPDATE `".$table."_statistic` SET `hits` = `hits` + 1 WHERE `date` = '$date' AND `id` != '1'");
    $gbook->query("UPDATE `".$table."_statistic` SET `hits` = `hits` + 1 WHERE `id` = '1'");

    $sql_select_ip = $gbook->query("SELECT `ip` FROM `".$table."_ip_ban` WHERE `ip` = '".$_SERVER['REMOTE_ADDR']."' AND `type` = 'stats'");

    if ($sql_select_ip->num_rows == 0) {
        $gbook->query("UPDATE `".$table."_statistic` SET `visits` = `visits` + 1 WHERE `date` = '$date' AND `id` != '1'");
        $gbook->query("UPDATE `".$table."_statistic` SET `visits` = `visits` + 1 WHERE `id` = '1'");
        $gbook->query("INSERT INTO ".$table."_ip_ban (ip, time, type) VALUES ('".$_SERVER['REMOTE_ADDR']."', '$time', 'stats')");
   }

?>
