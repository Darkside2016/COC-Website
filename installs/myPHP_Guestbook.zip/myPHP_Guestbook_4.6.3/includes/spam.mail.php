<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    08.10.2016
*/

	$adminmail['name'] 		= noInjektion($_POST['name']);
	$adminmail['email'] 	= noInjektion($_POST['email']);
	$adminmail['homepage'] 	= noInjektion($_POST['homepage']);
	$adminmail['icq'] 		= noInjektion($_POST['icq']);
	$adminmail['betreff'] 	= noInjektion($_POST['betreff']);

	$adminmail['name'] 		= htmlspecialchars(strip_tags($adminmail['name']), ENT_QUOTES);
	$adminmail['email'] 	= htmlspecialchars(strip_tags($adminmail['email']), ENT_QUOTES);
	$adminmail['town']	 	= htmlspecialchars(strip_tags($_POST['town']), ENT_QUOTES);
	$adminmail['country'] 	= htmlspecialchars(strip_tags($_POST['country']), ENT_QUOTES);
	$adminmail['homepage'] 	= htmlspecialchars(strip_tags($adminmail['homepage']), ENT_QUOTES);
	$adminmail['icq'] 		= htmlspecialchars(strip_tags($adminmail['icq']), ENT_QUOTES);
	$adminmail['betreff'] 	= htmlspecialchars(strip_tags($adminmail['betreff']), ENT_QUOTES);

	$adminmail['text']		= htmlentities($_POST['text'], ENT_QUOTES, "UTF-8");
	$adminmail['text'] 		= nl2br($adminmail['text']);				
	$adminmail['text'] 		= strip_tags($adminmail['text'], "<br /><br><br/>");

	mt_srand((double)microtime()*1000000);
	$activation_code     = mt_rand(1000000,9999999);
	$activation_hashcode = md5($activation_code);
						
	($properties['check_email'] != 4) ? $email_text = "".$fmsg[8]." ".$adminmail['email']."<br />" : $email_text = "";
	($properties['check_town'] == 0) ? $town_text = "".$fmsg[346]." ".$adminmail['town']."<br />" : $town_text = "";
	($properties['check_country'] == 0) ? $country_text = "".$fmsg[347]." ".$adminmail['country']."<br />" : $country_text = "";
	($properties['check_homepage'] == 0) ? $hp_text = "".$fmsg[9]." ".$adminmail['homepage']."<br />" : $hp_text = "";
	($properties['check_icq'] == 0) ? $icq_text = "".$fmsg[229]." ".$adminmail['icq']."<br />" : $icq_text = "";

	$header  = "MIME-Version: 1.0\n";
	$header .= "Content-type: text/html; charset=utf-8\n";
	$header .= "Content-Transfer-Encoding: 8bit\n";
	$header .= "X-Mailer: PHP\n";
	$header .= "From: \"".$properties['guestbook_title']."\" <".$properties['admin_email'].">\n";
											
	if ($properties['notification_entries'] == 1 OR $properties['thanks_email'] == 1 OR $filtered > 0)
		{
			// Wenn die Option "E-Mail bei neuem Eintrag an Admin" aktiviert ist **ODER** Spammerkmale festgestellt wurden => dann weiter prüfen ... 
			if ($properties['notification_entries'] == 1 OR $filtered > 0)
				{
					// Wenn geschriebene Beiträge vom Admin freigegeben werden müssen und **KEINE** Spammerkmale festgestellt wurden
					// => dann Aktivierungslink zur Freigabe des gesperrten Eintrags **UND** zur Freigabe von eventuell hochgeladenen Bildern in einem Beitrag
					if ($properties['release_entries'] && $filtered < 1)
						{
							$release_text = "<br />-----------------------------------------------------------<br /><br />".$fmsg[236]."<br /><br />".$fmsg[237]."<br /><br />".$url."index.php?action=activate_entry&free_code=".$activation_hashcode."";

							mail($properties['admin_email'], $fmsg[5], "".$fmsg[6]."<br /><br />".$fmsg[228]." ".date("d.m.Y").", ".date("H:i")."<br /><br />".$fmsg[7]." ".$adminmail['name']."<br />".$town_text."".$country_text."".$email_text."".$hp_text."".$icq_text."<br />".$fmsg[230]."<br />-----------------------------------------------------------<br />".$fmsg[313]." ".$adminmail['betreff']."<br /><br />".$adminmail['text']."<br />".$release_text."", $header);
						}

					// Wenn geschriebene Beiträge **NICHT** vom Admin freigegeben werden müssen und **KEINE** Spammerkmale ermittelt wurden **UND** die Anzeige von Grafiken und BBCodes aktiviert ist
					// => dann Aktivierungslink zur Freigabe von hochgeladenen Bildern in einem Beitrag
					// => UND Deaktivierungslink zur eventuellen Sperrung des bereits veröffentlichten gesamten Eintrags
					elseif (!$properties['release_entries'] && ($filtered < 1) && $properties['bbcode'] && $properties['images_in_entries'] && PIC_CHECK)
						{
							$release_text = "<br />-----------------------------------------------------------<br /><br />".$fmsg[319]."<br /><br />".$fmsg[320]."<br /><br />".$url."index.php?action=activate_entry&free_code=".$activation_hashcode."<br /><br />".$fmsg[241]."<br /><br />".$url."index.php?action=deactivate_entry&sperr_code=".$activation_hashcode."";

							mail($properties['admin_email'], $fmsg[5], "".$fmsg[6]."<br /><br />".$fmsg[228]." ".date("d.m.Y").", ".date("H:i")."<br /><br />".$fmsg[7]." ".$adminmail['name']."<br />".$town_text."".$country_text."".$email_text."".$hp_text."".$icq_text."<br />".$fmsg[230]."<br />-----------------------------------------------------------<br />".$fmsg[313]." ".$adminmail['betreff']."<br /><br />".$adminmail['text']."<br />".$release_text."", $header);
						}
						
					// Wenn geschriebene Beiträge **NICHT** vom Admin freigegeben werden müssen **UND** soviel Spammerkmale ermittelt wurden, dass der Eintrag sofort verworfen wird 
					// => dann Warnung vor Spamversuch, Eintrag verworfen, IP blockiert
					elseif ($filtered > 0 AND $filtered > ($properties['spam_marker']-1))
						{
							$release_text = "<br />-----------------------------------------------------------<br /><br />".$fmsg[238]." ".$filtered."<br /><br />".$warning."<br />".$fmsg[239]."";

							mail($properties['admin_email'], $fmsg[231], "".$fmsg[232]."<br /><br />".$fmsg[228]." ".date("d.m.Y").", ".date("H:i").", Absender-IP: ".$_SERVER['REMOTE_ADDR']."<br /><br />".$fmsg[7]." ".$adminmail['name']."<br />".$town_text."".$country_text."".$email_text."".$hp_text."".$icq_text."<br />".$fmsg[230]."<br />-----------------------------------------------------------<br />".$fmsg[313]." ".$adminmail['betreff']."<br /><br />".$adminmail['text']."<br />".$release_text."", $header);
						}
						
					// Wenn geschriebene Beiträge **NICHT** vom Admin freigegeben werden müssen, aber mindestens 1, jedoch **nicht** soviele Spammerkmale ermittelt wurden, dass der Eintrag sofort verworfen wird 
					// => dann Warnung vor **möglichem** Spam mit Aktivierungslink zu einem Eintrag;
					// => **FALLS** BBCodes und die Anzeige von Grafiken aktiviert sind, werden auch eventuell im Beitrag eingestellte Bilder freigeschaltet 
					elseif ($filtered > 0 AND $filtered < $properties['spam_marker'])
						{
							$release_text = "<br />-----------------------------------------------------------<br /><br />".$fmsg[238]." ".$filtered."<br /><br />".$warning."<br /><br />".$fmsg[240]."<br /><br />".$fmsg[237]."<br /><br />".$url."index.php?action=activate_entry&free_code=".$activation_hashcode."";

							mail($properties['admin_email'], $fmsg[233], "".$fmsg[234]."<br /><br />".$fmsg[228]." ".date("d.m.Y").", ".date("H:i").", ".$fmsg[235]." ".$_SERVER['REMOTE_ADDR']."<br /><br />".$fmsg[7]." ".$adminmail['name']."<br />".$town_text."".$country_text."".$email_text."".$hp_text."".$icq_text."<br />".$fmsg[230]."<br />-----------------------------------------------------------<br />".$fmsg[313]." ".$adminmail['betreff']."<br /><br />".$adminmail['text']."<br />".$release_text."", $header);
						}
						
					// Wenn geschriebene Beiträge **NICHT** vom Admin freigegeben werden müssen, auch **KEINE** Spammerkmale festgestellt wurden **UND ENTWEDER** die Anzeige von Grafiken und BBCodes **NICHT** aktiviert ist **ODER** hochgeladene Grafiken sofort freigegeben sind, der Beitrag aber trotzdem gesperrt werden soll
					// => Sperrlink zu einem neuen bereits veröffentlichten Eintrag
					else
						{
							$release_text = "<br />-----------------------------------------------------------<br /><br />".$fmsg[241]."<br /><br />".$url."index.php?action=deactivate_entry&sperr_code=".$activation_hashcode."";

							mail($properties['admin_email'], $fmsg[5], "".$fmsg[6]."<br /><br />".$fmsg[228]." ".date("d.m.Y").", ".date("H:i")."<br /><br />".$fmsg[7]." ".$adminmail['name']."<br />".$town_text."".$country_text."".$email_text."".$hp_text."".$icq_text."<br />".$fmsg[230]."<br />-----------------------------------------------------------<br />".$fmsg[313]." ".$adminmail['betreff']."<br /><br />".$adminmail['text']."<br />".$release_text."", $header);
						}
				}
				
			// Dankesmail an Gast, wenn in Konfig. aktiviert und Gast E-Mail-Adresse angegeben hat
			if ($properties['thanks_email'] == 1 AND $_POST['email'] != "")
				{
					$sql_select_text = $gbook->query("SELECT `thanks`, `noreply` FROM `".$table."_thankyou` WHERE `lang` = '".$lang_short."'");
					$select_text = $sql_select_text->fetch_assoc();

					($select_text['noreply'] != "") ? ($abs_thanks = $select_text['noreply']) : ($abs_thanks = $properties['admin_email']);

					$header02  = "MIME-Version: 1.0\n";
					$header02 .= "Content-type: text/html; charset=utf-8\n";
					$header02 .= "Content-Transfer-Encoding: 8bit\n";
					$header02 .= "X-Mailer: PHP\n";
					$header02 .= "From: \"".$properties['guestbook_title']."\" <".$abs_thanks.">\n";

					$no_code = array("<", ">");

					$guestmail = str_replace($no_code, "", $select_text['thanks']);
					$guestmail 	= nl2br($guestmail);				
					$guestmail 	= strip_tags($guestmail, "<br /><br><br/>");
					
					mail($_POST['email'], $fmsg[210], $guestmail, $header02);
				}
		}

?>