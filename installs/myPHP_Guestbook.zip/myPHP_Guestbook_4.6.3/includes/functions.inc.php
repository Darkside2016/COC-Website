<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x (MySQLi) Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.
    
	###################################################################################

	Die Funktion "shortWords" (Originalbezeichnung "MakeBreakable") stammt 
	mit freundlicher Genehmigung von Werner Rumpeltesz, <http://www.gaijin.at>,
	geändert/angepasst für das Programm myPHP Guestbook

    ###################################################################################

    06.02.2015
*/

// Settings
define('SPAM_PROTECT', true);		// Spamfilter aktivieren **EMPFOHLENE EINSTELLUNG!** (=> true) / deaktivieren (=> false)
define('PIC_CHECK', true);			// hochgeladene Fotos erst nach Freigabe durch Admin anzeigen **EMPFOHLENE EINSTELLUNG!** (=> true) / ohne Freigabe sofort anzeigen (=> false)

// Zeitzonen-Variable leeren (für Installationen bis v.4.5.5)
 $timezone = "";

// Konfigurationsfile includen
 require_once("config.inc.php");
 
// Verbindung zur Datenbank herstellen
 $gbook = new mysqli($host, $username, $password, $database);
 $gbook->set_charset('utf8');

// korrekte Zeitzone für Einträge im myPHP-Guestbook setzen; siehe "config.inc.php" (ab myPHP-Guestbook v.4.5.6 +)
// die Zeitzone muss durch PHP unterstützt werden, um z.B. durch die Funktion "date_default_timezone_set()" verarbeitet zu werden;
// für eine Liste unterstützter Zeitzonen siehe: <http://php.net/manual/de/timezones.php>
  function timezoneGBook()
 	{
        global $timezone;

		if ($timezone != "")
			{
				(function_exists('date_default_timezone_set')) ? (date_default_timezone_set($timezone)) : (ini_set('date.timezone', $timezone));
			}
	}

// Auslesen der css-Styles aus der Datenbank
 function getStyle()
    {
        global $gbook;
        global $default_style;
        global $template;
        global $table;
        
		$template['bgcolor']	= (isset($template['bgcolor'])) ? $template['bgcolor'] : '';
		$template['fontcolor']	= (isset($template['fontcolor'])) ? $template['fontcolor'] : '';
		$template['divalign']	= (isset($template['divalign'])) ? $template['divalign'] : '';
		$template['tablewidth']	= (isset($template['tablewidth'])) ? $template['tablewidth'] : '';
		$template['tdcolor']	= (isset($template['tdcolor'])) ? $template['tdcolor'] : '';
		$template['td2color']	= (isset($template['td2color'])) ? $template['td2color'] : '';

        $sql_style = $gbook->query("SELECT `name`, `style` FROM `".$table."_style` WHERE `id` = '$default_style'");
        $style = $sql_style->fetch_assoc();

		$style['style'] = str_replace("<\$bodycolor\$>", $template['bgcolor'], $style['style']);
		$style['style'] = str_replace("<\$fontcolor\$>", $template['fontcolor'], $style['style']);
		$style['style'] = str_replace("<\$divalign\$>", $template['divalign'], $style['style']);
		$style['style'] = str_replace("<\$maxwidth\$>", $template['tablewidth'], $style['style']);
		$style['style'] = str_replace("<\$topcolor\$>", $template['tdcolor'], $style['style']);
		$style['style'] = str_replace("<\$entriecolor\$>", $template['td2color'], $style['style']);

        echo $style['style'];
    }

// Auslesen der Filenamen eines Directories
 function getFiles($directory)
	{
		if ($dh = opendir($directory))
			{
				while (false !== ($file = readdir($dh)))
					{
						if ($file != "." && $file != ".." && $file != ".htaccess" && $file != "index.php" && $file != "ReadMe_Update_Sprachfiles.txt")
							{
								$files[] = $file;
							}
					}
					
				closedir($dh);
				return $files;
			}
	}

//Auslesen der vorhandenen Smilies aus der Datenbank
 function smilies(&$text_smilies)
    {
        global $gbook;
        global $table;
        global $url;
        
        $sql_smilies_function = $gbook->query("SELECT `bbcode`, `filename`, `height`, `name`, `width` FROM `".$table."_smilies`");

        while ($smilies_function = $sql_smilies_function->fetch_assoc()) {
                $text_smilies = str_replace($smilies_function['bbcode'], '<img src="'.$url.'images/smilies/'.$smilies_function['filename'].'" alt="'.$smilies_function['name'].'" width="'.$smilies_function['width'].'" height="'.$smilies_function['height'].'" />', $text_smilies);
        }
        return $text_smilies;
    }

// Badwordfilter
 function nobadwords(&$text_nobadwords)
	{
		global $gbook;
		global $table;
	
		$sql_nobadwords_function = $gbook->query("SELECT `badword` FROM `".$table."_badwords`");
	
		while ($nobadwords_function = $sql_nobadwords_function->fetch_assoc())
			{
				$length_badword 	= strlen($nobadwords_function['badword']);
				$censor				= str_repeat("*", $length_badword);
				$text_nobadwords  	= str_ireplace($nobadwords_function['badword'], $censor, $text_nobadwords);
			}
		return $text_nobadwords;
	}
    
// E-Mail Adressen in ASCII codieren
 function noSpam02(&$mail)
	{
         $content = trim($mail); 
         $encoded_content = (string)''; 
         for($i = 0; $i < strlen($content); $i++)
			{ 
            	$encoded_content .= '&#'.ord($content[$i]).';'; 
			} 
         return $encoded_content; 
	} 

// E-Mail Injektion unterbinden
 function noInjektion(&$mail)
    {
        return(str_replace(array("\\", "\\r", "\\n", "%OA", "%oa", "%OD", "%od",  "Content-Type:", "boundary", "content-transfer-encoding:", "mime-version:",  "BCC:", "bcc:", "CC:", "cc:", "&#", "reply-to:", "to:", "sender:", "from:"), "", $mail));
    }

 // Wortlänge prüfen und ggf. Leerzeichen einfügen
 function shortWords($text_short, $length, $split = ' ', $charset = 'UTF-8')
	{
		$result = '';
		$line = '';
		$count = 0;
		$wrappos = 0;
		$wrapcount = 0;
		$breakchars = " \r\n\t";
		$wrapchars = "-=,;!?:|]+/\\";
		$intag = false;
		$i = 0;
		
		$bbtag = array("[img]", "[/img]", "[url=", "[email=", "[zitat=",);
		$new_bbtag = array(" [img]", "[/img] ", " [url=", " [email=", " [zitat=",);

		$text_short	= str_replace($bbtag, $new_bbtag, $text_short);
		
		while ($i < mb_strlen($text_short, $charset))
			{
				$char = mb_substr($text_short, $i, 1, $charset);
			
				if ($char == '[')
					{
						$intag = true;
					}
			
				if (!$intag)
					{
						if (mb_strpos($breakchars, $char, 0, $charset) !== false)
							{
								$line .= $char;
								$count = 0;
								$wrappos = 0;
								$wrapcount = 0;
								$i++;
								
								continue;
							}
				
						if (mb_strpos($wrapchars, $char, 0, $charset) !== false)
							{
								$wrappos = mb_strlen($line, $charset) + 1;
								$wrapcount = $count;
							}
					}
			
				if ($count >= $length)
					{
						if ($wrappos > 0)
							{
								$result .= mb_substr($line, 0, $wrappos, $charset).$split;
								$line = mb_substr($line, $wrappos, mb_strlen($line, $charset), $charset);
								$count -= $wrapcount + 1;
								$wrappos = 0;
					
							}
						else
							{
								$result .= $line.$split;
								$line = '';
								$count = 0;
								$wrappos = 0;
							}
					}

				if (!$intag) $count++;
			
				if ($char == ']')
					{
						$intag = false;
					}
			
				$line .= $char;
				$i++;
			}
		
		$result .= $line;
		
		return $result;	
	}

// Seed setzen für die Generierung einer Zufallszahl
function makeRandomName()
	{
		if (function_exists('gettimeofday()')) { 
			list($usec, $sec) = explode(' ', microtime());
			return (float) $sec + ((float) $usec * 100000);
		} else {
			$sec = time();
			return (float) ($sec * 0.333);
		}
	}

// Zeichen präparieren (im Backup)
 function prepare($add_character)
    {
        $add_character = addslashes($add_character);
        $add_character = str_replace("\015", "\\r", $add_character);
        $add_character = str_replace("\012", "\\n", $add_character);
        $add_character = str_replace("\011", "\\t", $add_character);

        return $add_character;
    }

// BBCode in HTML umwandeln
function bbcode(&$text)
     {
        global $gbook;
        global $fmsg;
        global $table;

        $allowed_url_characters = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ';
        $allowed_email_characters = 'ßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ';
        
		$text = preg_replace("#\[url=(http:\/\/|https:\/\/|ftp:\/\/)([a-zA-Z'.$allowed_url_characters.'0-9\.\/\?\=\-\_\#]{1,})\](.*?)\[/url\]#si", "<a title=\"".$fmsg[266]."\" href=\"\\1\\2\" rel=\"external\">\\3</a>", $text);
		$text = preg_replace("#\[email=([_a-zA-Z'.$allowed_email_characters.'0-9-]+(\.[_a-zA-Z'.$allowed_email_characters.'0-9-]+)*@([a-zA-Z'.$allowed_email_characters.'0-9-]+\.)+([a-zA-Z]{2,3}))\]#si", "<a title=\"".$fmsg[311]."\" href=\"mailto:\\1\">\\1</a>", $text);
	    $text = preg_replace("/\[color=red\](.*?)\[\/color\]/si", "<span class=\"red\">\\1</span>", $text);
	    $text = preg_replace("/\[color=green\](.*?)\[\/color\]/si", "<span class=\"green\">\\1</span>", $text);
	    $text = preg_replace("/\[color=blue\](.*?)\[\/color\]/si", "<span class=\"blue\">\\1</span>", $text);
	    $text = preg_replace("/\[color=yellow\](.*?)\[\/color\]/si", "<span class=\"yellow\">\\1</span>", $text);
	    $text = preg_replace("/\[color=orange\](.*?)\[\/color\]/si", "<span class=\"orange\">\\1</span>", $text);
	    $text = preg_replace("/\[color=lime\](.*?)\[\/color\]/si", "<span class=\"lime\">\\1</span>", $text);
	    $text = preg_replace("/\[color=pink\](.*?)\[\/color\]/si", "<span class=\"pink\">\\1</span>", $text);
	    $text = preg_replace("/\[color=brown\](.*?)\[\/color\]/si", "<span class=\"brown\">\\1</span>", $text);
	    $text = preg_replace("/\[color=gray\](.*?)\[\/color\]/si", "<span class=\"gray\">\\1</span>", $text);
        $text = preg_replace("/\[size=8\](.*?)\[\/size\]/si", "<span class=\"size-8\">\\1</span>", $text);
        $text = preg_replace("/\[size=10\](.*?)\[\/size\]/si", "<span class=\"size-10\">\\1</span>", $text);
        $text = preg_replace("/\[size=14\](.*?)\[\/size\]/si", "<span class=\"size-14\">\\1</span>", $text);
        $text = preg_replace("/\[size=16\](.*?)\[\/size\]/si", "<span class=\"size-16\">\\1</span>", $text);
        $text = preg_replace("/\[size=18\](.*?)\[\/size\]/si", "<span class=\"size-18\">\\1</span>", $text);
        $text = preg_replace("/\[size=20\](.*?)\[\/size\]/si", "<span class=\"size-20\">\\1</span>", $text);
        $text = preg_replace("/\[b\](.*?)\[\/b\]/si", "<strong>\\1</strong>", $text);
        $text = preg_replace("/\[i\](.*?)\[\/i\]/si", "<span class=\"italic\">\\1</span>", $text);
        $text = preg_replace("/\[u\](.*?)\[\/u\]/si", "<span class=\"underline\">\\1</span>", $text);
	    $text = preg_replace("/\[shadow\](.*?)\[\/shadow\]/si", "<span class=\"text-shadow\">\\1</span>", $text);
        $text = preg_replace("/\[cross\](.*?)\[\/cross\]/si", "<span class=\"text-crossed\">\\1</span>", $text);
	    $text = preg_replace("/\[justify\](.*?)\[\/justify\]/si", "<div class=\"text-justify\">\\1</div>", $text);
	    $text = preg_replace("/\[center\](.*?)\[\/center\]/si", "<div class=\"text-center\">\\1</div>", $text);
	    $text = preg_replace("/\[right\](.*?)\[\/right\]/si", "<div class=\"text-right\">\\1</div>", $text);
	    $text = preg_replace("/\[sup\](.*?)\[\/sup\]/si", "<sup> \\1</sup>", $text);
        $text = preg_replace("/\[quote\](.*?)\[\/quote\]/si", "<div class=\"zitat\"><p class=\"heading\">".$fmsg[172]."</p>\\1</div>", $text);
        $text = preg_replace("/\[code\](.*?)\[\/code\]/si", "<div class=\"code\"><p class=\"heading\">Code:</p><code>\\1</code></div>", $text);
        $text = preg_replace("/\[-\](.*?)\[\/-\]/si", "<li>\\1</li>", $text);
        $text = preg_replace("/\[list\](.*?)\[\/list\]/si", "<ul>\\1</ul>", $text);
        $text = preg_replace("/\[numlist\](.*?)\[\/numlist\]/si", "<ol>\\1</ol>", $text);
        $text = str_replace("[hr]", "<hr />", $text);
        $text = str_replace("[/color]", "", $text);
        $text = str_replace("[/size]", "", $text);

        return $text;
    }

// Anzeige hochgeladener Fotos in Beiträgen
function pictures(&$text_pictures)
	{
		global $gbook;
		global $table;
		global $url;
		
		$sql_pictures_function = $gbook->query("SELECT `pic_name`, `width`, `height`, `title` FROM `".$table."_pictures`");

		while ($pictures_function = $sql_pictures_function->fetch_assoc()) {
			$text_pictures = str_replace(array("[img]","[/img]"), "", $text_pictures);
			$text_pictures = str_replace($pictures_function['pic_name'], '<img class="centered" title="'.$pictures_function['title'].'" src="'.$url.'img_guest/'.$pictures_function['pic_name'].'" alt="'.$pictures_function['title'].'" width="'.$pictures_function['width'].'" height="'.$pictures_function['height'].'" />', $text_pictures);
		}
		
	    return $text_pictures;
	}

// Zitatfunktion
function quote(&$text)
    {
        global $gbook;
        global $table;
	
		$text = preg_replace("/\[zitat=(.*?)\]/si", "<div class=\"zitat\"><strong><span class=\"italic underline\">\\1:</span></strong><br /><br />", $text);
		$text = str_replace("[/zitat]", "</div>", $text);

        return $text;
    }


// E-Mail Adresse prüfen
function validate_mail($mail) {

	$email = htmlspecialchars($mail);
	$r = false;

	if(preg_match('/(.*?)\@(.*?)\.(\w){2,6}/i', $email)) {
		$split = explode('@', $email);
    	$split2 = explode('.', $split[1]);
    	if(preg_match('/([a-zäöü]){1,64}/i', $split2[0])) {
     		if(preg_match('/([a-z0-9äöü\!\"\$\&\/\(\)\?\~\#\+\.\:\_\-]+){1,64}[^\@]/i', $split[0])) {
      			$MXCheck = getmxrr($split[1], $mxhosts);
        		if(!empty($MXCheck)) {
          			$r = true;
        		}
      		}
    	}
	}
	return $r;
}

// URL (nur) auf korrekte Syntax prüfen
function validate_url($domainname)
	{
	    $domainname = trim($domainname);
			
	    if(preg_match('%^(?:(?:https?)://)(?:\S+(?::\S*)?@|\d{1,3}(?:\.\d{1,3}){3}|(?:(?:[a-z\d\x{00a1}-\x{ffff}]+-?)*[a-z\d\x{00a1}-\x{ffff}]+)(?:\.(?:[a-z\d\x{00a1}-\x{ffff}]+-?)*[a-z\d\x{00a1}-\x{ffff}]+)*(?:\.[a-z\x{00a1}-\x{ffff}]{2,6}))(?::\d+)?(?:[^\s]*)?$%iu', $domainname))
			{
            	return true;
        	}
		else
			{
            	return false;
        	}
	}

?>