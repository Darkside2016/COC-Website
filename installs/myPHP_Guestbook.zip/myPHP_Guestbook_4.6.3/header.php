<?php
/*
    myPHP Guestbook Copyright (C) 2003 - 2006  Claudio Pose
    myPHP Guestbook was an open source project of Networkarea.ch

    Version 3.x Copyright (C) 2011 - 2014 Christian Thomas, www.hostonline.de

    Version 4.x Copyright (C) 2014 - 2016 Wolfgang Leverberg, www.php-guestbook.de

    This file is a part of myPHP Guestbook.
    myPHP Guestbook is free software; you can redistribute it and/or modify it under the terms of the 
    GNU General Public License as published by the Free Software Foundation; either version 3 of the 
    License, or (at your option) any later version.

    myPHP Guestbook is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

    See the GNU General Public License for more details.

    01.05.2016
*/
    
    header("content-type: text/html; charset=\"".$encoding."\"" );
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Pragma: no-cache");
	echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
	<!--[if IE 9]><html id=\"ie9\" dir=\"ltr\" lang=\"".$lang_short."\"><![endif]-->
	<!--[if IE 8]><html id=\"ie8\" dir=\"ltr\" lang=\"".$lang_short."\"><![endif]-->
	<!--[if IE 7]><html id=\"ie7\" dir=\"ltr\" lang=\"".$lang_short."\"><![endif]-->
	<!--[if !(IE 7) | !(IE 8) | !(IE 9) ]><!-->
	<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"".$lang_short."\" lang=\"".$lang_short."\">
	<!--<![endif]-->
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=".$encoding."\" />
	<meta name=\"viewport\" content=\"width=device-width\" />
	<meta http-equiv=\"content-script-type\" content=\"text/javascript\" />
	<meta http-equiv=\"content-style-type\" content=\"text/css\" />
	<link href=\"".$url."gbook.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
	<style type=\"text/css\">
	";
	getStyle();
	echo "
	</style>
	<title>".$properties['guestbook_title']."</title>
	</head>
	";

?>